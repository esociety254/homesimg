-- MySQL dump 10.13  Distrib 8.4.9, for Linux (x86_64)
--
-- Host: localhost    Database: hukhbjpu_mh_portal_2026
-- ------------------------------------------------------
-- Server version	8.4.9

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `hukhbjpu_mh_portal_2026`
--


--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `role` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` (`id`, `username`, `password_hash`, `name`, `avatar`, `last_login`, `role`, `created_at`) VALUES (1,'odiedo','$2y$10$6PECAnuBBAoKJZWZfsngyu4xMm3ldrVtKS0YlrWxmeodgnuRtS9vm','Super Admin','&#x1F4CB;','2026-06-16 04:38:24','superadmin','2026-03-20 15:36:50'),(2,'listings','$2y$10$dw7QS786zr2vuREZCCDlteKkKnG7Xqh.h4CaTI6AztVQhque8Z43S','Listings Manager','&#x1F4CB;','2026-06-17 11:36:59','listings_manager','2026-04-22 05:10:00'),(3,'orders','$2y$10$l3PL.Uby6QPxLEicCM2p1.NyJLY0PkEcNNr5jqeGg0ZBBDDtGN9AG','Orders Manager','&#x1F4E6;','2026-05-22 10:27:29','orders_manager','2026-04-22 05:10:00'),(4,'social','$2y$10$ldJ2wp4J9dHQ1re2eGxOcuu2aw3cipWCS1tA6YnIA3t8LUbfZlLwa','Social Manager','&#x1F4F1;','2026-05-26 05:00:29','social_manager','2026-04-22 05:10:00');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `analytics_events`
--

DROP TABLE IF EXISTS `analytics_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `analytics_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `listing_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'view',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `listing_id` (`listing_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_events`
--

LOCK TABLES `analytics_events` WRITE;
/*!40000 ALTER TABLE `analytics_events` DISABLE KEYS */;
INSERT INTO `analytics_events` (`id`, `listing_id`, `event`, `created_at`) VALUES (1,'i54','view','2026-06-13 04:39:07'),(2,'i27','view','2026-06-13 04:39:10'),(3,'i54','view','2026-06-13 04:39:11'),(4,'i27','view','2026-06-13 04:39:20'),(5,'i53','view','2026-06-13 04:39:24'),(6,'i27','view','2026-06-13 04:39:25'),(7,'h78','view','2026-06-13 04:39:27'),(8,'i54','view','2026-06-13 04:39:30'),(9,'i27','view','2026-06-14 01:19:14'),(10,'i54','view','2026-06-14 01:19:16'),(11,'i82','view','2026-06-14 01:19:17'),(12,'h78','view','2026-06-14 01:19:18'),(13,'i76','view','2026-06-14 01:19:21'),(14,'i30','view','2026-06-14 01:19:25'),(15,'i48','view','2026-06-14 01:19:26'),(16,'h32','view','2026-06-14 01:19:27'),(17,'i103','view','2026-06-14 01:29:40'),(18,'i27','view','2026-06-14 01:29:49'),(19,'i103','view','2026-06-14 01:29:50'),(20,'i27','view','2026-06-14 01:29:56'),(21,'i53','view','2026-06-14 01:29:57'),(22,'h32','view','2026-06-14 01:30:00'),(23,'i107','view','2026-06-14 01:30:01'),(24,'i67','view','2026-06-15 09:54:34'),(25,'i48','view','2026-06-15 09:54:47'),(26,'i103','view','2026-06-15 09:54:51'),(27,'h78','view','2026-06-15 09:55:33'),(28,'i75','view','2026-06-15 09:55:35'),(29,'i98','view','2026-06-15 09:55:38'),(30,'i54','view','2026-06-15 09:55:43'),(31,'h32','view','2026-06-15 09:55:44'),(32,'i67','view','2026-06-15 09:55:46'),(33,'h78','view','2026-06-15 09:55:47'),(34,'e110','view','2026-06-16 15:09:33'),(35,'i6081','view','2026-06-16 15:09:36'),(36,'e111','view','2026-06-16 15:09:38'),(37,'h32','view','2026-06-16 15:09:39'),(38,'i6081','view','2026-06-17 19:09:34'),(39,'e110','view','2026-06-17 19:18:31'),(40,'i6081','view','2026-06-17 19:18:32'),(41,'i6017','view','2026-06-17 19:18:34'),(42,'h48','view','2026-06-17 19:18:35'),(43,'e111','view','2026-06-17 19:18:37'),(44,'i7021','view','2026-06-17 19:18:39'),(45,'i6082','view','2026-06-17 19:18:41'),(46,'h32','view','2026-06-17 19:18:43'),(47,'e113','view','2026-06-17 19:18:51'),(48,'e129','view','2026-06-17 19:18:55'),(49,'i6008','view','2026-06-17 19:18:56'),(50,'e129','view','2026-06-17 19:18:56'),(51,'e110','view','2026-06-17 19:19:02');
/*!40000 ALTER TABLE `analytics_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `slug` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `slug`, `name`, `icon`, `color`) VALUES (1,'houses','Homes','🏠','#6C5CE7'),(2,'food','Food','🍔','#FD79A8'),(3,'items','Shopping','🛋️','#00B894');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_verified` tinyint(1) NOT NULL DEFAULT '0',
  `otp` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_expires` datetime DEFAULT NULL,
  `session_token` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`),
  KEY `session_token` (`session_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inquiries`
--

DROP TABLE IF EXISTS `inquiries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inquiries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `listing_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `listing_id` (`listing_id`),
  CONSTRAINT `inquiries_ibfk_1` FOREIGN KEY (`listing_id`) REFERENCES `listings` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inquiries`
--

LOCK TABLES `inquiries` WRITE;
/*!40000 ALTER TABLE `inquiries` DISABLE KEYS */;
INSERT INTO `inquiries` (`id`, `listing_id`, `user_name`, `user_phone`, `message`, `created_at`) VALUES (1,'f68','Jane','043050069','Food order: ugali with beef stew, Chapati and Beans | Roadblock | mpesa','2026-06-12 10:50:33'),(2,'i77','Odiedo Paul','724818991','Cart: Cooking tool set, hiscence fridge, Hp laptop | cash','2026-06-13 04:05:23'),(3,'i103','Patelo','724818991','Cart: Curated mirror, hisense microwave | cash','2026-06-13 04:32:59'),(4,'i77','Patelo','724818991','Cart: Cooking tool set, utencils rack | cash','2026-06-13 20:22:01'),(5,'i54','Patelo','724818991','Direct buy — cash','2026-06-15 01:40:26'),(6,'i6085','Patelo','724818991','Cart: Dell Latitude 5400 | 00 | cash','2026-06-17 01:53:11'),(7,'i7027','Patelo','724818991','LIPA MDOGO MDOGO | Freq:Twice a week | 4 Weeks | Per:KSH 124 | Deposit:KSH 190 | Total:KSH 988 | Pay:mpesa | DELIVER AFTER FULL PAYMENT ONLY','2026-06-17 14:08:25');
/*!40000 ALTER TABLE `inquiries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listing_features`
--

DROP TABLE IF EXISTS `listing_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `listing_features` (
  `id` int NOT NULL AUTO_INCREMENT,
  `listing_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feature_text` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `listing_id` (`listing_id`),
  CONSTRAINT `listing_features_ibfk_1` FOREIGN KEY (`listing_id`) REFERENCES `listings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listing_features`
--

LOCK TABLES `listing_features` WRITE;
/*!40000 ALTER TABLE `listing_features` DISABLE KEYS */;
/*!40000 ALTER TABLE `listing_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listing_images`
--

DROP TABLE IF EXISTS `listing_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `listing_images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `listing_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `listing_id` (`listing_id`),
  CONSTRAINT `listing_images_ibfk_1` FOREIGN KEY (`listing_id`) REFERENCES `listings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listing_images`
--

LOCK TABLES `listing_images` WRITE;
/*!40000 ALTER TABLE `listing_images` DISABLE KEYS */;
INSERT INTO `listing_images` (`id`, `listing_id`, `image_url`, `sort_order`) VALUES (17,'i75','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778607324/jnwych62tlgquglasbr6.jpg',0),(39,'i76','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778746489/ymyfmmqj0mu1w1f1vpen.jpg',0),(43,'i53','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778742844/dz3f95alzydvqhsr2w1h.jpg',0),(44,'i98','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778672531/ypwbiebjyayabapf7w0j.jpg',0),(45,'i98','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778672973/cf2c6uughpdfei8paktw.jpg',1),(47,'i65','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778744402/zyx1msjwp0fdbwgych9h.jpg',0),(50,'i84','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778743860/oxfxvuj7jeq75m5tg3vm.jpg',0),(51,'i30','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778744253/zdbnsopzgptfbkujy9gx.jpg',0),(55,'i48','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779179554/ydtucjxezsckvyahbrdm.jpg',0),(56,'i48','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779179742/qkva8cwdupixemnjuuit.jpg',1),(58,'i54','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779271370/p9jdgawfckdp1fkblaew.jpg',0),(59,'i54','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779271406/b1w7bfmcqngvzxbl42vo.jpg',1),(77,'i27','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779887215/f8wz4axe4xwqmpq1f1wy.jpg',0),(78,'i27','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779887229/g1xnnkgjpctbdcvgwjxi.jpg',1),(79,'i27','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779887267/z9abpagi5no21nles5rz.jpg',2),(80,'f35','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1780745104/onlhununcrbhxxpsipge.jpg',0),(81,'f35','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1780745161/o9oeksuqrux4n83o09ie.jpg',1),(85,'f38','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1780925570/nmtuuhlxft6f2p68fd51.jpg',0),(89,'f54','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1780782252/knil0t8qxysmeybdk5yl.jpg',0),(90,'f103','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779319792/cvkuiy5yypikin2jvnqv.jpg',0),(91,'f103','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779319808/x2fo84osbpdafyhncpuc.jpg',1),(92,'f89','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778745278/zxzcvfbrqq4lscqa5uvw.jpg',0),(93,'f96','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781380107/jssxh3xrqgivgqjrzusc.jpg',0),(103,'i103','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779272428/jczk6jwdql5yzf4c4woe.jpg',0),(104,'i103','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779272444/hfdf9unpola9mltqdxv0.jpg',1),(105,'i103','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779272462/hgo7idycmohlesogymwd.jpg',2),(106,'i67','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778743980/x0mcma0x8gnos2kqbgcc.jpg',0);
/*!40000 ALTER TABLE `listing_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listings`
--

DROP TABLE IF EXISTS `listings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `listings` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seller_id` int DEFAULT NULL,
  `category_id` int NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `badge` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views` int DEFAULT '0',
  `rating` decimal(3,1) DEFAULT NULL,
  `prep_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_category` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `restaurant_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Links food menu item to a restaurant',
  `is_featured` tinyint(1) DEFAULT '0',
  `is_premium` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_views` (`views`),
  KEY `idx_category` (`category_id`,`is_active`),
  KEY `idx_featured` (`is_featured`,`is_active`),
  KEY `seller_id` (`seller_id`),
  KEY `idx_restaurant` (`restaurant_id`),
  CONSTRAINT `listings_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listings`
--

LOCK TABLES `listings` WRITE;
/*!40000 ALTER TABLE `listings` DISABLE KEYS */;
INSERT INTO `listings` (`id`, `seller_id`, `category_id`, `title`, `description`, `price`, `location`, `image_url`, `video_url`, `contact_phone`, `contact_name`, `is_active`, `badge`, `views`, `rating`, `prep_time`, `sub_category`, `restaurant_id`, `is_featured`, `is_premium`, `created_at`, `updated_at`) VALUES ('d101',1,3,'Modern Wall Clock','Minimalist metallic wall clock, silent movement.','1500','Malaba','https://images.pexels.com/photos/279618/pexels-photo-279618.jpeg',NULL,'0747501436','Kanji Decors',1,'Hot',121,4.8,NULL,'Wall Decor',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:39:52'),('d102',1,3,'Artificial Potted Plant','Lifelike indoor plant, low maintenance.','1200','Malaba','https://images.pexels.com/photos/1005058/pexels-photo-1005058.jpeg',NULL,'0747501436','Kanji Decors',1,'Popular',95,4.7,NULL,'Home Decor',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('d103',1,3,'Ceramic Vase Set','Elegant white ceramic set for fresh flowers.','2200','Malaba','https://images.pexels.com/photos/267586/pexels-photo-267586.jpeg',NULL,'0747501436','Kanji Decors',1,'Featured',80,4.9,NULL,'Home Decor',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('d104',1,3,'Luxury Throw Pillow Covers','Velvet soft cushion covers, set of 2.','850','Malaba','https://images.pexels.com/photos/276583/pexels-photo-276583.jpeg',NULL,'0747501436','Kanji Decors',1,'New',50,4.6,NULL,'Living Room',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('d105',1,3,'Table Lamp','Warm lighting with a modern wooden base.','2800','Malaba','https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg',NULL,'0747501436','Kanji Decors',1,'Featured',65,4.8,NULL,'Lighting',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('d106',1,3,'Wall Art Canvas','Abstract landscape print, large size.','3500','Malaba','https://images.pexels.com/photos/2372930/pexels-photo-2372930.jpeg',NULL,'0747501436','Kanji Decors',1,'Popular',45,4.7,NULL,'Wall Decor',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('d107',1,3,'Scented Candle Set','Aromatic soy candles, pack of 3.','1500','Malaba','https://images.pexels.com/photos/1581384/pexels-photo-1581384.jpeg',NULL,'0747501436','Kanji Decors',1,'Hot',111,4.9,NULL,'Home Decor',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:40:33'),('d108',1,3,'Decorative Mirror','Geometric gold-rimmed wall mirror.','4500','Malaba','https://images.pexels.com/photos/276566/pexels-photo-276566.jpeg',NULL,'0747501436','Kanji Decors',1,'Featured',30,4.8,NULL,'Wall Decor',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('d109',1,3,'Floating Wall Shelves','Set of 3, rustic finish for books/decor.','1800','Malaba','https://images.pexels.com/photos/1080696/pexels-photo-1080696.jpeg',NULL,'0747501436','Kanji Decors',1,'New',40,4.5,NULL,'Storage',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('d110',1,3,'Floor Carpet/Rug','Soft plush rug, perfect for living area.','5500','Malaba','https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',NULL,'0747501436','Kanji Decors',1,'Featured',70,4.8,NULL,'Flooring',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('d111',1,3,'Photo Frame Set','Display your memories, 5-piece gallery set.','2100','Malaba','https://images.pexels.com/photos/208661/pexels-photo-208661.jpeg',NULL,'0747501436','Kanji Decors',1,'New',26,4.6,NULL,'Wall Decor',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:40:13'),('d112',1,3,'Wall Clock - Pendulum','Classic design with a modern touch.','2500','Malaba','https://images.pexels.com/photos/279618/pexels-photo-279618.jpeg',NULL,'0747501436','Kanji Decors',1,'Popular',35,4.7,NULL,'Wall Decor',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('d113',1,3,'Handcrafted Statue','African abstract wooden sculpture.','3200','Malaba','https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg',NULL,'0747501436','Kanji Decors',1,'Featured',20,4.9,NULL,'Home Decor',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('d114',1,3,'Table Runner','Traditional pattern, high-quality fabric.','950','Malaba','https://images.pexels.com/photos/276551/pexels-photo-276551.jpeg',NULL,'0747501436','Kanji Decors',1,'Hot',55,4.7,NULL,'Dining',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('d115',1,3,'Curtain Tie-backs','Magnetic gold curtain holders, set of 2.','600','Malaba','https://images.pexels.com/photos/276566/pexels-photo-276566.jpeg',NULL,'0747501436','Kanji Decors',1,'New',15,4.5,NULL,'Home Decor',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('e101',NULL,3,'Samsung Galaxy A15 4G','Brand new Samsung Galaxy A15. 128GB storage, 4GB RAM, 50MP camera, 5000mAh battery. Original with full box and 1-year warranty.','KSH 18,500','Malaba Town','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'📱 New',312,NULL,NULL,'electronics',NULL,1,0,'2026-03-01 13:00:00','2026-06-17 01:47:36'),('e102',NULL,3,'Tecno Spark 20 Pro','Tecno Spark 20 Pro 256GB/8GB RAM. Dual SIM, 6.78\" display, 108MP camera, fast charging. Sealed box with warranty.','KSH 22,000','Malaba Town','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'📱 Popular',285,NULL,NULL,'electronics',NULL,0,0,'2026-03-02 14:00:00','2026-06-16 04:13:27'),('e103',NULL,3,'Infinix Hot 40i','Infinix Hot 40i 128GB, 6GB RAM. Android 13, 5000mAh battery, fingerprint sensor. New in sealed box.','KSH 13,500','Malaba Town','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'🔥 Budget',190,NULL,NULL,'electronics',NULL,0,0,'2026-03-03 15:00:00','2026-06-16 04:13:27'),('e104',NULL,3,'Oraimo 20,000mAh Power Bank','Oraimo PowerPillar 20000mAh power bank with dual USB output and LED indicator. Fast charging, compact design.','KSH 2,800','Malaba Town','https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'⚡ Fast Charge',220,NULL,NULL,'electronics',NULL,0,0,'2026-03-04 13:30:00','2026-06-16 04:13:27'),('e105',NULL,3,'Type-C Fast Charger 65W','65W GaN USB-C fast charger compatible with Samsung, Tecno, Infinix, laptops. Travel adapter included.','KSH 1,200','Malaba Town','https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,NULL,145,NULL,NULL,'electronics',NULL,0,0,'2026-03-05 14:00:00','2026-06-16 04:13:27'),('e106',NULL,3,'USB-C to USB-C Cable 1.5m','Premium braided USB-C cable supporting 65W fast charging and high-speed data transfer. 1.5 metre length.','KSH 450','Malaba Town','https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,NULL,88,NULL,NULL,'electronics',NULL,0,0,'2026-03-06 13:00:00','2026-06-16 04:13:27'),('e107',NULL,3,'Oraimo Smart Watch FreePods 4','Oraimo FreePods 4 TWS earbuds with active noise cancellation, 30hr battery life, IPX5 waterproof.','KSH 2,500','Malaba Town','https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'🎧 ANC',175,NULL,NULL,'electronics',NULL,1,0,'2026-03-07 15:00:00','2026-06-16 04:13:27'),('e108',NULL,3,'Smartwatch With Health Monitor','Smart fitness watch with heart rate, blood oxygen, sleep tracking, WhatsApp & call notifications. Compatible with Android & iOS.','KSH 3,200','Malaba Town','https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'⌚ Smart',155,NULL,NULL,'electronics',NULL,0,0,'2026-03-08 13:00:00','2026-06-16 04:13:27'),('e109',NULL,3,'Wireless Earbuds TWS','True wireless earbuds with charging case, 8 hours playtime, touch controls and crystal-clear call quality.','KSH 1,800','Malaba Town','https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,NULL,132,NULL,NULL,'electronics',NULL,0,0,'2026-03-09 12:00:00','2026-06-16 04:13:27'),('e110',NULL,3,'Syinix 32\" Smart TV Android','Syinix 32-inch Smart TV with Android OS, built-in WiFi, Netflix, YouTube. 2 HDMI ports, USB, remote control.','KSH 21,000','Malaba Town','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTC6gXW20HvrwVYzaS-F-gc4XJCpQpHgTgtHQ&s','','0743050069','Malaba Electronics Hub',1,'📺 Smart TV',267,NULL,NULL,'electronics',NULL,1,1,'2026-03-10 13:00:00','2026-06-17 19:19:02'),('e111',NULL,3,'Hisense 43\" 4K UHD TV','Hisense 43-inch 4K UHD Smart TV with Dolby Vision, Dolby Atmos, built-in Freeview and VIDAA OS.','KSH 38,500','Malaba Town','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781697676/pamnyp2voet8fsexctcf.jpg','','0743050069','Malaba Electronics Hub',1,'🔥 4K',199,NULL,NULL,'electronics',NULL,1,1,'2026-03-11 14:00:00','2026-06-17 19:18:37'),('e112',NULL,3,'HDMI Cable 5m High Speed','5-metre HDMI 2.0 cable supporting 4K 60Hz. Gold-plated connectors, compatible with TV, laptop, decoder, PlayStation.','KSH 550','Malaba Town','https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,NULL,78,NULL,NULL,'electronics',NULL,0,0,'2026-03-12 12:00:00','2026-06-16 09:23:11'),('e113',NULL,3,'HP Laptop 15 Core i5 8GB','HP 15s Intel Core i5-1235U, 8GB RAM, 256GB SSD, 15.6\" FHD, Windows 11 Home. Brand new sealed.','KSH 62,000','Malaba Town','https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'💻 New',183,NULL,NULL,'electronics',NULL,1,1,'2026-03-13 13:00:00','2026-06-17 19:18:51'),('e114',NULL,3,'Wireless Keyboard & Mouse Combo','Wireless 2.4GHz keyboard and mouse combo. Quiet keys, ergonomic design, 12-month battery life. Plug and play USB receiver.','KSH 2,200','Malaba Town','https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,NULL,98,NULL,NULL,'electronics',NULL,0,0,'2026-03-14 12:00:00','2026-06-16 04:13:27'),('e115',NULL,3,'USB 3.0 Flash Drive 64GB','SanDisk Ultra 64GB USB 3.0 flash drive. Read speed up to 130MB/s. Compact design with slide mechanism.','KSH 750','Malaba Town','https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,NULL,112,NULL,NULL,'electronics',NULL,0,0,'2026-03-15 13:00:00','2026-06-16 04:13:27'),('e116',NULL,3,'TP-Link WiFi Router 300Mbps','TP-Link TL-WR841N 300Mbps wireless router. Easy setup, stable connection. Ideal for home and small office.','KSH 2,800','Malaba Town','https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'📶 WiFi',134,NULL,NULL,'electronics',NULL,0,0,'2026-03-16 14:00:00','2026-06-16 04:13:27'),('e117',NULL,3,'Canon EOS 700D DSLR Camera','Canon EOS 700D 18MP DSLR with 18-55mm lens kit. Ideal for photography beginners and enthusiasts. Clean body.','KSH 35,000','Malaba Town','https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'📷 DSLR',89,NULL,NULL,'electronics',NULL,0,1,'2026-03-17 13:00:00','2026-06-16 19:38:45'),('e118',NULL,3,'Tripod Stand Adjustable 150cm','Adjustable aluminium camera tripod 150cm tall. Compatible with DSLR, mirrorless, smartphones. Carry bag included.','KSH 1,500','Malaba Town','https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,NULL,67,NULL,NULL,'electronics',NULL,0,0,'2026-03-18 12:00:00','2026-06-16 04:13:27'),('e119',NULL,3,'Ring Light 18 Inch with Stand','18-inch LED ring light with adjustable colour temperature and brightness. Tripod stand included. Perfect for videos and calls.','KSH 4,500','Malaba Town','https://images.unsplash.com/photo-1574169208507-84376144848b?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'💡 Studio',146,NULL,NULL,'electronics',NULL,0,0,'2026-03-19 13:00:00','2026-06-17 01:49:53'),('e120',NULL,3,'Ramtons 20L Microwave Oven','Ramtons 20-litre microwave oven with defrost function, 700W power, 5 power levels and easy-clean interior.','KSH 8,500','Malaba Town','https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'🍽 Kitchen',122,NULL,NULL,'electronics',NULL,0,0,'2026-03-20 14:00:00','2026-06-16 04:13:27'),('e121',NULL,3,'Bruhm Standing Fan 18 Inch','Bruhm 18-inch 3-speed standing fan with remote control, oscillation, timer and quiet operation.','KSH 5,200','Malaba Town','https://images.unsplash.com/photo-1545259741-2ea3ebf61fa3?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,NULL,99,NULL,NULL,'electronics',NULL,0,0,'2026-03-21 13:00:00','2026-06-16 04:13:27'),('e122',NULL,3,'Nunix Electric Kettle 1.8L','Nunix 1.8-litre stainless steel electric kettle. 2200W rapid boiling, auto shut-off, concealed element.','KSH 1,600','Malaba Town','https://images.unsplash.com/photo-1563297007-0686b7003af7?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'⚡ Fast',166,NULL,NULL,'electronics',NULL,0,0,'2026-03-22 12:00:00','2026-06-16 04:13:27'),('e123',NULL,3,'Sayona Blender SB-4050 1.5L','Sayona countertop blender 1.5L, 500W motor, 4 stainless steel blades. Ideal for smoothies, soups and juices.','KSH 2,400','Malaba Town','https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,NULL,88,NULL,NULL,'electronics',NULL,0,0,'2026-03-23 13:00:00','2026-06-16 04:13:27'),('e124',NULL,3,'Ramtons Clothes Iron Dry & Steam','Ramtons 2200W dry and steam iron with non-stick sole plate, auto shut-off and self-cleaning function.','KSH 1,800','Malaba Town','https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,NULL,77,NULL,NULL,'electronics',NULL,0,0,'2026-03-24 12:00:00','2026-06-16 04:13:27'),('e125',NULL,3,'Solar Panel 100W Monocrystalline','100W monocrystalline solar panel. High efficiency 21%, IP65 waterproof, aluminium frame. Suitable for home and vehicles.','KSH 9,500','Malaba Town','https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'☀ Solar',110,NULL,NULL,'electronics',NULL,1,0,'2026-03-25 13:00:00','2026-06-16 04:13:27'),('e126',NULL,3,'100Ah Dry Cell Battery','100Ah 12V sealed lead-acid dry cell battery. Maintenance-free, suitable for solar systems, inverters and UPS.','KSH 12,000','Malaba Town','https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'🔋 Solar',96,NULL,NULL,'electronics',NULL,0,0,'2026-03-26 14:00:00','2026-06-17 01:48:30'),('e127',NULL,3,'1000W Pure Sine Wave Inverter','1000W 12V pure sine wave power inverter. Powers household appliances, TVs, laptops from car/solar battery.','KSH 8,800','Malaba Town','https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'⚡ Inverter',82,NULL,NULL,'electronics',NULL,0,0,'2026-03-27 13:00:00','2026-06-16 04:13:27'),('e128',NULL,3,'Solar Charge Controller 30A','30A MPPT solar charge controller with LCD display. Protects battery from overcharging, optimises solar energy harvest.','KSH 3,500','Malaba Town','https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,NULL,68,NULL,NULL,'electronics',NULL,0,0,'2026-03-28 12:00:00','2026-06-16 04:13:27'),('e129',NULL,3,'PlayStation 4 Slim 1TB Bundle','PS4 Slim 1TB console with 2 wireless controllers, HDMI cable and 3 game titles. Good working condition.','KSH 28,000','Malaba Town','https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'🎮 Gaming',149,NULL,NULL,'electronics',NULL,1,1,'2026-03-29 13:00:00','2026-06-17 19:18:56'),('e130',NULL,3,'Decoder Zuku / GoTV OpenView','OpenView HD decoder with dish and LNB. Free-to-air 20+ channels, no monthly subscription. Installation included.','KSH 3,800','Malaba Town','https://images.unsplash.com/photo-1593359677879-a4bb92f4a1fe?w=800&q=80&auto=format&fit=crop',NULL,'0743050069','Malaba Electronics Hub',1,'📡 Free TV',188,NULL,NULL,'electronics',NULL,0,0,'2026-03-30 14:00:00','2026-06-16 04:13:27'),('f103',1,2,'Pilau masala','Full plate 300\r\nHalf plate 150','300','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779320096/skskksoozjpwlkrworj0.jpg','','254743050069','Malaba Homes',1,'',0,NULL,'','Food','r103',0,0,'2026-05-20 23:35:25','2026-06-15 12:13:11'),('f112',3,2,'ugali with goat stew','served with greens','700','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778829426/gvopvnpydvake53p6z63.jpg','','0743050069','Eldocafe',1,'',0,NULL,'10 - 15min','Food','r29',0,0,'2026-05-15 07:17:05','2026-06-15 12:13:11'),('f114',3,2,'Beef stew with rice','','220','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779187694/bddrvwf7mpnxqqi1tkho.jpg','','0743050069','Eldocafe',1,'',0,NULL,'20min','Food','r29',0,0,'2026-05-19 10:48:27','2026-06-15 12:13:11'),('f201',1,3,'Modern Coffee Table','Tempered glass top with wooden legs.','8500','Malaba','https://images.pexels.com/photos/276583/pexels-photo-276583.jpeg',NULL,'0747501436','Kanji Decors',1,'Featured',151,4.9,NULL,'Furniture',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:39:40'),('f202',1,3,'Office Chair','Ergonomic swivel chair with lumbar support.','12500','Malaba','https://images.pexels.com/photos/1957477/pexels-photo-1957477.jpeg',NULL,'0747501436','Kanji Decors',1,'Popular',200,4.8,NULL,'Furniture',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('f203',1,3,'Bedside Cabinet','Compact storage with 2 drawers.','4500','Malaba','https://images.pexels.com/photos/276566/pexels-photo-276566.jpeg',NULL,'0747501436','Kanji Decors',1,'Hot',85,4.7,NULL,'Furniture',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('f204',1,3,'TV Stand/Console','Fits up to 55-inch screen, minimalist design.','9800','Malaba','https://images.pexels.com/photos/1080696/pexels-photo-1080696.jpeg',NULL,'0747501436','Kanji Decors',1,'Featured',110,4.8,NULL,'Furniture',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('f205',1,3,'Dining Chairs','Set of 4, stylish upholstery, durable.','16000','Malaba','https://images.pexels.com/photos/276583/pexels-photo-276583.jpeg',NULL,'0747501436','Kanji Decors',1,'Popular',60,4.9,NULL,'Furniture',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('f206',1,3,'Bookshelf/Display Unit','5-tier open shelves, sturdy metal frame.','7500','Malaba','https://images.pexels.com/photos/1080696/pexels-photo-1080696.jpeg',NULL,'0747501436','Kanji Decors',1,'New',45,4.6,NULL,'Furniture',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('f207',1,3,'Shoe Rack','3-tier compact rack, keeps entryway tidy.','3500','Malaba','https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg',NULL,'0747501436','Kanji Decors',1,'Hot',95,4.7,NULL,'Furniture',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('f208',1,3,'Folding Desk','Space-saving desk for small rooms.','5500','Malaba','https://images.pexels.com/photos/1957477/pexels-photo-1957477.jpeg',NULL,'0747501436','Kanji Decors',1,'Featured',40,4.5,NULL,'Furniture',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('f209',1,3,'Kitchen Stool','Modern bar height stool, adjustable.','3800','Malaba','https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg',NULL,'0747501436','Kanji Decors',1,'Popular',30,4.6,NULL,'Furniture',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('f210',1,3,'Storage Ottoman','Hidden storage space + comfy seating.','6500','Malaba','https://images.pexels.com/photos/276583/pexels-photo-276583.jpeg',NULL,'0747501436','Kanji Decors',1,'Featured',55,4.8,NULL,'Furniture',NULL,0,0,'2026-06-17 19:36:23','2026-06-17 19:36:23'),('f29',3,2,'chips and fried chicken','','250','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778828077/qayhayv2cpqsrtqr2qyx.jpg','','0743050069','Eldocafe',1,'New',0,NULL,'15min','Food','r29',0,0,'2026-05-15 06:54:40','2026-06-15 12:16:47'),('f35',3,2,'Chapati and Beans','N/A','50','Opposite Way Side','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1780745081/p8zmyjwt6cdifkobanmo.jpg',NULL,'254747501436','Holywood Hotel',1,NULL,0,NULL,'10 min','Food','r889',0,0,'2026-06-06 11:26:12','2026-06-14 15:16:15'),('f38',3,2,'Ugali with wet fry fish','','250','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779090773/re0qyfhcbkesp4vbn530.jpg','','0743050069','Eldocafe',1,'',0,NULL,'20min','Food','r29',0,0,'2026-05-18 07:52:57','2026-06-15 12:13:11'),('f47',3,2,'Ugali and fry fish','','330','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779090487/cdbfkyditvpvccyfodg2.jpg','','0743050069','Eldocafe',1,'',0,NULL,'15min','Food','r29',0,0,'2026-05-18 07:48:53','2026-06-15 12:13:11'),('f54',3,2,'nyama choma','grilled or barbecued spicy nyama choma\r\n\r\n1kg of meet @  Kshs. 850','850','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1780782304/sqyegntghxerc3bgruyq.jpg','','0743050069','winkers choma zone',1,'',0,NULL,'15 - 20min','Food','r54',0,0,'2026-05-14 07:23:59','2026-06-15 12:13:11'),('f68',3,2,'ugali with beef stew','served with any vegetable you suggest','200','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778829267/sj0dyoldhelnyhhmrl0b.jpg','','0743050069','Eldocafe',1,NULL,0,NULL,'10mins','Food','r29',0,0,'2026-05-15 07:14:26','2026-06-15 12:13:11'),('f77',3,2,'plain chips','full plate','100','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778828196/tzrwjlw9ve1ic7ntwioe.jpg','','0743050069','Eldocafe',1,'',0,NULL,'10 - 15min','Food','r29',0,0,'2026-05-15 06:56:37','2026-06-15 12:13:11'),('f89',3,2,'kfc Mtaani sreetwise 2','2 drumsticks \r\nchips','430','roadlock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778752183/csdkryvlwe8ecev4phjc.jpg','','0743050069','Eldocafe',1,'Offer',0,NULL,'20min','Food','r29',0,0,'2026-05-14 07:54:56','2026-06-15 12:16:47'),('f92',3,2,'Githeri and Avocado','Served while still hot','120','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781379255/i7j7epenjsoe3olyedfm.jpg','','0743050069','Eldocafe',1,'New',0,NULL,'15min','Food','r29',0,0,'2026-05-19 10:39:36','2026-06-15 12:16:47'),('f96',3,2,'Chapati and Beef stew','Beef stew combined with potatoes and accompanied by two pieces of chapati','260','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781380044/uvaqhqpxvyjbcpdo1jfq.jpg',NULL,'254743050069','Junction Mall',1,'New',0,NULL,'15min','Food','rdefault',0,0,'2026-06-13 19:48:31','2026-06-15 12:16:47'),('h16',1,1,'Bed sitter','Self contained\r\nAffordable\r\nSpacious','6000','applants','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779099301/yuh3by0vnmokm3i1w4rr.jpg','https://res.cloudinary.com/dsqo3yxkz/video/upload/v1779098832/avdy1nbtjmyl8gmaxrnb.mp4','0743050069','',1,NULL,0,NULL,NULL,'Rentals',NULL,0,0,'2026-05-18 10:07:25','2026-06-15 12:22:27'),('h19',1,3,'Tronic extension 4way','Available in both white and black','1500','Mugumoini','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1780067717/lhkdpqp4ljzjw6cdc04t.jpg','','','',1,NULL,0,NULL,NULL,'Rentals',NULL,0,0,'2026-05-29 15:16:03','2026-06-15 12:13:11'),('h32',1,1,'1 bedroom','Affordable','12000','Uplands','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779127227/cluhhwm2sqezabuv3rrs.jpg','https://res.cloudinary.com/dsqo3yxkz/video/upload/v1779103735/ail1r9qof6cqx6juarjf.mp4','+254 743 050069','',1,NULL,2,NULL,NULL,'Rentals',NULL,0,0,'2026-05-18 11:28:54','2026-06-17 19:18:43'),('h48',1,1,'1 bedroom apartment','','12000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779191261/crnrts1i3gzafkklbzau.jpg','https://res.cloudinary.com/dsqo3yxkz/video/upload/v1779191377/m2lla2kukeazkpzrtbtb.mp4','254743050069','Malaba Homes',1,NULL,1,NULL,NULL,'Rentals',NULL,0,0,'2026-05-19 11:50:15','2026-06-17 19:18:35'),('h56',1,1,'1 bedroom','Classy 🔥','11000','Alongside malaba Bungoma highway','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779109198/l1x7kwrerqnoie3gwyli.jpg','','+254 743 050069','',1,NULL,0,NULL,NULL,'Rentals',NULL,0,0,'2026-05-18 13:00:02','2026-06-15 12:13:11'),('h59',1,3,'Phone','S24ultra','56000','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778752901/r0f2wf5xp5jtogsdzvn8.jpg','','0743950069','Giddee enterprise',1,NULL,1,NULL,NULL,'Rentals',NULL,0,0,'2026-05-14 10:01:48','2026-06-17 01:29:34'),('h63',1,2,'Biryani','Delicious','500','Malaba roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779196106/cyb2exdjxvxwxusuh879.jpg','','0743050069','Eldocafe',1,'',0,NULL,NULL,'Rentals','r0',0,0,'2026-05-19 13:08:29','2026-06-15 12:13:11'),('h65',1,1,'2bedroom apartment','','15000','uplands','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779190025/alizgkiocj3iwprnkbka.jpg','https://res.cloudinary.com/dsqo3yxkz/video/upload/v1779190581/c9ohbfvny4lgb1yoej7m.mp4','254743050069','Malaba Homes',1,NULL,0,NULL,NULL,'Rentals',NULL,0,0,'2026-05-19 11:33:58','2026-06-15 12:22:27'),('h70',1,3,'Dress','Fitting','300','Malab roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778752731/d1godbgjmufbbvh0l1hk.jpg','','254743050069','Malaba Homes',1,NULL,0,NULL,NULL,'Rentals',NULL,0,0,'2026-05-14 09:58:57','2026-06-15 12:13:11'),('h78',1,1,'2 bedroom','Simple and classy','13000','Alongside malaba Bungoma highway','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779108040/jyw6fixnqtvxdrekwwjt.jpg','https://res.cloudinary.com/dsqo3yxkz/video/upload/v1779126896/xvqorl9n4qozzt47hahq.mp4','+254 743 050069','',1,NULL,0,NULL,NULL,'Rentals',NULL,0,0,'2026-05-18 12:33:35','2026-06-15 12:13:11'),('i102',2,3,'ely sia perfume','sweet fragrance','2000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778767605/vudbjsz2om5mau5ctrna.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 14:06:49','2026-06-15 12:22:27'),('i103',1,3,'Curated mirror','Tear drops mirror available','1500','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779272749/jw3wenwnmgisahjyjv6s.jpg','https://res.cloudinary.com/dsqo3yxkz/video/upload/v1781400774/tm1dvfaxzxpquu0cc3sh.mp4','254743050069','Malaba Homes',1,'',0,NULL,NULL,'Electronics',NULL,0,0,'2026-05-20 10:22:39','2026-06-15 12:22:27'),('i107',2,3,'flower vase','','1500','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778754384/aatiyzwdesiqyaqdsxh0.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 10:26:27','2026-06-15 12:24:20'),('i111',2,3,'Blowdry','Affordable','3000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778751949/lyqtbfjjrzcrhwkpsu3g.jpg','','254743050061','Mugumoini',1,NULL,0,NULL,NULL,'Electronics',NULL,0,0,'2026-05-14 09:45:52','2026-06-15 12:22:27'),('i117',2,3,'noir splash','','450','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778768288/ud6jjm3udlastifmuohs.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 14:18:12','2026-06-15 12:22:27'),('i118',2,3,'Mugs','900 @1 set','900','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779090084/lhwxk8hyv6vp30mc30ff.jpg','','0743050069','kanji decors',1,NULL,2,NULL,NULL,'Decors',NULL,0,0,'2026-05-18 07:41:31','2026-06-16 09:55:42'),('i125',2,3,'Asad perfume','Elegant longlasting scent','2500','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778921833/twcs6lnstlppgj4yzqi7.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-16 08:57:19','2026-06-15 12:22:27'),('i126',2,3,'Stanley cups','Classic','1850','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779089981/rmgxfhj9oyyafoeybpux.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-18 07:39:49','2026-06-15 12:22:27'),('i127',2,3,'Asad perfume','','2500','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778922102/ws97x1u8ar1j7yjl96ha.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-16 09:01:49','2026-06-15 12:22:27'),('i131',2,3,'Dishes and mugs','6 pieces','3000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779090344/tw5zc00mrf6fqxbkw6eu.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-18 07:45:49','2026-06-15 12:23:54'),('i19',2,3,'hiscence fridge','frust silver two door','40000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778742167/uxlxqisbnehupsscajxh.jpg','','254743050062','Gidee enterprise',1,NULL,0,NULL,NULL,'Electronics',NULL,0,0,'2026-05-14 07:03:05','2026-06-15 12:22:27'),('i201',2,3,'HP EliteBook 840 G6','Core i5 8th Gen, 8GB RAM, 256GB SSD','32000','Malaba','https://picsum.photos/500?1','','0747501436','Malaba Homes',1,'Hot',1,NULL,NULL,'Computers',NULL,0,0,'2026-06-15 11:56:14','2026-06-16 09:55:26'),('i202',2,3,'Dell Latitude 7490','Core i7, 16GB RAM, 512GB SSD','45000','Malaba','https://picsum.photos/500?2','','0747501436','Malaba Homes',1,'Featured',0,NULL,NULL,'Computers',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:15:51'),('i203',2,3,'Lenovo ThinkPad T480','Reliable business laptop','38000','Malaba','https://picsum.photos/500?3','','0747501436','Malaba Homes',1,'New',0,NULL,NULL,'Computers',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:19:17'),('i204',2,3,'Gaming Desktop PC','Core i7, RTX Graphics','85000','Malaba','https://picsum.photos/500?4','','0747501436','Malaba Homes',1,'Premium',0,NULL,NULL,'Computers',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:16:11'),('i205',2,3,'24 Inch Monitor','Full HD LED Monitor','9500','Malaba','https://picsum.photos/500?5','','0747501436','Malaba Homes',1,'New',0,NULL,NULL,'Accessories',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:19:34'),('i206',2,3,'Wireless Mouse','2.4GHz USB Mouse','800','Malaba','https://picsum.photos/500?6','','0747501436','Malaba Homes',1,'Sale',0,NULL,NULL,'Accessories',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:21:27'),('i207',2,3,'Mechanical Keyboard','RGB Backlit Keyboard','3500','Malaba','https://picsum.photos/500?7','','0747501436','Malaba Homes',1,'Hot',0,NULL,NULL,'Accessories',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:22:16'),('i208',2,3,'Laptop Cooling Pad','Dual Fan Cooling Pad','1500','Malaba','https://picsum.photos/500?8','','0747501436','Malaba Homes',1,'New',4,NULL,NULL,'Accessories',NULL,0,0,'2026-06-15 11:56:14','2026-06-17 02:12:46'),('i209',2,3,'HP Laser Printer','Fast office printer','18000','Malaba','https://picsum.photos/500?9','','0747501436','Malaba Homes',1,'Featured',0,NULL,NULL,'Printers',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:16:56'),('i210',2,3,'Epson EcoTank Printer','Low-cost printing solution','28000','Malaba','https://picsum.photos/500?10','','0747501436','Malaba Homes',1,'Featured',0,NULL,NULL,'Printers',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:15:22'),('i211',2,3,'Samsung Galaxy A55','128GB, 5G Smartphone','42000','Malaba','https://picsum.photos/500?11','','0747501436','Malaba Homes',1,'Hot',4,NULL,NULL,'Phones',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 20:46:49'),('i212',2,3,'Tecno Camon 40','Excellent camera phone','23000','Malaba','https://picsum.photos/500?12','','0747501436','Malaba Homes',1,'New',0,NULL,NULL,'Phones',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:21:45'),('i213',2,3,'Infinix Note 50','Large battery smartphone','21000','Malaba','https://picsum.photos/500?13','','0747501436','Malaba Homes',1,'New',0,NULL,NULL,'Phones',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:21:13'),('i214',2,3,'iPhone 13','128GB, Excellent Condition','65000','Malaba','https://picsum.photos/500?14','','0747501436','Malaba Homes',1,'Premium',0,NULL,NULL,'Phones',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:15:37'),('i215',2,3,'Bluetooth Speaker','Portable Wireless Speaker','2500','Malaba','https://picsum.photos/500?15','','0747501436','Malaba Homes',1,'Hot',2,NULL,NULL,'Audio',NULL,0,0,'2026-06-15 11:56:14','2026-06-17 02:13:15'),('i216',2,3,'JBL Headphones','Noise Cancelling Headphones','5500','Malaba','https://picsum.photos/500?16','','0747501436','Malaba Homes',1,'Featured',2,NULL,NULL,'Audio',NULL,0,0,'2026-06-15 11:56:14','2026-06-17 05:33:24'),('i217',2,3,'32 Inch Smart TV','Android Smart TV','18500','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781693448/wkdo6y0lfuwqhrk2qort.jpg','','0747501436','Malaba Homes',1,'Featured',2,NULL,NULL,'Televisions',NULL,0,0,'2026-06-15 11:56:14','2026-06-17 19:00:23'),('i218',2,3,'43 Inch Smart TV','4K UHD Smart TV','35000','Malaba','https://picsum.photos/500?18','','0747501436','Malaba Homes',1,'Premium',1,NULL,NULL,'Televisions',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 14:24:55'),('i219',2,3,'Extension Cable','6 Socket Surge Protector','1200','Malaba','https://picsum.photos/500?19','','0747501436','Malaba Homes',1,'Sale',0,NULL,NULL,'Electrical',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:19:05'),('i220',2,3,'WiFi Router','High Speed Router','4500','Malaba','https://picsum.photos/500?20','','0747501436','Malaba Homes',1,'Hot',0,NULL,NULL,'Networking',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:20:27'),('i221',2,3,'USB Flash 64GB','High Speed Storage','800','Malaba','https://picsum.photos/500?21','','0747501436','Malaba Homes',1,'Sale',0,NULL,NULL,'Storage',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:20:09'),('i222',2,3,'External Hard Disk 1TB','Portable Backup Storage','5500','Malaba','https://picsum.photos/500?22','','0747501436','Malaba Homes',1,'Featured',0,NULL,NULL,'Storage',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:19:48'),('i223',2,3,'Power Bank 20000mAh','Fast Charging Power Bank','2200','Malaba','https://picsum.photos/500?23','','0747501436','Malaba Homes',1,'Hot',1,NULL,NULL,'Accessories',NULL,0,0,'2026-06-15 11:56:14','2026-06-17 06:38:11'),('i224',2,3,'Smart Watch','Fitness and Notifications','3500','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781528746/aj59aifycluimnpfnj8x.jpg','','0747501436','Malaba Homes',1,'New',4,NULL,NULL,'Wearables',NULL,1,0,'2026-06-15 11:56:14','2026-06-15 20:38:38'),('i225',2,3,'Electric Kettle','2L Fast Boiling Kettle','1800','Malaba','https://picsum.photos/500?25','','0747501436','Malaba Homes',1,'Sale',0,NULL,NULL,'Appliances',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:18:39'),('i226',2,3,'Microwave Oven','20L Digital Microwave','8500','Malaba','https://picsum.photos/500?26','','0747501436','Malaba Homes',1,'Featured',3,NULL,NULL,'Appliances',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 20:46:39'),('i227',2,3,'Blender','Heavy Duty Kitchen Blender','3200','Malaba','https://picsum.photos/500?27','','0747501436','Malaba Homes',1,'New',0,NULL,NULL,'Appliances',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:18:15'),('i228',2,3,'Electric Iron Box','Non-stick Iron Box','1500','Malaba','https://picsum.photos/500?28','','0747501436','Malaba Homes',1,'Sale',0,NULL,NULL,'Appliances',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 13:17:59'),('i229',2,3,'Mini Fridge','Compact Refrigerator','16500','Malaba','https://picsum.photos/500?29','','0747501436','Malaba Homes',1,'Premium',1,NULL,NULL,'Appliances',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 20:37:21'),('i230',2,3,'CCTV Security Kit','4 Camera HD Surveillance System','24000','Malaba','https://picsum.photos/500?30','','0747501436','Malaba Homes',1,'Featured',3,NULL,NULL,'Security',NULL,0,0,'2026-06-15 11:56:14','2026-06-15 20:46:09'),('i27',2,3,'utencils rack','well drainer dishes utencils rack','5000','roadlock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778742564/budnapongsutqvmj5f2h.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 07:10:12','2026-06-15 12:22:27'),('i29',1,3,'comfy blankets','fluffy','1000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778753167/ef5t7y80chzdwsenogrh.jpg','','254743050069','Malaba Homes',1,NULL,1,NULL,NULL,'Electronics',NULL,0,0,'2026-05-14 10:06:14','2026-06-17 01:29:45'),('i30',2,3,'perfume','sweet and elegant','1500','roadlock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778829896/rb2uaxzy9o1mkiohmu2q.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 07:37:44','2026-06-15 12:22:27'),('i33',2,3,'9 pm perfume','long lasting','2500','roadlock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778766338/foon78dfvnuimyjuuoks.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 13:45:59','2026-06-15 12:22:27'),('i43',2,3,'Marshmallow perfume','Sweet fragrance','1000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778918557/mgxlxfxeh4n1kc6mv836.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-16 08:02:42','2026-06-15 12:22:27'),('i45',2,3,'rayan black perfume','','1000','roadlock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778766913/i0xfxhscvgemenxcjwby.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 13:55:16','2026-06-15 12:13:11'),('i48',1,3,'Lenovo mouse','Best for fast users and djs','450','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779179517/hrevmcog7v3eefpxxbxz.jpg','','254743050069','Malaba Homes',1,NULL,0,NULL,NULL,'Electronics',NULL,0,0,'2026-05-19 08:34:34','2026-06-15 12:23:25'),('i52',2,3,'berrys weekend perfume','pink edition\r\nviolet edition','2500','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778766652/zg3wjwjvkzbfpajtar5u.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 13:50:55','2026-06-15 12:22:27'),('i53',2,3,'fruit and vegetable rack','rootating and layered rack','2500','roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778752012/pvajplvgidzpzzqw1udy.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 07:14:23','2026-06-15 12:22:27'),('i54',1,3,'Hp laptop','4gb Ram\r\n256 SSD\r\nTouch screen','18000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779271293/pyz4hc0lotllk6cvowm4.jpg','','254743050069','Malaba Homes',1,NULL,0,NULL,NULL,'Electronics',NULL,0,0,'2026-05-20 10:17:57','2026-06-15 12:17:01'),('i55',2,3,'yara perfume','sweet fragrance','2500','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778767481/zj3nsusce2fmuz5tcpan.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 14:04:45','2026-06-15 12:22:27'),('i57',2,3,'body mist','','500','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778768378/lz6wc9mswmx4ybrlo3j8.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 14:19:42','2026-06-15 12:22:27'),('i59',2,3,'flower decor','classic','600','roadlock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778752495/dzqggrblbkkd1qpzqfqy.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 09:54:59','2026-06-15 12:22:27'),('i60',2,3,'utencils rack','well drainer dishes utencils rack','5000','roadlock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778742564/budnapongsutqvmj5f2h.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 07:10:09','2026-06-15 12:22:27'),('i6001',3,3,'Samsung Galaxy A15','Affordable Samsung smartphone with long battery life.','18500','Malaba','data:image/webp;base64,UklGRloSAABXRUJQVlA4IE4SAADQWwCdASq1AM0APkkgjUUioaES6SYkKASEsaBN3NHIDfRNJTn199kkkvJvi4Be6Ae79P/ikaBx0QHVf6LBWbujn4H7j87H5frG/q/7ryM8AL8g/mH+A/MjLufsf/H9GadPemf6HlIeQHuEflT/h/cB8tP+t54/qb/x/5z4D/5t/Xv+B/efbG9mXo1frwYSrJuEJe84cjpunysrYNmd1NJyj0iz1PhepEfhbZ8f2fLphr4a5iv2wZNDa297aNf71e1NFxahYY1WesfrPCussULMqqoBrygt+RCZct7ZOGa9ZXuJaC0ush1XpK6P/EOI6wjN7YsOcXMm4/kVR+Gkz/obKsbUICz09NgyL5x++6hixOWeB9h3gx8sX54dXeJjLF/OT/+BPLQHTB27HavjHsVcMYExU1DsSjrKUaueRLVvgQRv8YEZP1/fev6hTXhT28sRa','','0747501436','Mugumoini',1,'Popular',126,4.7,NULL,'Phones',NULL,1,0,'2026-06-15 15:14:41','2026-06-17 01:45:24'),('i6002',3,3,'Tecno Spark 20','Budget smartphone with excellent camera.','14500','Malaba','https://fdn2.gsmarena.com/vv/bigpic/tecno-spark-20.jpg','','0747501436','Mugumoini',1,'New',86,4.5,NULL,'Phones',NULL,0,0,'2026-06-15 15:14:41','2026-06-16 04:37:53'),('i6003',3,3,'Infinix Smart 9','Reliable smartphone suitable for everyday use.','12500','Malaba','https://fdn2.gsmarena.com/vv/bigpic/infinix-smart-9.jpg','','0747501436','Mugumoini',1,'Popular',95,4.6,NULL,'Phones',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 15:25:38'),('i6004',3,3,'Oraimo Power Bank 20000mAh','Fast charging power bank trusted by many users.','2800','Malaba','https://ng.jumia.is/unsafe/fit-in/680x680/filters:fill(white)/product/89/123456/1.jpg?1234','','0747501436','Mugumoini',1,'Hot',150,4.8,NULL,'Accessories',NULL,1,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6005',3,3,'Oraimo Type-C Charger','Fast charger compatible with most Android phones.','900','Malaba','https://images.unsplash.com/photo-1583394838339-acb4f0c3f7d7','','0747501436','Mugumoini',1,'New',75,4.5,NULL,'Accessories',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6006',3,3,'Wireless Bluetooth Earbuds','Clear sound and long battery life.','1800','Malaba','https://images.unsplash.com/photo-1505740420928-5e560c06d30e','','0747501436','Mugumoini',1,'Popular',92,4.4,NULL,'Audio',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 20:02:34'),('i6007',3,3,'JBL Portable Speaker','Portable speaker with deep bass.','3500','Malaba','https://images.unsplash.com/photo-1608043152269-423dbba4e7e1','','0747501436','Mugumoini',1,'Featured',218,4.8,NULL,'Audio',NULL,1,0,'2026-06-15 15:14:41','2026-06-17 14:05:20'),('i6008',3,3,'HP EliteBook 840 G5','Core i5 laptop suitable for office work.','32000','Malaba','https://images.unsplash.com/photo-1496181133206-80ce9b88a853','','0747501436','Mugumoini',1,'Featured',150,4.9,NULL,'Computers',NULL,1,1,'2026-06-15 15:14:41','2026-06-17 19:18:56'),('i6009',3,3,'Dell Latitude 7490','Business laptop with SSD storage.','36000','Malaba','https://images.unsplash.com/photo-1496181133206-80ce9b88a853','','0747501436','Mugumoini',1,'Premium',100,4.8,NULL,'Computers',NULL,1,1,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6010',3,3,'Lenovo ThinkPad T480','Durable laptop trusted by professionals.','34000','Malaba','https://images.unsplash.com/photo-1496181133206-80ce9b88a853','','0747501436','Mugumoini',1,'Popular',88,4.7,NULL,'Computers',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6011',3,3,'USB Flash Disk 64GB','Fast storage for school and office files.','800','Malaba','https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6','','0747501436','Mugumoini',1,'New',41,4.3,NULL,'Storage',NULL,0,0,'2026-06-15 15:14:41','2026-06-17 16:27:18'),('i6012',3,3,'External Hard Disk 1TB','Portable backup storage.','5500','Malaba','https://images.unsplash.com/photo-1563777885903-0b2f8f8f8f8f','','0747501436','Mugumoini',1,'Popular',65,4.7,NULL,'Storage',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6013',3,3,'Wireless Mouse','Comfortable wireless mouse.','700','Malaba','https://images.unsplash.com/photo-1527864550417-7fd91fc51a4f','','0747501436','Mugumoini',1,'New',35,4.2,NULL,'Accessories',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6014',3,3,'Mechanical Keyboard','RGB gaming keyboard.','3200','Malaba','https://images.unsplash.com/photo-1541140538779-0c3c5c0c8b0b','','0747501436','Mugumoini',1,'Hot',121,4.6,NULL,'Accessories',NULL,0,0,'2026-06-15 15:14:41','2026-06-17 06:38:23'),('i6015',3,3,'WiFi Router','High-speed internet router.','4500','Malaba','https://images.unsplash.com/photo-1558618047-3c8c76ca5d8f','','0747501436','Mugumoini',1,'Popular',95,4.6,NULL,'Networking',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6016',3,3,'Network Cable 20M','Reliable Cat6 network cable.','1200','Malaba','https://images.unsplash.com/photo-1583394838339-acb4f0c3f7d7','','0747501436','Mugumoini',1,'New',15,4.2,NULL,'Networking',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6017',3,3,'32 Inch Smart TV','Android smart TV for home entertainment.','18500','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781693515/slbysxbw7ewxiy85trzv.jpg','','0747501436','Mugumoini',1,'Featured',203,4.8,NULL,'Televisions',NULL,1,1,'2026-06-15 15:14:41','2026-06-17 19:18:34'),('i6018',3,3,'43 Inch Smart TV','4K UHD Smart Television.','34000','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781693611/hfvuprkkclktbj9clygb.jpg','','0747501436','Mugumoini',1,'Premium',133,4.9,NULL,'Televisions',NULL,1,1,'2026-06-15 15:14:41','2026-06-17 19:00:01'),('i6019',3,3,'Electric Kettle','Fast boiling electric kettle.','1800','Malaba','https://images.unsplash.com/photo-1588872657578-5d3f3f0e7e0f','','0747501436','Mugumoini',1,'Popular',70,4.5,NULL,'Appliances',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6020',3,3,'Blender','Heavy duty kitchen blender.','3200','Malaba','https://images.unsplash.com/photo-1588872657578-5d3f3f0e7e0f','','0747501436','Mugumoini',1,'New',45,4.4,NULL,'Appliances',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6021',3,3,'Microwave Oven','Compact microwave oven.','8500','Malaba','https://images.unsplash.com/photo-1588872657578-5d3f3f0e7e0f','','0747501436','Mugumoini',1,'Featured',91,4.7,NULL,'Appliances',NULL,1,0,'2026-06-15 15:14:41','2026-06-16 05:10:56'),('i6022',3,3,'Electric Iron Box','Non-stick iron box.','1500','Malaba','https://images.unsplash.com/photo-1588872657578-5d3f3f0e7e0f','','0747501436','Mugumoini',1,'Popular',60,4.4,NULL,'Appliances',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6023',3,3,'Extension Cable','6-way surge protected extension.','1200','Malaba','https://images.unsplash.com/photo-1583394838339-acb4f0c3f7d7','','0747501436','Mugumoini',1,'Hot',130,4.7,NULL,'Electrical',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6024',3,3,'LED Security Flood Light','Bright outdoor LED light.','2500','Malaba','https://images.unsplash.com/photo-1600585154340-be6161a56a9c','','0747501436','Mugumoini',1,'Popular',55,4.5,NULL,'Electrical',NULL,0,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6025',3,3,'Rechargeable Emergency Lamp','Useful during power outages.','1800','Malaba','https://images.unsplash.com/photo-1600585154340-be6161a56a9c','','0747501436','Mugumoini',1,'Hot',151,4.8,NULL,'Electrical',NULL,1,0,'2026-06-15 15:14:41','2026-06-15 15:30:53'),('i6026',3,3,'Samsung Galaxy A05','Reliable budget Samsung with big battery and clean Android.','13500','Malaba','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9','','0747501436','Mugumoini',1,'Popular',181,4.5,NULL,'Phones',NULL,1,0,'2026-06-15 15:20:45','2026-06-16 04:47:03'),('i6027',3,3,'Tecno Spark 20C','Best-selling budget phone with 50MP camera.','14800','Malaba','https://fdn2.gsmarena.com/vv/bigpic/tecno-spark-20c.jpg','','0747501436','Mugumoini',1,'Hot',250,4.6,NULL,'Phones',NULL,1,0,'2026-06-15 15:20:45','2026-06-17 10:52:08'),('i6028',3,3,'Infinix Hot 40i','Stylish design with 5000mAh battery.','15200','Malaba','https://fdn2.gsmarena.com/vv/bigpic/infinix-hot-40i.jpg','','0747501436','Mugumoini',1,'Popular',165,4.4,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6029',3,3,'Redmi 13C','Xiaomi phone with strong performance.','16800','Malaba','https://fdn2.gsmarena.com/vv/bigpic/xiaomi-redmi-13c.jpg','','0747501436','Mugumoini',1,'New',132,4.7,NULL,'Phones',NULL,1,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6030',3,3,'Samsung Galaxy A15','Most popular mid-range Samsung in Kenya.','18500','Malaba','https://images.unsplash.com/photo-1610945265064-0e34e5519bbf','','0747501436','Mugumoini',1,'Featured',317,4.8,NULL,'Phones',NULL,1,0,'2026-06-15 15:20:45','2026-06-17 02:10:37'),('i6031',3,3,'Tecno Camon 20','Excellent camera phone at affordable price.','22500','Malaba','https://fdn2.gsmarena.com/vv/bigpic/tecno-camon-20.jpg','','0747501436','Mugumoini',1,'Popular',199,4.7,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:26:36'),('i6032',3,3,'Infinix Note 30','Big screen and fast charging.','23800','Malaba','https://fdn2.gsmarena.com/vv/bigpic/infinix-note-30.jpg','','0747501436','Mugumoini',1,'Hot',145,4.6,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6033',3,3,'Redmi Note 13','Balanced performance and battery.','21900','Malaba','https://fdn2.gsmarena.com/vv/bigpic/xiaomi-redmi-note-13.jpg','','0747501436','Mugumoini',1,'Popular',180,4.7,NULL,'Phones',NULL,1,0,'2026-06-15 15:20:45','2026-06-16 04:44:38'),('i6034',3,3,'Samsung Galaxy A25','Premium feel with excellent display.','26500','Malaba','https://images.unsplash.com/photo-1565849904461-612cfa133b4c','','0747501436','Mugumoini',1,'Featured',99,4.8,NULL,'Phones',NULL,1,0,'2026-06-15 15:20:45','2026-06-16 05:13:43'),('i6035',3,3,'Tecno Spark 10 Pro','Great value with 108MP camera.','19800','Malaba','https://fdn2.gsmarena.com/vv/bigpic/tecno-spark-10-pro.jpg','','0747501436','Mugumoini',1,'New',169,4.5,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:28:56'),('i6036',3,3,'Itel A70','Super affordable reliable smartphone.','9800','Malaba','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9','','0747501436','Mugumoini',1,'Popular',225,4.3,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-17 10:50:41'),('i6037',3,3,'Nokia C31','Trusted Nokia build quality.','13500','Malaba','https://fdn2.gsmarena.com/vv/bigpic/nokia-c31.jpg','','0747501436','Mugumoini',1,'Popular',88,4.4,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6038',3,3,'Samsung Galaxy A14','Still very popular entry-level Samsung.','15500','Malaba','https://images.unsplash.com/photo-1610945265064-0e34e5519bbf','','0747501436','Mugumoini',1,'Hot',204,4.6,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-17 10:50:31'),('i6039',3,3,'Infinix Hot 40','Stylish and powerful budget phone.','17200','Malaba','https://fdn2.gsmarena.com/vv/bigpic/infinix-hot-40.jpg','','0747501436','Mugumoini',1,'Popular',142,4.5,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6040',3,3,'Redmi 12','Clean MIUI and good battery life.','16500','Malaba','https://fdn2.gsmarena.com/vv/bigpic/xiaomi-redmi-12.jpg','','0747501436','Mugumoini',1,'New',119,4.6,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6041',3,3,'Tecno Phantom V Flip','Premium foldable experience.','68000','Malaba','https://fdn2.gsmarena.com/vv/bigpic/tecno-phantom-v-flip.jpg','','0747501436','Mugumoini',1,'Premium',50,4.8,NULL,'Phones',NULL,1,1,'2026-06-15 15:20:45','2026-06-17 19:36:32'),('i6042',3,3,'Samsung Galaxy A34','Mid-range king with great camera.','29500','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781585205/grr74xsbky7cxrmy80mg.jpg','','0747501436','Mugumoini',1,'Featured',170,4.8,NULL,'Phones',NULL,1,0,'2026-06-15 15:20:45','2026-06-16 04:46:50'),('i6043',3,3,'Infinix Zero 30','Flagship killer at mid-range price.','42500','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781693764/ju9pgtrwjiyurkd7c8qr.jpg','','0747501436','Mugumoini',1,'Premium',80,4.7,NULL,'Phones',NULL,1,1,'2026-06-15 15:20:45','2026-06-17 10:56:12'),('i6044',3,3,'Nokia G21','Pure Android experience.','14800','Malaba','https://fdn2.gsmarena.com/vv/bigpic/nokia-g21.jpg','','0747501436','Mugumoini',1,'Popular',92,4.4,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6045',3,3,'Itel Vision 5','Stylish and reliable budget phone.','11200','Malaba','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9','','0747501436','Mugumoini',1,'New',105,4.3,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6046',3,3,'Samsung Galaxy A23','Still loved by many Kenyans.','19500','Malaba','https://fdn2.gsmarena.com/vv/bigpic/samsung-galaxy-a23.jpg','','0747501436','Mugumoini',1,'Popular',134,4.6,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6047',3,3,'Tecno Spark 20','Latest Spark series with big improvements.','16800','Malaba','https://fdn2.gsmarena.com/vv/bigpic/tecno-spark-20.jpg','','0747501436','Mugumoini',1,'Hot',211,4.6,NULL,'Phones',NULL,1,0,'2026-06-15 15:20:45','2026-06-16 15:16:59'),('i6048',3,3,'Redmi Note 12','Excellent display and performance.','20500','Malaba','https://fdn2.gsmarena.com/vv/bigpic/xiaomi-redmi-note-12.jpg','','0747501436','Mugumoini',1,'Featured',156,4.7,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6049',3,3,'Infinix Note 30 Pro','Premium features at great price.','29500','Malaba','https://fdn2.gsmarena.com/vv/bigpic/infinix-note-30-pro.jpg','','0747501436','Mugumoini',1,'Premium',96,4.8,NULL,'Phones',NULL,1,1,'2026-06-15 15:20:45','2026-06-17 19:56:50'),('i6050',3,3,'Samsung Galaxy S23 FE','Flagship experience made affordable.','52000','Malaba','https://images.unsplash.com/photo-1610945265064-0e34e5519bbf','','0747501436','Mugumoini',1,'Premium',68,4.9,NULL,'Phones',NULL,1,1,'2026-06-15 15:20:45','2026-06-15 20:01:56'),('i6051',3,3,'Nokia C22','Tough and reliable basic smartphone.','13800','Malaba','https://fdn2.gsmarena.com/vv/bigpic/nokia-c22.jpg','','0747501436','Mugumoini',1,'Popular',76,4.4,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6052',3,3,'Itel S23','Stylish design with good performance.','14500','Malaba','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9','','0747501436','Mugumoini',1,'New',99,4.5,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:26:23'),('i6053',3,3,'Tecno Camon 20 Premier','Camera powerhouse.','38500','Malaba','https://fdn2.gsmarena.com/vv/bigpic/tecno-camon-20-premier.jpg','','0747501436','Mugumoini',1,'Premium',73,4.8,NULL,'Phones',NULL,1,1,'2026-06-15 15:20:45','2026-06-16 05:13:21'),('i6054',3,3,'Samsung Galaxy A05s','Improved version of A05.','14800','Malaba','https://fdn2.gsmarena.com/vv/bigpic/samsung-galaxy-a05s.jpg','','0747501436','Mugumoini',1,'Popular',165,4.5,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6055',3,3,'Infinix Hot 40 Pro','Gaming capable budget phone.','19800','Malaba','https://fdn2.gsmarena.com/vv/bigpic/infinix-hot-40-pro.jpg','','0747501436','Mugumoini',1,'Hot',142,4.6,NULL,'Phones',NULL,0,0,'2026-06-15 15:20:45','2026-06-15 15:24:04'),('i6081',3,3,'HP EliteBook 840 G5','Core i5 8th Gen, 8GB RAM, 256GB SSD - Excellent business laptop.','32000','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781693657/mx8q7jcvfauo3cxwnipl.jpg','','0747501436','Mugumoini',1,'Featured',257,4.8,NULL,'Computers',NULL,1,1,'2026-06-15 21:21:29','2026-06-17 19:18:32'),('i6082',3,3,'Dell Latitude 7490','Core i5 8th Gen, 8GB RAM, 256GB SSD - Durable & reliable.','35500','Malaba','https://picsum.photos/seed/delllatitude7490/600/400','','0747501436','Mugumoini',1,'Premium',200,4.7,NULL,'Computers',NULL,1,1,'2026-06-15 21:21:29','2026-06-17 19:18:41'),('i6083',3,3,'Lenovo ThinkPad T480','Core i5, 8GB RAM, 256GB SSD - Legendary keyboard & durability.','34000','Malaba','https://picsum.photos/seed/thinkpadt480/600/400','','0747501436','Mugumoini',1,'Popular',317,4.9,NULL,'Computers',NULL,1,0,'2026-06-15 21:21:29','2026-06-17 15:21:02'),('i6084',3,3,'HP ProBook 650 G4','Core i5 7th Gen, 8GB RAM, 500GB HDD+256GB SSD.','29500','Malaba','https://picsum.photos/seed/hpprobook650g4/600/400','','0747501436','Mugumoini',1,'Hot',167,4.6,NULL,'Computers',NULL,0,0,'2026-06-15 21:21:29','2026-06-15 21:31:48'),('i6085',3,3,'Dell Latitude 5400','Core i5 8th Gen, 8GB RAM, 256GB SSD - Great for students.','28500','Malaba','https://picsum.photos/seed/delllatitude5400/600/400','','0747501436','Mugumoini',1,'Popular',238,4.7,NULL,'Computers',NULL,1,0,'2026-06-15 21:21:29','2026-06-17 16:25:51'),('i6086',3,3,'Lenovo IdeaPad 3','Core i5 11th Gen, 8GB RAM, 512GB SSD - Modern everyday laptop.','42000','Malaba','https://picsum.photos/seed/lenovoideapad3/600/400','','0747501436','Mugumoini',1,'New',189,4.6,NULL,'Computers',NULL,0,0,'2026-06-15 21:21:29','2026-06-15 21:31:48'),('i6087',3,3,'HP Pavilion 15','Core i5 10th Gen, 8GB RAM, 512GB SSD - Stylish multimedia laptop.','45000','Malaba','https://picsum.photos/seed/hppavilion15/600/400','','0747501436','Mugumoini',1,'Featured',156,4.7,NULL,'Computers',NULL,1,0,'2026-06-15 21:21:29','2026-06-15 21:31:48'),('i6088',3,3,'Dell Vostro 3400','Core i5 11th Gen, 8GB RAM, 512GB SSD.','39500','Malaba','https://picsum.photos/seed/dellvostro3400/600/400','','0747501436','Mugumoini',1,'Popular',178,4.5,NULL,'Computers',NULL,0,0,'2026-06-15 21:21:29','2026-06-15 21:31:48'),('i6089',3,3,'Lenovo ThinkPad X260','Core i5 6th Gen, 8GB RAM, 256GB SSD - Ultra portable.','22800','Malaba','https://picsum.photos/seed/thinkpadx260/600/400','','0747501436','Mugumoini',1,'Hot',145,4.4,NULL,'Computers',NULL,0,0,'2026-06-15 21:21:29','2026-06-15 21:31:48'),('i6090',3,3,'HP EliteBook 830 G6','Core i5 8th Gen, 16GB RAM, 512GB SSD - Premium build.','48000','Malaba','https://picsum.photos/seed/hpelitebook830g6/600/400','','0747501436','Mugumoini',1,'Premium',98,4.8,NULL,'Computers',NULL,1,1,'2026-06-15 21:21:29','2026-06-15 21:31:48'),('i6091',3,3,'Dell Latitude 5510','Core i7 10th Gen, 16GB RAM, 512GB SSD.','52000','Malaba','https://picsum.photos/seed/delllatitude5510/600/400','','0747501436','Mugumoini',1,'Featured',89,4.9,NULL,'Computers',NULL,1,1,'2026-06-15 21:21:29','2026-06-16 10:34:52'),('i6092',3,3,'Lenovo ThinkPad T490','Core i5 8th Gen, 8GB RAM, 256GB SSD - Business powerhouse.','36500','Malaba','https://picsum.photos/seed/thinkpadt490/600/400','','0747501436','Mugumoini',1,'Popular',207,4.7,NULL,'Computers',NULL,0,0,'2026-06-15 21:21:29','2026-06-17 19:16:21'),('i6093',3,3,'Acer Aspire 5','Core i5 10th Gen, 8GB RAM, 512GB SSD - Budget friendly performance.','38000','Malaba','https://picsum.photos/seed/aceraspire5/600/400','','0747501436','Mugumoini',1,'New',168,4.5,NULL,'Computers',NULL,0,0,'2026-06-15 21:21:29','2026-06-17 19:15:51'),('i6094',3,3,'HP 15s-eq2xxx','Core i3 11th Gen, 8GB RAM, 512GB SSD - Light & affordable.','29500','Malaba','https://picsum.photos/seed/hp15seq2xxx/600/400','','0747501436','Mugumoini',1,'Popular',245,4.4,NULL,'Computers',NULL,0,0,'2026-06-15 21:21:29','2026-06-15 21:31:48'),('i6095',3,3,'Dell Inspiron 15 3000','Core i5 10th Gen, 8GB RAM, 1TB HDD + 256GB SSD.','33500','Malaba','https://picsum.photos/seed/dellinspiron153000/600/400','','0747501436','Mugumoini',1,'Hot',132,4.6,NULL,'Computers',NULL,0,0,'2026-06-15 21:21:29','2026-06-15 21:31:48'),('i6096',3,3,'Lenovo IdeaPad Slim 3','Core i5 12th Gen, 8GB RAM, 512GB SSD - Slim & fast.','48000','Malaba','https://picsum.photos/seed/ideapadslim3/600/400','','0747501436','Mugumoini',1,'Featured',112,4.7,NULL,'Computers',NULL,1,0,'2026-06-15 21:21:29','2026-06-15 21:31:48'),('i6097',3,3,'HP EliteBook x360 1030 G3','Core i5, 8GB RAM, 256GB SSD - 2-in-1 Convertible.','52000','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781693565/vb8ryhjjpejtbgbndwp9.jpg','','0747501436','Mugumoini',1,'Premium',81,4.8,NULL,'Computers',NULL,1,1,'2026-06-15 21:21:29','2026-06-17 15:21:21'),('i6098',3,3,'Dell Latitude 3420','Core i5 11th Gen, 8GB RAM, 512GB SSD.','41500','Malaba','https://picsum.photos/seed/delllatitude3420/600/400','','0747501436','Mugumoini',1,'Popular',154,4.6,NULL,'Computers',NULL,0,0,'2026-06-15 21:21:29','2026-06-15 21:31:48'),('i6099',3,3,'Lenovo ThinkPad E14','Core i5 10th Gen, 8GB RAM, 256GB SSD - Reliable daily driver.','36800','Malaba','https://picsum.photos/seed/thinkpade14/600/400','','0747501436','Mugumoini',1,'New',189,4.7,NULL,'Computers',NULL,0,0,'2026-06-15 21:21:29','2026-06-15 21:31:48'),('i6100',3,3,'HP ProBook 440 G8','Core i5 11th Gen, 8GB RAM, 512GB SSD.','42500','Malaba','https://picsum.photos/seed/hpprobook440g8/600/400','','0747501436','Mugumoini',1,'Featured',134,4.7,NULL,'Computers',NULL,1,0,'2026-06-15 21:21:29','2026-06-15 21:31:48'),('i6201',3,3,'TP-Link TL-WR840N Router','Reliable wireless router suitable for homes and small offices.','2800','Malaba','https://images.unsplash.com/photo-1606904825846-647eb07f5be2?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',120,4.6,NULL,'Networking',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6202',3,3,'TP-Link Archer C6','Dual-band high speed WiFi router with strong coverage.','5500','Malaba','https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',80,4.8,NULL,'Networking',NULL,1,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6203',3,3,'MikroTik hAP Lite','Affordable router trusted by cyber cafes and businesses.','4200','Malaba','https://images.unsplash.com/photo-1606904825846-647eb07f5be2?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',95,4.7,NULL,'Networking',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6204',3,3,'Huawei 4G Router','SIM card router with excellent network reception.','6500','Malaba','https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Hot',140,4.8,NULL,'Networking',NULL,1,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6205',3,3,'TP-Link 8 Port Switch','Easy network expansion for offices and homes.','3200','Malaba','https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',60,4.5,NULL,'Networking',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6206',3,3,'D-Link 5 Port Switch','Compact and energy efficient network switch.','1800','Malaba','https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',75,4.4,NULL,'Networking',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6207',3,3,'Cat6 Ethernet Cable 30M','High-speed networking cable for reliable connections.','1500','Malaba','https://images.unsplash.com/photo-1588508065123-287b28e013da?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',40,4.5,NULL,'Networking',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6208',3,3,'WiFi Range Extender','Boosts wireless signal coverage in large homes.','2900','Malaba','https://images.unsplash.com/photo-1606904825846-647eb07f5be2?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Hot',88,4.6,NULL,'Networking',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6209',3,3,'TP-Link USB WiFi Adapter','Adds wireless connectivity to desktop computers.','1200','Malaba','https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',70,4.5,NULL,'Networking',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6210',3,3,'Mercusys AC1200 Router','Affordable dual-band router with excellent coverage.','4300','Malaba','https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',65,4.7,NULL,'Networking',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6211',3,3,'Outdoor Access Point','Long range WiFi access point for outdoor installations.','9500','Malaba','https://images.unsplash.com/photo-1565514020179-026b92b84bb6?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Premium',25,4.8,NULL,'Networking',NULL,1,1,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6212',3,3,'PoE Injector','Power over Ethernet injector for IP cameras.','1100','Malaba','https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',20,4.4,NULL,'Networking',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6213',3,3,'Network Crimping Tool','Professional networking installation tool.','1800','Malaba','https://images.unsplash.com/photo-1504222490345-c075b2f5c058?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',35,4.5,NULL,'Networking',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6214',3,3,'RJ45 Connector Pack','High quality Ethernet connectors.','450','Malaba','https://images.unsplash.com/photo-1588508065123-287b28e013da?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',18,4.3,NULL,'Networking',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6215',3,3,'4G USB Modem','Portable internet access device.','2500','Malaba','https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Hot',90,4.6,NULL,'Networking',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6216',3,3,'Electric Kettle 2L','Fast boiling electric kettle for daily use.','1800','Malaba','https://images.unsplash.com/photo-1546182990-dffeafbe841d?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',140,4.6,NULL,'Appliances',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6217',3,3,'Mika Electric Kettle','Energy efficient electric kettle.','2200','Malaba','https://images.unsplash.com/photo-1563297007-0686b7003af7?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',110,4.5,NULL,'Appliances',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6218',3,3,'Ramtons Blender','Heavy duty kitchen blender suitable for families.','3800','Malaba','https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',90,4.7,NULL,'Appliances',NULL,1,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6219',3,3,'Mika Blender','Reliable blender for juices and smoothies.','3200','Malaba','https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',76,4.5,NULL,'Appliances',NULL,0,0,'2026-06-15 21:36:57','2026-06-17 15:17:03'),('i6220',3,3,'Electric Iron Box','Non-stick soleplate iron box.','1500','Malaba','https://images.unsplash.com/photo-1545173168-9f1947eebb7f?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Hot',165,4.7,NULL,'Appliances',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6221',3,3,'Ramtons Microwave Oven','20L microwave for home cooking.','9500','Malaba','https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',70,4.8,NULL,'Appliances',NULL,1,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6222',3,3,'Portable Electric Cooker','Single burner electric cooker.','2800','Malaba','https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',88,4.5,NULL,'Appliances',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6223',3,3,'Electric Pressure Cooker','Modern cooker with multiple cooking modes.','10500','Malaba','https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Premium',40,4.9,NULL,'Appliances',NULL,1,1,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6224',3,3,'Rice Cooker 1.8L','Automatic rice cooker for everyday use.','3500','Malaba','https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',66,4.6,NULL,'Appliances',NULL,0,0,'2026-06-15 21:36:57','2026-06-17 07:32:13'),('i6225',3,3,'Electric Water Dispenser','Hot and cold water dispenser.','12000','Malaba','https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',50,4.7,NULL,'Appliances',NULL,1,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6226',3,3,'Mini Refrigerator','Compact fridge ideal for small spaces.','18000','Malaba','https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Premium',40,4.8,NULL,'Appliances',NULL,1,1,'2026-06-15 21:36:57','2026-06-17 16:25:33'),('i6227',3,3,'Standing Fan','Powerful cooling fan with adjustable height.','4500','Malaba','https://images.unsplash.com/photo-1597524678053-5f2c0c0f9f1b?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',85,4.6,NULL,'Appliances',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6228',3,3,'Table Fan','Compact and energy efficient fan.','2500','Malaba','https://images.unsplash.com/photo-1597524678053-5f2c0c0f9f1b?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',45,4.4,NULL,'Appliances',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6229',3,3,'Electric Toaster','2-slice bread toaster.','2200','Malaba','https://images.unsplash.com/photo-1583865348208-27c19db4b7f2?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',30,4.4,NULL,'Appliances',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6230',3,3,'Sandwich Maker','Easy breakfast sandwich maker.','2700','Malaba','https://images.unsplash.com/photo-1583865348208-27c19db4b7f2?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',22,4.5,NULL,'Appliances',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6231',3,3,'Vacuum Cleaner','Compact home vacuum cleaner.','8500','Malaba','https://images.unsplash.com/photo-1558317374-067fb5f30001?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',20,4.7,NULL,'Appliances',NULL,1,0,'2026-06-15 21:36:57','2026-06-16 05:10:51'),('i6232',3,3,'Electric Meat Grinder','Heavy duty kitchen grinder.','6200','Malaba','https://images.unsplash.com/photo-1556909212-d5b604d0c90d?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',14,4.6,NULL,'Appliances',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6233',3,3,'Food Processor','Multi-function kitchen appliance.','9500','Malaba','https://images.unsplash.com/photo-1556909212-d5b604d0c90d?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',11,4.8,NULL,'Appliances',NULL,1,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6234',3,3,'Portable Air Fryer','Healthy oil-free cooking appliance.','12500','Malaba','https://images.unsplash.com/photo-1626201850129-4d8a0f3e07e4?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Premium',29,4.9,NULL,'Appliances',NULL,1,1,'2026-06-15 21:36:57','2026-06-16 05:11:10'),('i6235',3,3,'Electric Coffee Maker','Automatic coffee maker for home and office.','6800','Malaba','https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',19,4.7,NULL,'Appliances',NULL,0,0,'2026-06-15 21:36:57','2026-06-16 05:10:42'),('i6236',3,3,'6 Way Extension Cable','Heavy duty surge protected extension cable.','1200','Malaba','https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',121,4.6,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-17 16:25:23'),('i6237',3,3,'4 Way Extension Cable','Quality extension cable for home and office.','850','Malaba','https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',90,4.4,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6238',3,3,'LED Bulb 12W','Energy saving LED bulb.','250','Malaba','https://images.unsplash.com/photo-1531854716290-a0e4cfe4fd6a?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',150,4.7,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6239',3,3,'LED Bulb 18W','Bright energy efficient bulb.','350','Malaba','https://images.unsplash.com/photo-1531854716290-a0e4cfe4fd6a?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Hot',130,4.8,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6240',3,3,'LED Flood Light 50W','Outdoor security floodlight.','1800','Malaba','https://images.unsplash.com/photo-1513694203232-719a280e022f?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',81,4.7,NULL,'Electrical',NULL,1,0,'2026-06-15 21:40:41','2026-06-17 10:50:14'),('i6241',3,3,'LED Flood Light 100W','Powerful outdoor lighting.','2800','Malaba','https://images.unsplash.com/photo-1513694203232-719a280e022f?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',70,4.8,NULL,'Electrical',NULL,1,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6242',3,3,'Wall Socket Double','Durable wall power socket.','450','Malaba','https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',45,4.3,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6243',3,3,'Circuit Breaker 32A','Reliable electrical protection device.','850','Malaba','https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',60,4.5,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6244',3,3,'Voltage Protector','Protect appliances from power surges.','1200','Malaba','https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Hot',95,4.7,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6245',3,3,'Digital Multimeter','Professional electrical testing meter.','1800','Malaba','https://images.unsplash.com/photo-1504222490345-c075b2f5c058?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',55,4.8,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6246',3,3,'Electric Tester Screwdriver','Voltage testing screwdriver.','250','Malaba','https://images.unsplash.com/photo-1504222490345-c075b2f5c058?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',30,4.2,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6247',3,3,'Electrical Tape Pack','Insulation tape for wiring.','120','Malaba','https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',40,4.3,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6248',3,3,'Solar Lamp','Rechargeable solar lighting solution.','2500','Malaba','https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Hot',88,4.7,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6249',3,3,'Rechargeable Lantern','Portable emergency lighting.','1800','Malaba','https://images.unsplash.com/photo-1558618047-3c8c76ca5d8f?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',92,4.6,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6250',3,3,'Electric Door Bell','Simple home doorbell system.','650','Malaba','https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',20,4.2,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6251',3,3,'PVC Electrical Conduit','Protective conduit pipe.','350','Malaba','https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',12,4.1,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6252',3,3,'Electrical Junction Box','Quality wiring junction box.','450','Malaba','https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',10,4.0,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6253',3,3,'Electric Cable 1.5mm','Domestic wiring cable.','5500','Malaba','https://images.unsplash.com/photo-1543286386-713bdd548da4?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',15,4.5,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6254',3,3,'Electric Cable 2.5mm','Heavy duty wiring cable.','7500','Malaba','https://images.unsplash.com/photo-1543286386-713bdd548da4?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',18,4.6,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6255',3,3,'LED Tube Light','Bright office lighting.','850','Malaba','https://images.unsplash.com/photo-1531854716290-a0e4cfe4fd6a?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',20,4.4,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6256',3,3,'Solar Street Light','Outdoor solar-powered light.','12500','Malaba','https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Premium',30,4.9,NULL,'Electrical',NULL,1,1,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6257',3,3,'Portable Generator 1kVA','Backup power solution.','38000','Malaba','https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Premium',15,4.8,NULL,'Electrical',NULL,1,1,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6258',3,3,'Automatic Changeover Switch','Reliable generator switching.','3500','Malaba','https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',12,4.6,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6259',3,3,'LED Ceiling Panel','Modern ceiling lighting.','1800','Malaba','https://images.unsplash.com/photo-1531854716290-a0e4cfe4fd6a?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',15,4.4,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6260',3,3,'Motion Sensor Light','Automatic sensor security light.','2800','Malaba','https://images.unsplash.com/photo-1513694203232-719a280e022f?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Hot',40,4.7,NULL,'Electrical',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6261',3,3,'4 Camera CCTV Kit','Complete HD CCTV surveillance package.','18000','Malaba','https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',96,4.8,NULL,'Security',NULL,1,1,'2026-06-15 21:40:41','2026-06-16 15:16:39'),('i6262',3,3,'8 Camera CCTV Kit','Professional CCTV monitoring system.','32000','Malaba','https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Premium',57,4.9,NULL,'Security',NULL,1,1,'2026-06-15 21:40:41','2026-06-16 19:31:28'),('i6263',3,3,'Wireless CCTV Camera','Easy installation WiFi camera.','4500','Malaba','https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',88,4.6,NULL,'Security',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6275',3,3,'Smart Door Lock','Fingerprint and password door lock.','12500','Malaba','https://images.unsplash.com/photo-1558618047-3c8c76ca5d8f?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Premium',19,4.8,NULL,'Security',NULL,1,1,'2026-06-15 21:40:41','2026-06-16 04:14:50'),('i6276',3,3,'JBL Bluetooth Speaker','Portable speaker with deep bass.','3800','Malaba','https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',121,4.8,NULL,'Audio',NULL,1,0,'2026-06-15 21:40:41','2026-06-17 05:30:47'),('i6277',3,3,'Oraimo Bluetooth Speaker','Affordable portable speaker.','2500','Malaba','https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',96,4.6,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-17 15:21:47'),('i6278',3,3,'JBL Headphones','High-quality over-ear headphones.','5500','Malaba','https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',77,4.8,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-17 10:51:29'),('i6279',3,3,'Oraimo Earbuds','Wireless earbuds with charging case.','1800','Malaba','https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',135,4.7,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6280',3,3,'Sony Home Theatre','Powerful surround sound system.','28500','Malaba','https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Premium',22,4.9,NULL,'Audio',NULL,1,1,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6281',3,3,'Wireless Microphone','Perfect for events and karaoke.','2800','Malaba','https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',40,4.5,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6282',3,3,'Portable PA Speaker','Rechargeable public address speaker.','12000','Malaba','https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',55,4.7,NULL,'Audio',NULL,1,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6283',3,3,'Computer Speakers','Stereo speakers for desktop PCs.','1800','Malaba','https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',45,4.5,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6284',3,3,'Soundbar Speaker','Enhance your TV audio experience.','8500','Malaba','https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',36,4.8,NULL,'Audio',NULL,1,0,'2026-06-15 21:40:41','2026-06-17 19:17:28'),('i6285',3,3,'DJ Mixer','Professional audio mixing equipment.','14500','Malaba','https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Premium',13,4.9,NULL,'Audio',NULL,1,1,'2026-06-15 21:40:41','2026-06-16 04:23:05'),('i6286',3,3,'Studio Microphone','Clear voice recording microphone.','4500','Malaba','https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',18,4.7,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6287',3,3,'Bluetooth Neckband','Comfortable wireless audio device.','1500','Malaba','https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',66,4.5,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-17 01:33:13'),('i6288',3,3,'Subwoofer System','Powerful bass speaker system.','22000','Malaba','https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',28,4.8,NULL,'Audio',NULL,1,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6289',3,3,'Portable Megaphone','Ideal for schools and events.','3200','Malaba','https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',11,4.4,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-17 15:21:56'),('i6290',3,3,'Car Bluetooth FM Transmitter','Wireless car audio accessory.','1200','Malaba','https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',15,4.3,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6291',3,3,'USB Sound Card','Audio enhancement accessory.','900','Malaba','https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',12,4.2,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6292',3,3,'Conference Speakerphone','Ideal for online meetings.','6500','Malaba','https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',14,4.7,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6293',3,3,'Gaming Headset','Comfortable headset with microphone.','3500','Malaba','https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Popular',30,4.6,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6294',3,3,'Portable Voice Recorder','Digital audio recording device.','4200','Malaba','https://images.unsplash.com/photo-1478737270239-2f02b77fc618?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'New',8,4.5,NULL,'Audio',NULL,0,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i6295',3,3,'Bluetooth Party Speaker','Large speaker with LED lights.','14500','Malaba','https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&q=80&auto=format&fit=crop','','0747501436','Mugumoini',1,'Featured',50,4.8,NULL,'Audio',NULL,1,0,'2026-06-15 21:40:41','2026-06-16 04:13:27'),('i63',2,3,'3D marble wallpaper','','1000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778921227/acnthwt3wj8t0gqfsjuf.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-16 08:47:15','2026-06-15 12:23:16'),('i65',2,3,'hp laptop','affordable','20000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778752971/nryr3vuaijwlqnlycyif.jpg','','254743050062','Gidee enterprise',1,NULL,0,NULL,NULL,'Electronics',NULL,0,0,'2026-05-14 07:40:14','2026-06-15 12:22:27'),('i67',2,3,'hisense microwave','low energy consumption','3000','roadlock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778751557/wvt4lih54ejfupzllykh.jpg','https://res.cloudinary.com/dsqo3yxkz/video/upload/v1781400840/vtmwzrt8dwaagtrkwwpo.mp4','254743050062','Gidee enterprise',1,'',0,NULL,NULL,'Electronics',NULL,0,0,'2026-05-14 07:33:12','2026-06-15 12:22:27'),('i70',2,3,'gas cooker','affordable\r\n2 burner','sh 3000','roadlock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778765627/gf8qbpidbhxcll0swpxz.jpg','','254743050061','Mugumoini',1,NULL,0,NULL,NULL,'Electronics',NULL,0,0,'2026-05-14 13:33:51','2026-06-15 12:13:11'),('i7001',3,3,'24 Piece Stainless Steel Cutlery Set','Elegant stainless steel cutlery set ideal for modern homes and gifting.','2500','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781697278/d4gx0d5z3mvffsq5doqt.jpg','','0747501436','Mama Vyombo',1,'Featured',120,4.8,NULL,'Cutlery',NULL,1,0,'2026-06-16 09:44:16','2026-06-17 11:54:42'),('i7002',3,3,'Stainless Steel Spoon Set','Durable everyday dining spoon set for family use.','850','Malaba','https://source.unsplash.com/600x400/?spoons','','0747501436','Mama Vyombo',1,'Popular',85,4.6,NULL,'Cutlery',NULL,0,0,'2026-06-16 09:44:16','2026-06-16 09:44:16'),('i7003',3,3,'Stainless Steel Fork Set','Premium rust-resistant fork set.','850','Malaba','https://source.unsplash.com/600x400/?forks','','0747501436','Mama Vyombo',1,'Popular',65,4.5,NULL,'Cutlery',NULL,0,0,'2026-06-16 09:44:16','2026-06-16 09:44:16'),('i7004',3,3,'Kitchen Knife Set','Professional kitchen knife set with wooden block.','2800','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781697240/goxxivtgafk352cvqdlf.jpg','','0747501436','Mama Vyombo',1,'Featured',92,4.7,NULL,'Kitchen Tools',NULL,1,0,'2026-06-16 09:44:16','2026-06-17 11:54:03'),('i7005',3,3,'Wooden Cooking Spoon Set','Traditional wooden cooking spoons for African kitchens.','650','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781697193/h4dfqlxihlnocbyhkq3f.jpg','','0747501436','Mama Vyombo',1,'Popular',76,4.5,NULL,'Utensils',NULL,0,0,'2026-06-16 09:44:16','2026-06-17 11:53:15'),('i7006',3,3,'Silicone Spatula Set','Heat resistant spatulas suitable for non-stick cookware.','1200','Malaba','https://source.unsplash.com/600x400/?spatula','','0747501436','Mugumoini',1,'New',31,4.4,NULL,'Utensils',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 01:51:43'),('i7007',3,3,'Vegetable Peeler','Sharp and durable peeler for daily kitchen use.','250','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781697142/rpxxltiuzehhlx87x8kg.jpg','','0747501436','Mugumoini',1,'Popular',40,4.3,NULL,'Kitchen Tools',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 11:52:23'),('i7008',3,3,'Kitchen Grater','Multi-purpose grater for vegetables and cheese.','550','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781697117/ls0agrxeajytlew5kmoq.jpg','','0747501436','Mugumoini',1,'New',22,4.2,NULL,'Kitchen Tools',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 11:51:59'),('i7009',3,3,'Large Chopping Board','Food-grade chopping board for meat and vegetables.','850','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781697092/t40lqwxdjlbp95eh3d1n.jpg','','0747501436','Mugumoini',1,'Popular',44,4.5,NULL,'Kitchen Tools',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 11:51:33'),('i7010',3,3,'Food Storage Container Set','Airtight storage containers for kitchen organization.','1800','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781697064/o2h9ezobkxho4vteuwts.jpg','','0747501436','Mugumoini',1,'Featured',75,4.7,NULL,'Storage',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 11:51:05'),('i7011',3,3,'Glass Storage Jar Set','Beautiful kitchen jars for sugar, tea and spices.','2200','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781697028/okpj1o0ivt2sjn3uqohv.jpg','','0747501436','Mugumoini',1,'Featured',64,4.8,NULL,'Storage',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 11:50:30'),('i7012',3,3,'Spice Rack Organizer','Stylish spice organizer rack.','2500','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781697002/xzn0yks74aowqbr0eqmx.jpg','','0747501436','Mugumoini',1,'Popular',50,4.6,NULL,'Storage',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 11:50:03'),('i7013',3,3,'Dish Drying Rack','Space-saving dish drying rack.','3200','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696964/q7x0v3f0fet4mynzf5rn.jpg','','0747501436','Mugumoini',1,'Featured',55,4.7,NULL,'Kitchen Organizers',NULL,1,0,'2026-06-16 09:50:51','2026-06-17 11:49:27'),('i7014',3,3,'Ceramic Dinner Plate Set','Premium ceramic plates suitable for modern homes.','3500','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696918/ey439canhbnasm68exya.jpg','','0747501436','Mugumoini',1,'Featured',111,4.8,NULL,'Dining Sets',NULL,1,0,'2026-06-16 09:50:51','2026-06-17 15:19:46'),('i7015',3,3,'Soup Bowl Set','Elegant bowl set for family meals.','2200','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696885/o0xfpvwhkbvjeyawso24.jpg','','0747501436','Mugumoini',1,'Popular',61,4.5,NULL,'Dining Sets',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 15:19:52'),('i7016',3,3,'Glass Drinking Set','6-piece premium drinking glass set.','1800','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696857/hbsqrmwollz6aqmbv0yf.jpg','','0747501436','Mugumoini',1,'Popular',96,4.6,NULL,'Dining Sets',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 15:19:39'),('i7017',3,3,'Coffee Mug Set','Elegant ceramic coffee mug set.','1500','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696835/geoiyr31303yn6w4ivde.jpg','','0747501436','Mugumoini',1,'New',46,4.4,NULL,'Dining Sets',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 15:20:01'),('i7018',3,3,'Serving Tray Set','Beautiful serving trays for guests.','1600','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696806/knupc5hj6fiw9q8ytkwu.jpg','','0747501436','Mugumoini',1,'Popular',58,4.5,NULL,'Dining Sets',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 11:46:53'),('i7019',3,3,'Water Jug Set','Water jug with matching drinking glasses.','2200','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696772/whzpwvlyvkaww5at83tu.jpg','','0747501436','Mugumoini',1,'Featured',70,4.7,NULL,'Dining Sets',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 11:46:14'),('i7020',3,3,'Non-Stick Frying Pan','High quality non-stick frying pan.','2200','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696739/odcbpgy26irtupypwxc0.jpg','','0747501436','Mugumoini',1,'Hot',145,4.8,NULL,'Cookware',NULL,1,0,'2026-06-16 09:50:51','2026-06-17 11:45:41'),('i7021',3,3,'5 Piece Cooking Pot Set','Durable stainless steel cooking pots.','6800','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696705/w6ct3ekruhxqsljkf4ba.jpg','','0747501436','Mugumoini',1,'Hot',192,4.9,NULL,'Cookware',NULL,1,1,'2026-06-16 09:50:51','2026-06-17 19:18:39'),('i7022',3,3,'Pressure Cooker 7L','Energy-saving pressure cooker.','5500','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696672/aizmlkzwuimxde4ittfq.jpg','','0747501436','Mugumoini',1,'Featured',130,4.8,NULL,'Cookware',NULL,1,0,'2026-06-16 09:50:51','2026-06-17 11:44:34'),('i7023',3,3,'Tea Kettle','Modern stainless steel tea kettle.','1800','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696644/bkx17m9fzn7xfwbokm2i.jpg','','0747501436','Mugumoini',1,'Popular',81,4.5,NULL,'Cookware',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 15:20:51'),('i7024',3,3,'Kitchen Organizer Shelf','Multi-tier kitchen storage shelf.','4500','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696614/anotmvoa8yvfnkqfwblx.jpg','','0747501436','Mugumoini',1,'Featured',60,4.7,NULL,'Kitchen Organizers',NULL,1,0,'2026-06-16 09:50:51','2026-06-17 11:43:36'),('i7025',3,3,'Kitchen Waste Bin','Stylish covered kitchen dustbin.','1200','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696544/ngwpn1u5vnqusysixfbo.jpg','','0747501436','Mugumoini',1,'Popular',50,4.4,NULL,'Kitchen Organizers',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 11:42:26'),('i7026',3,3,'Kitchen Apron Set','Elegant cooking apron with pockets.','750','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696448/smrsxx3phey5wxbzwpj8.jpg','','0747501436','Mugumoini',1,'New',25,4.3,NULL,'Accessories',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 11:40:50'),('i7027',3,3,'Dining Table Mat Set','Decorative dining mats for modern homes.','950','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696398/cclmywwxeqyhp69lslyi.jpg','','0747501436','Mugumoini',1,'Popular',46,4.4,NULL,'Accessories',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 14:07:58'),('i7028',3,3,'Oil Dispenser Bottle Set','Premium oil and vinegar dispenser set.','1200','Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781696357/laiwnlbeyyfm1gsucx1y.jpg','','0747501436','Mugumoini',1,'New',28,4.3,NULL,'Accessories',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 11:39:21'),('i7029',3,3,'Mortar and Pestle','Traditional African kitchen grinding set.','950','Malaba','https://source.unsplash.com/600x400/?mortar-pestle','','0747501436','Mugumoini',1,'Popular',73,4.6,NULL,'Traditional Kitchen',NULL,0,0,'2026-06-16 09:50:51','2026-06-17 05:31:42'),('i71',2,3,'3D wall stickers','','400','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778921435/cvamf3gnncawws4nmrwr.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-16 08:50:39','2026-06-15 12:22:27'),('i7101',2,3,'Silk Pillowcase','Luxury silk pillowcase that helps protect hair and skin while sleeping.','1200','Malaba','https://images.pexels.com/photos/4210331/pexels-photo-4210331.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Featured',50,4.9,NULL,'Beauty Accessories',NULL,1,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7102',2,3,'Ice Face Roller','Cooling facial roller for reducing puffiness and refreshing skin.','950','Malaba','https://images.pexels.com/photos/5938583/pexels-photo-5938583.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Hot',35,4.8,NULL,'Skincare',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7103',2,3,'Satin Hair Wrap','Premium satin wrap that prevents hair breakage.','450','Malaba','https://images.pexels.com/photos/7262446/pexels-photo-7262446.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Popular',28,4.7,NULL,'Hair Care',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7104',2,3,'Foot Peel Mask','Exfoliating foot mask for soft and smooth feet.','650','Malaba','https://images.pexels.com/photos/716411/pexels-photo-716411.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'New',15,4.6,NULL,'Personal Care',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7105',2,3,'LED Makeup Mirror','Rechargeable mirror with adjustable LED lighting.','2499','Malaba','https://images.pexels.com/photos/6621307/pexels-photo-6621307.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Featured',40,4.9,NULL,'Beauty Accessories',NULL,1,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7106',2,3,'Facial Steamer','Portable facial steamer for deep cleansing.','2800','Malaba','https://images.pexels.com/photos/7262961/pexels-photo-7262961.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Premium',22,4.8,NULL,'Skincare',NULL,1,1,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7107',2,3,'Jade Roller Set','Natural jade facial massage roller.','850','Malaba','https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Popular',18,4.7,NULL,'Skincare',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7108',2,3,'Heatless Curling Ribbon','Create curls overnight without heat damage.','799','Malaba','https://images.pexels.com/photos/7263013/pexels-photo-7263013.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Trending',30,4.8,NULL,'Hair Care',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7109',2,3,'Portable Jewelry Organizer','Travel-friendly jewelry storage case.','1200','Malaba','https://images.pexels.com/photos/3738096/pexels-photo-3738096.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Featured',25,4.7,NULL,'Accessories',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7110',2,3,'Reusable Makeup Remover Pads','Eco-friendly washable makeup remover pads.','550','Malaba','https://images.pexels.com/photos/4041386/pexels-photo-4041386.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Hot',20,4.7,NULL,'Beauty Accessories',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7111',2,3,'Electric Eyebrow Trimmer','Rechargeable eyebrow shaping trimmer.','999','Malaba','https://images.pexels.com/photos/3762800/pexels-photo-3762800.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Popular',21,4.6,NULL,'Beauty Tools',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7112',2,3,'Rose Quartz Face Roller','Premium facial massage tool.','950','Malaba','https://images.pexels.com/photos/4041391/pexels-photo-4041391.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Featured',24,4.8,NULL,'Skincare',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7113',2,3,'Mini Perfume Atomizer','Refillable pocket perfume spray bottle.','450','Malaba','https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'New',12,4.5,NULL,'Beauty Accessories',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7114',2,3,'Hair Scalp Massager','Silicone scalp massage brush.','650','Malaba','https://images.pexels.com/photos/6621308/pexels-photo-6621308.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Popular',17,4.6,NULL,'Hair Care',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7115',2,3,'Under Eye Gel Masks','Hydrating eye masks for reducing dark circles.','799','Malaba','https://images.pexels.com/photos/7262973/pexels-photo-7262973.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Trending',16,4.7,NULL,'Skincare',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7116',2,3,'Portable Nail Dryer','USB powered nail polish dryer.','1350','Malaba','https://images.pexels.com/photos/6621306/pexels-photo-6621306.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Featured',15,4.7,NULL,'Beauty Tools',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7117',2,3,'Silicone Face Cleansing Brush','Soft facial cleansing brush for deep cleaning.','950','Malaba','https://images.pexels.com/photos/4041395/pexels-photo-4041395.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Popular',18,4.8,NULL,'Skincare',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7118',2,3,'Travel Cosmetic Organizer','Waterproof cosmetic storage bag.','899','Malaba','https://images.pexels.com/photos/3738092/pexels-photo-3738092.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Featured',22,4.8,NULL,'Beauty Accessories',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7119',2,3,'LED Selfie Ring Light','Rechargeable selfie light for content creators.','1499','Malaba','https://images.pexels.com/photos/6621251/pexels-photo-6621251.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Hot',40,4.9,NULL,'Accessories',NULL,1,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7120',2,3,'Hair Wax Stick','Smooths flyaways and edges instantly.','350','Malaba','https://images.pexels.com/photos/7262968/pexels-photo-7262968.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Trending',35,4.8,NULL,'Hair Care',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7121',2,3,'Mini Handheld Fan','Rechargeable beauty and travel fan.','850','Malaba','https://images.pexels.com/photos/7262965/pexels-photo-7262965.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Popular',18,4.6,NULL,'Lifestyle',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7122',2,3,'Neck Beauty Pillow','Special pillow designed for beauty sleep.','2200','Malaba','https://images.pexels.com/photos/4210334/pexels-photo-4210334.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Premium',12,4.8,NULL,'Lifestyle',NULL,0,1,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7123',2,3,'Hydrating Lip Sleeping Mask','Overnight lip treatment mask.','750','Malaba','https://images.pexels.com/photos/4041389/pexels-photo-4041389.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Featured',20,4.9,NULL,'Skincare',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7124',2,3,'Portable Facial Mister','Rechargeable facial hydration spray.','1299','Malaba','https://images.pexels.com/photos/5938575/pexels-photo-5938575.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Hot',25,4.8,NULL,'Skincare',NULL,0,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7125',2,3,'Velvet Jewelry Box','Elegant jewelry organizer with mirror.','1850','Malaba','https://images.pexels.com/photos/3738098/pexels-photo-3738098.jpeg',NULL,'0747501436','Zuri Beauty Shop',1,'Featured',30,4.9,NULL,'Accessories',NULL,1,0,'2026-06-17 15:50:48','2026-06-17 16:23:51'),('i7201',2,3,'Ladies Handbag','Stylish everyday handbag with multiple compartments.','1999','Malaba','https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg',NULL,'0747501436','Mercy Beauty',1,'Featured',87,4.8,NULL,'Fashion',NULL,1,0,'2026-06-17 16:14:15','2026-06-17 19:00:50'),('i7202',2,3,'Body Lotion','Moisturizing body lotion for daily skincare.','450','Malaba','https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg',NULL,'0747501436','Mercy Beauty',1,'Popular',60,4.7,NULL,'Beauty',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7203',2,3,'Lip Gloss','Long-lasting lip gloss with natural shine.','350','Malaba','https://images.pexels.com/photos/3373739/pexels-photo-3373739.jpeg',NULL,'0747501436','Mercy Beauty',1,'New',40,4.6,NULL,'Beauty',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7204',2,3,'Hair Bonnet','Satin bonnet for hair protection while sleeping.','300','Malaba','https://images.pexels.com/photos/8534273/pexels-photo-8534273.jpeg',NULL,'0747501436','Mercy Beauty',1,'Popular',55,4.7,NULL,'Hair Care',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7205',2,3,'Sanitary Pads Pack','Comfortable sanitary pads for everyday protection.','180','Malaba','https://images.pexels.com/photos/8139364/pexels-photo-8139364.jpeg',NULL,'0747501436','Mercy Beauty',1,'Hot',90,4.9,NULL,'Personal Care',NULL,1,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7206',2,3,'Ladies Wallet','Compact wallet with card and cash compartments.','850','Malaba','https://images.pexels.com/photos/2081199/pexels-photo-2081199.jpeg',NULL,'0747501436','Mercy Beauty',1,'Featured',40,4.6,NULL,'Fashion',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7207',2,3,'Facial Cleanser','Gentle facial cleanser suitable for daily use.','650','Malaba','https://images.pexels.com/photos/4041391/pexels-photo-4041391.jpeg',NULL,'0747501436','Mercy Beauty',1,'Featured',45,4.8,NULL,'Beauty',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7208',2,3,'Perfume Spray','Long-lasting ladies perfume.','1200','Malaba','https://images.pexels.com/photos/965990/pexels-photo-965990.jpeg',NULL,'0747501436','Mercy Beauty',1,'Popular',80,4.8,NULL,'Beauty',NULL,1,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7209',2,3,'Makeup Bag','Portable cosmetic storage pouch.','500','Malaba','https://images.pexels.com/photos/3373745/pexels-photo-3373745.jpeg',NULL,'0747501436','Mercy Beauty',1,'New',25,4.5,NULL,'Beauty',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7210',2,3,'Hair Brush','Professional detangling hair brush.','350','Malaba','https://images.pexels.com/photos/6621307/pexels-photo-6621307.jpeg',NULL,'0747501436','Mercy Beauty',1,'Popular',30,4.6,NULL,'Hair Care',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7211',2,3,'Ladies Sandals','Comfortable flat sandals for everyday wear.','1500','Malaba','https://images.pexels.com/photos/1488463/pexels-photo-1488463.jpeg',NULL,'0747501436','Mercy Beauty',1,'Featured',75,4.7,NULL,'Footwear',NULL,1,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7212',2,3,'Nail Polish Set','Colorful nail polish collection.','550','Malaba','https://images.pexels.com/photos/4587665/pexels-photo-4587665.jpeg',NULL,'0747501436','Mercy Beauty',1,'New',35,4.5,NULL,'Beauty',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7213',2,3,'Ladies Sunglasses','Fashionable UV-protected sunglasses.','899','Malaba','https://images.pexels.com/photos/701877/pexels-photo-701877.jpeg',NULL,'0747501436','Mercy Beauty',1,'Popular',29,4.6,NULL,'Accessories',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:20:31'),('i7214',2,3,'Body Mist','Refreshing body mist fragrance.','650','Malaba','https://images.pexels.com/photos/4041395/pexels-photo-4041395.jpeg',NULL,'0747501436','Mercy Beauty',1,'Hot',50,4.7,NULL,'Beauty',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7215',2,3,'Hair Oil','Nourishing hair oil for healthy hair growth.','450','Malaba','https://images.pexels.com/photos/4041383/pexels-photo-4041383.jpeg',NULL,'0747501436','Mercy Beauty',1,'Popular',45,4.8,NULL,'Hair Care',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:19:13'),('i7216',2,3,'Ladies Belt','Stylish adjustable fashion belt.','550','Malaba','https://images.unsplash.com/photo-1617112848920-5c8b5c5e5f5f?w=800&q=85',NULL,'0747501436','Mercy Beauty',1,'New',15,4.4,NULL,'Fashion',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:14:15'),('i7217',2,3,'Compact Mirror','Portable beauty mirror for handbags.','250','Malaba','https://images.unsplash.com/photo-1616394584738-9e6e5f5f5f5f?w=800&q=85',NULL,'0747501436','Mercy Beauty',1,'Popular',20,4.5,NULL,'Beauty',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:14:15'),('i7218',2,3,'Face Powder','Smooth finishing powder for daily makeup.','700','Malaba','https://images.unsplash.com/photo-1621351183012-e2f9972dd9bf?w=800&q=85',NULL,'0747501436','Mercy Beauty',1,'Featured',41,4.7,NULL,'Beauty',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:21:21'),('i7219',2,3,'Ladies Earrings','Elegant everyday earrings.','399','Malaba','https://images.unsplash.com/photo-1617112848920-5c8b5c5e5f5f?w=800&q=85',NULL,'0747501436','Mercy Beauty',1,'Popular',38,4.6,NULL,'Jewelry',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:14:15'),('i7220',2,3,'Shower Cap','Reusable waterproof shower cap.','200','Malaba','https://images.unsplash.com/photo-1583947215259-6f4d1d0f3e8e?w=800&q=85',NULL,'0747501436','Mercy Beauty',1,'New',12,4.3,NULL,'Personal Care',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:14:15'),('i7221',2,3,'Ladies Scarf','Soft fashionable scarf.','650','Malaba','https://images.unsplash.com/photo-1617112848920-5c8b5c5e5f5f?w=800&q=85',NULL,'0747501436','Mercy Beauty',1,'Featured',25,4.6,NULL,'Fashion',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:14:15'),('i7222',2,3,'Makeup Brushes Set','Professional makeup brush kit.','1200','Malaba','https://images.unsplash.com/photo-1622445275576-721325763afe?w=800&q=85',NULL,'0747501436','Mercy Beauty',1,'Featured',56,4.8,NULL,'Beauty',NULL,1,0,'2026-06-17 16:14:15','2026-06-17 16:21:13'),('i7223',2,3,'Ladies Wrist Watch','Elegant watch suitable for everyday use.','1999','Malaba','https://images.unsplash.com/photo-1524592094714-0f4f5c5f5f5f?w=800&q=85',NULL,'0747501436','Mercy Beauty',1,'Premium',65,4.9,NULL,'Accessories',NULL,1,1,'2026-06-17 16:14:15','2026-06-17 16:14:15'),('i7224',2,3,'Hair Clips Set','Fashion hair clips for styling.','250','Malaba','https://images.unsplash.com/photo-1617112848920-5c8b5c5e5f5f?w=800&q=85',NULL,'0747501436','Mercy Beauty',1,'New',18,4.4,NULL,'Hair Care',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:14:15'),('i7225',2,3,'Cotton Tote Bag','Reusable shopping and everyday carry bag.','650','Malaba','https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&q=85',NULL,'0747501436','Mercy Beauty',1,'Featured',42,4.7,NULL,'Fashion',NULL,0,0,'2026-06-17 16:14:15','2026-06-17 16:14:15'),('i74',2,3,'dishes','classic','sh 5000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778752649/bqvx8e2serk1bd3fiwnt.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 09:57:31','2026-06-15 12:13:11'),('i75',2,3,'Wireless Earbuds','Offer freedom and high-quality audio for music, calls, and gaming. The trend is toward dual-form earbuds (like the Soundcore AeroFit 2 Pro) that switch between open-ear and in-ear modes for situational awareness and noise cancellation.','999','Magharibi','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778607347/yvefbabfhysnlbmicjb0.jpg','','254743050061','Mugumoini',1,NULL,0,NULL,NULL,'Electronics',NULL,0,0,'2026-05-12 17:35:53','2026-06-15 12:16:47'),('i76',2,3,'puffy pillows','comfortable \r\nflufffy','850','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778751210/nyxdeyoesf4t8yu359qq.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 07:27:53','2026-06-15 12:23:04'),('i77',2,3,'Cooking tool set','Classic','2000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779189489/gphcddnj82ggupcau8ec.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-19 11:18:18','2026-06-15 12:22:27'),('i81',2,3,'Bathing towels','','900','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1779188132/k6i95v8epnhf7wi9emke.jpg','','0743050063','Malaba mtumba deals',1,NULL,0,NULL,NULL,'Electronics',NULL,0,0,'2026-05-19 11:03:22','2026-06-15 12:22:27'),('i82',2,3,'yum yum perfume','','sh 3000','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778767896/ceg921wennq6yusve1l7.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 14:11:40','2026-06-15 12:13:11'),('i84',2,3,'dinning table','6 set','40000','roadlock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778753045/gly0sspfy64v1oxu5slh.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 07:31:15','2026-06-15 12:22:27'),('i88',2,3,'Marble coffee table','2 in 1','8500','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778923191/l5eu0tz7oiffqpomoc8q.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-16 09:19:55','2026-06-15 12:22:27'),('i93',2,3,'eclaire perfume','sweet fragrance','2500','Roadblock','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778766134/asnb7uubeskzbpbfwv50.jpg','','0743050069','kanji decors',1,NULL,0,NULL,NULL,'Decors',NULL,0,0,'2026-05-14 13:42:36','2026-06-15 12:22:27'),('i98',2,3,'comfy sofa','comfortable\r\ndesigned','45000','near malaba market','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1778752120/agczbn97kevv8hquhiqi.jpg','','254743050061','Mugumoini',1,NULL,0,NULL,NULL,'Electronics',NULL,0,0,'2026-05-13 11:48:43','2026-06-15 12:22:27');
/*!40000 ALTER TABLE `listings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_status_history`
--

DROP TABLE IF EXISTS `order_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_status_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `old_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `changed_by` int DEFAULT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_status_history`
--

LOCK TABLES `order_status_history` WRITE;
/*!40000 ALTER TABLE `order_status_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_status_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_status_log`
--

DROP TABLE IF EXISTS `order_status_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_status_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `old_status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_status_log`
--

LOCK TABLES `order_status_log` WRITE;
/*!40000 ALTER TABLE `order_status_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_status_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int DEFAULT NULL,
  `order_ref` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('houses','food','items') COLLATE utf8mb4_unicode_ci NOT NULL,
  `listing_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `listing_title` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `listing_price` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_address` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id_no` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int DEFAULT '1',
  `unit_price` decimal(12,2) DEFAULT '0.00',
  `total_amount` decimal(12,2) DEFAULT '0.00',
  `payment_method` enum('cash','mpesa','cash_on_delivery','mpesa_on_delivery') COLLATE utf8mb4_unicode_ci DEFAULT 'cash',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','confirmed','processing','dispatched','delivered','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `payment_status` enum('pending','received','failed','refunded') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `delivered_at` timestamp NULL DEFAULT NULL,
  `wa_notified` tinyint(1) DEFAULT '0',
  `wa_last_msg` text COLLATE utf8mb4_unicode_ci,
  `wa_sent_at` timestamp NULL DEFAULT NULL,
  `handled_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_ref` (`order_ref`),
  KEY `category` (`category`),
  KEY `status` (`status`),
  KEY `payment_status` (`payment_status`),
  KEY `created_at` (`created_at`),
  KEY `listing_id` (`listing_id`),
  KEY `orders_admin_fk` (`handled_by`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `orders_admin_fk` FOREIGN KEY (`handled_by`) REFERENCES `admins` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_listing_fk` FOREIGN KEY (`listing_id`) REFERENCES `listings` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`id`, `customer_id`, `order_ref`, `category`, `listing_id`, `listing_title`, `listing_price`, `customer_name`, `customer_phone`, `customer_address`, `customer_id_no`, `quantity`, `unit_price`, `total_amount`, `payment_method`, `notes`, `status`, `payment_status`, `created_at`, `updated_at`, `delivered_at`, `wa_notified`, `wa_last_msg`, `wa_sent_at`, `handled_by`) VALUES (83,NULL,'MH-2026-0001','food','f68','ugali with beef stew','KSH 350','Jane','043050069','Roadblock','',1,0.00,350.00,'mpesa_on_delivery','Food order: ugali with beef stew, Chapati and Beans | Roadblock | mpesa','pending','pending','2026-06-12 10:50:33','2026-06-12 10:50:33',NULL,0,NULL,NULL,NULL),(84,NULL,'MH-2026-0084','items','i77','Cooking tool set','ksh 2000','Odiedo Paul','724818991','Uplands','',1,0.00,60000.00,'cash_on_delivery','Cart: Cooking tool set, hiscence fridge, Hp laptop | cash','pending','pending','2026-06-13 04:05:23','2026-06-13 04:05:23',NULL,0,NULL,NULL,NULL),(85,NULL,'MH-2026-0085','items','i103','Curated mirror','1,500','Patelo','724818991','00','',1,0.00,4500.00,'cash_on_delivery','Cart: Curated mirror, hisense microwave | cash','pending','pending','2026-06-13 04:32:59','2026-06-13 04:32:59',NULL,0,NULL,NULL,NULL),(87,NULL,'MH-2026-0086','items','i77','Cooking tool set','ksh 2000','Patelo','724818991','00','',1,0.00,7000.00,'cash_on_delivery','Cart: Cooking tool set, utencils rack | cash','pending','pending','2026-06-13 20:22:01','2026-06-13 20:22:01',NULL,0,NULL,NULL,NULL),(88,NULL,'MH-2026-0088','items','i54','Hp laptop','18000','Patelo','724818991','00','',1,0.00,18000.00,'cash_on_delivery','Direct buy — cash','pending','pending','2026-06-15 01:40:26','2026-06-15 01:40:26',NULL,0,NULL,NULL,NULL),(89,NULL,'MH-2026-0089','items','i6085','Dell Latitude 5400','28500','Patelo','724818991','00','',1,0.00,28500.00,'cash_on_delivery','Cart: Dell Latitude 5400 | 00 | cash','pending','pending','2026-06-17 01:53:11','2026-06-17 01:53:11',NULL,0,NULL,NULL,NULL),(90,NULL,'MH-2026-0090','items','i7027','Dining Table Mat Set','950','Patelo','724818991','00','',1,0.00,988.00,'mpesa','LIPA MDOGO MDOGO | Freq:Twice a week | 4 Weeks | Per:KSH 124 | Deposit:KSH 190 | Total:KSH 988 | Pay:mpesa | DELIVER AFTER FULL PAYMENT ONLY','pending','pending','2026-06-17 14:08:25','2026-06-17 14:08:25',NULL,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `before_order_insert` BEFORE INSERT ON `orders` FOR EACH ROW BEGIN
  IF NEW.order_ref IS NULL OR NEW.order_ref = '' THEN
    SET NEW.order_ref = CONCAT('MH-', YEAR(NOW()), '-', LPAD(
      (SELECT COALESCE(MAX(id),0)+1 FROM orders), 4, '0'
    ));
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_order_status_history` BEFORE UPDATE ON `orders` FOR EACH ROW BEGIN
  IF NEW.status <> OLD.status THEN
    INSERT INTO order_status_history (order_id, old_status, new_status)
    VALUES (OLD.id, OLD.status, NEW.status);
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `push_deliveries`
--

DROP TABLE IF EXISTS `push_deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `push_deliveries` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `notification_id` int unsigned NOT NULL,
  `subscriber_id` int unsigned NOT NULL,
  `status` enum('sent','delivered','clicked','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sent',
  `error_msg` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `clicked_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notif` (`notification_id`),
  KEY `idx_sub` (`subscriber_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_deliveries`
--

LOCK TABLES `push_deliveries` WRITE;
/*!40000 ALTER TABLE `push_deliveries` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_deliveries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_notifications`
--

DROP TABLE IF EXISTS `push_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `push_notifications` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `click_url` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'URL to open when notification tapped',
  `segment` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all' COMMENT 'Who it was sent to',
  `sent_count` int unsigned NOT NULL DEFAULT '0',
  `fail_count` int unsigned NOT NULL DEFAULT '0',
  `sent_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Admin username who sent it',
  `status` enum('draft','sending','sent','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `scheduled_at` datetime DEFAULT NULL COMMENT 'NULL = send immediately',
  `sent_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_segment` (`segment`),
  KEY `idx_sent_at` (`sent_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_notifications`
--

LOCK TABLES `push_notifications` WRITE;
/*!40000 ALTER TABLE `push_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_subscribers`
--

DROP TABLE IF EXISTS `push_subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `push_subscribers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'FCM device token',
  `platform` enum('android','ios','web') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'android',
  `segment` set('all','food','shop','homes','orders') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all' COMMENT 'Which types of notifications they care about',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Linked customer phone if known',
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_seen_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_token` (`token`(191)),
  KEY `idx_segment` (`segment`),
  KEY `idx_active` (`is_active`),
  KEY `idx_platform` (`platform`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_subscribers`
--

LOCK TABLES `push_subscribers` WRITE;
/*!40000 ALTER TABLE `push_subscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_subscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant_hours`
--

DROP TABLE IF EXISTS `restaurant_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurant_hours` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day_of_week` tinyint NOT NULL COMMENT '0=Sun, 1=Mon, ..., 6=Sat',
  `open_time` time DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `is_closed` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rest` (`restaurant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant_hours`
--

LOCK TABLES `restaurant_hours` WRITE;
/*!40000 ALTER TABLE `restaurant_hours` DISABLE KEYS */;
/*!40000 ALTER TABLE `restaurant_hours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant_images`
--

DROP TABLE IF EXISTS `restaurant_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurant_images` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rest` (`restaurant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant_images`
--

LOCK TABLES `restaurant_images` WRITE;
/*!40000 ALTER TABLE `restaurant_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `restaurant_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurants`
--

DROP TABLE IF EXISTS `restaurants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurants` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Restaurant display name e.g. Malaba Pizza House',
  `description` text COLLATE utf8mb4_unicode_ci,
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Restaurant cover photo',
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'WhatsApp number for orders',
  `contact_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Owner or manager name',
  `cuisine` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g. Pizza, Burgers, Local Food',
  `delivery_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g. 15-25 min',
  `rating` decimal(3,1) DEFAULT '4.5',
  `views` int unsigned DEFAULT '0',
  `total_orders` int unsigned DEFAULT '0',
  `is_open` tinyint(1) DEFAULT '1',
  `is_featured` tinyint(1) DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `opening_hours` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g. 7am - 10pm daily',
  `min_order` int DEFAULT '0' COMMENT 'Minimum order in KSH',
  `delivery_fee` int DEFAULT '50' COMMENT 'Delivery fee in KSH, 0 = free',
  `badge` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g. Popular, New, Top Rated',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_active` (`is_active`),
  KEY `idx_featured` (`is_featured`),
  KEY `idx_open` (`is_open`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurants`
--

LOCK TABLES `restaurants` WRITE;
/*!40000 ALTER TABLE `restaurants` DISABLE KEYS */;
INSERT INTO `restaurants` (`id`, `name`, `description`, `image_url`, `location`, `contact_phone`, `contact_name`, `cuisine`, `delivery_time`, `rating`, `views`, `total_orders`, `is_open`, `is_featured`, `is_active`, `opening_hours`, `min_order`, `delivery_fee`, `badge`, `created_at`, `updated_at`) VALUES ('r0','Eldo Cafe','Serving delicious food in Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1780758821/gfu1dgcabwohgubsoyvl.jpg','Malaba roadblock','0743050069','Mwangi','Local Food','10 - 15min',4.5,0,0,1,0,1,'6am - 12am',5,50,'','2026-06-06 06:42:22','2026-06-06 17:32:47'),('r103','Shiviling supermarket','Serving delicious food in Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1780779686/oy1z9iifapym58ujlrxy.jpg','Roadblock','0743050069','Shiviling','Supermarket','10 - 15min',4.5,0,0,1,0,1,'6am - 12am',1,50,'Hot deals','2026-06-06 06:42:22','2026-06-08 23:41:15'),('r29','Royal Food Court','Serving delicious food in Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781379429/ue2d05a30gdkeqsmsipl.jpg','Roadblock','0743050069','Hassan Chemos','Local Food','10 - 25min',4.5,0,0,1,0,1,'6am - 12am',1,50,'Popular','2026-06-06 06:42:22','2026-06-13 15:37:15'),('r54','winkers choma zone','Serving delicious food in Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781379604/wcdkxsspakkvmv64p0iv.jpg','Roadblock','0743050069','Mwangi','Local Food','10 - 25min',4.5,0,0,1,0,1,'6am - 12am',1,50,'Popular','2026-06-06 06:42:22','2026-06-13 15:40:48'),('r889','Holywood Hotel','Food is sweet and very affordable','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1780743973/hxdkerqn4ipxcc7v168e.jpg','Opposite Way Side','254747501436','Charlse','Local Food','15-25 min',4.5,0,0,1,0,1,'24Hours Daily',1,50,'Top Rated','2026-06-06 07:06:25','2026-06-08 09:42:00'),('rdefault','Junction Mall','Your local food spot in Malaba','https://res.cloudinary.com/dsqo3yxkz/image/upload/v1781379723/tpmaz4fxi4ucpng3sbh7.jpg','Malaba','254743050069','Charles','Local Food','10 - 15min',4.5,0,0,1,0,1,'6am - 12am',1,50,'Top','2026-06-06 06:47:31','2026-06-13 15:45:04');
/*!40000 ALTER TABLE `restaurants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sellers`
--

DROP TABLE IF EXISTS `sellers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sellers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `whatsapp` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shop_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shop_desc` text COLLATE utf8mb4_unicode_ci,
  `logo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `commission_pct` decimal(5,2) NOT NULL DEFAULT '10.00',
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_token` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sellers`
--

LOCK TABLES `sellers` WRITE;
/*!40000 ALTER TABLE `sellers` DISABLE KEYS */;
INSERT INTO `sellers` (`id`, `name`, `phone`, `whatsapp`, `email`, `shop_name`, `shop_desc`, `logo_url`, `is_active`, `is_verified`, `commission_pct`, `password_hash`, `session_token`, `created_at`) VALUES (1,'Njeri Rayhab','0747501436','0747501436','njeri@malabahomes.com','Malaba Homes','Local marketplace services.','https://malabahomes.com/uploads/logos/malabahomes.png',1,1,5.00,'$2y$10$examplehash001',NULL,'2026-06-14 15:11:17'),(2,'Odiedo Paul','0723456789','0723456789','odiedo@funcorpdevelopers.com','Fun-Corp Developers','Phone repairs, accessories, electronics and mobile devices.','https://malabahomes.com/logo.png',1,1,8.00,'$2y$10$examplehash002',NULL,'2026-06-14 15:11:17'),(3,'Grace Atieno','0712345678','0712345678','orders@graceskitchen.co.ke','Grace Kitchen','Restaurant offering food delivery, catering and local dishes.','https://malabahomes.com/uploads/logos/graceskitchen.png',1,0,10.00,'$2y$10$examplehash003',NULL,'2026-06-14 15:11:17');
/*!40000 ALTER TABLE `sellers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_log`
--

DROP TABLE IF EXISTS `sms_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'africastalking',
  `status` enum('sent','failed','queued') COLLATE utf8mb4_unicode_ci DEFAULT 'queued',
  `provider_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_log`
--

LOCK TABLES `sms_log` WRITE;
/*!40000 ALTER TABLE `sms_log` DISABLE KEYS */;
INSERT INTO `sms_log` (`id`, `order_id`, `phone`, `message`, `provider`, `status`, `provider_id`, `created_at`) VALUES (21,40,'+254743050069','Hi Odiedo Paul! ✅ Order MH-2026-0001 (Matoke) confirmed. We\'ll start preparing shortly. Track: malaba.co.ke/track?ref=MH-2026-0001','africastalking','sent','DEV-1780663402','2026-06-05 12:43:22');
/*!40000 ALTER TABLE `sms_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_dashboard_stats`
--

DROP TABLE IF EXISTS `v_dashboard_stats`;
/*!50001 DROP VIEW IF EXISTS `v_dashboard_stats`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_dashboard_stats` AS SELECT 
 1 AS `total_active`,
 1 AS `total_houses`,
 1 AS `total_food`,
 1 AS `total_items`,
 1 AS `inquiries_today`,
 1 AS `total_inquiries`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_food_items`
--

DROP TABLE IF EXISTS `v_food_items`;
/*!50001 DROP VIEW IF EXISTS `v_food_items`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_food_items` AS SELECT 
 1 AS `id`,
 1 AS `seller_id`,
 1 AS `category_id`,
 1 AS `title`,
 1 AS `description`,
 1 AS `price`,
 1 AS `location`,
 1 AS `image_url`,
 1 AS `video_url`,
 1 AS `contact_phone`,
 1 AS `contact_name`,
 1 AS `is_active`,
 1 AS `badge`,
 1 AS `views`,
 1 AS `rating`,
 1 AS `prep_time`,
 1 AS `sub_category`,
 1 AS `restaurant_id`,
 1 AS `is_featured`,
 1 AS `is_premium`,
 1 AS `created_at`,
 1 AS `updated_at`,
 1 AS `restaurant_name`,
 1 AS `restaurant_image`,
 1 AS `restaurant_cuisine`,
 1 AS `restaurant_delivery_time`,
 1 AS `restaurant_phone`,
 1 AS `restaurant_is_open`,
 1 AS `restaurant_rating`,
 1 AS `restaurant_is_featured`,
 1 AS `restaurant_total_orders`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_listings_full`
--

DROP TABLE IF EXISTS `v_listings_full`;
/*!50001 DROP VIEW IF EXISTS `v_listings_full`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_listings_full` AS SELECT 
 1 AS `id`,
 1 AS `category_id`,
 1 AS `title`,
 1 AS `description`,
 1 AS `price`,
 1 AS `location`,
 1 AS `image_url`,
 1 AS `contact_phone`,
 1 AS `contact_name`,
 1 AS `is_active`,
 1 AS `created_at`,
 1 AS `updated_at`,
 1 AS `category_slug`,
 1 AS `category_name`,
 1 AS `category_icon`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_orders_full`
--

DROP TABLE IF EXISTS `v_orders_full`;
/*!50001 DROP VIEW IF EXISTS `v_orders_full`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_orders_full` AS SELECT 
 1 AS `id`,
 1 AS `order_ref`,
 1 AS `category`,
 1 AS `listing_id`,
 1 AS `listing_title`,
 1 AS `listing_price`,
 1 AS `customer_name`,
 1 AS `customer_phone`,
 1 AS `customer_address`,
 1 AS `customer_id_no`,
 1 AS `quantity`,
 1 AS `unit_price`,
 1 AS `total_amount`,
 1 AS `payment_method`,
 1 AS `notes`,
 1 AS `status`,
 1 AS `payment_status`,
 1 AS `created_at`,
 1 AS `updated_at`,
 1 AS `delivered_at`,
 1 AS `wa_notified`,
 1 AS `wa_last_msg`,
 1 AS `wa_sent_at`,
 1 AS `handled_by`,
 1 AS `listing_image`,
 1 AS `category_name`,
 1 AS `category_icon`,
 1 AS `handled_by_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_restaurants`
--

DROP TABLE IF EXISTS `v_restaurants`;
/*!50001 DROP VIEW IF EXISTS `v_restaurants`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_restaurants` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `image_url`,
 1 AS `location`,
 1 AS `contact_phone`,
 1 AS `contact_name`,
 1 AS `cuisine`,
 1 AS `delivery_time`,
 1 AS `rating`,
 1 AS `views`,
 1 AS `total_orders`,
 1 AS `is_open`,
 1 AS `is_featured`,
 1 AS `is_active`,
 1 AS `opening_hours`,
 1 AS `min_order`,
 1 AS `delivery_fee`,
 1 AS `badge`,
 1 AS `created_at`,
 1 AS `updated_at`,
 1 AS `menu_item_count`,
 1 AS `order_count`,
 1 AS `computed_rating`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_sales_summary`
--

DROP TABLE IF EXISTS `v_sales_summary`;
/*!50001 DROP VIEW IF EXISTS `v_sales_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_sales_summary` AS SELECT 
 1 AS `sale_date`,
 1 AS `category`,
 1 AS `total_orders`,
 1 AS `delivered`,
 1 AS `cancelled`,
 1 AS `revenue`,
 1 AS `gmv`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_search`
--

DROP TABLE IF EXISTS `v_search`;
/*!50001 DROP VIEW IF EXISTS `v_search`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_search` AS SELECT 
 1 AS `id`,
 1 AS `title`,
 1 AS `description`,
 1 AS `location`,
 1 AS `price`,
 1 AS `image`,
 1 AS `badge`,
 1 AS `views`,
 1 AS `is_featured`,
 1 AS `created_at`,
 1 AS `type`,
 1 AS `category_name`,
 1 AS `category_icon`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'hukhbjpu_mh_portal_2026'
--

--
-- Dumping routines for database 'hukhbjpu_mh_portal_2026'
--

--
-- Current Database: `hukhbjpu_mh_portal_2026`
--


--
-- Final view structure for view `v_dashboard_stats`
--

/*!50001 DROP VIEW IF EXISTS `v_dashboard_stats`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_dashboard_stats` AS select (select count(0) from `listings` where (`listings`.`is_active` = 1)) AS `total_active`,(select count(0) from `listings` where ((`listings`.`category_id` = 1) and (`listings`.`is_active` = 1))) AS `total_houses`,(select count(0) from `listings` where ((`listings`.`category_id` = 2) and (`listings`.`is_active` = 1))) AS `total_food`,(select count(0) from `listings` where ((`listings`.`category_id` = 3) and (`listings`.`is_active` = 1))) AS `total_items`,(select count(0) from `inquiries` where (cast(`inquiries`.`created_at` as date) = curdate())) AS `inquiries_today`,(select count(0) from `inquiries`) AS `total_inquiries` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_food_items`
--

/*!50001 DROP VIEW IF EXISTS `v_food_items`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_food_items` AS select `l`.`id` AS `id`,`l`.`seller_id` AS `seller_id`,`l`.`category_id` AS `category_id`,`l`.`title` AS `title`,`l`.`description` AS `description`,`l`.`price` AS `price`,`l`.`location` AS `location`,`l`.`image_url` AS `image_url`,`l`.`video_url` AS `video_url`,`l`.`contact_phone` AS `contact_phone`,`l`.`contact_name` AS `contact_name`,`l`.`is_active` AS `is_active`,`l`.`badge` AS `badge`,`l`.`views` AS `views`,`l`.`rating` AS `rating`,`l`.`prep_time` AS `prep_time`,`l`.`sub_category` AS `sub_category`,`l`.`restaurant_id` AS `restaurant_id`,`l`.`is_featured` AS `is_featured`,`l`.`is_premium` AS `is_premium`,`l`.`created_at` AS `created_at`,`l`.`updated_at` AS `updated_at`,`r`.`name` AS `restaurant_name`,`r`.`image_url` AS `restaurant_image`,`r`.`cuisine` AS `restaurant_cuisine`,`r`.`delivery_time` AS `restaurant_delivery_time`,`r`.`contact_phone` AS `restaurant_phone`,`r`.`is_open` AS `restaurant_is_open`,`r`.`rating` AS `restaurant_rating`,`r`.`is_featured` AS `restaurant_is_featured`,`r`.`total_orders` AS `restaurant_total_orders` from (`listings` `l` left join `restaurants` `r` on((`r`.`id` = `l`.`restaurant_id`))) where ((`l`.`category_id` = 2) and (`l`.`is_active` = 1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_listings_full`
--

/*!50001 DROP VIEW IF EXISTS `v_listings_full`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_listings_full` AS select `l`.`id` AS `id`,`l`.`category_id` AS `category_id`,`l`.`title` AS `title`,`l`.`description` AS `description`,`l`.`price` AS `price`,`l`.`location` AS `location`,`l`.`image_url` AS `image_url`,`l`.`contact_phone` AS `contact_phone`,`l`.`contact_name` AS `contact_name`,`l`.`is_active` AS `is_active`,`l`.`created_at` AS `created_at`,`l`.`updated_at` AS `updated_at`,`c`.`slug` AS `category_slug`,`c`.`name` AS `category_name`,`c`.`icon` AS `category_icon` from (`listings` `l` join `categories` `c` on((`l`.`category_id` = `c`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_orders_full`
--

/*!50001 DROP VIEW IF EXISTS `v_orders_full`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_orders_full` AS select `o`.`id` AS `id`,`o`.`order_ref` AS `order_ref`,`o`.`category` AS `category`,`o`.`listing_id` AS `listing_id`,`o`.`listing_title` AS `listing_title`,`o`.`listing_price` AS `listing_price`,`o`.`customer_name` AS `customer_name`,`o`.`customer_phone` AS `customer_phone`,`o`.`customer_address` AS `customer_address`,`o`.`customer_id_no` AS `customer_id_no`,`o`.`quantity` AS `quantity`,`o`.`unit_price` AS `unit_price`,`o`.`total_amount` AS `total_amount`,`o`.`payment_method` AS `payment_method`,`o`.`notes` AS `notes`,`o`.`status` AS `status`,`o`.`payment_status` AS `payment_status`,`o`.`created_at` AS `created_at`,`o`.`updated_at` AS `updated_at`,`o`.`delivered_at` AS `delivered_at`,`o`.`wa_notified` AS `wa_notified`,`o`.`wa_last_msg` AS `wa_last_msg`,`o`.`wa_sent_at` AS `wa_sent_at`,`o`.`handled_by` AS `handled_by`,`l`.`image_url` AS `listing_image`,`c`.`name` AS `category_name`,`c`.`icon` AS `category_icon`,`a`.`name` AS `handled_by_name` from (((`orders` `o` left join `listings` `l` on((`l`.`id` = `o`.`listing_id`))) left join `categories` `c` on((`c`.`slug` = `o`.`category`))) left join `admins` `a` on((`a`.`id` = `o`.`handled_by`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_restaurants`
--

/*!50001 DROP VIEW IF EXISTS `v_restaurants`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_restaurants` AS select `r`.`id` AS `id`,`r`.`name` AS `name`,`r`.`description` AS `description`,`r`.`image_url` AS `image_url`,`r`.`location` AS `location`,`r`.`contact_phone` AS `contact_phone`,`r`.`contact_name` AS `contact_name`,`r`.`cuisine` AS `cuisine`,`r`.`delivery_time` AS `delivery_time`,`r`.`rating` AS `rating`,`r`.`views` AS `views`,`r`.`total_orders` AS `total_orders`,`r`.`is_open` AS `is_open`,`r`.`is_featured` AS `is_featured`,`r`.`is_active` AS `is_active`,`r`.`opening_hours` AS `opening_hours`,`r`.`min_order` AS `min_order`,`r`.`delivery_fee` AS `delivery_fee`,`r`.`badge` AS `badge`,`r`.`created_at` AS `created_at`,`r`.`updated_at` AS `updated_at`,count(distinct `l`.`id`) AS `menu_item_count`,count(distinct `o`.`id`) AS `order_count`,coalesce(avg(`l`.`rating`),`r`.`rating`) AS `computed_rating` from ((`restaurants` `r` left join `listings` `l` on(((`l`.`restaurant_id` = `r`.`id`) and (`l`.`is_active` = 1)))) left join `orders` `o` on((`o`.`listing_id` = `l`.`id`))) where (`r`.`is_active` = 1) group by `r`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_sales_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_sales_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_sales_summary` AS select cast(`orders`.`created_at` as date) AS `sale_date`,`orders`.`category` AS `category`,count(0) AS `total_orders`,sum((case when (`orders`.`status` = 'delivered') then 1 else 0 end)) AS `delivered`,sum((case when (`orders`.`status` = 'cancelled') then 1 else 0 end)) AS `cancelled`,sum((case when (`orders`.`payment_status` = 'received') then `orders`.`total_amount` else 0 end)) AS `revenue`,sum(`orders`.`total_amount`) AS `gmv` from `orders` group by cast(`orders`.`created_at` as date),`orders`.`category` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_search`
--

/*!50001 DROP VIEW IF EXISTS `v_search`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_search` AS select `l`.`id` AS `id`,`l`.`title` AS `title`,coalesce(`l`.`description`,'') AS `description`,coalesce(`l`.`location`,'') AS `location`,`l`.`price` AS `price`,`l`.`image_url` AS `image`,coalesce(`l`.`badge`,'') AS `badge`,coalesce(`l`.`views`,0) AS `views`,coalesce(`l`.`is_featured`,0) AS `is_featured`,`l`.`created_at` AS `created_at`,`c`.`slug` AS `type`,`c`.`name` AS `category_name`,`c`.`icon` AS `category_icon` from (`listings` `l` join `categories` `c` on((`l`.`category_id` = `c`.`id`))) where (`l`.`is_active` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-18  1:41:37
