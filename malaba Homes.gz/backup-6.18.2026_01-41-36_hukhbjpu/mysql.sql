-- cPanel mysql backup
GRANT USAGE ON *.* TO 'hukhbjpu'@'102.212.247.114' IDENTIFIED BY PASSWORD '*72F69AA214F4070C954EFD36E79BFA8B85055BEA';
GRANT ALL PRIVILEGES ON `hukhbjpu\_mh\_portal\_2026`.* TO 'hukhbjpu'@'102.212.247.114';
GRANT USAGE ON *.* TO 'hukhbjpu'@'a2891.calalemedba.com' IDENTIFIED BY PASSWORD '*72F69AA214F4070C954EFD36E79BFA8B85055BEA';
GRANT ALL PRIVILEGES ON `hukhbjpu\_mh\_portal\_2026`.* TO 'hukhbjpu'@'a2891.calalemedba.com';
GRANT USAGE ON *.* TO 'hukhbjpu'@'das125.truehost.cloud' IDENTIFIED BY PASSWORD '*72F69AA214F4070C954EFD36E79BFA8B85055BEA';
GRANT ALL PRIVILEGES ON `hukhbjpu\_mh\_portal\_2026`.* TO 'hukhbjpu'@'das125.truehost.cloud';
GRANT USAGE ON *.* TO 'hukhbjpu'@'localhost' IDENTIFIED BY PASSWORD '*72F69AA214F4070C954EFD36E79BFA8B85055BEA';
GRANT ALL PRIVILEGES ON `hukhbjpu\_mh\_portal\_2026`.* TO 'hukhbjpu'@'localhost';
GRANT USAGE ON *.* TO 'hukhbjpu_odiedo'@'102.212.247.114' IDENTIFIED BY PASSWORD '*013E07B05EF9F1029DB97E4FBA92A201FAD6782C';
GRANT ALL PRIVILEGES ON `hukhbjpu\_mh\_portal\_2026`.* TO 'hukhbjpu_odiedo'@'102.212.247.114';
GRANT USAGE ON *.* TO 'hukhbjpu_odiedo'@'a2891.calalemedba.com' IDENTIFIED BY PASSWORD '*013E07B05EF9F1029DB97E4FBA92A201FAD6782C';
GRANT ALL PRIVILEGES ON `hukhbjpu\_mh\_portal\_2026`.* TO 'hukhbjpu_odiedo'@'a2891.calalemedba.com';
GRANT USAGE ON *.* TO 'hukhbjpu_odiedo'@'das125.truehost.cloud' IDENTIFIED BY PASSWORD '*013E07B05EF9F1029DB97E4FBA92A201FAD6782C';
GRANT ALL PRIVILEGES ON `hukhbjpu\_mh\_portal\_2026`.* TO 'hukhbjpu_odiedo'@'das125.truehost.cloud';
GRANT USAGE ON *.* TO 'hukhbjpu_odiedo'@'localhost' IDENTIFIED BY PASSWORD '*013E07B05EF9F1029DB97E4FBA92A201FAD6782C';
GRANT ALL PRIVILEGES ON `hukhbjpu\_mh\_portal\_2026`.* TO 'hukhbjpu_odiedo'@'localhost';
