---
customlog:
  -
    format: combined
    target: /etc/apache2/logs/domlogs/malabahomes.com
  -
    format: "\"%{%s}t %I .\\n%{%s}t %O .\""
    target: /etc/apache2/logs/domlogs/malabahomes.com-bytes_log
documentroot: /home/hukhbjpu/public_html
group: hukhbjpu
hascgi: 1
homedir: /home/hukhbjpu
ip: 102.212.247.115
owner: truehost
phpopenbasedirprotect: 1
phpversion: ea-php83
port: 80
scriptalias:
  -
    path: /home/hukhbjpu/public_html/cgi-bin
    url: /cgi-bin/
serveradmin: webmaster@malabahomes.com
serveralias: www.malabahomes.com mail.malabahomes.com
servername: malabahomes.com
usecanonicalname: 'Off'
user: hukhbjpu
