// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCFWhRA2Ca7NQgcuMMLtw7U_w9VjT9SDlM",
  authDomain: "malaba-homes.firebaseapp.com",
  projectId: "malaba-homes",
  storageBucket: "malaba-homes.firebasestorage.app",
  messagingSenderId: "123484577811",
  appId: "1:123484577811:web:f6e1b85dae424050421fe6",
  measurementId: "G-0THFJFY7WY"
};