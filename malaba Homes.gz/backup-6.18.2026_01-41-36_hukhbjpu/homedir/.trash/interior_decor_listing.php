<?php
$apiBase = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/api';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1">
  <meta name="theme-color" content="#080400">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="description" content="Interior Home Decors — browse, quick view, buy fast, and pay with Lipa Mdogo Mdogo.">
  <title>Interior Home Decors — Malaba Homes</title>
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <style>
    :root{
      --ink:#080400;--ink2:#100a00;--surface:#161210;--card:#1c1812;
      --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);
      --text:#F5F0EB;--muted:#8a8078;--dim:#5a534c;
      --amber:#E8521A;--amber2:#FF7043;--gold:#F5A623;
      --green:#22C55E;
      --sb:env(safe-area-inset-bottom,0px);
      --st:env(safe-area-inset-top,0px);
      --r:12px;--rl:18px;--nav:56px;--bnav:62px;
    }
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
    html{overflow-x:hidden;}
    body{font-family:'Outfit',sans-serif;background:var(--ink);color:var(--text);min-height:100dvh;overflow-x:hidden;-webkit-font-smoothing:antialiased;padding-bottom:calc(var(--bnav) + var(--sb) + 10px);}
    a{color:inherit;text-decoration:none;}
    button{cursor:pointer;font-family:inherit;border:none;background:none;}
    img{display:block;max-width:100%;}

    /* Header */
    .hdr{position:sticky;top:0;z-index:200;background:rgba(8,4,0,.96);backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);border-bottom:1px solid var(--border);padding-top:var(--st);}
    .hdr-row{height:var(--nav);display:flex;align-items:center;gap:10px;padding:0 14px;}
    .back-btn{width:36px;height:36px;border-radius:50%;background:var(--surface);border:1px solid var(--border2);display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:transform .15s;}
    .back-btn:active{transform:scale(.9);}
    .back-btn svg{width:17px;height:17px;color:var(--text);}
    .hdr-brand{flex:1;font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:2px;}
    .hdr-brand span{color:var(--amber2);}
    .hdr-acts{display:flex;gap:7px;}
    .ico-btn{width:36px;height:36px;border-radius:50%;background:var(--surface);border:1px solid var(--border2);display:flex;align-items:center;justify-content:center;font-size:15px;position:relative;transition:transform .15s;}
    .ico-btn:active{transform:scale(.9);}

    /* Search */
    .srch-row{padding:9px 14px;}
    .srch-box{display:flex;align-items:center;gap:9px;background:var(--surface);border:1.5px solid var(--border2);border-radius:30px;padding:0 15px;}
    .srch-box svg{color:var(--muted);flex-shrink:0;width:14px;height:14px;}
    .srch-box input{flex:1;padding:11px 0;background:transparent;border:none;outline:none;font-family:inherit;font-size:14px;color:var(--text);}
    .srch-box input::placeholder{color:var(--muted);}

    /* Chips */
    .cats-row{display:flex;gap:7px;padding:0 14px 10px;overflow-x:auto;scrollbar-width:none;}
    .cats-row::-webkit-scrollbar{display:none;}
    .cat-tab{display:inline-flex;align-items:center;gap:6px;padding:6px 13px;border-radius:30px;border:1px solid var(--border2);background:var(--surface);font-size:12px;font-weight:600;color:var(--muted);white-space:nowrap;flex-shrink:0;transition:all .2s;}
    .cat-tab.on{background:var(--amber);border-color:var(--amber);color:#fff;}
    .cat-tab:active{transform:scale(.95);}

    /* Section head */
    .sec-head{display:flex;align-items:center;justify-content:space-between;padding:8px 14px;}
    .sec-head h2{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.5px;}
    .sec-head h2 span{color:var(--amber2);}
    .res-count{font-size:11px;color:var(--dim);padding:0 14px 8px;}

    /* Pinterest-ish grid */
    .grid{
      display:grid;
      gap:10px;
      grid-template-columns:repeat(2,1fr);
      padding:0 10px;
    }
    @media(min-width:480px){.grid{gap:12px;padding:0 14px;}}
    @media(min-width:700px){.grid{grid-template-columns:repeat(3,1fr);padding:0 18px;}}
    @media(min-width:980px){.grid{grid-template-columns:repeat(4,1fr);padding:0 24px;}}

    .pcard{
      background:var(--card);
      border:1px solid var(--border);
      border-radius:var(--rl);
      overflow:hidden;
      cursor:pointer;
      transition:transform .2s,box-shadow .2s,border-color .2s;
      animation:fadeUp .3s ease both;
      position:relative;
    }
    @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
    .pcard:active{transform:scale(.97);}
    @media(hover:hover){.pcard:hover{transform:translateY(-4px);box-shadow:0 14px 36px rgba(0,0,0,.5);border-color:var(--border2);}}

    /* variable height to mimic masonry */
    .pcard[data-h="1"]{grid-row:span 1;}
    .pcard-img{position:relative;overflow:hidden;}
    .pcard-img img{width:100%;height:100%;object-fit:cover;transform:scale(1.01);transition:transform .55s;}
    .pcard:hover .pcard-img img{transform:scale(1.07);}
    .pbadge{position:absolute;top:8px;left:8px;background:rgba(8,4,0,.82);backdrop-filter:blur(6px);color:var(--text);font-size:9px;font-weight:800;padding:3px 8px;border-radius:12px;letter-spacing:.2px;}
    .plipa-badge{position:absolute;bottom:8px;left:8px;background:linear-gradient(135deg,rgba(245,166,35,.95),rgba(232,82,26,.95));color:#fff;font-size:8px;font-weight:900;padding:3px 7px;border-radius:10px;letter-spacing:.2px;}
    .wish{position:absolute;top:8px;right:8px;width:28px;height:28px;border-radius:50%;background:rgba(8,4,0,.68);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;z-index:2;border:1px solid rgba(255,255,255,.12);}
    .wish.liked{background:rgba(232,82,26,.22);border-color:rgba(232,82,26,.35)}

    .pcard-body{padding:9px 10px 2px;}
    .ptitle{font-weight:800;font-size:12px;line-height:1.25;min-height:30px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
    .pprice{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.3px;color:var(--amber2);padding:6px 10px 10px;}

    .pcard-foot{display:flex;gap:6px;padding:0 10px 12px;}
    .btn-buy{flex:1;padding:10px 8px;border-radius:12px;background:var(--amber);color:#fff;font-family:'Bebas Neue',sans-serif;font-size:14px;letter-spacing:.3px;display:flex;align-items:center;justify-content:center;gap:6px;}
    .btn-lipa{padding:10px 10px;border-radius:12px;background:linear-gradient(135deg,var(--gold),var(--amber));color:#fff;font-size:12px;font-weight:900;flex-shrink:0;}
    .btn-qv{width:40px;border-radius:12px;background:rgba(255,255,255,.04);border:1px solid var(--border2);color:var(--muted);font-size:13px;}

    /* Overlay */
    .overlay{position:fixed;inset:0;z-index:400;background:rgba(0,0,0,.82);backdrop-filter:blur(6px);opacity:0;pointer-events:none;transition:opacity .25s;display:flex;align-items:flex-end;}
    .overlay.open{opacity:1;pointer-events:all;}
    .sheet{width:100%;background:var(--ink2);border-radius:24px 24px 0 0;border:1px solid rgba(255,255,255,.08);transform:translateY(100%);transition:transform .38s cubic-bezier(.32,1,.68,1);max-height:94dvh;overflow-y:auto;}
    .overlay.open .sheet{transform:translateY(0);}
    .sh-top{display:flex;align-items:center;justify-content:space-between;padding:13px 16px 0;}
    .sh-handle{width:38px;height:4px;border-radius:2px;background:rgba(255,255,255,.1);}
    .sh-close{width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.5);font-size:14px;}
    .sh-close:active{transform:scale(.9);}

    .qv-img{width:100%;height:230px;object-fit:cover;}
    .qv-pad{padding:14px 16px 16px;}
    .qv-title{font-family:'Bebas Neue',sans-serif;font-size:24px;letter-spacing:.3px;margin-bottom:6px;}
    .qv-price{font-family:'Bebas Neue',sans-serif;font-size:30px;letter-spacing:.5px;color:var(--amber2);margin-bottom:10px;}
    .qv-desc{font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:14px;}

    .buy-options{display:flex;flex-direction:column;gap:10px;margin-bottom:10px;}
    .buy-opt{display:flex;align-items:center;gap:12px;padding:14px 14px;border-radius:16px;border:2px solid var(--border2);background:rgba(255,255,255,.02);}
    .buy-opt:active{transform:scale(.99);}
    .bo-icon{width:44px;height:44px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;background:rgba(255,255,255,.05);}
    .buy-opt.full{border-color:rgba(232,82,26,.4);background:rgba(232,82,26,.07);}
    .buy-opt.full .bo-icon{background:rgba(232,82,26,.16);}
    .buy-opt.lipa{border-color:rgba(245,166,35,.45);background:rgba(245,166,35,.06);}
    .buy-opt.lipa .bo-icon{background:rgba(245,166,35,.14);}
    .bo-info{flex:1;min-width:0;}
    .bo-title{font-weight:900;color:var(--text);margin-bottom:2px;}
    .bo-sub{font-size:12px;color:var(--muted);}

    /* Direct order form */
    .field{margin-bottom:11px;}
    .field label{display:block;font-size:10px;font-weight:900;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:5px;}
    .field input{width:100%;padding:11px 13px;border-radius:var(--r);background:rgba(255,255,255,.05);border:1.5px solid var(--border2);color:var(--text);outline:none;font-size:14px;}
    .field input:focus{border-color:var(--amber);}
    .row2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}

    .pay-opts{display:flex;flex-direction:column;gap:8px;margin-bottom:12px;}
    .po{display:flex;align-items:center;gap:11px;padding:12px 12px;border-radius:var(--r);border:2px solid var(--border2);background:rgba(255,255,255,.02);cursor:pointer;}
    .po.sel{border-color:var(--amber);background:rgba(232,82,26,.07);}
    .po-dot{width:17px;height:17px;border-radius:50%;border:2px solid var(--dim);margin-left:auto;display:flex;align-items:center;justify-content:center;}
    .po.sel .po-dot{border-color:var(--amber);background:var(--amber);}
    .po.sel .po-dot::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}
    .po-ico{font-size:18px;}
    .po-txt strong{display:block;font-size:13px;font-weight:900;}
    .po-txt span{display:block;font-size:11px;color:var(--muted);}

    .sbtn{width:100%;padding:14px;border-radius:18px;background:linear-gradient(135deg,var(--amber),var(--amber2));color:#fff;font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.3px;box-shadow:0 4px 18px rgba(232,82,26,.35);}

    /* Lipa mdogo mdogo sheet */
    .lipa-sec-title{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:.3px;margin-bottom:6px;}
    .lipa-sec-sub{font-size:12px;color:var(--muted);line-height:1.5;margin-bottom:14px;}

    .lipa-panel{display:none;padding:14px 16px 16px;}
    .lipa-panel.active{display:block;}
    .lipa-steps{display:flex;gap:8px;align-items:center;margin:0 16px 14px;}
    .lstep{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;}
    .ls-dot{width:26px;height:26px;border-radius:50%;border:2px solid var(--border2);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:900;color:var(--muted);}
    .lstep.active .ls-dot{background:var(--amber);border-color:var(--amber);color:#fff;box-shadow:0 0 0 4px rgba(232,82,26,.18);}
    .lstep.done .ls-dot{background:var(--green);border-color:var(--green);color:#000;}
    .ls-lbl{font-size:9px;font-weight:800;color:var(--muted);}
    .lstep.active .ls-lbl{color:var(--amber);}
    .lipa-durs{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;}
    .lipa-dur{padding:12px 10px;border-radius:18px;border:2px solid var(--border2);background:rgba(255,255,255,.02);cursor:pointer;}
    .lipa-dur.sel{border-color:rgba(245,166,35,.6);background:rgba(245,166,35,.08);}
    .ld-weeks{font-family:'Bebas Neue',sans-serif;font-size:22px;color:var(--text);letter-spacing:.3px;}
    .ld-label{font-size:10px;color:var(--muted);}
    .ld-per{font-size:12px;font-weight:900;color:var(--gold);margin-top:2px;}
    .ld-total{font-size:10px;color:var(--dim);margin-top:2px;}

    /* Chips etc inside sheet */
    .lipa-freq{display:flex;align-items:center;gap:12px;padding:13px 13px;border-radius:18px;border:2px solid var(--border2);background:rgba(255,255,255,.02);cursor:pointer;}
    .lipa-freq.sel{border-color:rgba(245,166,35,.6);background:rgba(245,166,35,.08);}
    .lf-radio{width:17px;height:17px;border-radius:50%;border:2px solid var(--dim);display:flex;align-items:center;justify-content:center;}
    .lipa-freq.sel .lf-radio{background:var(--gold);border-color:var(--gold);}
    .lipa-freq.sel .lf-radio::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}
    .lf-info{flex:1;}
    .lf-name{font-size:13px;font-weight:900;color:var(--text);margin-bottom:2px;}
    .lf-desc{font-size:11px;color:var(--muted);}
    .lf-right{text-align:right;}
    .lf-amount{font-family:'Bebas Neue',sans-serif;font-size:16px;color:var(--gold);letter-spacing:.3px;}
    .lf-per{font-size:9px;color:var(--muted);}

    /* Toast */
    .toast{position:fixed;bottom:calc(var(--bnav) + var(--sb) + 14px);left:50%;transform:translateX(-50%) translateY(8px);background:var(--text);color:var(--ink);padding:10px 20px;border-radius:30px;font-size:13px;font-weight:800;z-index:999;opacity:0;pointer-events:none;transition:all .22s;white-space:nowrap;box-shadow:0 8px 24px rgba(0,0,0,.4);}
    .toast.show{opacity:1;transform:translateX(-50%) translateY(0);}

    /* Bottom nav */
    .bnav{position:fixed;bottom:0;left:0;right:0;z-index:200;height:calc(var(--bnav) + var(--sb));padding-bottom:var(--sb);background:rgba(8,4,0,.95);backdrop-filter:blur(28px);border-top:1px solid rgba(255,255,255,.07);display:flex;align-items:stretch;}
    .bni{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:0 4px;-webkit-tap-highlight-color:transparent;}
    .bni-ico{font-size:20px;color:rgba(255,255,255,.38);transition:all .22s;line-height:1.15;}
    .bni-lbl{font-size:9px;font-weight:700;color:rgba(255,255,255,.3);letter-spacing:.5px;text-transform:uppercase;transition:all .22s;}
    .bni.active .bni-ico,.bni.active .bni-lbl{color:var(--amber);}
    .bni.active{position:relative;}
    .bni.active::before{content:'';position:absolute;bottom:2px;width:20px;height:2px;border-radius:1px;background:var(--amber);animation:indIn .3s ease;}
    @keyframes indIn{from{width:0;opacity:0;}to{width:20px;opacity:1;}}

    /* Loading */
    .skel-grid{display:grid;gap:12px;grid-template-columns:repeat(2,1fr);padding:0 14px;}
    @media(min-width:700px){.skel-grid{grid-template-columns:repeat(3,1fr);}}
    .skel-card{height:280px;border-radius:18px;background:linear-gradient(90deg,rgba(255,255,255,.04) 25%,rgba(255,255,255,.08) 50%,rgba(255,255,255,.04) 75%);background-size:200% 100%;animation:shim 1.4s infinite;}
    @keyframes shim{0%{background-position:200% 0}100%{background-position:-200% 0}}

  </style>
</head>
<body>

<header class="hdr">
  <div class="hdr-row">
    <a href="shop_listing.php" class="back-btn" title="Back to Shop">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
        <path d="M19 12H5M5 12l7-7M5 12l7 7"/>
      </svg>
    </a>
    <div class="hdr-brand">Malaba <span>Decors</span></div>
    <div class="hdr-acts">
      <button class="ico-btn" onclick="openCartPreview()" title="Cart (demo)">&#x1F6D2;</button>
    </div>
  </div>

  <div class="srch-row">
    <div class="srch-box">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
        <circle cx="11" cy="11" r="8"/>
        <path d="m21 21-4.35-4.35"/>
      </svg>
      <input type="search" id="srchInput" placeholder="Search decor items…" autocomplete="off" enterkeyhint="search">
    </div>
  </div>

  <div class="cats-row" id="catsRow">
    <button class="cat-tab on" data-cat="all">&#x2728; All</button>
    <button class="cat-tab" data-cat="wall">&#x1F5BC; Wall Decor</button>
    <button class="cat-tab" data-cat="lighting">&#x1F4A1; Lighting</button>
    <button class="cat-tab" data-cat="curtains">&#x1F4F7; Curtains</button>
    <button class="cat-tab" data-cat="storage">&#x1F9F9; Storage</button>
    <button class="cat-tab" data-cat="furniture">&#x1F6CB; Furniture</button>
    <button class="cat-tab" data-cat="cleaning">&#x1F9F9; Cleaning</button>
  </div>
</header>

<div class="sec-head">
  <h2>&#x1F3E0; <span>Interior Home Decors</span></h2>
</div>
<div class="res-count" id="resCount">Loading…</div>

<div id="grid" class="grid" style="display:none"></div>
<div id="skel" class="skel-grid">
  <div class="skel-card"></div><div class="skel-card"></div>
  <div class="skel-card"></div><div class="skel-card"></div>
</div>

<!-- Overlay -->
<div class="overlay" id="overlay" onclick="handleOvClick(event)">
  <div class="sheet" id="sheet">
    <div id="sheetContent"></div>
  </div>
</div>

<div class="toast" id="toast"></div>

<nav class="bnav">
  <a href="index.php" class="bni">
    <div class="bni-ico">&#x1F3E1;</div>
    <div class="bni-lbl">Home</div>
  </a>
  <a href="homes_listing.php" class="bni">
    <div class="bni-ico">&#x1F3E0;</div>
    <div class="bni-lbl">Homes</div>
  </a>
  <a href="video_feed.php" class="bni">
    <div class="bni-ico">&#x25B6;</div>
    <div class="bni-lbl">Watch</div>
  </a>
  <a href="food_listing.php" class="bni">
    <div class="bni-ico">&#x1F354;</div>
    <div class="bni-lbl">Food</div>
  </a>
  <a href="shop_listing.php" class="bni active">
    <div class="bni-ico">&#x1F6D2;</div>
    <div class="bni-lbl">Shop</div>
  </a>
</nav>

<script>
  // FRONTEND ONLY (demo data)
  // This page does not connect to backend yet.

  const LS_WISH = 'mh_interior_wish';
  const LS_CART = 'mh_interior_cart';

  let state = {
    cat: 'all',
    search: '',
    currentItem: null,
    wishlist: [],
    cart: [],
    // Lipa wizard state
    lipaFreq: null,
    lipaDur: null,
    lipaPayMode: 'mpesa',
  };

  try { state.wishlist = JSON.parse(localStorage.getItem(LS_WISH) || '[]'); } catch(e){}
  try { state.cart = JSON.parse(localStorage.getItem(LS_CART) || '[]'); } catch(e){}

  const demoItems = [
    { id:'d1', title:'Modern Wall Frame Set (3pcs)', price:'KSH 2,450', cat:'wall', badge:'Bestseller', rating:4.7, img:'https://images.unsplash.com/photo-1526481280695-3c687fd643ed?w=900&q=80', desc:'Clean lines and premium finish. Instant upgrade for your living room.' },
    { id:'d2', title:'Vintage Pattern Wall Art', price:'KSH 1,200', cat:'wall', badge:'New', rating:4.5, img:'https://images.unsplash.com/photo-1519710164239-da123dc03ef4?w=900&q=80', desc:'Warm tones to match any interior style.' },
    { id:'d3', title:'LED Ambient Strip Lights', price:'KSH 3,900', cat:'lighting', badge:'Hot', rating:4.8, img:'https://images.unsplash.com/photo-1519710887728-6f4cfe4b5a5d?w=900&q=80', desc:'Mood lighting for TV, beds, and shelves.' },
    { id:'d4', title:'Minimal Table Lamp (Warm Light)', price:'KSH 4,250', cat:'lighting', badge:'Premium', rating:4.6, img:'https://images.unsplash.com/photo-1505691938895-1758d7feb511?w=900&q=80', desc:'Soft warm glow for cozy evenings.' },
    { id:'d5', title:'Blackout Curtains (1 Pair)', price:'KSH 2,800', cat:'curtains', badge:'Value', rating:4.4, img:'https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=900&q=80', desc:'Blocks light + improves privacy and sleep comfort.' },
    { id:'d6', title:'Modern Floor Storage Basket', price:'KSH 1,650', cat:'storage', badge:'Organize', rating:4.3, img:'https://images.unsplash.com/photo-1551298370-9d0d2a7f0e0c?w=900&q=80', desc:'Keep your space tidy with stylish woven storage.' },
    { id:'d7', title:'Compact Shoe Cabinet', price:'KSH 5,900', cat:'furniture', badge:'Family', rating:4.7, img:'https://images.unsplash.com/photo-1545047812-6c7c6c7f5b2b?w=900&q=80', desc:'Perfect for entryways. Clean storage for daily shoes.' },
    { id:'d8', title:'Comfort Throw Blanket', price:'KSH 2,100', cat:'furniture', badge:'Cozy', rating:4.6, img:'https://images.unsplash.com/photo-1549187774-b4e9b0445b41?w=900&q=80', desc:'Soft texture for sofa, bed, and reading corners.' },
    { id:'d9', title:'All-purpose Cleaning Set', price:'KSH 900', cat:'cleaning', badge:'Easy Home', rating:4.2, img:'https://images.unsplash.com/photo-1581579185169-3f2b0b5f5d9d?w=900&q=80', desc:'Simple cleaning essentials for a fresh home daily.' },
    { id:'d10', title:'Wall Shelf (Floating) — 2pcs', price:'KSH 2,990', cat:'storage', badge:'Top Rated', rating:4.8, img:'https://images.unsplash.com/photo-1484101403633-562f891dc89a?w=900&q=80', desc:'Display frames, plants, and essentials neatly.' },
  ];

  const cats = [
    {key:'all', label:'All'},
    {key:'wall', label:'Wall Decor'},
    {key:'lighting', label:'Lighting'},
    {key:'curtains', label:'Curtains'},
    {key:'storage', label:'Storage'},
    {key:'furniture', label:'Furniture'},
    {key:'cleaning', label:'Cleaning'}
  ];

  function pxPrice(str){
    const n = parseFloat(String(str||'').replace(/[^0-9.]/g,''));
    return isNaN(n)?0:n;
  }

  function esc(s){
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'<').replace(/>/g,'>').replace(/"/g,'"');
  }

  function toast(msg){
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(()=>t.classList.remove('show'), 2400);
  }

  function openOverlay(){
    document.getElementById('overlay').classList.add('open');
    document.body.style.overflow='hidden';
  }
  function closeOverlay(){
    document.getElementById('overlay').classList.remove('open');
    document.body.style.overflow='';
  }
  function handleOvClick(e){ if(e.target===e.currentTarget) closeOverlay(); }

  function saveWish(){
    localStorage.setItem(LS_WISH, JSON.stringify(state.wishlist));
  }
  function saveCart(){
    localStorage.setItem(LS_CART, JSON.stringify(state.cart));
  }

  function toggleWish(id, el){
    const i = state.wishlist.indexOf(id);
    if(i!==-1){
      state.wishlist.splice(i,1);
      el.classList.remove('liked');
      el.innerHTML = '&#x2661;';
      toast('Removed from saved');
    } else {
      state.wishlist.unshift(id);
      el.classList.add('liked');
      el.innerHTML = '&#x2665;';
      toast('Saved!');
    }
    saveWish();
  }

  function upsertCart(item, qty){
    const ex = state.cart.find(c=>c.id===item.id);
    if(ex){ ex.qty += qty; if(ex.qty<=0) state.cart = state.cart.filter(c=>c.id!==item.id); }
    else if(qty>0){ state.cart.push({id:item.id,title:item.title,price:item.price,img:item.img,qty}); }
    saveCart();
  }

  function openCartPreview(){
    const n = state.cart.reduce((s,c)=>s+c.qty,0);
    if(!n){
      toast('Cart is empty (demo)');
      return;
    }
    const total = state.cart.reduce((s,c)=>s+pxPrice(c.price)*c.qty,0);
    document.getElementById('sheetContent').innerHTML =
      '<div class="sh-top"><div class="sh-handle"></div><button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>'+
      '<div style="padding:14px 16px 16px;">'+
      '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:26px;letter-spacing:.5px;margin-bottom:12px;">Cart</div>'+
      state.cart.map(c=>
        '<div style="display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:14px;padding:10px 12px;margin-bottom:10px;">'+
          '<div style="min-width:0;max-width:70%;">'+
            '<div style="font-weight:900;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">'+esc(c.title)+'</div>'+
            '<div style="font-size:11px;color:rgba(255,255,255,.55);margin-top:2px;">'+esc(c.price)+' × '+c.qty+'</div>'+
          '</div>'+
          '<div style="display:flex;align-items:center;gap:8px;">'+
            '<button style="width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:var(--text);" onclick="qtyDemo(\''+esc(c.id)+'\',-1)">−</button>'+
            '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:18px;color:var(--amber2);">'+c.qty+'</div>'+
            '<button style="width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:var(--text);" onclick="qtyDemo(\''+esc(c.id)+'\',1)">+</button>'+
          '</div>'+
        '</div>'
      ).join('')+
      '<div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:18px;padding:12px;margin-top:14px;">'+
        '<div style="display:flex;justify-content:space-between;font-size:13px;color:rgba(255,255,255,.65);"><span>Estimated Total</span><span style="color:var(--amber2);font-weight:900;">KSH '+Math.round(total).toLocaleString('en-KE')+'</span></div>'+
        '<div style="font-size:12px;color:rgba(255,255,255,.55);margin-top:6px;line-height:1.6;">Demo checkout: connect backend later.</div>'+
      '</div>'+
      '</div>';
    openOverlay();
  }

  function qtyDemo(id, delta){
    const item = state.cart.find(c=>c.id===id);
    if(!item) return;
    upsertCart(item, delta);
    openCartPreview();
  }

  function formatKSH(n){
    return 'KSH ' + Math.round(n).toLocaleString('en-KE');
  }

  function buildCardHTML(item, idx){
    const liked = state.wishlist.includes(item.id);
    const priceNum = pxPrice(item.price);
    const hasLipa = priceNum >= 200;

    // variable height: pseudo masonry
    const heights = [270, 290, 310, 280, 300, 320];
    const h = heights[idx % heights.length];

    return (
      '<div class="pcard" data-h="'+idx+'" onclick="openQV(\''+esc(item.id)+'\')">'+
        '<div class="pcard-img" style="height:'+h+'px">'+
          '<img src="'+esc(item.img)+'" alt="'+esc(item.title)+'" loading="lazy" onerror="this.src=\'https://images.unsplash.com/photo-1526481280695-3c687fd643ed?w=900&q=80\'">'+
          (item.badge ? '<div class="pbadge">'+esc(item.badge)+'</div>' : '')+
          (hasLipa ? '<div class="plipa-badge">&#x1F4B0; Lipa Mdogo</div>' : '')+
          '<button class="wish '+(liked?'liked':'')+'" onclick="event.stopPropagation();toggleWish(\''+esc(item.id)+'\',this)">'+(liked?'&#x2665;':'&#x2661;')+'</button>'+
        '</div>'+
        '<div class="pcard-body">'+
          '<div class="ptitle">'+esc(item.title)+'</div>'+
        '</div>'+
        '<div class="pprice">'+esc(item.price)+'</div>'+
        '<div class="pcard-foot" onclick="event.stopPropagation()">'+
          '<button class="btn-buy" onclick="buyNow(\''+esc(item.id)+'\')">&#x1F6D2; Buy</button>'+
          (hasLipa ? '<button class="btn-lipa" onclick="openLipa(\''+esc(item.id)+'\')" title="Pay in instalments">&#x1F4B0;</button>' : '')+
          '<button class="btn-qv" onclick="openQV(\''+esc(item.id)+'\')">&#x1F441;</button>'+
        '</div>'+
      '</div>'
    );
  }

  function filteredItems(){
    const q = state.search.trim().toLowerCase();
    return demoItems.filter(it=>{
      const catOk = state.cat==='all' ? true : it.cat===state.cat;
      if(!catOk) return false;
      if(!q) return true;
      const txt = (it.title+' '+it.desc+' '+it.badge).toLowerCase();
      return txt.includes(q);
    });
  }

  function render(){
    const list = filteredItems();
    document.getElementById('resCount').textContent = list.length + ' decor item' + (list.length!==1?'s':'');
    const grid = document.getElementById('grid');
    grid.style.display = 'grid';
    document.getElementById('skel').style.display = 'none';
    grid.innerHTML = list.map((it,idx)=>buildCardHTML(it,idx)).join('');
  }

  // Filters
  document.querySelectorAll('.cat-tab').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.cat-tab').forEach(x=>x.classList.remove('on'));
      btn.classList.add('on');
      state.cat = btn.dataset.cat;
      render();
    });
  });

  // Search
  document.getElementById('srchInput').addEventListener('input', (e)=>{
    state.search = e.target.value || '';
    render();
  });

  // Quick View
  function openQV(id){
    const item = demoItems.find(x=>x.id===id);
    if(!item) return;
    state.currentItem = item;

    const priceNum = pxPrice(item.price);
    const hasLipa = priceNum >= 200;

    document.getElementById('sheetContent').innerHTML =
      '<div class="sh-top">'+
        '<div class="sh-handle"></div>'+
        '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button>'+
      '</div>'+
      (item.img ? '<img class="qv-img" src="'+esc(item.img)+'" alt="'+esc(item.title)+'">' : '')+
      '<div class="qv-pad">'+
        (item.badge ? '<div style="display:inline-flex;align-items:center;gap:6px;background:rgba(232,82,26,.10);border:1px solid rgba(232,82,26,.25);padding:6px 10px;border-radius:999px;color:var(--amber2);font-weight:900;font-size:12px;margin-bottom:10px;">'+esc(item.badge)+'</div>' : '')+
        '<div class="qv-title">'+esc(item.title)+'</div>'+
        '<div class="qv-price">'+esc(item.price)+'</div>'+
        '<div class="qv-desc">'+esc(item.desc)+'</div>'+
        '<div class="buy-options">'+
          '<div class="buy-opt full" onclick="buyNow(\''+esc(item.id)+'\')">'+
            '<div class="bo-icon">&#x1F6D2;</div>'+
            '<div class="bo-info">'+
              '<div class="bo-title">Buy Now — Fast Checkout</div>'+
              '<div class="bo-sub">Send name, phone, and address. Pay on delivery.</div>'+
            '</div>'+
            '<div style="font-size:18px;color:rgba(255,255,255,.6)">&#x203A;</div>'+
          '</div>'+
          (hasLipa ?
          '<div class="buy-opt lipa" onclick="openLipa(\''+esc(item.id)+'\')">'+
            '<div class="bo-icon">&#x1F4B0;</div>'+
            '<div class="bo-info">'+
              '<div class="bo-title">Lipa Mdogo Mdogo</div>'+
              '<div class="bo-sub">Choose daily / weekly and a plan duration. Delivery after full payment.</div>'+
            '</div>'+
            '<div style="font-size:18px;color:rgba(255,255,255,.6)">&#x203A;</div>'+
          '</div>'
          : '')+
        '</div>'+
        '<div style="font-size:12px;color:rgba(255,255,255,.55);line-height:1.6;">Note: Frontend demo only — orders are not sent to backend yet.</div>'+
      '</div>';

    openOverlay();
  }

  // Direct Buy (demo)
  function buyNow(id){
    const item = demoItems.find(x=>x.id===id);
    if(!item) return;
    state.currentItem = item;

    document.getElementById('sheetContent').innerHTML =
      '<div class="sh-top">'+
        '<div class="sh-handle"></div>'+
        '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button>'+
      '</div>'+
      '<div style="padding:14px 16px 16px;">'+
        '<div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">'+
          '<div style="font-size:28px">&#x1F6D2;</div>'+
          '<div><div style="font-family:\'Bebas Neue\',sans-serif;font-size:20px;letter-spacing:.3px;">'+esc(item.title)+'</div>'+
          '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:26px;color:var(--amber2);letter-spacing:.4px;">'+esc(item.price)+'</div></div>'+
        '</div>'+
        '<div class="row2">'+
          '<div class="field"><label>Full Name *</label><input type="text" id="do_name" placeholder="Your name" autocomplete="name"></div>'+
          '<div class="field"><label>Phone *</label><input type="tel" id="do_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>'+
        '</div>'+
        '<div class="field"><label>Delivery Address *</label><input type="text" id="do_addr" placeholder="e.g. Near Malaba Market"></div>'+

        '<div style="font-size:10px;font-weight:900;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin:8px 0 8px;">Payment Method</div>'+
        '<div class="pay-opts">'+
          '<div class="po sel" id="do_cash" onclick="setPayMode(\'cash\',this)"><div class="po-ico">&#x1F4B5;</div><div class="po-txt"><strong>Cash on Delivery</strong><span>Pay when item arrives</span></div><div class="po-dot"></div></div>'+
          '<div class="po" id="do_mpesa" onclick="setPayMode(\'mpesa\',this)"><div class="po-ico">&#x1F4F1;</div><div class="po-txt"><strong>M-Pesa on Delivery</strong><span>Send when delivered</span></div><div class="po-dot"></div></div>'+
        '</div>'+

        '<button class="sbtn" id="doSubmit" onclick="submitDirect()">&#x2705; Place Order (Demo)</button>'+
        '<div style="font-size:12px;color:rgba(255,255,255,.55);line-height:1.6;margin-top:10px;">This is frontend-only. Tap will show a success screen instead of sending to backend.</div>'+
      '</div>';

    state._payMode = 'cash';
    openOverlay();
  }

  function setPayMode(mode, el){
    state._payMode = mode;
    document.getElementById('do_cash').classList.toggle('sel', mode==='cash');
    document.getElementById('do_mpesa').classList.toggle('sel', mode==='mpesa');
  }

  function submitDirect(){
    const item = state.currentItem;
    const name = (document.getElementById('do_name').value||'').trim();
    const phone = (document.getElementById('do_phone').value||'').trim();
    const addr = (document.getElementById('do_addr').value||'').trim();

    if(!name){ toast('Enter your full name'); return; }
    if(!phone || phone.replace(/\D/g,'').length<9){ toast('Enter a valid phone number'); return; }
    if(!addr){ toast('Enter your delivery address'); return; }

    document.getElementById('sheetContent').innerHTML =
      '<div class="sh-top">'+
        '<div class="sh-handle"></div>'+
        '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button>'+
      '</div>'+
      '<div style="padding:22px 16px 16px;text-align:center;">'+
        '<div style="font-size:54px;margin-bottom:10px;">&#x2705;</div>'+
        '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:26px;letter-spacing:.5px;margin-bottom:6px;">Order Placed!</div>'+
        '<div style="font-size:13px;color:rgba(255,255,255,.65);line-height:1.6;margin-bottom:12px;">Demo success. Next step is wiring to api/order.php.</div>'+
        '<div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:18px;padding:12px;text-align:left;">'+
          '<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px;"><span style="color:rgba(255,255,255,.55);">Item</span><span style="font-weight:900;">'+esc(item.title)+'</span></div>'+
          '<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px;"><span style="color:rgba(255,255,255,.55);">Total</span><span style="font-weight:900;color:var(--amber2);">'+esc(item.price)+'</span></div>'+
          '<div style="display:flex;justify-content:space-between;font-size:13px;"><span style="color:rgba(255,255,255,.55);">Payment</span><span style="font-weight:900;">'+esc(state._payMode.toUpperCase())+'</span></div>'+
        '</div>'+
        '<button class="sbtn" style="margin-top:14px;" onclick="closeOverlay()">Continue Shopping</button>'+
      '</div>';
  }

  // Lipa mdogo mdogo (demo)
  function openLipa(id){
    const item = demoItems.find(x=>x.id===id);
    if(!item) return;
    state.currentItem = item;
    state.lipaFreq = null;
    state.lipaDur = null;
    state.lipaPayMode = 'mpesa';

    const raw = pxPrice(item.price);

    const freqs = calcFreqs(raw);

    document.getElementById('sheetContent').innerHTML =
      '<div class="sh-top">'+
        '<div class="sh-handle"></div>'+
        '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button>'+
      '</div>'+
      '<div class="lipa-steps">'+
        '<div class="lstep active" id="ls1"><div class="ls-dot">1</div><div class="ls-lbl">Frequency</div></div>'+
        '<div class="lstep" id="ls2"><div class="ls-dot">2</div><div class="ls-lbl">Duration</div></div>'+
        '<div class="lstep" id="ls3"><div class="ls-dot">3</div><div class="ls-lbl">Details</div></div>'+
      '</div>'+
      '<div class="lipa-panel active" id="lp1">'+
        '<div class="lipa-sec-title">How often can you pay?</div>'+
        '<div class="lipa-sec-sub">Daily has no extra charge. Pick a plan that fits you.</div>'+
        '<div id="freqList" style="display:flex;flex-direction:column;gap:10px;margin-top:10px;">'+
          freqs.map((f,idx)=>{
            const est = f.estimatePerPay(raw);
            return '<div class="lipa-freq'+(idx===0?' sel':'')+'" onclick="selFreq(\''+f.id+'\','+idx+')" id="lf-'+f.id+'">'+
              '<div class="lf-radio"></div>'+
              '<div class="lf-info">'+
                '<div class="lf-name">'+esc(f.label)+'</div>'+
                '<div class="lf-desc">'+esc(f.desc)+'</div>'+
              '</div>'+
              '<div class="lf-right">'+
                '<div class="lf-amount">'+esc(formatKSH(est))+'</div>'+
                '<div class="lf-per">/'+esc(f.per)+'</div>'+
              '</div>'+
            +'</div>';
          }).join('')+
        +'</div>'+
        '<div style="padding:0 16px 16px;margin-top:14px;">'+
          '<button class="sbtn" onclick="lipaNext(1)">Next: Duration &#x2192;</button>'+
        +'</div>'+
      '</div>'+
      '<div class="lipa-panel" id="lp2">'+
        '<div class="lipa-sec-title">How long to pay?</div>'+
        '<div class="lipa-sec-sub">Choose a duration. Delivery happens after full payment only.</div>'+
        '<div id="durGrid" class="lipa-durs"></div>'+
        '<div id="durSummary" style="background:rgba(245,166,35,.07);border:1px solid rgba(245,166,35,.18);border-radius:18px;padding:12px;margin:0 16px 12px;display:none;"></div>'+
        '<div style="display:flex;gap:10px;padding:0 16px 16px;">'+
          '<button class="btn-qv" style="flex:0 0 auto;" onclick="lipaBack(2)">&#x2190;</button>'+
          '<button class="sbtn" style="flex:1;" onclick="lipaNext(2)">Next: Details &#x2192;</button>'+
        '</div>'+
      '</div>'+
      '<div class="lipa-panel" id="lp3">'+
        '<div class="lipa-sec-title">Your Details</div>'+
        '<div class="lipa-sec-sub">Enter where to deliver. We confirm your plan via WhatsApp (demo).</div>'+
        '<div style="background:rgba(232,82,26,.07);border:1px solid rgba(232,82,26,.15);border-radius:18px;padding:10px 12px;margin:0 16px 12px;font-size:12px;line-height:1.6;color:rgba(255,190,120,.85);">&#x26A0; Important: product is delivered ONLY after all payments are received.</div>'+
        '<div class="row2" style="padding:0 16px;">'+
          '<div class="field"><label>Full Name *</label><input type="text" id="lp_name" placeholder="Your full name" autocomplete="name"></div>'+
          '<div class="field"><label>Phone *</label><input type="tel" id="lp_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>'+
        '</div>'+
        '<div class="field" style="padding:0 16px;"><label>Delivery Address *</label><input type="text" id="lp_addr" placeholder="e.g. Near Malaba Market"></div>'+
        '<div style="font-size:10px;font-weight:900;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin:0 16px 8px;">First Payment Method</div>'+
        '<div class="pay-opts" style="padding:0 16px;">'+
          '<div class="po sel" id="lpo_mpesa" onclick="setLipaPay(\'mpesa\',this)"><div class="po-ico">&#x1F4F1;</div><div class="po-txt"><strong>M-Pesa</strong><span>Send for first instalment</span></div><div class="po-dot"></div></div>'+
          '<div class="po" id="lpo_cash" onclick="setLipaPay(\'cash\',this)"><div class="po-ico">&#x1F4B5;</div><div class="po-txt"><strong>Cash</strong><span>Pay first instalment in cash</span></div><div class="po-dot"></div></div>'+
        '</div>'+
        '<div style="padding:0 16px 18px;margin-top:12px;">'+
          '<button class="sbtn" onclick="submitLipa()">&#x1F4B0; Submit Plan Request (Demo)</button>'+
        '</div>'+
      '</div>';

    // default select first frequency
    state.lipaFreq = freqs[0];
    document.querySelector('#lp2 .lipa-durs') && buildDurGrid();
    buildDurGrid();

    openOverlay();

    function calcFreqs(total){
      return [
        {id:'daily', label:'Daily', per:'day', desc:'Best value. No extra markup.', estimatePerPay:(t)=> t/14, factor:1.0},
        {id:'3xweek', label:'3× per week', per:'week', desc:'+2% total. Flexible.', estimatePerPay:(t)=> (t*1.02)/6, factor:1.02},
        {id:'2xweek', label:'Twice a week', per:'week', desc:'+4% total. Comfortable pace.', estimatePerPay:(t)=> (t*1.04)/4, factor:1.04},
        {id:'weekly', label:'Weekly', per:'week', desc:'+7% total. Once per week.', estimatePerPay:(t)=> (t*1.07)/2, factor:1.07},
      ];
    }

    // Duration options computed based on selected frequency
    window.selFreq = function(id, idx){
      // update selected visuals
      document.querySelectorAll('.lipa-freq').forEach(el=>el.classList.remove('sel'));
      const el = document.getElementById('lf-'+id);
      if(el) el.classList.add('sel');
      state.lipaFreq = freqs[idx];
      buildDurGrid();
    };

    window.lipaNext = function(step){
      if(step===1){
        if(!state.lipaFreq){ toast('Please select a frequency'); return; }
        setPanel(2);
      } else if(step===2){
        if(!state.lipaDur){ toast('Please select a duration'); return; }
        setPanel(3);
      }
    };

    window.lipaBack = function(step){
      if(step===2) setPanel(1);
      if(step===3) setPanel(2);
    };

    window.setLipaPay = function(mode, el){
      state.lipaPayMode = mode;
      const mp = document.getElementById('lpo_mpesa');
      const c  = document.getElementById('lpo_cash');
      if(mp) mp.classList.toggle('sel', mode==='mpesa');
      if(c) c.classList.toggle('sel', mode==='cash');
    };

    window.submitLipa = function(){
      const name = (document.getElementById('lp_name').value||'').trim();
      const phone= (document.getElementById('lp_phone').value||'').trim();
      const addr = (document.getElementById('lp_addr').value||'').trim();
      if(!name){ toast('Enter your full name'); return; }
      if(!phone || phone.replace(/\D/g,'').length<9){ toast('Enter a valid phone number'); return; }
      if(!addr){ toast('Enter your delivery address'); return; }
      if(!state.lipaDur){ toast('Select duration first'); return; }

      document.getElementById('sheetContent').innerHTML =
        '<div class="sh-top">'+
          '<div class="sh-handle"></div>'+
          '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button>'+
        '</div>'+
        '<div style="padding:22px 16px 16px;text-align:center;">'+
          '<div style="font-size:54px;margin-bottom:10px;">&#x1F389;</div>'+
          '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:26px;letter-spacing:.5px;margin-bottom:6px;">Request Sent!</div>'+
          '<div style="font-size:13px;color:rgba(255,255,255,.65);line-height:1.6;margin-bottom:12px;">Demo success. Wire this to backend later (api/order.php).</div>'+
          '<div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:18px;padding:12px;text-align:left;">'+
            '<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px;"><span style="color:rgba(255,255,255,.55);">Item</span><span style="font-weight:900;">'+esc(item.title)+'</span></div>'+
            '<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px;"><span style="color:rgba(255,255,255,.55);">Plan</span><span style="font-weight:900;color:var(--gold);">'+esc(state.lipaFreq.label)+' &bull; '+esc(state.lipaDur.label)+'</span></div>'+
            '<div style="display:flex;justify-content:space-between;font-size:13px;"><span style="color:rgba(255,255,255,.55);">First Pay</span><span style="font-weight:900;">'+esc(state.lipaPayMode.toUpperCase())+'</span></div>'+
          '</div>'+
          '<button class="sbtn" style="margin-top:14px;" onclick="closeOverlay()">Continue Shopping</button>'+
        '</div>';
    };

    function setPanel(p){
      // panels
      document.getElementById('lp1').classList.toggle('active', p===1);
      document.getElementById('lp2').classList.toggle('active', p===2);
      document.getElementById('lp3').classList.toggle('active', p===3);

      // steps
      const ls1 = document.getElementById('ls1');
      const ls2 = document.getElementById('ls2');
      const ls3 = document.getElementById('ls3');
      [ls1,ls2,ls3].forEach(x=>x && x.classList.remove('active','done'));
      if(p===1){ ls1 && ls1.classList.add('active'); }
      if(p===2){ ls1 && ls1.classList.add('done'); ls2 && ls2.classList.add('active'); }
      if(p===3){ ls1 && ls1.classList.add('done'); ls2 && ls2.classList.add('done'); ls3 && ls3.classList.add('active'); }
    }

    function buildDurGrid(){
      const durGrid = document.getElementById('durGrid');
      const summary = document.getElementById('durSummary');
      if(!durGrid) return;

      const total = raw * state.lipaFreq.factor;

      // show 4 durations
      const options = [
        {weeks:2,  label:'2 Weeks',  deposit: total*0.25, total: total*1.00},
        {weeks:4,  label:'4 Weeks',  deposit: total*0.20, total: total*1.01},
        {weeks:8,  label:'8 Weeks',  deposit: total*0.15, total: total*1.03},
        {weeks:12, label:'12 Weeks', deposit: total*0.10, total: total*1.05},
      ].map(o=>{
        const payCount = Math.max(1, Math.round(o.weeks));
        const perPay = o.total / payCount;
        return {
          ...o,
          perPay,
          totalFinal:o.total,
        };
      });

      state.lipaDur = null;
      durGrid.innerHTML = options.map((d,idx)=>{
        return '<div class="lipa-dur" id="ld-'+idx+'" onclick="selDur('+idx+')">'+
          '<div class="ld-weeks">'+d.weeks+'</div>'+
          '<div class="ld-label">weeks</div>'+
          '<div class="ld-per">'+esc(formatKSH(d.perPay))+'</div>'+
          '<div class="ld-total">Total: '+esc(formatKSH(d.totalFinal))+'</div>'+
        '</div>';
      }).join('');

      summary.style.display='none';
    }

    window.selDur = function(i){
      const total = raw * state.lipaFreq.factor;
      const options = [
        {weeks:2,  label:'2 Weeks',  deposit: total*0.25, total: total*1.00},
        {weeks:4,  label:'4 Weeks',  deposit: total*0.20, total: total*1.01},
        {weeks:8,  label:'8 Weeks',  deposit: total*0.15, total: total*1.03},
        {weeks:12, label:'12 Weeks', deposit: total*0.10, total: total*1.05},
      ].map(o=>{
        const payCount = Math.max(1, Math.round(o.weeks));
        const perPay = o.total / payCount;
        return {
          ...o,
          perPay,
          totalFinal:o.total,
        };
      });
      state.lipaDur = options[i];

      document.querySelectorAll('.lipa-dur').forEach(el=>el.classList.remove('sel'));
      const el = document.getElementById('ld-'+i);
      if(el) el.classList.add('sel');

      const summary = document.getElementById('durSummary');
      if(summary){
        summary.style.display='block';
        summary.innerHTML =
          '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:18px;color:var(--amber2);letter-spacing:.3px;margin-bottom:4px;">Plan Summary</div>'+
          '<div style="display:flex;justify-content:space-between;font-size:12px;padding:3px 0;"><span style="color:rgba(255,255,255,.62);">Frequency</span><span style="font-weight:900;color:var(--text);">'+esc(state.lipaFreq.label)+'</span></div>'+
          '<div style="display:flex;justify-content:space-between;font-size:12px;padding:3px 0;"><span style="color:rgba(255,255,255,.62);">Duration</span><span style="font-weight:900;color:var(--text);">'+esc(state.lipaDur.label)+'</span></div>'+
          '<div style="display:flex;justify-content:space-between;font-size:12px;padding:3px 0;"><span style="color:rgba(255,255,255,.62);">Per payment (est.)</span><span style="font-weight:900;color:var(--gold);">'+esc(formatKSH(state.lipaDur.perPay))+'</span></div>'+
          '<div style="display:flex;justify-content:space-between;font-size:12px;padding:3px 0;"><span style="color:rgba(255,255,255,.62);">Deposit</span><span style="font-weight:900;color:var(--text);">'+esc(formatKSH(state.lipaDur.deposit))+'</span></div>'+
          '<div style="display:flex;justify-content:space-between;font-size:12px;padding:3px 0;"><span style="color:rgba(255,255,255,.62);">Grand total</span><span style="font-weight:900;color:var(--text);">'+esc(formatKSH(state.lipaDur.totalFinal))+'</span></div>';
      }
    }

    // expose helpers
    window.lipaBack = window.lipaBack;
    window.lipaNext = window.lipaNext;
    window.selFreq = window.selFreq;
    window.selDur = window.selDur;
    window.setLipaPay = window.setLipaPay;
    window.submitLipa = window.submitLipa;

    function buildDurGrid(){
      // overwritten by inner function call
    }
  }

  // Init
  render();
</script>
</body>
</html>

