/**
 * img_perf.js — Malaba Homes Image & Render Performance Layer
 * Include on every listing page: <script src="img_perf.js"></script>
 * ─────────────────────────────────────────────────────────────
 * Handles:
 *  1. CDN URL optimisation (Cloudinary, Unsplash, generic)
 *  2. Progressive batched card rendering (no DOM flood)
 *  3. Blur-up placeholder → real image transition
 *  4. Retry on failed images
 *  5. Scroll performance (passive listeners, will-change hints)
 *  6. Intersection Observer lazy activation (Ken Burns only fires
 *     when card is actually visible)
 */

(function(global) {
  'use strict';

  /* ─── 1. CDN IMAGE OPTIMISER ─────────────────────────────── */
  function cdnImg(url, w, h, quality) {
    if (!url) return '';
    quality = quality || 75;
    w = w || 800; h = h || 600;

    // Cloudinary
    if (url.indexOf('cloudinary.com') !== -1) {
      var transform = 'w_' + w + ',h_' + h + ',c_fill,f_auto,q_auto:' +
                      (quality >= 80 ? 'good' : 'eco') + ',dpr_auto';
      return url.replace('/upload/', '/upload/' + transform + '/');
    }
    // Unsplash
    if (url.indexOf('unsplash.com') !== -1) {
      var base = url.split('?')[0];
      return base + '?w=' + w + '&h=' + h + '&q=' + quality +
             '&auto=format&fit=crop';
    }
    // imgbb, imgur
    if (url.indexOf('imgbb.com') !== -1 || url.indexOf('imgur.com') !== -1) {
      return url; // no resize API, serve as-is
    }
    return url;
  }

  // Convenience sizes
  function imgCard(url)    { return cdnImg(url, 600, 450, 75); }   // card thumbnail
  function imgThumb(url)   { return cdnImg(url, 120, 90,  60); }   // tiny thumbnail strip
  function imgHero(url)    { return cdnImg(url, 1200, 800, 80); }  // full detail view
  function imgBlur(url)    { return cdnImg(url, 20, 15, 30); }     // tiny blur placeholder


  /* ─── 2. BLUR-UP IMAGE LOADER ────────────────────────────── */
  /**
   * Creates an <img> element that:
   *  - Shows a blurred 20px placeholder immediately
   *  - Cross-fades to the full image when loaded
   *  - Never causes layout shift (wrapper has fixed aspect ratio)
   *
   * Usage:
   *   var el = MhImgPerf.lazyImg(url, 'Card title', '4/3');
   *   container.appendChild(el);
   */
  function lazyImg(src, alt, ratio, w, h) {
    ratio = ratio || '4/3';
    w = w || 600; h = h || 450;
    alt = alt || '';

    var wrap = document.createElement('div');
    wrap.style.cssText =
      'position:relative;width:100%;overflow:hidden;' +
      'aspect-ratio:' + ratio + ';background:#141008;';

    // Blur placeholder (tiny, loads instantly)
    var blurSrc = imgBlur(src);
    var placeholder = document.createElement('img');
    placeholder.src = blurSrc;
    placeholder.alt = '';
    placeholder.setAttribute('aria-hidden', 'true');
    placeholder.style.cssText =
      'position:absolute;inset:0;width:100%;height:100%;' +
      'object-fit:cover;filter:blur(8px);transform:scale(1.08);' +
      'transition:opacity .4s ease;';

    // Full image (loaded lazily)
    var full = document.createElement('img');
    full.alt = alt;
    full.loading = 'lazy';
    full.decoding = 'async';
    full.style.cssText =
      'position:absolute;inset:0;width:100%;height:100%;' +
      'object-fit:cover;opacity:0;' +
      'transition:opacity .5s ease;will-change:opacity;';
    full.setAttribute('width', w);
    full.setAttribute('height', h);

    // Cross-fade when full image loads
    full.onload = function() {
      full.style.opacity = '1';
      // Fade out placeholder
      setTimeout(function() {
        placeholder.style.opacity = '0';
      }, 100);
    };

    // Fallback on error
    full.onerror = function() {
      full.src = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=600&q=60';
      full.style.opacity = '1';
    };

    // Intersection Observer: only set src when near viewport
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function(entries) {
        if (entries[0].isIntersecting) {
          full.src = cdnImg(src, w, h, 75);
          io.disconnect();
        }
      }, { rootMargin: '400px 0px' }); // load 400px before visible
      io.observe(wrap);
    } else {
      // Fallback: load immediately
      full.src = cdnImg(src, w, h, 75);
    }

    wrap.appendChild(placeholder);
    wrap.appendChild(full);
    return wrap;
  }


  /* ─── 3. BATCHED CARD RENDERER ───────────────────────────── */
  /**
   * Renders items in small batches as user scrolls.
   * Prevents rendering 80 cards at once which freezes the browser.
   *
   * Usage:
   *   MhImgPerf.batchRender({
   *     items:      allItems,        // array
   *     container:  gridElement,     // DOM element to append to
   *     sentinel:   sentinelElement, // DOM element at the bottom
   *     batchSize:  8,               // cards per batch (default 8)
   *     renderOne:  function(item) { return cardElement; },
   *     onEmpty:    function() { sentinelElement.innerHTML='All done'; }
   *   });
   */
  function batchRender(opts) {
    var items     = opts.items     || [];
    var container = opts.container;
    var sentinel  = opts.sentinel;
    var batchSize = opts.batchSize || 8;
    var renderOne = opts.renderOne;
    var onEmpty   = opts.onEmpty   || function(){};
    var rendered  = 0;
    var loading   = false;

    function doRender() {
      if (loading || rendered >= items.length) return;
      loading = true;

      var batch = items.slice(rendered, rendered + batchSize);
      var frag  = document.createDocumentFragment();

      batch.forEach(function(item, i) {
        var el = renderOne(item);
        if (!el) return;
        // Stagger animation delay — max 7 cards staggered
        if (el.style !== undefined) {
          el.style.animationDelay = Math.min(i, 6) * 0.055 + 's';
        }
        frag.appendChild(el);
      });

      container.appendChild(frag);
      rendered += batch.length;
      loading = false;

      if (rendered >= items.length && onEmpty) {
        onEmpty();
        if (obs) obs.disconnect();
      }
    }

    // First batch immediately
    doRender();

    // Subsequent batches on scroll
    var obs = null;
    if ('IntersectionObserver' in window && sentinel) {
      obs = new IntersectionObserver(function(entries) {
        if (entries[0].isIntersecting) doRender();
      }, { rootMargin: '300px' });
      obs.observe(sentinel);
    }

    return {
      reset: function(newItems) {
        items = newItems; rendered = 0;
        container.innerHTML = '';
        doRender();
        if (obs && sentinel) obs.observe(sentinel);
      },
      append: function(newItems) {
        items = items.concat(newItems);
        doRender();
        if (obs && sentinel) obs.observe(sentinel);
      }
    };
  }


  /* ─── 4. SCROLL PERFORMANCE ──────────────────────────────── */
  /**
   * Applies will-change and passive scroll listeners globally.
   * Call once on page load.
   */
  function initScrollPerf() {
    // Tell browser which elements will animate
    var scrollContainers = document.querySelectorAll('.feed,.food-list,.homes-list,.shop-grid');
    scrollContainers.forEach(function(el) {
      el.style.willChange = 'transform';
    });

    // Throttle scroll events — run at most once per animation frame
    var ticking = false;
    document.addEventListener('scroll', function() {
      if (!ticking) {
        requestAnimationFrame(function() { ticking = false; });
        ticking = true;
      }
    }, { passive: true });
  }


  /* ─── 5. INTERSECTION OBSERVER FOR KEN BURNS ─────────────── */
  /**
   * Ken Burns zoom animation should only run on the visible card.
   * This activates/deactivates the CSS class as cards enter/leave.
   */
  function initKenBurns(containerSelector) {
    if (!('IntersectionObserver' in window)) return;
    var obs = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        entry.target.classList.toggle('active', entry.isIntersecting);
      });
    }, { threshold: 0.3 });

    document.querySelectorAll(containerSelector).forEach(function(el) {
      obs.observe(el);
    });
  }


  /* ─── 6. SKELETON → REAL CONTENT SWAP ───────────────────── */
  /**
   * Show skeletons while loading, then swap to real content
   * with a smooth fade — no jarring jump.
   */
  function swapSkeletons(container, realContent) {
    var skels = container.querySelectorAll('.skel-card,.skel-fcard,.skel');
    // Fade out skeletons
    skels.forEach(function(s) {
      s.style.transition = 'opacity .3s ease';
      s.style.opacity = '0';
    });
    setTimeout(function() {
      container.innerHTML = '';
      // Fade in real content
      realContent.style.opacity = '0';
      container.appendChild(realContent);
      requestAnimationFrame(function() {
        realContent.style.transition = 'opacity .4s ease';
        realContent.style.opacity = '1';
      });
    }, 300);
  }


  /* ─── 7. PRELOAD ABOVE-THE-FOLD IMAGES ──────────────────── */
  /**
   * Preload the first 3 images immediately (above the fold).
   * Everything else is lazy loaded.
   */
  function preloadFirst(items, n) {
    n = n || 3;
    items.slice(0, n).forEach(function(item) {
      var src = item.image || item.image_url || '';
      if (!src) return;
      var link = document.createElement('link');
      link.rel  = 'preload';
      link.as   = 'image';
      link.href = cdnImg(src, 600, 450, 75);
      document.head.appendChild(link);
    });
  }


  /* ─── SHARED CSS (injected once) ─────────────────────────── */
  function injectCSS() {
    if (document.getElementById('mhImgPerfCSS')) return;
    var style = document.createElement('style');
    style.id  = 'mhImgPerfCSS';
    style.textContent = [
      /* Fixed aspect-ratio image boxes — prevents ALL layout shift */
      '.mh-img-box{position:relative;width:100%;overflow:hidden;background:#141008;}',
      '.mh-img-box img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;}',
      /* Cards enter from below */
      '.mh-card-enter{opacity:0;transform:translateY(14px);animation:mhCardIn .38s ease forwards;}',
      '@keyframes mhCardIn{to{opacity:1;transform:translateY(0)}}',
      /* Blur-up fade */
      '.mh-blur-placeholder{filter:blur(8px);transform:scale(1.08);transition:opacity .4s ease;}',
      '.mh-blur-placeholder.hidden{opacity:0;}',
      /* Smooth image load */
      '.mh-img-full{opacity:0;transition:opacity .5s ease;will-change:opacity;}',
      '.mh-img-full.loaded{opacity:1;}',
      /* Skeleton pulse */
      '.skel{background:linear-gradient(90deg,#151008 25%,rgba(255,255,255,.04) 50%,#151008 75%);' +
        'background-size:200% 100%;animation:mhShim 1.4s infinite;}',
      '@keyframes mhShim{0%{background-position:200% 0}100%{background-position:-200% 0}}',
    ].join('');
    document.head.appendChild(style);
  }

  injectCSS();
  initScrollPerf();

  /* ─── PUBLIC API ─────────────────────────────────────────── */
  global.MhImgPerf = {
    cdnImg      : cdnImg,
    imgCard     : imgCard,
    imgThumb    : imgThumb,
    imgHero     : imgHero,
    lazyImg     : lazyImg,
    batchRender : batchRender,
    preloadFirst: preloadFirst,
    initKenBurns: initKenBurns,
    swapSkeletons: swapSkeletons,
    initScrollPerf: initScrollPerf,
  };

})(window);
