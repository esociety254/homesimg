<?php
require_once 'includes/auth.php';
requireLogin();

$db = getDB();
$lid = $_SESSION['landlord_id'];

$tenants = $db->prepare("
    SELECT t.*, u.unit_number, u.rent_amount, b.name as building_name, b.id as building_id,
           (SELECT COUNT(*) FROM penalties p WHERE p.tenant_id=t.id AND p.status='unpaid') as pending_penalties,
           (SELECT COALESCE(SUM(amount),0) FROM penalties p WHERE p.tenant_id=t.id AND p.status='unpaid') as penalty_total
    FROM tenants t
    JOIN units u ON t.unit_id=u.id
    JOIN buildings b ON u.building_id=b.id
    WHERE t.landlord_id=? AND t.active=1
    ORDER BY b.name, u.unit_number
");
$tenants->execute([$lid]);
$allTenants = $tenants->fetchAll();

// Get vacant units for adding tenants
$vacantUnits = $db->prepare("
    SELECT u.id, u.unit_number, u.rent_amount, b.name as building_name, b.id as building_id
    FROM units u
    JOIN buildings b ON u.building_id=b.id
    WHERE b.landlord_id=? AND u.status='vacant'
    ORDER BY b.name, u.unit_number
");
$vacantUnits->execute([$lid]);
$vacant = $vacantUnits->fetchAll();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>Tenants – MalabaHomes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>

<main class="main-content">
  <div class="page-header">
    <div>
      <h1 class="page-title">Tenants</h1>
      <p class="page-sub"><?= count($allTenants) ?> active tenants · <?= count($vacant) ?> vacant units</p>
    </div>
    <button class="btn-primary" onclick="openModal('addTenantModal')" <?= empty($vacant)?'disabled title="No vacant units"':'' ?>>+ Add Tenant</button>
  </div>

  <?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg']) ?></div>
  <?php endif; ?>

  <?php if (empty($vacant) && empty($allTenants)): ?>
    <div class="empty-full">
      <div class="empty-icon">👥</div>
      <h3>No units available</h3>
      <p>Add buildings and units first, then add tenants</p>
      <a href="buildings.php" class="btn-primary">Go to Buildings →</a>
    </div>
  <?php else: ?>
  <div class="tenant-cards">
    <?php foreach ($allTenants as $t): ?>
    <div class="tenant-full-card">
      <div class="tfc-left">
        <div class="tenant-avatar large"><?= strtoupper(substr($t['name'],0,1)) ?></div>
        <div class="tfc-info">
          <div class="tfc-name"><?= htmlspecialchars($t['name']) ?></div>
          <div class="tfc-unit">🏠 <?= htmlspecialchars($t['building_name']) ?> · Unit <?= htmlspecialchars($t['unit_number']) ?></div>
          <div class="tfc-phone">📞 <?= htmlspecialchars($t['phone']) ?></div>
          <?php if ($t['email']): ?><div class="tfc-email">✉️ <?= htmlspecialchars($t['email']) ?></div><?php endif; ?>
          <?php if ($t['move_in_date']): ?><div class="tfc-date">📅 Moved in: <?= date('d M Y', strtotime($t['move_in_date'])) ?></div><?php endif; ?>
          <div class="tfc-rent">💰 <?= formatMoney($t['rent_amount']) ?>/mo</div>
          <?php if ($t['pending_penalties'] > 0): ?>
          <div class="tfc-penalty">⚠️ <?= $t['pending_penalties'] ?> pending penalty · <?= formatMoney($t['penalty_total']) ?></div>
          <?php endif; ?>
        </div>
      </div>
      <div class="tfc-actions">
        <a href="<?= getWhatsAppLink($t['phone'], "Hello {$t['name']}, ") ?>" target="_blank" class="btn-wa-full">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.096.537 4.07 1.482 5.795L0 24l6.349-1.461A11.932 11.932 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.885 0-3.655-.51-5.18-1.396l-.371-.22-3.767.866.896-3.67-.242-.385A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/></svg>
          WhatsApp
        </a>
        <button class="btn-sm btn-outline" onclick="editTenant(<?= $t['id'] ?>, '<?= addslashes($t['name']) ?>', '<?= $t['phone'] ?>', '<?= $t['email'] ?>', '<?= $t['id_number'] ?>')">Edit</button>
        <form method="POST" action="api.php" style="display:inline" onsubmit="return confirm('Remove tenant from this unit?')">
          <input type="hidden" name="action" value="remove_tenant">
          <input type="hidden" name="id" value="<?= $t['id'] ?>">
          <button type="submit" class="btn-sm btn-danger">Remove</button>
        </form>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</main>

<!-- ADD TENANT MODAL -->
<div id="addTenantModal" class="modal-overlay" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3>Add New Tenant</h3>
      <button onclick="closeModal('addTenantModal')" class="modal-close">✕</button>
    </div>
    <form method="POST" action="api.php">
      <input type="hidden" name="action" value="add_tenant">
      <div class="field">
        <label>Assign to Unit *</label>
        <select name="unit_id" required>
          <option value="">Select vacant unit...</option>
          <?php foreach ($vacant as $v): ?>
          <option value="<?= $v['id'] ?>"><?= htmlspecialchars($v['building_name']) ?> · Unit <?= htmlspecialchars($v['unit_number']) ?> (<?= formatMoney($v['rent_amount']) ?>/mo)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label>Full Name *</label>
        <input type="text" name="name" placeholder="Tenant full name" required>
      </div>
      <div class="field">
        <label>Phone Number *</label>
        <input type="tel" name="phone" placeholder="07XX XXX XXX" required>
      </div>
      <div class="field">
        <label>Email (optional)</label>
        <input type="email" name="email" placeholder="tenant@email.com">
      </div>
      <div class="field">
        <label>ID Number (optional)</label>
        <input type="text" name="id_number" placeholder="National ID">
      </div>
      <div class="field">
        <label>Move-in Date</label>
        <input type="date" name="move_in_date" value="<?= date('Y-m-d') ?>">
      </div>
      <button type="submit" class="btn-primary full">Add Tenant</button>
    </form>
  </div>
</div>

<!-- EDIT TENANT MODAL -->
<div id="editTenantModal" class="modal-overlay" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3>Edit Tenant</h3>
      <button onclick="closeModal('editTenantModal')" class="modal-close">✕</button>
    </div>
    <form method="POST" action="api.php">
      <input type="hidden" name="action" value="edit_tenant">
      <input type="hidden" name="id" id="editTenantId">
      <div class="field">
        <label>Full Name</label>
        <input type="text" name="name" id="editTenantName" required>
      </div>
      <div class="field">
        <label>Phone Number</label>
        <input type="tel" name="phone" id="editTenantPhone" required>
      </div>
      <div class="field">
        <label>Email</label>
        <input type="email" name="email" id="editTenantEmail">
      </div>
      <div class="field">
        <label>ID Number</label>
        <input type="text" name="id_number" id="editTenantId2">
      </div>
      <button type="submit" class="btn-primary full">Save Changes</button>
    </form>
  </div>
</div>

<?php include 'includes/bottom-nav.php'; ?>
<script>
function openModal(id) { document.getElementById(id).style.display='flex'; }
function closeModal(id) { document.getElementById(id).style.display='none'; }
function editTenant(id, name, phone, email, idno) {
  document.getElementById('editTenantId').value = id;
  document.getElementById('editTenantName').value = name;
  document.getElementById('editTenantPhone').value = phone;
  document.getElementById('editTenantEmail').value = email;
  document.getElementById('editTenantId2').value = idno;
  openModal('editTenantModal');
}
document.querySelectorAll('.modal-overlay').forEach(m => m.addEventListener('click', function(e){ if(e.target===this) this.style.display='none'; }));
</script>
</body>
</html>
