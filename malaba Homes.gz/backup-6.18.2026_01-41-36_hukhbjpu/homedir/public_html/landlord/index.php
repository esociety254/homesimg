<?php
require_once 'includes/auth.php';

if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$mode = $_GET['mode'] ?? 'login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = getDB();

    if ($_POST['action'] === 'register') {
        $name  = trim($_POST['name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $pass  = $_POST['password'];

        if (strlen($pass) < 6) {
            $error = 'Password must be at least 6 characters.';
            $mode  = 'register';
        } else {
            try {
                $db->prepare("INSERT INTO landlords (name,email,phone,password) VALUES (?,?,?,?)")
                   ->execute([$name, $email, $phone, password_hash($pass, PASSWORD_DEFAULT)]);
                $id = $db->lastInsertId();
                $_SESSION['landlord_id']   = $id;
                $_SESSION['landlord_name'] = $name;
                header('Location: dashboard.php');
                exit;
            } catch (Exception $e) {
                $error = 'That email is already registered.';
                $mode  = 'register';
            }
        }
    } else {
        $stmt = $db->prepare("SELECT * FROM landlords WHERE email = ?");
        $stmt->execute([trim($_POST['email'])]);
        $landlord = $stmt->fetch();
        if ($landlord && password_verify($_POST['password'], $landlord['password'])) {
            $_SESSION['landlord_id']   = $landlord['id'];
            $_SESSION['landlord_name'] = $landlord['name'];
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Incorrect email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>MalabaHomes – Rental Management</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
<style>
  /* Auth-specific overrides */
  .auth-hero-subtitle {
    margin-top: 6px;
    display: flex; align-items: center; justify-content: center; gap: 10px;
  }
  .hero-dot { width: 4px; height: 4px; border-radius: 50%; background: var(--red); }
  .hero-word { font-size: 10px; font-weight: 700; letter-spacing: 2.5px; text-transform: uppercase; color: rgba(255,255,255,.4); }

  /* Input icons */
  .input-group { position: relative; }
  .input-group .input-icon {
    position: absolute; left: 13px; top: 50%; transform: translateY(-50%);
    font-size: 15px; pointer-events: none;
    opacity: .45;
  }
  .input-group textarea + .input-icon { top: 14px; transform: none; }
  .input-group input,
  .input-group select {
    padding-left: 38px !important;
  }

  /* Password toggle */
  .pw-toggle {
    position: absolute; right: 12px; top: 50%; transform: translateY(-50%);
    background: none; border: none; cursor: pointer;
    font-size: 16px; padding: 4px; opacity: .4;
    transition: opacity .2s;
  }
  .pw-toggle:hover { opacity: .8; }

  /* Footer strip */
  .auth-footer {
    text-align: center; padding: 14px 0 4px;
    font-size: 11.5px; color: var(--text-muted); font-weight: 500;
  }
  .auth-footer span { color: var(--primary); font-weight: 700; }

  /* Submit button loading state */
  .btn-primary.loading { pointer-events: none; opacity: .7; }
  .btn-primary.loading::after {
    content: '';
    display: inline-block; width: 14px; height: 14px;
    border: 2px solid rgba(255,255,255,.4);
    border-top-color: #fff;
    border-radius: 50%;
    animation: spin .6s linear infinite;
    margin-left: 8px;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  /* Divider */
  .form-divider {
    display: flex; align-items: center; gap: 10px;
    margin: 6px 0 14px; color: var(--text-light); font-size: 11px;
  }
  .form-divider::before, .form-divider::after {
    content: ''; flex: 1; height: 1px; background: var(--border);
  }
</style>
</head>
<body class="auth-body">

<!-- ── Hero Band ─────────────────────────────── -->
<!--<div class="auth-hero">-->
<!--  <div class="auth-logo-wrap">-->
<!--    <img src="assets/logo.png"  alt="MalabaHomes" class="auth-logo" onerror="this.outerHTML='<div style=\'font-size:28px;font-weight:900;color:#fff;letter-spacing:-1px\'>🏠 MALABA<span style=\'color:#C0001A\'>HOMES</span></div>'"-->
<!--    >-->
<!--  </div>-->
<!--  <div class="auth-hero-subtitle">-->
<!--    <span class="hero-word">Eat</span>-->
<!--    <div class="hero-dot"></div>-->
<!--    <span class="hero-word">Shop</span>-->
<!--    <div class="hero-dot"></div>-->
<!--    <span class="hero-word">Stay</span>-->
<!--  </div>-->
<!--  <div class="auth-tagline">Rental Management Portal</div>-->
<!--</div>-->

<!-- ── Auth Card ──────────────────────────────── -->
<div class="auth-card">

  <!-- Tabs -->
  <div class="auth-tabs">
    <button class="tab-btn <?= $mode==='login'?'active':'' ?>" onclick="switchTab('login', this)">Sign In</button>
    <button class="tab-btn <?= $mode==='register'?'active':'' ?>" onclick="switchTab('register', this)">Create Account</button>
  </div>

  <?php if ($error): ?>
    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <!-- ── LOGIN ──────────────────────────────── -->
  <form method="POST" id="loginForm" class="auth-form <?= $mode==='login'?'active':'' ?>" onsubmit="setLoading(this)">
    <input type="hidden" name="action" value="login">

    <div class="field">
      <label>Email Address</label>
      <div class="input-group">
        <span class="input-icon">✉️</span>
        <input type="email" name="email" placeholder="you@email.com" required autocomplete="email">
      </div>
    </div>

    <div class="field">
      <label>Password</label>
      <div class="input-group" style="position:relative">
        <span class="input-icon">🔒</span>
        <input type="password" name="password" id="loginPw" placeholder="••••••••" required autocomplete="current-password">
        <button type="button" class="pw-toggle" onclick="togglePw('loginPw', this)">👁</button>
      </div>
    </div>

    <button type="submit" class="btn-primary full">Sign In →</button>

    <div class="form-divider">New here?</div>
    <button type="button" class="btn-sm full" style="background:transparent;color:var(--primary);border:1.5px solid var(--red-mid);font-size:13px;padding:9px" onclick="switchTabBtn('register')">
      Create a free account
    </button>
  </form>

  <!-- ── REGISTER ───────────────────────────── -->
  <form method="POST" id="registerForm" class="auth-form <?= $mode==='register'?'active':'' ?>" onsubmit="setLoading(this)">
    <input type="hidden" name="action" value="register">

    <div class="field">
      <label>Full Name</label>
      <div class="input-group">
        <span class="input-icon">👤</span>
        <input type="text" name="name" placeholder="John Malaba" required autocomplete="name">
      </div>
    </div>

    <div class="field">
      <label>Email Address</label>
      <div class="input-group">
        <span class="input-icon">✉️</span>
        <input type="email" name="email" placeholder="you@email.com" required autocomplete="email">
      </div>
    </div>

    <div class="field">
      <label>Phone Number</label>
      <div class="input-group">
        <span class="input-icon">📞</span>
        <input type="tel" name="phone" placeholder="0712 345 678" required autocomplete="tel">
      </div>
    </div>

    <div class="field">
      <label>Password</label>
      <div class="input-group" style="position:relative">
        <span class="input-icon">🔒</span>
        <input type="password" name="password" id="regPw" placeholder="Min 6 characters" required autocomplete="new-password">
        <button type="button" class="pw-toggle" onclick="togglePw('regPw', this)">👁</button>
      </div>
    </div>

    <button type="submit" class="btn-primary full">Create Account →</button>

    <div class="form-divider">Already have an account?</div>
    <button type="button" class="btn-sm full" style="background:transparent;color:var(--primary);border:1.5px solid var(--red-mid);font-size:13px;padding:9px" onclick="switchTabBtn('login')">
      Sign in instead
    </button>
  </form>

  <div class="auth-footer">
    © <?= date('Y') ?> <span>MalabaHomes</span> · Eat · Shop · Stay
  </div>
</div>

<script>
function switchTab(tab, btn) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
  if (btn) btn.classList.add('active');
  document.getElementById(tab + 'Form').classList.add('active');
}
function switchTabBtn(tab) {
  const btn = [...document.querySelectorAll('.tab-btn')].find(b => b.textContent.toLowerCase().includes(tab === 'login' ? 'sign' : 'create'));
  switchTab(tab, btn);
}
function togglePw(id, btn) {
  const el = document.getElementById(id);
  if (el.type === 'password') { el.type = 'text'; btn.textContent = '🙈'; }
  else { el.type = 'password'; btn.textContent = '👁'; }
}
function setLoading(form) {
  const btn = form.querySelector('.btn-primary');
  btn.classList.add('loading');
  btn.textContent = 'Please wait';
}
</script>
</body>
</html>
