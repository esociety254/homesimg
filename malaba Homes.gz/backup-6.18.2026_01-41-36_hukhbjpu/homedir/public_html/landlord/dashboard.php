<?php
require_once 'includes/auth.php';
requireLogin();

$db = getDB();
$lid = $_SESSION['landlord_id'];
$month = $_GET['month'] ?? getCurrentMonth();
$landlord = getLandlord();

// Stats
$buildings = $db->prepare("SELECT COUNT(*) FROM buildings WHERE landlord_id=?");
$buildings->execute([$lid]);
$totalBuildings = $buildings->fetchColumn();

$units = $db->prepare("SELECT COUNT(*) FROM units u JOIN buildings b ON u.building_id=b.id WHERE b.landlord_id=?");
$units->execute([$lid]);
$totalUnits = $units->fetchColumn();

$occupied = $db->prepare("SELECT COUNT(*) FROM units u JOIN buildings b ON u.building_id=b.id WHERE b.landlord_id=? AND u.status='occupied'");
$occupied->execute([$lid]);
$occupiedUnits = $occupied->fetchColumn();

// Monthly payments
$paidStmt = $db->prepare("SELECT COALESCE(SUM(amount),0) FROM payments WHERE landlord_id=? AND month=? AND status='paid'");
$paidStmt->execute([$lid, $month]);
$collected = $paidStmt->fetchColumn();

$expectedStmt = $db->prepare("SELECT COALESCE(SUM(u.rent_amount),0) FROM units u JOIN buildings b ON u.building_id=b.id WHERE b.landlord_id=? AND u.status='occupied'");
$expectedStmt->execute([$lid]);
$expected = $expectedStmt->fetchColumn();

$paidCountStmt = $db->prepare("SELECT COUNT(*) FROM payments WHERE landlord_id=? AND month=? AND status='paid'");
$paidCountStmt->execute([$lid, $month]);
$paidCount = $paidCountStmt->fetchColumn();

$pendingStmt = $db->prepare("
    SELECT t.id, t.name, t.phone, u.unit_number, u.rent_amount, b.name as building_name,
           p.status, p.id as payment_id
    FROM tenants t
    JOIN units u ON t.unit_id=u.id
    JOIN buildings b ON u.building_id=b.id
    LEFT JOIN payments p ON p.tenant_id=t.id AND p.month=?
    WHERE t.landlord_id=? AND t.active=1
    ORDER BY p.status ASC, b.name, u.unit_number
");
$pendingStmt->execute([$month, $lid]);
$allTenants = $pendingStmt->fetchAll();

$pendingPenalties = $db->prepare("SELECT COUNT(*) FROM penalties WHERE landlord_id=? AND status='unpaid'");
$pendingPenalties->execute([$lid]);
$penaltyCount = $pendingPenalties->fetchColumn();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>Dashboard – MalabaHomes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>

<?php include 'includes/nav.php'; ?>

<main class="main-content">
  <div class="page-header">
    <div>
      <h1 class="page-title">Dashboard</h1>
      <p class="page-sub">Welcome back, <?= htmlspecialchars($landlord['name']) ?></p>
    </div>
    <div class="month-picker">
      <input type="month" id="monthPicker" value="<?= $month ?>" onchange="location='?month='+this.value">
    </div>
  </div>

  <?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg']) ?></div>
  <?php endif; ?>

  <!-- STATS GRID -->
  <div class="stats-grid">
    <div class="stat-card stat-blue">
      <div class="stat-icon">🏢</div>
      <div class="stat-val"><?= $totalBuildings ?></div>
      <div class="stat-lbl">Buildings</div>
    </div>
    <div class="stat-card stat-green">
      <div class="stat-icon">🏠</div>
      <div class="stat-val"><?= $occupiedUnits ?>/<?= $totalUnits ?></div>
      <div class="stat-lbl">Occupied Units</div>
    </div>
    <div class="stat-card stat-purple">
      <div class="stat-icon">💰</div>
      <div class="stat-val"><?= formatMoney($collected) ?></div>
      <div class="stat-lbl">Collected <?= date('M Y', strtotime($month.'-01')) ?></div>
    </div>
    <div class="stat-card stat-orange <?= $penaltyCount>0?'has-badge':'' ?>">
      <div class="stat-icon">⚠️</div>
      <div class="stat-val"><?= $penaltyCount ?></div>
      <div class="stat-lbl">Pending Penalties</div>
    </div>
  </div>

  <!-- COLLECTION PROGRESS -->
  <?php if ($expected > 0): $pct = round(($collected/$expected)*100); ?>
  <div class="card collection-bar-card">
    <div class="card-row">
      <span class="card-label">Rent Collection Progress</span>
      <span class="coll-fraction"><?= formatMoney($collected) ?> / <?= formatMoney($expected) ?></span>
    </div>
    <div class="progress-track">
      <div class="progress-fill" style="width:<?= min($pct,100) ?>%"></div>
    </div>
    <div class="progress-pct"><?= $pct ?>% collected · <?= $paidCount ?> of <?= count($allTenants) ?> tenants paid</div>
  </div>
  <?php endif; ?>

  <!-- TENANT PAYMENT TABLE -->
  <div class="card">
    <div class="card-header">
      <h2>Rent Status – <?= date('F Y', strtotime($month.'-01')) ?></h2>
      <a href="tenants.php" class="btn-sm">+ Add Tenant</a>
    </div>
    <div class="tenant-list">
      <?php foreach ($allTenants as $t): 
        $status = $t['status'] ?? 'pending';
        $waLink = getWhatsAppLink($t['phone'], "Hello {$t['name']}, this is a reminder that your rent of " . formatMoney($t['rent_amount']) . " for " . date('F Y', strtotime($month.'-01')) . " is due. Please make payment. – MalabaHomes");
      ?>
      <div class="tenant-row <?= $status ?>">
        <div class="tenant-info">
          <div class="tenant-avatar"><?= strtoupper(substr($t['name'],0,1)) ?></div>
          <div>
            <div class="tenant-name"><?= htmlspecialchars($t['name']) ?></div>
            <div class="tenant-meta"><?= htmlspecialchars($t['building_name']) ?> · Unit <?= htmlspecialchars($t['unit_number']) ?></div>
          </div>
        </div>
        <div class="tenant-right">
          <div class="rent-amount"><?= formatMoney($t['rent_amount']) ?></div>
          <span class="status-badge <?= $status ?>"><?= ucfirst($status) ?></span>
          <div class="tenant-actions">
            <?php if ($status !== 'paid'): ?>
              <form method="POST" action="api.php" style="display:inline">
                <input type="hidden" name="action" value="mark_paid">
                <input type="hidden" name="tenant_id" value="<?= $t['id'] ?>">
                <input type="hidden" name="month" value="<?= $month ?>">
                <input type="hidden" name="amount" value="<?= $t['rent_amount'] ?>">
                <button type="submit" class="btn-icon btn-pay" title="Mark Paid">✓</button>
              </form>
              <a href="<?= $waLink ?>" target="_blank" class="btn-icon btn-wa" title="WhatsApp Reminder">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.096.537 4.07 1.482 5.795L0 24l6.349-1.461A11.932 11.932 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.885 0-3.655-.51-5.18-1.396l-.371-.22-3.767.866.896-3.67-.242-.385A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/></svg>
              </a>
              <button class="btn-icon btn-sms" title="Send SMS Reminder" onclick="sendSMS(<?= $t['id'] ?>, '<?= addslashes($t['name']) ?>', '<?= $t['phone'] ?>', '<?= addslashes(formatMoney($t['rent_amount'])) ?>')">💬</button>
            <?php else: ?>
              <span class="paid-check">✓ Paid</span>
            <?php endif; ?>
            <button class="btn-icon btn-penalty" title="Add Penalty" onclick="openPenalty(<?= $t['id'] ?>, '<?= addslashes($t['name']) ?>')">⚠</button>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
      <?php if (empty($allTenants)): ?>
        <div class="empty-state">No tenants yet. <a href="tenants.php">Add your first tenant →</a></div>
      <?php endif; ?>
    </div>
  </div>
</main>

<!-- PENALTY MODAL -->
<div id="penaltyModal" class="modal-overlay" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3>Add Penalty</h3>
      <button onclick="closeModal('penaltyModal')" class="modal-close">✕</button>
    </div>
    <form method="POST" action="api.php">
      <input type="hidden" name="action" value="add_penalty">
      <input type="hidden" name="tenant_id" id="penaltyTenantId">
      <div class="field">
        <label>Tenant</label>
        <input type="text" id="penaltyTenantName" readonly class="input-readonly">
      </div>
      <div class="field">
        <label>Amount (KSh)</label>
        <input type="number" name="amount" placeholder="e.g. 500" min="1" required>
      </div>
      <div class="field">
        <label>Reason</label>
        <textarea name="reason" placeholder="e.g. Late payment fee, Damage to property..." required rows="3"></textarea>
      </div>
      <button type="submit" class="btn-primary full">Apply Penalty</button>
    </form>
  </div>
</div>

<!-- SMS MODAL -->
<div id="smsModal" class="modal-overlay" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3>Send SMS Reminder</h3>
      <button onclick="closeModal('smsModal')" class="modal-close">✕</button>
    </div>
    <form method="POST" action="api.php">
      <input type="hidden" name="action" value="send_sms">
      <input type="hidden" name="tenant_id" id="smsTenantId">
      <div class="field">
        <label>To</label>
        <input type="text" id="smsTenantDisplay" readonly class="input-readonly">
      </div>
      <div class="field">
        <label>Message</label>
        <textarea name="message" id="smsMessage" rows="4" required></textarea>
      </div>
      <button type="submit" class="btn-primary full">📲 Send SMS</button>
    </form>
  </div>
</div>

<?php include 'includes/bottom-nav.php'; ?>

<script>
function openPenalty(id, name) {
  document.getElementById('penaltyTenantId').value = id;
  document.getElementById('penaltyTenantName').value = name;
  document.getElementById('penaltyModal').style.display = 'flex';
}
function sendSMS(id, name, phone, rent) {
  document.getElementById('smsTenantId').value = id;
  document.getElementById('smsTenantDisplay').value = name + ' · ' + phone;
  document.getElementById('smsMessage').value = `Hello ${name}, this is a reminder that your rent of ${rent} is due. Please make payment at your earliest convenience.\n– MalabaHomes`;
  document.getElementById('smsModal').style.display = 'flex';
}
function closeModal(id) {
  document.getElementById(id).style.display = 'none';
}
document.querySelectorAll('.modal-overlay').forEach(m => m.addEventListener('click', function(e){ if(e.target===this) this.style.display='none'; }));
</script>
</body>
</html>
