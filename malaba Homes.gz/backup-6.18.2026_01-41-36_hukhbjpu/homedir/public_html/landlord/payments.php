<?php
require_once 'includes/auth.php';
requireLogin();

$db = getDB();
$lid = $_SESSION['landlord_id'];
$tab = $_GET['tab'] ?? 'payments';
$month = $_GET['month'] ?? getCurrentMonth();

// Payments
$payments = $db->prepare("
    SELECT p.*, t.name as tenant_name, t.phone, u.unit_number, b.name as building_name
    FROM payments p
    JOIN tenants t ON p.tenant_id=t.id
    JOIN units u ON p.unit_id=u.id
    JOIN buildings b ON u.building_id=b.id
    WHERE p.landlord_id=? AND p.month=?
    ORDER BY p.status ASC, b.name, u.unit_number
");
$payments->execute([$lid, $month]);
$allPayments = $payments->fetchAll();

// Penalties
$penalties = $db->prepare("
    SELECT pen.*, t.name as tenant_name, t.phone, u.unit_number, b.name as building_name
    FROM penalties pen
    JOIN tenants t ON pen.tenant_id=t.id
    JOIN units u ON t.unit_id=u.id
    JOIN buildings b ON u.building_id=b.id
    WHERE pen.landlord_id=?
    ORDER BY pen.status ASC, pen.applied_date DESC
");
$penalties->execute([$lid]);
$allPenalties = $penalties->fetchAll();

// Summary
$totalPaid = array_sum(array_column(array_filter($allPayments, fn($p)=>$p['status']==='paid'), 'amount'));
$totalPending = array_sum(array_column(array_filter($allPayments, fn($p)=>$p['status']!=='paid'), 'amount'));
$totalPenalties = array_sum(array_column(array_filter($allPenalties, fn($p)=>$p['status']==='unpaid'), 'amount'));

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>Payments – MalabaHomes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>

<main class="main-content">
  <div class="page-header">
    <div>
      <h1 class="page-title">Payments & Penalties</h1>
    </div>
    <button class="btn-primary" onclick="openModal('bulkSmsModal')">📲 Bulk Remind</button>
  </div>

  <?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg']) ?></div>
  <?php endif; ?>

  <!-- TABS -->
  <div class="tab-bar">
    <a href="?tab=payments&month=<?= $month ?>" class="tab-link <?= $tab==='payments'?'active':'' ?>">💰 Payments</a>
    <a href="?tab=penalties" class="tab-link <?= $tab==='penalties'?'active':'' ?>">
      ⚠️ Penalties
      <?php if ($totalPenalties > 0): ?><span class="tab-badge"><?= count(array_filter($allPenalties,fn($p)=>$p['status']==='unpaid')) ?></span><?php endif; ?>
    </a>
  </div>

  <?php if ($tab === 'payments'): ?>
  <!-- PAYMENT SUMMARY -->
  <div class="stats-grid compact">
    <div class="stat-card stat-green">
      <div class="stat-val small"><?= formatMoney($totalPaid) ?></div>
      <div class="stat-lbl">Collected</div>
    </div>
    <div class="stat-card stat-orange">
      <div class="stat-val small"><?= formatMoney($totalPending) ?></div>
      <div class="stat-lbl">Pending</div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <h2>Payments – <?= date('F Y', strtotime($month.'-01')) ?></h2>
      <input type="month" value="<?= $month ?>" onchange="location='?tab=payments&month='+this.value" style="font-size:13px;padding:6px 10px;border:1px solid var(--border);border-radius:8px;background:var(--surface);color:var(--text)">
    </div>

    <div class="tenant-list">
      <?php foreach ($allPayments as $p): ?>
      <div class="tenant-row <?= $p['status'] ?>">
        <div class="tenant-info">
          <div class="tenant-avatar"><?= strtoupper(substr($p['tenant_name'],0,1)) ?></div>
          <div>
            <div class="tenant-name"><?= htmlspecialchars($p['tenant_name']) ?></div>
            <div class="tenant-meta"><?= htmlspecialchars($p['building_name']) ?> · Unit <?= htmlspecialchars($p['unit_number']) ?></div>
            <?php if ($p['paid_date']): ?>
            <div class="tenant-meta">Paid: <?= date('d M Y', strtotime($p['paid_date'])) ?></div>
            <?php endif; ?>
          </div>
        </div>
        <div class="tenant-right">
          <div class="rent-amount"><?= formatMoney($p['amount']) ?></div>
          <span class="status-badge <?= $p['status'] ?>"><?= ucfirst($p['status']) ?></span>
          <div class="tenant-actions">
            <?php if ($p['status'] !== 'paid'): ?>
              <form method="POST" action="api.php" style="display:inline">
                <input type="hidden" name="action" value="mark_paid">
                <input type="hidden" name="tenant_id" value="<?= $p['tenant_id'] ?>">
                <input type="hidden" name="month" value="<?= $month ?>">
                <input type="hidden" name="amount" value="<?= $p['amount'] ?>">
                <button type="submit" class="btn-icon btn-pay" title="Mark Paid">✓</button>
              </form>
            <?php else: ?>
              <form method="POST" action="api.php" style="display:inline">
                <input type="hidden" name="action" value="mark_unpaid">
                <input type="hidden" name="payment_id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn-icon btn-outline" title="Undo" onclick="return confirm('Mark as unpaid?')">↩</button>
              </form>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
      <?php if (empty($allPayments)): ?>
        <div class="empty-state">No payment records for this month.</div>
      <?php endif; ?>
    </div>
  </div>

  <?php else: ?>
  <!-- PENALTIES TAB -->
  <div class="stats-grid compact">
    <div class="stat-card stat-orange">
      <div class="stat-val small"><?= formatMoney($totalPenalties) ?></div>
      <div class="stat-lbl">Outstanding Penalties</div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <h2>All Penalties</h2>
    </div>
    <div class="tenant-list">
      <?php foreach ($allPenalties as $p): ?>
      <div class="tenant-row <?= $p['status']==='paid'?'paid':'pending' ?>">
        <div class="tenant-info">
          <div class="tenant-avatar"><?= strtoupper(substr($p['tenant_name'],0,1)) ?></div>
          <div>
            <div class="tenant-name"><?= htmlspecialchars($p['tenant_name']) ?></div>
            <div class="tenant-meta"><?= htmlspecialchars($p['building_name']) ?> · Unit <?= htmlspecialchars($p['unit_number']) ?></div>
            <div class="tenant-meta penalty-reason">📌 <?= htmlspecialchars($p['reason']) ?></div>
            <div class="tenant-meta">Applied: <?= date('d M Y', strtotime($p['applied_date'])) ?></div>
          </div>
        </div>
        <div class="tenant-right">
          <div class="rent-amount"><?= formatMoney($p['amount']) ?></div>
          <span class="status-badge <?= $p['status']==='paid'?'paid':'pending' ?>"><?= $p['status']==='paid'?'Resolved':'Unpaid' ?></span>
          <div class="tenant-actions">
            <?php if ($p['status'] !== 'paid'): ?>
              <form method="POST" action="api.php" style="display:inline">
                <input type="hidden" name="action" value="resolve_penalty">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn-icon btn-pay" title="Resolve">✓</button>
              </form>
            <?php endif; ?>
            <form method="POST" action="api.php" style="display:inline" onsubmit="return confirm('Delete this penalty?')">
              <input type="hidden" name="action" value="delete_penalty">
              <input type="hidden" name="id" value="<?= $p['id'] ?>">
              <button type="submit" class="btn-icon btn-danger" title="Delete">🗑</button>
            </form>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
      <?php if (empty($allPenalties)): ?>
        <div class="empty-state">No penalties recorded.</div>
      <?php endif; ?>
    </div>
  </div>
  <?php endif; ?>
</main>

<!-- BULK SMS MODAL -->
<div id="bulkSmsModal" class="modal-overlay" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3>📲 Bulk SMS Reminder</h3>
      <button onclick="closeModal('bulkSmsModal')" class="modal-close">✕</button>
    </div>
    <form method="POST" action="api.php">
      <input type="hidden" name="action" value="send_bulk_sms">
      <input type="hidden" name="month" value="<?= $month ?>">
      <div class="field">
        <label>Send To</label>
        <select name="type">
          <option value="unpaid">Only unpaid tenants this month</option>
          <option value="all">All active tenants</option>
        </select>
      </div>
      <div class="field">
        <label>Message <small>(use {name} and {month})</small></label>
        <textarea name="message" rows="4" required>Hello {name}, this is a reminder that your rent for {month} is due. Please make payment. – MalabaHomes</textarea>
      </div>
      <button type="submit" class="btn-primary full">Send Bulk SMS</button>
    </form>
  </div>
</div>

<?php include 'includes/bottom-nav.php'; ?>
<script>
function openModal(id) { document.getElementById(id).style.display='flex'; }
function closeModal(id) { document.getElementById(id).style.display='none'; }
document.querySelectorAll('.modal-overlay').forEach(m => m.addEventListener('click', function(e){ if(e.target===this) this.style.display='none'; }));
</script>
</body>
</html>
