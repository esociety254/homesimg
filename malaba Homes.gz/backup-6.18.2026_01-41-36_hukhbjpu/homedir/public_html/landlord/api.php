<?php
require_once 'includes/auth.php';
requireLogin();

$db = getDB();
$lid = $_SESSION['landlord_id'];
$action = $_POST['action'] ?? '';
$redirect = $_SERVER['HTTP_REFERER'] ?? 'dashboard.php';

function doRedirect($url, $type, $msg) {
    flash($type, $msg);
    header('Location: ' . $url);
    exit;
}

switch ($action) {

    // ── BUILDINGS ──────────────────────────────────────────────
    case 'add_building':
        $name    = trim($_POST['name']);
        $type    = $_POST['type'];
        $floors  = (int)($_POST['floors'] ?? 1);
        $address = trim($_POST['address'] ?? '');
        if (!$name || !in_array($type, ['storey','non_storey']))
            doRedirect('buildings.php', 'error', 'Invalid input.');
        $db->prepare("INSERT INTO buildings (landlord_id,name,type,floors,address) VALUES (?,?,?,?,?)")
           ->execute([$lid, $name, $type, max(1,$floors), $address]);
        doRedirect('buildings.php', 'success', "Building \"$name\" added.");

    case 'edit_building':
        $id      = (int)$_POST['id'];
        $name    = trim($_POST['name']);
        $floors  = (int)($_POST['floors'] ?? 1);
        $address = trim($_POST['address'] ?? '');
        $db->prepare("UPDATE buildings SET name=?,floors=?,address=? WHERE id=? AND landlord_id=?")
           ->execute([$name, max(1,$floors), $address, $id, $lid]);
        doRedirect('buildings.php', 'success', 'Building updated.');

    case 'delete_building':
        $id = (int)$_POST['id'];
        // Check no tenants
        $check = $db->prepare("SELECT COUNT(*) FROM tenants t JOIN units u ON t.unit_id=u.id WHERE u.building_id=? AND t.active=1");
        $check->execute([$id]);
        if ($check->fetchColumn() > 0)
            doRedirect('buildings.php', 'error', 'Cannot delete: building has active tenants.');
        $db->prepare("DELETE FROM units WHERE building_id=?")->execute([$id]);
        $db->prepare("DELETE FROM buildings WHERE id=? AND landlord_id=?")->execute([$id, $lid]);
        doRedirect('buildings.php', 'success', 'Building deleted.');

    // ── UNITS ──────────────────────────────────────────────────
    case 'add_unit':
        $buildingId  = (int)$_POST['building_id'];
        $unitNumber  = trim($_POST['unit_number']);
        $floor       = (int)($_POST['floor'] ?? 1);
        $rent        = (float)$_POST['rent_amount'];
        $bedrooms    = (int)($_POST['bedrooms'] ?? 1);
        // Verify building belongs to landlord
        $b = $db->prepare("SELECT id FROM buildings WHERE id=? AND landlord_id=?");
        $b->execute([$buildingId, $lid]);
        if (!$b->fetch()) doRedirect($redirect, 'error', 'Invalid building.');
        $db->prepare("INSERT INTO units (building_id,unit_number,floor,rent_amount,bedrooms) VALUES (?,?,?,?,?)")
           ->execute([$buildingId, $unitNumber, $floor, $rent, $bedrooms]);
        doRedirect("units.php?building=$buildingId", 'success', "Unit $unitNumber added.");

    case 'bulk_add_units':
        $buildingId = (int)$_POST['building_id'];
        $count      = min((int)$_POST['count'], 100);
        $prefix     = trim($_POST['prefix'] ?? 'Unit');
        $floor      = (int)($_POST['floor'] ?? 1);
        $rent       = (float)$_POST['rent_amount'];
        $b = $db->prepare("SELECT id FROM buildings WHERE id=? AND landlord_id=?");
        $b->execute([$buildingId, $lid]);
        if (!$b->fetch()) doRedirect($redirect, 'error', 'Invalid building.');
        // Find starting number
        $lastStmt = $db->prepare("SELECT unit_number FROM units WHERE building_id=? ORDER BY id DESC LIMIT 1");
        $lastStmt->execute([$buildingId]);
        $last = $lastStmt->fetchColumn();
        preg_match('/(\d+)$/', $last ?? '', $m);
        $start = isset($m[1]) ? (int)$m[1] + 1 : 1;
        $stmt = $db->prepare("INSERT INTO units (building_id,unit_number,floor,rent_amount) VALUES (?,?,?,?)");
        for ($i = 0; $i < $count; $i++) {
            $stmt->execute([$buildingId, $prefix . ($start + $i), $floor, $rent]);
        }
        doRedirect("units.php?building=$buildingId", 'success', "$count units added.");

    case 'edit_unit':
        $id         = (int)$_POST['id'];
        $unitNumber = trim($_POST['unit_number']);
        $rent       = (float)$_POST['rent_amount'];
        // Verify ownership
        $check = $db->prepare("SELECT u.id FROM units u JOIN buildings b ON u.building_id=b.id WHERE u.id=? AND b.landlord_id=?");
        $check->execute([$id, $lid]);
        if (!$check->fetch()) doRedirect($redirect, 'error', 'Unauthorized.');
        $db->prepare("UPDATE units SET unit_number=?, rent_amount=? WHERE id=?")->execute([$unitNumber, $rent, $id]);
        doRedirect($redirect, 'success', 'Unit updated.');

    case 'delete_unit':
        $id = (int)$_POST['id'];
        $check = $db->prepare("SELECT u.id FROM units u JOIN buildings b ON u.building_id=b.id WHERE u.id=? AND b.landlord_id=? AND u.status='vacant'");
        $check->execute([$id, $lid]);
        if (!$check->fetch()) doRedirect($redirect, 'error', 'Cannot delete occupied unit.');
        $db->prepare("DELETE FROM units WHERE id=?")->execute([$id]);
        doRedirect($redirect, 'success', 'Unit deleted.');

    // ── TENANTS ────────────────────────────────────────────────
    case 'add_tenant':
        $unitId    = (int)$_POST['unit_id'];
        $name      = trim($_POST['name']);
        $phone     = trim($_POST['phone']);
        $email     = trim($_POST['email'] ?? '');
        $idNumber  = trim($_POST['id_number'] ?? '');
        $moveIn    = $_POST['move_in_date'] ?? date('Y-m-d');
        // Verify unit is vacant and belongs to landlord
        $u = $db->prepare("SELECT u.id FROM units u JOIN buildings b ON u.building_id=b.id WHERE u.id=? AND b.landlord_id=? AND u.status='vacant'");
        $u->execute([$unitId, $lid]);
        if (!$u->fetch()) doRedirect('tenants.php', 'error', 'Unit not available.');
        $db->prepare("INSERT INTO tenants (unit_id,landlord_id,name,phone,email,id_number,move_in_date) VALUES (?,?,?,?,?,?,?)")
           ->execute([$unitId, $lid, $name, $phone, $email, $idNumber, $moveIn]);
        $db->prepare("UPDATE units SET status='occupied' WHERE id=?")->execute([$unitId]);
        // Create pending payment for current month
        $tenantId = $db->lastInsertId();
        $unitInfo = $db->prepare("SELECT rent_amount FROM units WHERE id=?");
        $unitInfo->execute([$unitId]);
        $rentAmt = $unitInfo->fetchColumn();
        $db->prepare("INSERT INTO payments (tenant_id,unit_id,landlord_id,amount,month,status) VALUES (?,?,?,?,?,?)")
           ->execute([$tenantId, $unitId, $lid, $rentAmt, getCurrentMonth(), 'pending']);
        doRedirect('tenants.php', 'success', "Tenant \"$name\" added successfully.");

    case 'edit_tenant':
        $id      = (int)$_POST['id'];
        $name    = trim($_POST['name']);
        $phone   = trim($_POST['phone']);
        $email   = trim($_POST['email'] ?? '');
        $idno    = trim($_POST['id_number'] ?? '');
        $db->prepare("UPDATE tenants SET name=?,phone=?,email=?,id_number=? WHERE id=? AND landlord_id=?")
           ->execute([$name, $phone, $email, $idno, $id, $lid]);
        doRedirect('tenants.php', 'success', 'Tenant updated.');

    case 'remove_tenant':
        $id = (int)$_POST['id'];
        $t = $db->prepare("SELECT unit_id FROM tenants WHERE id=? AND landlord_id=?");
        $t->execute([$id, $lid]);
        $tenant = $t->fetch();
        if (!$tenant) doRedirect('tenants.php', 'error', 'Tenant not found.');
        $db->prepare("UPDATE tenants SET active=0 WHERE id=?")->execute([$id]);
        $db->prepare("UPDATE units SET status='vacant' WHERE id=?")->execute([$tenant['unit_id']]);
        doRedirect('tenants.php', 'success', 'Tenant removed. Unit is now vacant.');

    // ── PAYMENTS ───────────────────────────────────────────────
    case 'mark_paid':
        $tenantId = (int)$_POST['tenant_id'];
        $month    = $_POST['month'];
        $amount   = (float)$_POST['amount'];
        // Verify tenant belongs to landlord
        $t = $db->prepare("SELECT id, unit_id FROM tenants WHERE id=? AND landlord_id=?");
        $t->execute([$tenantId, $lid]);
        $tenant = $t->fetch();
        if (!$tenant) doRedirect($redirect, 'error', 'Unauthorized.');
        // Upsert payment
        $existing = $db->prepare("SELECT id FROM payments WHERE tenant_id=? AND month=?");
        $existing->execute([$tenantId, $month]);
        if ($existing->fetch()) {
            $db->prepare("UPDATE payments SET status='paid', paid_date=CURRENT_DATE, amount=? WHERE tenant_id=? AND month=?")
               ->execute([$amount, $tenantId, $month]);
        } else {
            $db->prepare("INSERT INTO payments (tenant_id,unit_id,landlord_id,amount,month,status,paid_date) VALUES (?,?,?,?,?,'paid',CURRENT_DATE)")
               ->execute([$tenantId, $tenant['unit_id'], $lid, $amount, $month]);
        }
        doRedirect($redirect, 'success', 'Payment marked as paid.');

    case 'mark_unpaid':
        $paymentId = (int)$_POST['payment_id'];
        $db->prepare("UPDATE payments SET status='pending', paid_date=NULL WHERE id=? AND landlord_id=?")
           ->execute([$paymentId, $lid]);
        doRedirect($redirect, 'success', 'Payment marked as pending.');

    // ── PENALTIES ─────────────────────────────────────────────
    case 'add_penalty':
        $tenantId = (int)$_POST['tenant_id'];
        $amount   = (float)$_POST['amount'];
        $reason   = trim($_POST['reason']);
        $t = $db->prepare("SELECT id FROM tenants WHERE id=? AND landlord_id=?");
        $t->execute([$tenantId, $lid]);
        if (!$t->fetch()) doRedirect($redirect, 'error', 'Unauthorized.');
        $db->prepare("INSERT INTO penalties (tenant_id,landlord_id,amount,reason) VALUES (?,?,?,?)")
           ->execute([$tenantId, $lid, $amount, $reason]);
        doRedirect($redirect, 'success', 'Penalty applied.');

    case 'resolve_penalty':
        $id = (int)$_POST['id'];
        $db->prepare("UPDATE penalties SET status='paid' WHERE id=? AND landlord_id=?")->execute([$id, $lid]);
        doRedirect($redirect, 'success', 'Penalty marked as resolved.');

    case 'delete_penalty':
        $id = (int)$_POST['id'];
        $db->prepare("DELETE FROM penalties WHERE id=? AND landlord_id=?")->execute([$id, $lid]);
        doRedirect($redirect, 'success', 'Penalty removed.');

    // ── SMS ────────────────────────────────────────────────────
    case 'send_sms':
        $tenantId = (int)$_POST['tenant_id'];
        $message  = trim($_POST['message']);
        $t = $db->prepare("SELECT phone, name FROM tenants WHERE id=? AND landlord_id=?");
        $t->execute([$tenantId, $lid]);
        $tenant = $t->fetch();
        if (!$tenant) doRedirect($redirect, 'error', 'Tenant not found.');
        $result = sendTextSMS($tenant['phone'], $message, $tenantId);
        if ($result['success'])
            doRedirect($redirect, 'success', 'SMS sent to ' . $tenant['name']);
        else
            doRedirect($redirect, 'error', 'SMS failed. Check your TextSMS API key in includes/auth.php');

    case 'send_bulk_sms':
        $month   = $_POST['month'] ?? getCurrentMonth();
        $type    = $_POST['type'] ?? 'unpaid'; // 'all' or 'unpaid'
        $message = trim($_POST['message']);
        if ($type === 'unpaid') {
            $stmt = $db->prepare("
                SELECT t.id, t.name, t.phone FROM tenants t
                LEFT JOIN payments p ON p.tenant_id=t.id AND p.month=?
                WHERE t.landlord_id=? AND t.active=1 AND (p.status IS NULL OR p.status != 'paid')
            ");
            $stmt->execute([$month, $lid]);
        } else {
            $stmt = $db->prepare("SELECT id, name, phone FROM tenants WHERE landlord_id=? AND active=1");
            $stmt->execute([$lid]);
        }
        $tenants = $stmt->fetchAll();
        $sent = 0;
        foreach ($tenants as $t) {
            $msg = str_replace(['{name}','{month}'], [$t['name'], date('F Y', strtotime($month.'-01'))], $message);
            sendTextSMS($t['phone'], $msg, $t['id']);
            $sent++;
        }
        doRedirect($redirect, 'success', "SMS sent to $sent tenant(s).");

    // ── ACCOUNT ────────────────────────────────────────────────
    case 'update_account':
        $name  = trim($_POST['name']);
        $phone = trim($_POST['phone']);
        $db->prepare("UPDATE landlords SET name=?, phone=? WHERE id=?")->execute([$name, $phone, $lid]);
        if (!empty($_POST['new_password'])) {
            if (strlen($_POST['new_password']) < 6)
                doRedirect('settings.php', 'error', 'Password must be at least 6 characters.');
            $db->prepare("UPDATE landlords SET password=? WHERE id=?")
               ->execute([password_hash($_POST['new_password'], PASSWORD_DEFAULT), $lid]);
        }
        $_SESSION['landlord_name'] = $name;
        doRedirect('settings.php', 'success', 'Account updated.');

    case 'logout':
        session_destroy();
        header('Location: index.php');
        exit;

    default:
        doRedirect($redirect, 'error', 'Unknown action.');
}
