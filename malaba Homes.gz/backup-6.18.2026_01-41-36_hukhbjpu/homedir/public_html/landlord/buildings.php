<?php
require_once 'includes/auth.php';
requireLogin();

$db = getDB();
$lid = $_SESSION['landlord_id'];

$buildings = $db->prepare("
    SELECT b.*, 
           COUNT(DISTINCT u.id) as total_units,
           COUNT(DISTINCT CASE WHEN u.status='occupied' THEN u.id END) as occupied_units,
           COALESCE(SUM(CASE WHEN u.status='occupied' THEN u.rent_amount ELSE 0 END),0) as monthly_income
    FROM buildings b
    LEFT JOIN units u ON u.building_id=b.id
    WHERE b.landlord_id=?
    GROUP BY b.id
    ORDER BY b.created_at DESC
");
$buildings->execute([$lid]);
$allBuildings = $buildings->fetchAll();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>Buildings – MalabaHomes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>

<main class="main-content">
  <div class="page-header">
    <div>
      <h1 class="page-title">Buildings</h1>
      <p class="page-sub"><?= count($allBuildings) ?> properties managed</p>
    </div>
    <button class="btn-primary" onclick="openModal('addBuildingModal')">+ Add Building</button>
  </div>

  <?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg']) ?></div>
  <?php endif; ?>

  <div class="building-grid">
    <?php foreach ($allBuildings as $b): ?>
    <div class="building-card" onclick="location='units.php?building=<?= $b['id'] ?>'">
      <div class="building-type-badge <?= $b['type'] ?>"><?= $b['type']==='storey'?'🏢 Storey':'🏠 Non-Storey' ?></div>
      <h3 class="building-name"><?= htmlspecialchars($b['name']) ?></h3>
      <p class="building-address">📍 <?= htmlspecialchars($b['address'] ?: 'No address') ?></p>
      <?php if ($b['type']==='storey'): ?>
        <p class="building-floors">🏗 <?= $b['floors'] ?> Floor<?= $b['floors']>1?'s':'' ?></p>
      <?php endif; ?>
      <div class="building-stats">
        <div class="bstat">
          <span class="bstat-val"><?= $b['occupied_units'] ?>/<?= $b['total_units'] ?></span>
          <span class="bstat-lbl">Occupied</span>
        </div>
        <div class="bstat">
          <span class="bstat-val"><?= formatMoney($b['monthly_income']) ?></span>
          <span class="bstat-lbl">Monthly Rent</span>
        </div>
      </div>
      <div class="building-actions" onclick="event.stopPropagation()">
        <a href="units.php?building=<?= $b['id'] ?>" class="btn-sm">Manage Units →</a>
        <button class="btn-sm btn-outline" onclick="editBuilding(<?= $b['id'] ?>, '<?= addslashes($b['name']) ?>', '<?= $b['type'] ?>', '<?= addslashes($b['address']) ?>', <?= $b['floors'] ?>)">Edit</button>
        <form method="POST" action="api.php" style="display:inline" onsubmit="return confirm('Delete this building and all its units?')">
          <input type="hidden" name="action" value="delete_building">
          <input type="hidden" name="id" value="<?= $b['id'] ?>">
          <button type="submit" class="btn-sm btn-danger">Delete</button>
        </form>
      </div>
    </div>
    <?php endforeach; ?>

    <?php if (empty($allBuildings)): ?>
    <div class="empty-full">
      <div class="empty-icon">🏗</div>
      <h3>No buildings yet</h3>
      <p>Add your first property to get started</p>
      <button class="btn-primary" onclick="openModal('addBuildingModal')">+ Add Building</button>
    </div>
    <?php endif; ?>
  </div>
</main>

<!-- ADD BUILDING MODAL -->
<div id="addBuildingModal" class="modal-overlay" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3>Add New Building</h3>
      <button onclick="closeModal('addBuildingModal')" class="modal-close">✕</button>
    </div>
    <form method="POST" action="api.php">
      <input type="hidden" name="action" value="add_building">
      <div class="field">
        <label>Building Name *</label>
        <input type="text" name="name" placeholder="e.g. Block A, Sunrise Apartments" required>
      </div>
      <div class="field">
        <label>Building Type *</label>
        <div class="type-selector">
          <label class="type-option">
            <input type="radio" name="type" value="storey" required onchange="toggleFloors(true)">
            <span>🏢 Storey Building</span>
          </label>
          <label class="type-option">
            <input type="radio" name="type" value="non_storey" onchange="toggleFloors(false)">
            <span>🏠 Non-Storey</span>
          </label>
        </div>
      </div>
      <div class="field" id="floorsField" style="display:none">
        <label>Number of Floors</label>
        <input type="number" name="floors" placeholder="e.g. 3" min="1" max="50">
      </div>
      <div class="field">
        <label>Address / Location</label>
        <input type="text" name="address" placeholder="e.g. Malaba Town, Near Market">
      </div>
      <button type="submit" class="btn-primary full">Add Building</button>
    </form>
  </div>
</div>

<!-- EDIT BUILDING MODAL -->
<div id="editBuildingModal" class="modal-overlay" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3>Edit Building</h3>
      <button onclick="closeModal('editBuildingModal')" class="modal-close">✕</button>
    </div>
    <form method="POST" action="api.php">
      <input type="hidden" name="action" value="edit_building">
      <input type="hidden" name="id" id="editBuildingId">
      <div class="field">
        <label>Building Name *</label>
        <input type="text" name="name" id="editBuildingName" required>
      </div>
      <div class="field" id="editFloorsField">
        <label>Number of Floors</label>
        <input type="number" name="floors" id="editBuildingFloors" min="1" max="50">
      </div>
      <div class="field">
        <label>Address / Location</label>
        <input type="text" name="address" id="editBuildingAddress">
      </div>
      <button type="submit" class="btn-primary full">Save Changes</button>
    </form>
  </div>
</div>

<?php include 'includes/bottom-nav.php'; ?>
<script>
function openModal(id) { document.getElementById(id).style.display='flex'; }
function closeModal(id) { document.getElementById(id).style.display='none'; }
function toggleFloors(show) { document.getElementById('floorsField').style.display = show?'block':'none'; }
function editBuilding(id, name, type, address, floors) {
  document.getElementById('editBuildingId').value = id;
  document.getElementById('editBuildingName').value = name;
  document.getElementById('editBuildingAddress').value = address;
  document.getElementById('editBuildingFloors').value = floors;
  document.getElementById('editFloorsField').style.display = type==='storey'?'block':'none';
  openModal('editBuildingModal');
}
document.querySelectorAll('.modal-overlay').forEach(m => m.addEventListener('click', function(e){ if(e.target===this) this.style.display='none'; }));
</script>
</body>
</html>
