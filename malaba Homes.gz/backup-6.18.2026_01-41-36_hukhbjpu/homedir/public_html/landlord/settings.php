<?php
require_once 'includes/auth.php';
requireLogin();
$landlord = getLandlord();
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>Settings – MalabaHomes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>

<main class="main-content">
  <div class="page-header">
    <div>
      <h1 class="page-title">Settings</h1>
      <p class="page-sub">Manage your account & SMS integration</p>
    </div>
  </div>

  <?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg']) ?></div>
  <?php endif; ?>

  <!-- PROFILE -->
  <div class="card settings-card">
    <div class="settings-section-title">👤 Account Details</div>
    <form method="POST" action="api.php">
      <input type="hidden" name="action" value="update_account">
      <div class="field">
        <label>Full Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($landlord['name']) ?>" required>
      </div>
      <div class="field">
        <label>Email Address</label>
        <input type="email" value="<?= htmlspecialchars($landlord['email']) ?>" readonly class="input-readonly">
        <span class="field-hint">Email cannot be changed.</span>
      </div>
      <div class="field">
        <label>Phone Number</label>
        <input type="tel" name="phone" value="<?= htmlspecialchars($landlord['phone']) ?>">
      </div>
      <div class="settings-divider">Change Password (leave blank to keep current)</div>
      <div class="field">
        <label>New Password</label>
        <input type="password" name="new_password" placeholder="Min 6 characters">
      </div>
      <button type="submit" class="btn-primary">Save Changes</button>
    </form>
  </div>

  <!-- SMS SETUP -->
  <div class="card settings-card">
    <div class="settings-section-title">📲 TextSMS Integration</div>
    <div class="sms-setup-box">
      <p>To enable SMS reminders via <strong>TextSMS Kenya</strong>, update your API credentials in <code>includes/auth.php</code>:</p>
      <div class="code-block">
        <code>$apiKey    = 'YOUR_TEXTSMS_API_KEY';<br>
$partnerID = 'YOUR_PARTNER_ID';<br>
$shortcode = 'MalabaHomes'; // or your sender ID</code>
      </div>
      <ol class="setup-steps">
        <li>Register at <a href="https://sms.textsms.co.ke" target="_blank">sms.textsms.co.ke</a></li>
        <li>Go to <strong>Account → API Access</strong></li>
        <li>Copy your <strong>API Key</strong> and <strong>Partner ID</strong></li>
        <li>Paste them into <code>includes/auth.php</code></li>
      </ol>
    </div>
  </div>

  <!-- WHATSAPP INFO -->
  <div class="card settings-card">
    <div class="settings-section-title">💬 WhatsApp Reminders</div>
    <div class="sms-setup-box">
      <p>WhatsApp reminders work instantly — no setup needed. Clicking the WhatsApp button on any tenant opens a pre-filled message in WhatsApp Web or the app.</p>
      <p style="margin-top:8px;color:var(--text-muted)">Ensure tenants' phone numbers are saved in international format (07XX → +254 7XX).</p>
    </div>
  </div>

  <!-- DANGER ZONE -->
  <div class="card settings-card danger-zone">
    <div class="settings-section-title">⚠️ Session</div>
    <form method="POST" action="api.php" onsubmit="return confirm('Sign out?')">
      <input type="hidden" name="action" value="logout">
      <button type="submit" class="btn-danger full">Sign Out</button>
    </form>
  </div>
</main>

<?php include 'includes/bottom-nav.php'; ?>
</body>
</html>
