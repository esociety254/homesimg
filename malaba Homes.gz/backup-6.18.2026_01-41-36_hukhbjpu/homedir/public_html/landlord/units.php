<?php
require_once 'includes/auth.php';
requireLogin();

$db = getDB();
$lid = $_SESSION['landlord_id'];
$buildingId = $_GET['building'] ?? null;

if ($buildingId) {
    $bStmt = $db->prepare("SELECT * FROM buildings WHERE id=? AND landlord_id=?");
    $bStmt->execute([$buildingId, $lid]);
    $building = $bStmt->fetch();
    if (!$building) { header('Location: buildings.php'); exit; }
    
    $units = $db->prepare("
        SELECT u.*, t.name as tenant_name, t.id as tenant_id, t.phone as tenant_phone
        FROM units u
        LEFT JOIN tenants t ON t.unit_id=u.id AND t.active=1
        WHERE u.building_id=?
        ORDER BY u.floor ASC, u.unit_number ASC
    ");
    $units->execute([$buildingId]);
    $allUnits = $units->fetchAll();
} else {
    header('Location: buildings.php');
    exit;
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title><?= htmlspecialchars($building['name']) ?> Units – MalabaHomes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>

<main class="main-content">
  <div class="page-header">
    <div>
      <a href="buildings.php" class="back-link">← Buildings</a>
      <h1 class="page-title"><?= htmlspecialchars($building['name']) ?></h1>
      <p class="page-sub"><?= $building['type']==='storey'?'🏢 Storey · '.$building['floors'].' floors':'🏠 Non-Storey' ?> · <?= count($allUnits) ?> units</p>
    </div>
    <button class="btn-primary" onclick="openModal('addUnitModal')">+ Add Unit</button>
  </div>

  <?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg']) ?></div>
  <?php endif; ?>

  <!-- Bulk add shortcut -->
  <div class="card bulk-hint">
    <span>💡 Add multiple units at once:</span>
    <button class="btn-sm" onclick="openModal('bulkAddModal')">Bulk Add Units</button>
  </div>

  <?php
  $byFloor = [];
  foreach ($allUnits as $u) {
    $floor = $building['type']==='storey' ? ($u['floor'] ?: 1) : 0;
    $byFloor[$floor][] = $u;
  }
  ksort($byFloor);
  ?>

  <?php foreach ($byFloor as $floor => $units): ?>
    <?php if ($building['type']==='storey'): ?>
      <div class="floor-label">Floor <?= $floor ?></div>
    <?php endif; ?>
    <div class="units-grid">
      <?php foreach ($units as $u): ?>
      <div class="unit-card <?= $u['status'] ?>">
        <div class="unit-number">Unit <?= htmlspecialchars($u['unit_number']) ?></div>
        <div class="unit-rent"><?= formatMoney($u['rent_amount']) ?>/mo</div>
        <?php if ($u['tenant_name']): ?>
          <div class="unit-tenant">👤 <?= htmlspecialchars($u['tenant_name']) ?></div>
          <div class="unit-phone">📞 <?= htmlspecialchars($u['tenant_phone']) ?></div>
        <?php else: ?>
          <div class="unit-vacant">Vacant</div>
        <?php endif; ?>
        <div class="unit-actions">
          <button class="btn-icon" onclick="editUnit(<?= $u['id'] ?>, '<?= addslashes($u['unit_number']) ?>', <?= $u['rent_amount'] ?>, <?= $u['floor'] ?>)" title="Edit">✏️</button>
          <?php if (!$u['tenant_id']): ?>
          <form method="POST" action="api.php" style="display:inline" onsubmit="return confirm('Delete unit?')">
            <input type="hidden" name="action" value="delete_unit">
            <input type="hidden" name="id" value="<?= $u['id'] ?>">
            <button type="submit" class="btn-icon btn-danger" title="Delete">🗑</button>
          </form>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>

  <?php if (empty($allUnits)): ?>
    <div class="empty-full">
      <div class="empty-icon">🚪</div>
      <h3>No units yet</h3>
      <p>Add units to this building</p>
      <button class="btn-primary" onclick="openModal('addUnitModal')">+ Add Unit</button>
    </div>
  <?php endif; ?>
</main>

<!-- ADD UNIT MODAL -->
<div id="addUnitModal" class="modal-overlay" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3>Add Unit</h3>
      <button onclick="closeModal('addUnitModal')" class="modal-close">✕</button>
    </div>
    <form method="POST" action="api.php">
      <input type="hidden" name="action" value="add_unit">
      <input type="hidden" name="building_id" value="<?= $buildingId ?>">
      <div class="field">
        <label>Unit Number / Name *</label>
        <input type="text" name="unit_number" placeholder="e.g. A1, 101, Ground Floor Left" required>
      </div>
      <?php if ($building['type']==='storey'): ?>
      <div class="field">
        <label>Floor *</label>
        <input type="number" name="floor" placeholder="e.g. 1" min="1" max="<?= $building['floors'] ?>" required>
      </div>
      <?php else: ?>
      <input type="hidden" name="floor" value="1">
      <?php endif; ?>
      <div class="field">
        <label>Monthly Rent (KSh) *</label>
        <input type="number" name="rent_amount" placeholder="e.g. 5000" min="1" required>
      </div>
      <div class="field">
        <label>Bedrooms</label>
        <select name="bedrooms">
          <option value="1">1 Bedroom (Bedsitter)</option>
          <option value="2">2 Bedrooms</option>
          <option value="3">3 Bedrooms</option>
          <option value="4">4+ Bedrooms</option>
        </select>
      </div>
      <button type="submit" class="btn-primary full">Add Unit</button>
    </form>
  </div>
</div>

<!-- BULK ADD MODAL -->
<div id="bulkAddModal" class="modal-overlay" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3>Bulk Add Units</h3>
      <button onclick="closeModal('bulkAddModal')" class="modal-close">✕</button>
    </div>
    <form method="POST" action="api.php">
      <input type="hidden" name="action" value="bulk_add_units">
      <input type="hidden" name="building_id" value="<?= $buildingId ?>">
      <div class="field">
        <label>Number of Units to Add</label>
        <input type="number" name="count" placeholder="e.g. 10" min="1" max="100" required>
      </div>
      <div class="field">
        <label>Unit Name Prefix</label>
        <input type="text" name="prefix" placeholder="e.g. A (creates A1, A2...)" value="Unit">
      </div>
      <?php if ($building['type']==='storey'): ?>
      <div class="field">
        <label>Floor</label>
        <input type="number" name="floor" placeholder="1" min="1" max="<?= $building['floors'] ?>" required>
      </div>
      <?php else: ?>
      <input type="hidden" name="floor" value="1">
      <?php endif; ?>
      <div class="field">
        <label>Monthly Rent (KSh) for all units</label>
        <input type="number" name="rent_amount" placeholder="e.g. 5000" min="1" required>
      </div>
      <button type="submit" class="btn-primary full">Add Units</button>
    </form>
  </div>
</div>

<!-- EDIT UNIT MODAL -->
<div id="editUnitModal" class="modal-overlay" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3>Edit Unit</h3>
      <button onclick="closeModal('editUnitModal')" class="modal-close">✕</button>
    </div>
    <form method="POST" action="api.php">
      <input type="hidden" name="action" value="edit_unit">
      <input type="hidden" name="id" id="editUnitId">
      <div class="field">
        <label>Unit Number</label>
        <input type="text" name="unit_number" id="editUnitNumber" required>
      </div>
      <div class="field">
        <label>Monthly Rent (KSh) *</label>
        <input type="number" name="rent_amount" id="editUnitRent" required>
      </div>
      <p class="field-hint">⚠️ Updating rent will apply from next month for existing tenants.</p>
      <button type="submit" class="btn-primary full">Save Changes</button>
    </form>
  </div>
</div>

<?php include 'includes/bottom-nav.php'; ?>
<script>
function openModal(id) { document.getElementById(id).style.display='flex'; }
function closeModal(id) { document.getElementById(id).style.display='none'; }
function editUnit(id, number, rent, floor) {
  document.getElementById('editUnitId').value = id;
  document.getElementById('editUnitNumber').value = number;
  document.getElementById('editUnitRent').value = rent;
  openModal('editUnitModal');
}
document.querySelectorAll('.modal-overlay').forEach(m => m.addEventListener('click', function(e){ if(e.target===this) this.style.display='none'; }));
</script>
</body>
</html>
