<?php
require_once __DIR__ . '/db.php';

session_start();

function isLoggedIn() {
    return isset($_SESSION['landlord_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}

function getLandlord() {
    if (!isLoggedIn()) return null;
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM landlords WHERE id = ?");
    $stmt->execute([$_SESSION['landlord_id']]);
    return $stmt->fetch();
}

function sendTextSMS($phone, $message, $tenantId = null) {
    // TextSMS Kenya API
    $apiKey = 'YOUR_TEXTSMS_API_KEY'; // Replace with actual key
    $partnerID = 'YOUR_PARTNER_ID';
    $shortcode = 'MalabaHomes';

    $phone = preg_replace('/^0/', '+254', $phone);
    $phone = preg_replace('/^\+?254/', '254', $phone);
    $phone = ltrim($phone, '+');

    $payload = json_encode([
        'apikey'    => $apiKey,
        'partnerID' => $partnerID,
        'message'   => $message,
        'shortcode' => $shortcode,
        'mobile'    => $phone
    ]);

    $ch = curl_init('https://sms.textsms.co.ke/api/services/sendsms/');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    // Log SMS
    $db = getDB();
    $status = $err ? 'failed' : 'sent';
    $db->prepare("INSERT INTO sms_logs (tenant_id, phone, message, status) VALUES (?,?,?,?)")
       ->execute([$tenantId, $phone, $message, $status]);

    return ['success' => !$err, 'response' => $response, 'error' => $err];
}

function getWhatsAppLink($phone, $message) {
    $phone = preg_replace('/^0/', '254', $phone);
    $phone = preg_replace('/[^0-9]/', '', $phone);
    return 'https://wa.me/' . $phone . '?text=' . urlencode($message);
}

function getCurrentMonth() {
    return date('Y-m');
}

function formatMoney($amount) {
    return 'KSh ' . number_format($amount, 2);
}

function jsonResponse($data) {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function flash($type, $msg) {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}
