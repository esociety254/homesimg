<?php
$currentPage  = basename($_SERVER['PHP_SELF'], '.php');
$landlordName = $_SESSION['landlord_name'] ?? 'Landlord';
$firstName    = explode(' ', $landlordName)[0];
?>
<header class="top-nav">
  <div class="nav-logo-wrap">
    <img src="assets/logo.png" alt="MalabaHomes" class="nav-logo"
         onerror="this.style.display='none';document.getElementById('navFallback').style.display='block'">
    <span id="navFallback" class="nav-brand-text" style="display:none">
      MALABA<span>HOMES</span>
    </span>
  </div>
  <div class="nav-right">
    <span class="nav-user">👤 <?= htmlspecialchars($firstName) ?></span>
    <a href="settings.php" class="nav-settings-btn" title="Settings">⚙️</a>
  </div>
</header>
