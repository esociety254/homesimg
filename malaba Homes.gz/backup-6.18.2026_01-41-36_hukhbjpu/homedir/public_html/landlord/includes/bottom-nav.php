<?php
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$nav = [
  ['dashboard', '🏠', 'Home'],
  ['buildings',  '🏢', 'Buildings'],
  ['tenants',    '👥', 'Tenants'],
  ['payments',   '💰', 'Payments'],
  ['settings',   '⚙️',  'Settings'],
];
?>
<nav class="bottom-nav">
  <?php foreach ($nav as [$page, $icon, $label]): ?>
  <a href="<?= $page ?>.php"
     class="bottom-nav-item <?= $currentPage === $page ? 'active' : '' ?>">
    <span class="bnav-icon"><?= $icon ?></span>
    <span class="bnav-label"><?= $label ?></span>
  </a>
  <?php endforeach; ?>
</nav>
