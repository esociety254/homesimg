<?php
$apiBase = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/api';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1">
<meta name="theme-color" content="#080400">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>Find a Home — Malaba Homes</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<?php include 'pwa_head.php'; ?>

  <script src="/firebase-config.js"></script>
  <script src="/push_register.js"></script>
<style>
/* ── TOKENS ── */
:root{
  --ink:#080400;--ink2:#0f0900;--surface:#151008;--card:#1c1610;
  --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);
  --text:#F5F0EB;--muted:#8a8070;--dim:#5a5040;
  --green:#2D6A4F;--green2:#52B788;--green3:#86efac;
  --amber:#E8521A;--amber2:#FF7043;--gold:#F5A623;
  --blue:#4895EF;--purple:#7c3aed;
  --sb:env(safe-area-inset-bottom,0px);
  --st:env(safe-area-inset-top,0px);
  --r:12px;--rl:20px;--nav:56px;--bnav:62px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
html{overflow-x:hidden;scroll-behavior:smooth;}
body{font-family:'Outfit',sans-serif;background:var(--ink);color:var(--text);min-height:100dvh;overflow-x:hidden;-webkit-font-smoothing:antialiased;padding-bottom:calc(var(--bnav) + var(--sb) + 8px);}
a{color:inherit;text-decoration:none;}button{cursor:pointer;font-family:inherit;border:none;background:none;}img{display:block;max-width:100%;}
::-webkit-scrollbar{width:3px;height:3px;}::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px;}

/* ── HEADER ── */
.hdr{position:sticky;top:0;z-index:200;background:rgba(8,4,0,.96);backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);border-bottom:1px solid var(--border);padding-top:var(--st);}
.hdr-row{height:var(--nav);display:flex;align-items:center;gap:10px;padding:0 14px;}
.back-btn{width:36px;height:36px;border-radius:50%;background:var(--surface);border:1px solid var(--border2);display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:transform .15s;}
.back-btn:active{transform:scale(.9);}
.back-btn svg{width:17px;height:17px;color:var(--text);}
.hdr-brand{flex:1;font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:2px;}
.hdr-brand span{color:var(--green2);}
.hdr-acts{display:flex;gap:7px;}
.ico-btn{width:36px;height:36px;border-radius:50%;background:var(--surface);border:1px solid var(--border2);display:flex;align-items:center;justify-content:center;font-size:15px;transition:transform .15s;}
.ico-btn:active{transform:scale(.9);}

/* Search */
.srch-row{padding:9px 14px;}
.srch-box{display:flex;align-items:center;gap:9px;background:var(--surface);border:1.5px solid var(--border2);border-radius:30px;padding:0 15px;transition:border-color .2s;}
.srch-box:focus-within{border-color:var(--green2);}
.srch-box svg{color:var(--muted);flex-shrink:0;width:14px;height:14px;}
.srch-box input{flex:1;padding:11px 0;background:transparent;border:none;outline:none;font-family:inherit;font-size:14px;color:var(--text);}
.srch-box input::placeholder{color:var(--muted);}

/* Chips */
.chips-row{display:flex;gap:7px;padding:0 14px 10px;overflow-x:auto;scrollbar-width:none;}
.chips-row::-webkit-scrollbar{display:none;}
.chip{display:inline-flex;align-items:center;gap:5px;padding:6px 13px;border-radius:30px;border:1px solid var(--border2);background:var(--surface);font-size:12px;font-weight:500;color:var(--muted);white-space:nowrap;flex-shrink:0;transition:all .2s;}
.chip.on{background:var(--green);border-color:var(--green);color:#fff;font-weight:700;}
.chip:active{transform:scale(.95);}

/* Section head */
.sec-head{display:flex;align-items:center;justify-content:space-between;padding:8px 14px;}
.sec-head h2{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.5px;}
.sec-head h2 span{color:var(--green2);}
.res-count{font-size:11px;color:var(--dim);padding:0 14px 8px;}

/* ── HOME CARDS ── */
.homes-list{padding:0 14px;display:flex;flex-direction:column;gap:14px;}

.hcard{background:var(--card);border-radius:var(--rl);border:1px solid var(--border);overflow:hidden;cursor:pointer;animation:fadeUp .38s ease both;transition:transform .2s,box-shadow .2s,border-color .2s;position:relative;}
@keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
.hcard:active{transform:scale(.985);}
@media(hover:hover){.hcard:hover{transform:translateY(-4px);box-shadow:0 14px 36px rgba(0,0,0,.5);border-color:var(--border2);}}

/* ── CAROUSEL ── */
.hcard-carousel{position:relative;height:210px;overflow:hidden;border-radius:var(--rl) var(--rl) 0 0;}
@media(min-width:480px){.hcard-carousel{height:250px;}}

/* Carousel track: only 1 active slide now (light mode) */
.carousel-track{
  display:block;height:100%;
  transition:none;
  will-change:auto;
}
.carousel-slide{min-width:100%;height:100%;position:relative;}
.carousel-slide img{width:100%;height:100%;object-fit:cover;user-select:none;pointer-events:none;}
.car-main-img{opacity:1;transition:opacity .18s ease;}
.carousel-grad{position:absolute;inset:0;background:linear-gradient(to top,rgba(8,4,0,.9) 0%,rgba(8,4,0,.1) 45%,transparent 100%);}


/* Carousel controls */
.car-btn{
  position:absolute;top:50%;transform:translateY(-50%);z-index:4;
  width:34px;height:34px;border-radius:50%;
  background:rgba(8,4,0,.65);backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.15);
  display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:16px;transition:all .18s;
  opacity:0;pointer-events:none;
}
.hcard-carousel:hover .car-btn{opacity:1;pointer-events:all;}
.car-btn:active{transform:translateY(-50%) scale(.9);}
.car-prev{left:10px;}
.car-next{right:10px;}

/* Dot indicators */
.car-dots{position:absolute;bottom:10px;left:0;right:0;display:flex;justify-content:center;gap:5px;z-index:4;pointer-events:none;}
.car-dot{width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,.4);transition:all .25s;}
.car-dot.on{background:#fff;width:16px;border-radius:3px;}

/* Thumb strip */
.car-thumbs{display:flex;gap:6px;padding:8px 10px 4px;overflow-x:auto;scrollbar-width:none;background:rgba(255,255,255,.02);border-bottom:1px solid var(--border);}
.car-thumbs::-webkit-scrollbar{display:none;}
.car-thumb{width:52px;height:42px;border-radius:7px;object-fit:cover;flex-shrink:0;cursor:pointer;border:2px solid transparent;opacity:.6;transition:all .2s;}
.car-thumb.on{border-color:var(--green2);opacity:1;}

/* Overlay badges */
.card-badges{position:absolute;top:10px;left:10px;right:10px;display:flex;justify-content:space-between;align-items:flex-start;z-index:3;}
.hbadge{font-size:10px;font-weight:700;padding:4px 10px;border-radius:20px;backdrop-filter:blur(8px);}
.hb-new    {background:rgba(82,183,136,.85);color:#fff;}
.hb-hot    {background:rgba(245,158,11,.85);color:#000;}
.hb-budget {background:rgba(45,106,79,.85); color:#fff;}
.hb-family {background:rgba(72,149,239,.85); color:#fff;}
.hb-default{background:rgba(255,255,255,.15);color:#fff;}
.wish-btn{width:32px;height:32px;border-radius:50%;background:rgba(8,4,0,.7);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;font-size:15px;transition:all .2s;border:1px solid rgba(255,255,255,.12);}
.wish-btn:active{transform:scale(.85);}
.wish-btn.liked{background:rgba(255,60,60,.2);color:#ff6b6b;}
.price-tag{position:absolute;bottom:12px;left:14px;z-index:3;font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:.5px;color:#fff;text-shadow:0 2px 8px rgba(0,0,0,.6);}

/* Card body */
.hcard-body{padding:13px 14px 4px;}
.hcard-title{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.3px;color:var(--text);margin-bottom:3px;}
.hcard-meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px;}
.hloc{font-size:12px;color:var(--muted);display:flex;align-items:center;gap:3px;}
.hcard-desc{font-size:12px;color:var(--muted);line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-bottom:9px;}
.feat-row{display:flex;gap:5px;flex-wrap:wrap;}
.fp{font-size:10px;background:rgba(82,183,136,.1);color:var(--green2);border-radius:7px;padding:3px 8px;white-space:nowrap;}

/* Card footer */
.hcard-foot{display:flex;gap:7px;padding:10px 14px 13px;}
.btn-book{flex:1;padding:10px 12px;background:linear-gradient(135deg,var(--green),#1b5e3a);color:#fff;border-radius:var(--r);font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:.3px;transition:all .18s;display:flex;align-items:center;justify-content:center;gap:5px;box-shadow:0 3px 12px rgba(45,106,79,.35);}
.btn-book:active{transform:scale(.96);}
.btn-wa{width:42px;border-radius:var(--r);background:#25D366;color:#fff;font-size:18px;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .18s;box-shadow:0 3px 12px rgba(37,211,102,.3);}
.btn-wa:active{transform:scale(.94);}

/* ── SKELETON ── */
.skel{background:linear-gradient(90deg,var(--surface) 25%,rgba(255,255,255,.04) 50%,var(--surface) 75%);background-size:200% 100%;animation:shim 1.4s infinite;}
@keyframes shim{0%{background-position:200% 0}100%{background-position:-200% 0}}
.skel-card{background:var(--card);border-radius:var(--rl);overflow:hidden;border:1px solid var(--border);margin-bottom:14px;}
.skel-img{height:210px;}
.skel-body{padding:14px;display:flex;flex-direction:column;gap:9px;}
.skel-ln{height:12px;border-radius:4px;}

/* ── EMPTY STATE ── */
.empty-state{padding:20px 14px;}

/* Conversion card */
.conv-card{background:var(--card);border-radius:var(--rl);border:1px solid var(--border);overflow:hidden;margin-bottom:14px;cursor:pointer;transition:all .2s;}
.conv-card:active{transform:scale(.99);}
.conv-card:hover{border-color:var(--border2);}
.conv-img{height:140px;width:100%;object-fit:cover;filter:brightness(.55);}
.conv-body{padding:13px 14px 14px;}
.conv-cat{font-size:9px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:4px;}
.conv-title{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:.3px;margin-bottom:4px;}
.conv-desc{font-size:12px;color:var(--muted);line-height:1.5;}
.conv-cta{display:inline-flex;align-items:center;gap:5px;margin-top:9px;padding:7px 14px;border-radius:20px;font-size:12px;font-weight:700;transition:all .2s;}
.conv-card:active .conv-cta{transform:translateX(3px);}

/* 30-min promise section */
.promise-section{padding:0 14px 20px;}
.promise-title{font-family:'Bebas Neue',sans-serif;font-size:24px;letter-spacing:.5px;margin-bottom:14px;text-align:center;}
.promise-title span{color:var(--amber);}
.promise-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.promise-item{background:var(--card);border:1px solid var(--border);border-radius:var(--rl);padding:14px;display:flex;flex-direction:column;gap:6px;cursor:pointer;transition:all .2s;}
.promise-item:active{transform:scale(.97);}
.promise-item:hover{border-color:var(--border2);}
.pi-ico{font-size:26px;}
.pi-title{font-size:13px;font-weight:700;}
.pi-desc{font-size:11px;color:var(--muted);line-height:1.4;}
.pi-time{font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;width:fit-content;}

/* Inquire section */
.inquire-strip{margin:0 14px 20px;background:linear-gradient(135deg,rgba(45,106,79,.12),rgba(45,106,79,.05));border:1px solid rgba(82,183,136,.18);border-radius:var(--rl);padding:18px 16px;}
.is-title{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:.5px;margin-bottom:4px;}
.is-sub{font-size:12px;color:var(--muted);margin-bottom:14px;line-height:1.5;}
.is-btn{display:flex;align-items:center;justify-content:center;gap:8px;padding:12px;background:linear-gradient(135deg,var(--green),#1b5e3a);color:#fff;border-radius:var(--r);font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.3px;box-shadow:0 4px 14px rgba(45,106,79,.35);transition:all .2s;}
.is-btn:active{transform:scale(.97);}

/* ── OVERLAY + SHEETS ── */
.overlay{position:fixed;inset:0;z-index:400;background:rgba(0,0,0,.82);backdrop-filter:blur(6px);opacity:0;pointer-events:none;transition:opacity .25s;display:flex;align-items:flex-end;}
.overlay.open{opacity:1;pointer-events:all;}
.sheet{width:100%;background:var(--ink2);border-radius:24px 24px 0 0;border:1px solid rgba(255,255,255,.08);transform:translateY(100%);transition:transform .38s cubic-bezier(.32,1,.68,1);max-height:94dvh;overflow-y:auto;padding-bottom:calc(20px + var(--sb));}
.overlay.open .sheet{transform:translateY(0);}
.sh-grip{display:flex;align-items:center;justify-content:space-between;padding:13px 16px 0;}
.sh-handle{width:38px;height:4px;border-radius:2px;background:rgba(255,255,255,.1);}
.sh-x{width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.5);font-size:14px;}
.sh-x:active{transform:scale(.9);}

/* ── DETAIL SHEET ── */
/* Main gallery in sheet */
.det-gallery{position:relative;overflow:hidden;}
.det-track{display:flex;transition:transform .42s cubic-bezier(.25,.46,.45,.94);will-change:transform;}
.det-slide{min-width:100%;flex-shrink:0;}
.det-slide img{width:100%;height:280px;object-fit:cover;}
@media(min-width:600px){.det-slide img{height:360px;}}
.det-car-btn{position:absolute;top:50%;transform:translateY(-50%);width:38px;height:38px;border-radius:50%;background:rgba(8,4,0,.7);backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;color:#fff;font-size:17px;z-index:4;transition:all .2s;}
.det-car-btn:active{transform:translateY(-50%) scale(.9);}
.det-prev{left:12px;}.det-next{right:12px;}
.det-dots{position:absolute;bottom:10px;left:0;right:0;display:flex;justify-content:center;gap:5px;z-index:4;pointer-events:none;}
.det-dot{width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.4);transition:all .25s;}
.det-dot.on{background:#fff;width:18px;border-radius:4px;}
/* Thumbnail strip in sheet */
.det-thumbs{display:flex;gap:6px;padding:10px 16px 4px;overflow-x:auto;scrollbar-width:none;}
.det-thumbs::-webkit-scrollbar{display:none;}
.det-thumb{width:58px;height:46px;border-radius:8px;object-fit:cover;flex-shrink:0;cursor:pointer;border:2px solid transparent;opacity:.6;transition:all .2s;}
.det-thumb.on{border-color:var(--green2);opacity:1;}

.det-body{padding:14px 16px;}
.det-badge{display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:700;padding:4px 11px;border-radius:20px;background:rgba(82,183,136,.12);color:var(--green2);margin-bottom:8px;}
.det-title{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:.3px;margin-bottom:3px;}
.det-price{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:.5px;color:var(--green2);margin-bottom:6px;}
.det-loc{font-size:13px;color:var(--muted);margin-bottom:10px;display:flex;align-items:center;gap:4px;}
.det-desc{font-size:13px;color:var(--muted);line-height:1.65;margin-bottom:14px;}
.det-feats{display:grid;grid-template-columns:1fr 1fr;gap:8px;background:rgba(255,255,255,.03);border-radius:var(--r);padding:12px;margin-bottom:14px;border:1px solid var(--border);}
.df{display:flex;align-items:center;gap:7px;font-size:12px;color:var(--muted);}
.df-ico{font-size:16px;}
.landlord-box{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,.03);border-radius:var(--r);padding:13px;margin-bottom:16px;border:1px solid var(--border);}
.ll-av{width:40px;height:40px;border-radius:50%;background:rgba(45,106,79,.25);border:1px solid rgba(82,183,136,.2);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;}
.ll-name{font-size:14px;font-weight:700;}
.ll-sub{font-size:11px;color:var(--muted);}

/* ── BOOKING FORM ── */
.bk-title{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:.3px;margin-bottom:2px;}
.bk-sub{font-size:12px;color:var(--muted);margin-bottom:14px;}

/* Step indicator */
.bk-steps{display:flex;align-items:center;margin-bottom:18px;}
.bks{display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;}
.bks:last-child{flex:0;flex-shrink:0;}
.bks-dot{width:26px;height:26px;border-radius:50%;border:2px solid var(--border2);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:var(--muted);transition:all .28s;}
.bks-dot.done  {background:var(--green2);border-color:var(--green2);color:#000;font-size:12px;}
.bks-dot.active{background:var(--green); border-color:var(--green);  color:#fff;box-shadow:0 0 0 4px rgba(45,106,79,.2);}
.bks-lbl{font-size:9px;font-weight:600;color:var(--muted);letter-spacing:.2px;text-align:center;}
.bks-lbl.active{color:var(--green2);}
.bks-lbl.done  {color:var(--green2);}
.bks-line{flex:1;height:2px;background:var(--border2);margin:0 4px;margin-bottom:14px;transition:background .28s;}
.bks-line.done{background:var(--green2);}

/* Step panels */
.bk-panel{display:none;animation:panelIn .22s ease;}
.bk-panel.active{display:block;}
@keyframes panelIn{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:translateX(0)}}

/* Form fields */
.field{margin-bottom:11px;}
.field label{display:block;font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:5px;}
.field input,.field textarea,.field select{width:100%;padding:11px 13px;border-radius:var(--r);background:rgba(255,255,255,.05);border:1.5px solid var(--border2);color:var(--text);font-family:inherit;font-size:14px;outline:none;transition:border-color .2s;}
.field input:focus,.field textarea:focus,.field select:focus{border-color:var(--green2);}
.field input::placeholder,.field textarea::placeholder{color:rgba(255,255,255,.22);}
.field select option{background:var(--ink2);}
.field textarea{resize:vertical;min-height:72px;}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}

/* Summary box */
.bk-summary{background:rgba(255,255,255,.03);border-radius:var(--r);padding:12px;margin-bottom:12px;border:1px solid var(--border);}
.bks-row{display:flex;justify-content:space-between;font-size:13px;padding:5px 0;border-bottom:1px solid var(--border);}
.bks-row:last-child{border-bottom:none;}
.bks-row span:first-child{color:var(--muted);}
.bks-row span:last-child{font-weight:600;}
.pay-option{display:flex;align-items:center;gap:12px;padding:12px 13px;border-radius:var(--r);border:2px solid rgba(82,183,136,.3);background:rgba(45,106,79,.07);margin-bottom:12px;}
.po-dot2{width:17px;height:17px;border-radius:50%;background:var(--green2);border:2px solid var(--green2);margin-left:auto;flex-shrink:0;display:flex;align-items:center;justify-content:center;}
.po-dot2::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}

/* Nav buttons */
.bk-nav{display:flex;gap:8px;padding-top:4px;}
.bk-back{padding:12px 16px;background:rgba(255,255,255,.06);border:1px solid var(--border2);border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;color:var(--muted);cursor:pointer;transition:all .18s;}
.bk-next{flex:1;padding:13px;background:linear-gradient(135deg,var(--green),#1b5e3a);color:#fff;border:none;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.3px;cursor:pointer;transition:all .18s;box-shadow:0 4px 16px rgba(45,106,79,.3);}
.bk-next:active{transform:scale(.98);}
.bk-submit{width:100%;padding:14px;background:linear-gradient(135deg,var(--green),#1b5e3a);color:#fff;border:none;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.3px;cursor:pointer;transition:all .18s;box-shadow:0 4px 16px rgba(45,106,79,.3);margin-bottom:8px;}
.bk-submit:active{transform:scale(.98);}
.bk-wa{width:100%;padding:13px;background:#25D366;color:#fff;border:none;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.3px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px;margin-bottom:8px;transition:all .2s;}
.bk-wa:active{transform:scale(.98);}
.bk-done{width:100%;padding:12px;background:rgba(255,255,255,.05);color:var(--muted);border:1px solid var(--border2);border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;cursor:pointer;}

/* Success */
.suc-wrap{text-align:center;padding:26px 16px 10px;}
.suc-ico{font-size:52px;margin-bottom:12px;}
.suc-title{font-family:'Bebas Neue',sans-serif;font-size:24px;letter-spacing:.5px;margin-bottom:6px;}
.suc-sub{font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:14px;}
.suc-det{background:rgba(255,255,255,.03);border-radius:var(--r);padding:11px;text-align:left;margin-bottom:14px;border:1px solid var(--border);}
.sd-row{display:flex;justify-content:space-between;font-size:13px;padding:5px 0;border-bottom:1px solid var(--border);}
.sd-row:last-child{border-bottom:none;}
.sd-row span:first-child{color:var(--muted);}
.sd-row span:last-child{font-weight:600;}

/* ── INQUIRE SHEET ── */
.inq-title{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:.3px;margin-bottom:2px;}
.inq-sub{font-size:12px;color:var(--muted);margin-bottom:14px;line-height:1.5;}

/* ── BOTTOM NAV — matches index.php exactly ── */
.bnav{position:fixed;bottom:0;left:0;right:0;z-index:200;height:calc(var(--bnav) + var(--sb));padding-bottom:var(--sb);background:rgba(8,4,0,.95);backdrop-filter:blur(28px);-webkit-backdrop-filter:blur(28px);border-top:1px solid rgba(255,255,255,.07);display:flex;align-items:stretch;}
.bni{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:0 4px;-webkit-tap-highlight-color:transparent;transition:all .2s;position:relative;}
.bni-ico{font-size:20px;color:rgba(255,255,255,.38);transition:all .22s;line-height:1.15;}
.bni-lbl{font-size:9px;font-weight:700;color:rgba(255,255,255,.3);letter-spacing:.5px;text-transform:uppercase;transition:all .22s;}
.bni.active .bni-ico{color:var(--amber);}
.bni.active .bni-lbl{color:var(--amber);}
.bni.active::before{content:'';position:absolute;bottom:2px;width:20px;height:2px;border-radius:1px;background:var(--amber);animation:indIn .3s ease;}
@keyframes indIn{from{width:0;opacity:0;}to{width:20px;opacity:1;}}
.bni-center{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;-webkit-tap-highlight-color:transparent;cursor:pointer;position:relative;}
.bni-center-btn{width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#6366f1);display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:0 -2px 16px rgba(124,58,237,.5);margin-top:-16px;border:3px solid rgba(8,4,0,.95);transition:all .22s;}
.bni-center:active .bni-center-btn{transform:scale(.92);}
.bni-center-lbl{font-size:9px;font-weight:700;color:rgba(139,92,246,.75);letter-spacing:.5px;text-transform:uppercase;}

/* ── TOAST ── */
.toast{position:fixed;bottom:calc(var(--bnav) + var(--sb) + 14px);left:50%;transform:translateX(-50%) translateY(8px);background:var(--text);color:var(--ink);padding:10px 20px;border-radius:30px;font-size:13px;font-weight:600;z-index:999;opacity:0;pointer-events:none;transition:all .22s;white-space:nowrap;box-shadow:0 8px 24px rgba(0,0,0,.4);}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
</style>
</head>
<body>

<!-- HEADER -->
<header class="hdr">
  <div class="hdr-row">
    <a href="index.php" class="back-btn">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M19 12H5M5 12l7-7M5 12l7 7"/></svg>
    </a>
    <div class="hdr-brand">Malaba <span>Homes</span></div>
    <div class="hdr-acts">
      <button class="ico-btn" onclick="openInquireSheet(null)" title="Inquire about a home">&#x1F4AC;</button>
    </div>
  </div>
  <div class="srch-row">
    <div class="srch-box">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      <input type="search" id="srchInput" placeholder="Search by name or area…" autocomplete="off" enterkeyhint="search">
    </div>
  </div>
  <div class="chips-row">
    <button class="chip on" data-f="">All Types</button>
    <button class="chip" data-f="studio">Studio</button>
    <button class="chip" data-f="1 bed">1 Bed</button>
    <button class="chip" data-f="2 bed">2 Bed</button>
    <button class="chip" data-f="3 bed">3 Bed</button>
    <button class="chip" data-f="house">House</button>
    <button class="chip" data-f="furnished">Furnished</button>
  </div>
</header>

<div class="sec-head">
  <h2>&#x1F3E0; <span id="gridTitle">Available Homes</span></h2>
</div>
<div class="res-count" id="resCount"></div>

<div class="homes-list" id="homesList">
  <div class="skel-card"><div class="skel-img skel"></div><div class="skel-body"><div class="skel-ln skel" style="width:70%"></div><div class="skel-ln skel" style="width:50%"></div></div></div>
  <div class="skel-card"><div class="skel-img skel"></div><div class="skel-body"><div class="skel-ln skel" style="width:80%"></div><div class="skel-ln skel" style="width:45%"></div></div></div>
  <div class="skel-card"><div class="skel-img skel"></div><div class="skel-body"><div class="skel-ln skel" style="width:65%"></div><div class="skel-ln skel" style="width:55%"></div></div></div>
</div>

<!-- BOTTOM NAV -->
<nav class="bnav">
  <a href="index.php" class="bni">
    <div class="bni-ico">&#x1F3E1;</div>
    <div class="bni-lbl">Home</div>
  </a>
  <a href="shop_listing.php" class="bni">
    <div class="bni-ico">&#x1F6D2;</div>
    <div class="bni-lbl">Shop</div>
  </a>
  <a href="video_feed.php" class="bni-center">
    <div class="bni-center-btn">&#x25B6;</div>
    <div class="bni-center-lbl">Watch</div>
  </a>
  <a href="food_listing.php" class="bni">
    <div class="bni-ico">&#x1F354;</div>
    <div class="bni-lbl">Food</div>
  </a>
  <a href="homes_listing.php" class="bni active">
    <div class="bni-ico">&#127976;</div>
    <div class="bni-lbl">Rentals</div>
  </a>
</nav>

<!-- OVERLAY — hosts all sheets -->
<div class="overlay" id="overlay" onclick="handleOvClick(event)">
  <div class="sheet" id="mainSheet">
    <div id="sheetContent"></div>
  </div>
</div>


<div class="toast" id="toast"></div>

<script src="data.js"></script>
<script src="mh_user.js"></script>
<script src="image-performance-helper.js"></script>
<script>
/* ════════════════════════════════════════
   STATE
════════════════════════════════════════ */
var allHomes    = [];
var filtered    = [];
var filterChip  = '';
var searchQ     = '';
var wishlist    = [];
var currentItem = null;
var detGalIdx   = 0;
var cardGalIdx  = {};
var bkStep      = 1;

try { wishlist = JSON.parse(localStorage.getItem('mh_h_wish') || '[]'); } catch(e){}

var API_BASE = (function(){
  var scripts = document.querySelectorAll('script[src]');
  for (var i=0; i<scripts.length; i++) {
    if (scripts[i].src && scripts[i].src.indexOf('data.js') !== -1) {
      return scripts[i].src.replace(/\/data\.js[^\/]*$/,'/api');
    }
  }
  return '<?php echo htmlspecialchars($apiBase, ENT_QUOTES); ?>';
})();

/* ════════════════════════════════════════
   LOAD FROM API
════════════════════════════════════════ */
(function init(){
  var xhr = new XMLHttpRequest();
  xhr.open('GET', API_BASE + '/listings.php?type=houses&limit=40&sort=smart', true);
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout = 9000;
  xhr.onload = function() {
    try {
      var d = JSON.parse(xhr.responseText);
      if (d && d.success && d.data && d.data.length) {
        allHomes = d.data;
        filtered = allHomes;
        renderCards(allHomes);
        return;
      }
    } catch(e){}
    // Fallback to seed data
    loadSeed();
  };
  xhr.onerror = xhr.ontimeout = function(){ loadSeed(); };
  xhr.send();
})();

function loadSeed() {
  if (window.MalabaAPI) {
    var seed = MalabaAPI._seed && MalabaAPI._seed.houses;
    if (seed && seed.length) { allHomes = seed; filtered = seed; renderCards(seed); return; }
  }
  allHomes = []; renderEmpty();
}

/* ════════════════════════════════════════
   RENDER CARDS
════════════════════════════════════════ */
function renderCards(items) {
  var list = document.getElementById('homesList');
  var cnt  = document.getElementById('resCount');
  if (cnt) cnt.textContent = items.length + ' home' + (items.length!==1?'s':'') + ' available';

  if (!items.length) { renderEmpty(); return; }

  var html = '';
  items.forEach(function(h, i) {
    var imgs   = (h.images && h.images.length > 1) ? h.images : [h.image || h.image_url || ''];
    imgs = imgs.filter(function(x){ return x; });
    if (!imgs.length) imgs = ['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900&q=80'];

    var multi  = imgs.length > 1;
    var liked  = wishlist.indexOf(h.id) !== -1;
    var feats  = (h.features || []).slice(0, 4);
    var raw    = parseFloat(String(h.price||'').replace(/[^0-9.]/g,'')) || 0;
    var badgeCls = getBadgeCls(h.badge);
    var phone  = (h.contact && h.contact.phone) ? h.contact.phone : (h.contact_phone || '');
    var waNum  = normWA(phone);
    var waMsg  = encodeURIComponent('Hi! I\'m interested in *'+h.title+'*\nRent: '+h.price+'\nLocation: '+(h.location||''));

    // Light carousel: render only first full image immediately; others are lazy-swapped on navigation.
    var first = imgs[0];
    var rest  = imgs.slice(1);
    var restJSON = JSON.stringify(rest).replace(/</g,'\\u003c').replace(/>/g,'\\u003e');

var slides =
      '<div class="carousel-slide">' +
        '<div style="position:absolute;inset:0;" class="mh-img-reserve" aria-hidden="true"></div>' +
        '<img class="car-main-img" src="'+esc(first)+'" alt="'+esc(h.title)+'" decoding="async" loading="eager" width="320" height="240" onerror="this.style.opacity=\'0\'; this.parentElement.style.background=\'rgba(255,255,255,.05)\';" style="width:100%;height:100%;object-fit:cover;" >' +
        '<div class="carousel-grad"></div>' +
      '</div>';

    var dots = imgs.map(function(_, di) {
      return '<div class="car-dot'+(di===0?' on':'')+'"></div>';
    }).join('');

var thumbs = multi ? imgs.map(function(img, ti) {
      return '<img src="'+esc(img)+'" class="car-thumb'+(ti===0?' on':'')+'" onclick="cardGalTo(\''+esc(h.id)+'\','+ti+')" loading="lazy" decoding="async" width="52" height="42">';
    }).join('') : '';


    html +=
      '<div class="hcard" style="animation-delay:'+(Math.min(i,6)*.07)+'s">' +
        '<div class="hcard-carousel">' +
          '<div class="carousel-track" id="ct-'+esc(h.id)+'" data-imgs="'+restJSON+'">'+slides+'</div>' +

          '<div class="card-badges">' +
            (h.badge ? '<div class="hbadge '+badgeCls+'">'+esc(h.badge)+'</div>' : '<div></div>') +
            '<button class="wish-btn'+(liked?' liked':'')+'" onclick="toggleWish(event,\''+esc(h.id)+'\',this)">'+( liked?'&#x2665;':'&#x2661;' )+'</button>' +
          '</div>' +
          (multi ? '<button class="car-btn car-prev" onclick="cardGal(\''+esc(h.id)+'\',-1,event)">&#x2039;</button><button class="car-btn car-next" onclick="cardGal(\''+esc(h.id)+'\',1,event)">&#x203A;</button>' : '') +
          '<div class="car-dots" id="cd-'+esc(h.id)+'">'+dots+'</div>' +
          '<div class="price-tag">'+esc(h.price)+'</div>' +
        '</div>' +
        (multi ? '<div class="car-thumbs" id="cth-'+esc(h.id)+'">'+thumbs+'</div>' : '') +
        '<div class="hcard-body">' +
          '<div class="hcard-title">'+esc(h.title)+'</div>' +
          '<div class="hcard-meta">' +
            '<div class="hloc">&#x1F4CD; '+esc((h.location||'').split(',')[0])+'</div>' +
            (raw > 0 ? '<div style="font-size:11px;color:var(--green2);">&#x2B50; '+(3.9+Math.random()*.9).toFixed(1)+'</div>' : '') +
          '</div>' +
          (h.description ? '<div class="hcard-desc">'+esc(h.description)+'</div>' : '') +
          (feats.length ? '<div class="feat-row">'+feats.map(function(f){ return '<span class="fp">'+(f.icon||'&#x2705;')+' '+esc(f.text||f.feature_text||'')+'</span>'; }).join('')+'</div>' : '') +
        '</div>' +
        '<div class="hcard-foot">' +
          '<button class="btn-book" onclick="openDetail(\''+esc(h.id)+'\')">&#x1F4CB; View &amp; Book</button>' +
          '<a href="https://wa.me/'+waNum+'?text='+waMsg+'" target="_blank" rel="noopener" class="btn-wa" onclick="event.stopPropagation()">&#x1F4AC;</a>' +
        '</div>' +
      '</div>';
  });
  list.innerHTML = html;
}

/* ── Card carousel navigation ── */
function cardGal(id, dir, ev) {
  if (ev) ev.stopPropagation();
  var track = document.getElementById('ct-'+id);
  if (!track) return;
  var slides = track.querySelectorAll('.carousel-slide');
  if (!slides.length) return;
  var cur = cardGalIdx[id] || 0;
  var next = (cur + dir + slides.length) % slides.length;
  cardGalTo(id, next);
}
function cardGalTo(id, idx) {
  var track  = document.getElementById('ct-'+id);
  var dots   = document.getElementById('cd-'+id);
  var thumbs = document.getElementById('cth-'+id);
  if (!track) return;
  cardGalIdx[id] = idx;

  // Light carousel: only 1 slide exists in DOM.
  // Swap the main image instead of translating across many off-screen slides.
  var mainImg = track.querySelector('img.car-main-img');
  var cardDiv = document.querySelector('.hcard');
  // Use the stored images list from attribute if available
  var json = track.getAttribute('data-imgs');
  var imgs = [];
  if (json) {
    try { imgs = JSON.parse(json); } catch(e){}
  }
  if (!imgs.length) {
    // Fallback: keep transform behavior off
    track.style.transform = 'none';
  } else {
    var u = imgs[idx] || imgs[0];
    if (mainImg && u) {
      mainImg.style.opacity = '0.001';
      mainImg.src = u;
      mainImg.addEventListener('load', function(){ mainImg.style.opacity = '1'; }, {once:true});
    }
    track.style.transform = 'none';
  }

  if (dots) {
    var dEls = dots.querySelectorAll('.car-dot');
    dEls.forEach(function(d,i){ d.classList.toggle('on', i===idx); });
  }
  if (thumbs) {
    var tEls = thumbs.querySelectorAll('.car-thumb');
    tEls.forEach(function(t,i){ t.classList.toggle('on', i===idx); });
  }
}

/* Touch swipe on card carousels */
document.addEventListener('DOMContentLoaded', function() {
  document.addEventListener('touchstart', function(e) {
    var track = e.target.closest('.carousel-track');
    if (!track) return;
    track._tsX = e.touches[0].clientX;
  }, {passive:true});
  document.addEventListener('touchend', function(e) {
    var track = e.target.closest('.carousel-track');
    if (!track || track._tsX === undefined) return;
    var dx = e.changedTouches[0].clientX - track._tsX;
    if (Math.abs(dx) < 40) return;
    var id = track.id.replace('ct-','');
    cardGal(id, dx < 0 ? 1 : -1, null);
  }, {passive:true});
});

/* ════════════════════════════════════════
   FILTER + SEARCH
════════════════════════════════════════ */
document.querySelectorAll('.chip').forEach(function(c) {
  c.addEventListener('click', function() {
    document.querySelectorAll('.chip').forEach(function(x){ x.classList.remove('on'); });
    c.classList.add('on');
    filterChip = c.dataset.f;
    applyFilter();
  });
});
var srchTimer;
document.getElementById('srchInput').addEventListener('input', function(e) {
  clearTimeout(srchTimer);
  var q = e.target.value;
  srchTimer = setTimeout(function() { searchQ = q.trim().toLowerCase(); applyFilter(); }, 320);
});
function applyFilter() {
  filtered = allHomes.filter(function(h) {
    var txt = (h.title+' '+(h.description||'')+' '+(h.location||'')).toLowerCase();
    var mq  = !searchQ   || txt.indexOf(searchQ) !== -1;
    var mc  = !filterChip || txt.indexOf(filterChip) !== -1;
    return mq && mc;
  });
  renderCards(filtered);
}

/* ════════════════════════════════════════
   EMPTY STATE — convert every visitor
════════════════════════════════════════ */
function renderEmpty() {
  var list = document.getElementById('homesList');
  var cnt  = document.getElementById('resCount');
  if (cnt) cnt.textContent = '';

  list.innerHTML =
    // Empty message + inquire
    '<div style="text-align:center;padding:28px 14px 20px;">' +
      '<div style="font-size:52px;margin-bottom:12px;">&#x1F3D8;</div>' +
      '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:24px;letter-spacing:.5px;margin-bottom:6px;">No Homes Listed Yet</div>' +
      '<div style="font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:18px;max-width:340px;margin-left:auto;margin-right:auto;">We\'re adding new homes every day. Tell us what you\'re looking for and we\'ll find it for you personally.</div>' +
      '<button onclick="openInquireSheet(null)" style="display:inline-flex;align-items:center;gap:7px;padding:12px 24px;background:linear-gradient(135deg,var(--green),#1b5e3a);color:#fff;border:none;border-radius:30px;font-family:\'Bebas Neue\',sans-serif;font-size:16px;letter-spacing:.3px;cursor:pointer;box-shadow:0 4px 14px rgba(45,106,79,.35);">&#x1F4AC; Describe Your Dream Home</button>' +
    '</div>' +

    // 30-min promise
    '<div class="promise-section">' +
      '<div class="promise-title">While you wait — get it in <span>&lt; 30 min</span></div>' +
      '<div class="promise-grid">' +
        promiseItem('&#x1F354;','Hot Food Delivered','Burgers, pilau, nyama choma — straight to your door.','10–25 min','rgba(193,68,14,.15)','rgba(252,165,165,.7)','food_listing.php') +
        promiseItem('&#x1F373;','Kitchen Essentials','Pots, pans, utensils — everything you need for your new home.','Same day','rgba(27,79,158,.15)','rgba(147,197,253,.7)','shop_listing.php') +
        promiseItem('&#x26A1;','Electronics & Appliances','Kettles, radios, phone accessories, bulbs and more.','Same day','rgba(245,166,35,.12)','rgba(253,224,71,.7)','shop_listing.php?sub=appliances') +
        promiseItem('&#x1F6CB;','Home Furniture','Foldable chairs, storage baskets, wall decor for any space.','Same day','rgba(139,92,246,.12)','rgba(196,181,253,.7)','shop_listing.php?sub=furniture') +
        promiseItem('&#x1F9F9;','Cleaning Supplies','Brooms, mops, detergent — move-in ready in minutes.','Same day','rgba(82,183,136,.12)','rgba(134,239,172,.7)','shop_listing.php?sub=cleaning') +
        promiseItem('&#x25B6;','Watch &amp; Shop','See products in real video. Order in one tap.','Always open','rgba(109,40,217,.12)','rgba(196,181,253,.7)','video_feed.php') +
      '</div>' +
    '</div>' +

    // Alternative CTA cards
    '<div class="empty-state">' +
      convCard('https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=900&q=70','&#x1F354; Food','Order Hot Food Now','Hungry? Get food delivered in 10–25 minutes anywhere in Malaba. Fresh, fast, affordable.','var(--amber)','Order Food &#x2192;','rgba(232,82,26,.1)','rgba(255,112,67,.6)','food_listing.php') +
      convCard('https://images.unsplash.com/photo-1601004890684-d8cbf643f5f2?w=900&q=70','&#x1F6D2; Shop','Shop with Lipa Mdogo Mdogo','Pay daily, weekly or twice a week. Get home goods, electronics and more — delivered to your door.','var(--blue)','Browse Shop &#x2192;','rgba(72,149,239,.1)','rgba(72,149,239,.6)','shop_listing.php') +
    '</div>' +

    // Inquire strip
    '<div class="inquire-strip">' +
      '<div class="is-title">&#x1F50D; Can\'t Find What You Need?</div>' +
      '<div class="is-sub">Tell us exactly what you\'re looking for — number of rooms, budget, location. Our team will find options for you personally within 24 hours.</div>' +
      '<button class="is-btn" onclick="openInquireSheet(null)">&#x1F4AC; Inquire About a Home</button>' +
    '</div>';
}

function promiseItem(icon, title, desc, time, bg, timeBg, href) {
  return '<div class="promise-item" style="background:'+bg+';border-color:rgba(255,255,255,.07);" onclick="location.href=\''+href+'\'">' +
    '<div class="pi-ico">'+icon+'</div>' +
    '<div class="pi-title">'+title+'</div>' +
    '<div class="pi-desc">'+desc+'</div>' +
    '<div class="pi-time" style="background:'+timeBg+';color:var(--ink);">&#x23F0; '+time+'</div>' +
  '</div>';
}
function convCard(img, cat, title, desc, catColor, cta, bg, border, href) {
  return '<div class="conv-card" onclick="location.href=\''+href+'\'" style="background:'+bg+';border-color:'+border+';">' +
    '<img class="conv-img" src="'+img+'" alt="'+title+'" loading="lazy">' +
    '<div class="conv-body">' +
      '<div class="conv-cat" style="color:'+catColor+'">'+cat+'</div>' +
      '<div class="conv-title">'+title+'</div>' +
      '<div class="conv-desc">'+desc+'</div>' +
      '<div class="conv-cta" style="background:rgba(255,255,255,.08);color:var(--text);">'+cta+'</div>' +
    '</div>' +
  '</div>';
}

/* ════════════════════════════════════════
   DETAIL SHEET
════════════════════════════════════════ */
function openDetail(id) {
  var item = allHomes.find(function(h){ return h.id===id; });
  if (!item) { showToast('Could not load details'); return; }
  currentItem = item;
  detGalIdx = 0; bkStep = 1;
  renderDetailSheet(item);
  openOverlay();
  if (window.MalabaAPI) MalabaAPI.trackView(id);
}

function renderDetailSheet(item) {
  var imgs  = (item.images && item.images.length > 1) ? item.images : [item.image || item.image_url || ''];
  imgs = imgs.filter(function(x){ return x; });
  if (!imgs.length) imgs = ['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900&q=80'];
  var multi = imgs.length > 1;
  var feats = item.features || [];
  var phone = (item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'');
  var waNum = normWA(phone);

  var slides = imgs.map(function(img) {
    return '<div class="det-slide"><img src="'+esc(img)+'" alt="'+esc(item.title)+'" loading="lazy" onerror="this.src=\'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900&q=80\'"></div>';
  }).join('');
  var dots = imgs.map(function(_,i) {
    return '<div class="det-dot'+(i===0?' on':'')+'"></div>';
  }).join('');
  var thumbs = multi ? imgs.map(function(img,i) {
    return '<img src="'+esc(img)+'" class="det-thumb'+(i===0?' on':'')+'" onclick="detGalTo('+i+')" loading="lazy">';
  }).join('') : '';

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-grip"><div class="sh-handle"></div><button class="sh-x" onclick="closeOverlay()">&#x2715;</button></div>' +
    // Gallery
    '<div class="det-gallery">' +
      '<div class="det-track" id="detTrack">'+slides+'</div>' +
      (multi ? '<button class="det-car-btn det-prev" onclick="detGal(-1)">&#x2039;</button><button class="det-car-btn det-next" onclick="detGal(1)">&#x203A;</button>' : '') +
      '<div class="det-dots" id="detDots">'+dots+'</div>' +
    '</div>' +
    (multi ? '<div class="det-thumbs" id="detThumbs">'+thumbs+'</div>' : '') +
    // Body
    '<div class="det-body">' +
      (item.badge ? '<div class="det-badge">&#x1F3E0; '+esc(item.badge)+'</div>' : '') +
      '<div class="det-title">'+esc(item.title)+'</div>' +
      '<div class="det-price">'+esc(item.price)+'</div>' +
      '<div class="det-loc">&#x1F4CD; '+esc(item.location||'')+'</div>' +
      (item.description ? '<div class="det-desc">'+esc(item.description)+'</div>' : '') +
      (feats.length ?
        '<div class="det-feats">'+feats.map(function(f){ return '<div class="df"><span class="df-ico">'+(f.icon||'&#x2705;')+'</span><span>'+esc(f.text||f.feature_text||'')+'</span></div>'; }).join('')+'</div>'
        : '') +
      '<div class="landlord-box">' +
        '<div class="ll-av">&#x1F464;</div>' +
        '<div><div class="ll-name">'+esc((item.contact&&item.contact.name)?item.contact.name:(item.contact_name||'Landlord'))+'</div><div class="ll-sub">Verified Landlord &bull; Responds within 2 hours</div></div>' +
      '</div>' +
      // Booking form
      buildBookingForm() +
    '</div>';

  // Touch swipe on detail gallery
  var track = document.getElementById('detTrack');
  if (track) {
    var tx = 0;
    track.addEventListener('touchstart', function(e){ tx = e.touches[0].clientX; }, {passive:true});
    track.addEventListener('touchend', function(e){
      var dx = e.changedTouches[0].clientX - tx;
      if (Math.abs(dx) > 45) detGal(dx < 0 ? 1 : -1);
    }, {passive:true});
  }
  prefillSaved();
}

function detGal(dir) {
  var imgs = (currentItem.images && currentItem.images.length > 1) ? currentItem.images : [currentItem.image||currentItem.image_url];
  imgs = imgs.filter(function(x){ return x; });
  detGalIdx = (detGalIdx + dir + imgs.length) % imgs.length;
  detGalTo(detGalIdx);
}
function detGalTo(idx) {
  var track  = document.getElementById('detTrack');
  var dots   = document.getElementById('detDots');
  var thumbs = document.getElementById('detThumbs');
  if (!track) return;
  detGalIdx = idx;
  track.style.transform = 'translateX(-'+( idx*100 )+'%)';
  if (dots) {
    var dEls = dots.querySelectorAll('.det-dot');
    dEls.forEach(function(d,i){ d.classList.toggle('on', i===idx); });
  }
  if (thumbs) {
    var tEls = thumbs.querySelectorAll('.det-thumb');
    tEls.forEach(function(t,i){ t.classList.toggle('on', i===idx); });
  }
}

/* ════════════════════════════════════════
   BOOKING FORM (3-step)
════════════════════════════════════════ */
function buildBookingForm() {
  return (
    '<div id="bkForm">' +
      '<div class="bk-title">&#x1F4CB; Book a Visit</div>' +
      '<div class="bk-sub">The landlord will call you within 2 hours.</div>' +
      // Step dots
      '<div class="bk-steps">' +
        '<div class="bks"><div class="bks-dot active" id="bsd1">1</div><div class="bks-lbl active" id="bsl1">Details</div></div>' +
        '<div class="bks-line" id="bsln1"></div>' +
        '<div class="bks"><div class="bks-dot" id="bsd2">2</div><div class="bks-lbl" id="bsl2">Move-in</div></div>' +
        '<div class="bks-line" id="bsln2"></div>' +
        '<div class="bks"><div class="bks-dot" id="bsd3">3</div><div class="bks-lbl" id="bsl3">Confirm</div></div>' +
      '</div>' +
      // Step 1
      '<div class="bk-panel active" id="bkp1">' +
        '<div class="row2">' +
          '<div class="field"><label>Full Name *</label><input type="text" id="bk_name" placeholder="Your name" autocomplete="name"></div>' +
          '<div class="field"><label>Phone *</label><input type="tel" id="bk_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>' +
        '</div>' +
        '<div class="field"><label>ID Number *</label><input type="text" id="bk_id" placeholder="e.g. 12345678" inputmode="numeric"></div>' +
        '<div class="bk-nav"><button class="bk-next" onclick="bkNext()">Next: Move-in Info &#x2192;</button></div>' +
      '</div>' +
      // Step 2
      '<div class="bk-panel" id="bkp2">' +
        '<div class="row2">' +
          '<div class="field"><label>Move-in Date</label><input type="date" id="bk_date"></div>' +
          '<div class="field"><label>Duration</label><select id="bk_dur"><option>6 months</option><option>1 year</option><option>2 years</option><option>Open-ended</option></select></div>' +
        '</div>' +
        '<div class="field"><label>Message (Optional)</label><textarea id="bk_msg" placeholder="Any questions for the landlord?"></textarea></div>' +
        '<div class="bk-nav"><button class="bk-back" onclick="bkBack()">&#x2190; Back</button><button class="bk-next" onclick="bkToConfirm()">Review &amp; Confirm &#x2192;</button></div>' +
      '</div>' +
      // Step 3
      '<div class="bk-panel" id="bkp3">' +
        '<div class="bk-summary" id="bkSummary"></div>' +
        '<div class="pay-option">' +
          '<div style="font-size:20px;">&#x1F4B5;</div>' +
          '<div><div style="font-size:13px;font-weight:700;">Cash on Move-In</div><div style="font-size:11px;color:var(--muted);">No deposit upfront — pay when you move in</div></div>' +
          '<div class="po-dot2"></div>' +
        '</div>' +
        '<button class="bk-submit" id="bkSubmitBtn" onclick="submitBooking()">&#x1F3E0; Send Booking Request</button>' +
        '<button class="bk-wa" onclick="quickWA(null,currentItem.id,\'\',\'\')">&#x1F4AC; WhatsApp Landlord Instead</button>' +
        '<div class="bk-nav" style="padding-top:0;"><button class="bk-back" onclick="bkBack()">&#x2190; Back</button></div>' +
      '</div>' +
    '</div>'
  );
}

/* Step navigation */
function bkNext() {
  var name  = (document.getElementById('bk_name').value||'').trim();
  var phone = (document.getElementById('bk_phone').value||'').trim();
  var id    = (document.getElementById('bk_id').value||'').trim();
  if (!name)  { showToast('Enter your full name'); return; }
  if (!phone || phone.replace(/\D/g,'').length < 9) { showToast('Enter a valid phone number'); return; }
  if (!id)    { showToast('ID number is required'); return; }
  setBkStep(2);
}
function bkToConfirm() {
  // Build summary
  var name  = (document.getElementById('bk_name').value||'').trim();
  var phone = (document.getElementById('bk_phone').value||'').trim();
  var date  = document.getElementById('bk_date').value || 'Not set';
  var dur   = document.getElementById('bk_dur').value  || '';
  var sum = document.getElementById('bkSummary');
  if (sum) {
    var rows = [
      ['Home', currentItem ? currentItem.title : ''],
      ['Rent', currentItem ? currentItem.price : ''],
      ['Your Name', name],['Phone', phone],
      ['Move-in', date],['Duration', dur],['Payment','Cash on Move-In'],
    ];
    sum.innerHTML = '<div style="font-size:12px;font-weight:700;color:var(--text);margin-bottom:8px;letter-spacing:.5px;text-transform:uppercase;">Order Summary</div>' +
      rows.map(function(r){ return '<div class="bks-row"><span>'+r[0]+'</span><span>'+esc(r[1])+'</span></div>'; }).join('');
  }
  setBkStep(3);
}
function bkBack() {
  setBkStep(bkStep - 1);
}
function setBkStep(s) {
  // Update panel visibility
  [1,2,3].forEach(function(n) {
    var p = document.getElementById('bkp'+n);
    if (p) p.className = 'bk-panel' + (n===s?' active':'');
  });
  // Update step dots
  [1,2,3].forEach(function(n) {
    var dot  = document.getElementById('bsd'+n);
    var lbl  = document.getElementById('bsl'+n);
    var line = document.getElementById('bsln'+n);
    if (!dot) return;
    if (n < s) {
      dot.className='bks-dot done'; dot.innerHTML='&#x2713;';
      lbl.className='bks-lbl done';
      if(line) line.className='bks-line done';
    } else if (n===s) {
      dot.className='bks-dot active'; dot.innerHTML=n;
      lbl.className='bks-lbl active';
    } else {
      dot.className='bks-dot'; dot.innerHTML=n;
      lbl.className='bks-lbl';
      if(line) line.className='bks-line';
    }
  });
  bkStep = s;
}

/* Submit booking */
function submitBooking() {
  var name  = (document.getElementById('bk_name').value||'').trim();
  var phone = (document.getElementById('bk_phone').value||'').trim();
  var id    = (document.getElementById('bk_id').value||'').trim();
  var date  = document.getElementById('bk_date').value || 'Not set';
  var dur   = document.getElementById('bk_dur').value  || '';
  var msg   = document.getElementById('bk_msg').value  || '';

  var btn = document.getElementById('bkSubmitBtn');
  if (btn) { btn.disabled=true; btn.textContent='Sending…'; }

  saveMhUser(name, phone);
  var item = currentItem;
  var phone2 = (item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'');
  var waNum  = normWA(phone2);

  var xhr = new XMLHttpRequest();
  xhr.open('POST', API_BASE+'/order.php', true);
  xhr.setRequestHeader('Content-Type','application/json');
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout = 12000;
  xhr.onload = function() {
    var ref = '';
    try { var d = JSON.parse(xhr.responseText); ref = d.order_ref||''; } catch(e){}
    var waMsg = encodeURIComponent(
      'Hi! Booking request for *'+item.title+'*\nRent: '+item.price+'\nName: '+name+'\nPhone: '+phone+'\nID: '+id+'\nMove-in: '+date+'\nDuration: '+dur+(msg?'\nMessage: '+msg:'')+'\nRef: '+(ref||'—')
    );
    var form = document.getElementById('bkForm');
    if (form) {
      form.innerHTML =
        '<div class="suc-wrap">' +
          '<div class="suc-ico">&#x1F3E1;</div>' +
          '<div class="suc-title">Booking Request Sent!</div>' +
          '<div class="suc-sub">The landlord will call <strong>'+esc(phone)+'</strong> within 2 hours.'+(ref?' Ref: <strong>'+esc(ref)+'</strong>':'')+' — or tap WhatsApp below for instant response.</div>' +
          '<div class="suc-det">' +
            '<div class="sd-row"><span>Home</span><span>'+esc(item.title)+'</span></div>' +
            '<div class="sd-row"><span>Rent</span><span>'+esc(item.price)+'</span></div>' +
            '<div class="sd-row"><span>Move-in</span><span>'+esc(date)+'</span></div>' +
            '<div class="sd-row"><span>Duration</span><span>'+esc(dur)+'</span></div>' +
          '</div>' +
          '<button class="bk-wa" onclick="window.open(\'https://wa.me/'+waNum+'?text='+waMsg+'\',\'_blank\')">&#x1F4AC; Chat on WhatsApp</button>' +
          '<button class="bk-done" onclick="closeOverlay()">Done</button>' +
        '</div>';
    }
  };
  xhr.onerror = xhr.ontimeout = function() {
    showToast('Booking sent! The landlord will contact you.');
    if (btn) { btn.disabled=false; btn.textContent='&#x1F3E0; Send Booking Request'; }
  };
  xhr.send(JSON.stringify({
    listing_id:item.id||'', listing_title:item.title||'', listing_price:item.price||'',
    category:'houses', name:name, phone:phone, id_no:id,
    address:'Move-in: '+date+' | Duration: '+dur,
    payment_method:'cash_on_delivery',
    notes:'ID:'+id+' | Move-in:'+date+' | Duration:'+dur+(msg?' | '+msg:''),
    total_amount:'0',
  }));
}

/* ════════════════════════════════════════
   INQUIRE SHEET (custom home request)
════════════════════════════════════════ */
function openInquireSheet(item) {
  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-grip"><div class="sh-handle"></div><button class="sh-x" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<div style="padding:14px 16px;">' +
      '<div class="inq-title">&#x1F50D; Describe Your Dream Home</div>' +
      '<div class="inq-sub">Can\'t find what you need? Tell us exactly what you\'re looking for and we\'ll find it for you personally within 24 hours.</div>' +
      '<div class="field"><label>Full Name *</label><input type="text" id="iq_name" placeholder="Your full name" autocomplete="name"></div>' +
      '<div class="field"><label>Phone *</label><input type="tel" id="iq_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>' +
      '<div class="row2">' +
        '<div class="field"><label>Home Type *</label>' +
          '<select id="iq_type"><option value="">Choose type</option><option>Studio</option><option>1 Bedroom</option><option>2 Bedrooms</option><option>3 Bedrooms</option><option>House</option><option>Furnished</option></select>' +
        '</div>' +
        '<div class="field"><label>Budget (KSH)</label><input type="text" id="iq_budget" placeholder="e.g. 8,000/month"></div>' +
      '</div>' +
      '<div class="field"><label>Preferred Location</label><input type="text" id="iq_location" placeholder="e.g. Near Malaba Market"></div>' +
      '<div class="field"><label>Move-in Date</label><input type="date" id="iq_date"></div>' +
      '<div class="field"><label>Any other requirements?</label><textarea id="iq_msg" placeholder="e.g. must allow pets, ground floor preferred, close to school…"></textarea></div>' +
      '<button style="width:100%;padding:14px;background:linear-gradient(135deg,var(--green),#1b5e3a);color:#fff;border:none;border-radius:var(--rl);font-family:\'Bebas Neue\',sans-serif;font-size:18px;letter-spacing:.3px;cursor:pointer;box-shadow:0 4px 16px rgba(45,106,79,.3);margin-bottom:8px;" id="iqSubmitBtn" onclick="submitInquiry()">&#x1F4AC; Send My Request</button>' +
      '<div style="text-align:center;font-size:11px;color:var(--muted);">We reply within 24 hours &bull; No commitment needed</div>' +
    '</div>';

  openOverlay();
  prefillSaved('iq_name','iq_phone');
}

function submitInquiry() {
  var name = (document.getElementById('iq_name').value||'').trim();
  var phone= (document.getElementById('iq_phone').value||'').trim();
  var type = (document.getElementById('iq_type').value||'').trim();
  if (!name)  { showToast('Enter your full name'); return; }
  if (!phone || phone.replace(/\D/g,'').length < 9) { showToast('Enter a valid phone number'); return; }

  var btn = document.getElementById('iqSubmitBtn');
  if (btn) { btn.disabled=true; btn.textContent='Sending…'; }

  saveMhUser(name, phone);
  var budget  = (document.getElementById('iq_budget').value||'').trim();
  var loc     = (document.getElementById('iq_location').value||'').trim();
  var date    = document.getElementById('iq_date').value||'';
  var msg     = (document.getElementById('iq_msg').value||'').trim();

  var waMsg = encodeURIComponent(
    'Home Inquiry:\nName: '+name+'\nPhone: '+phone+'\nType: '+(type||'Any')+'\nBudget: '+(budget||'Flexible')+'\nLocation: '+(loc||'Malaba')+'\nMove-in: '+(date||'ASAP')+(msg?'\nNotes: '+msg:'')
  );

  var xhr = new XMLHttpRequest();
  xhr.open('POST', API_BASE+'/inquiry.php', true);
  xhr.setRequestHeader('Content-Type','application/json');
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout = 9000;
  xhr.onload = xhr.onerror = xhr.ontimeout = function() {
    document.getElementById('sheetContent').innerHTML =
      '<div class="sh-grip"><div class="sh-handle"></div><button class="sh-x" onclick="closeOverlay()">&#x2715;</button></div>' +
      '<div class="suc-wrap">' +
        '<div class="suc-ico">&#x1F3E0;</div>' +
        '<div class="suc-title">Request Received!</div>' +
        '<div class="suc-sub">We\'ll find the best homes matching your requirements and contact you on <strong>'+esc(phone)+'</strong> within 24 hours.</div>' +
        '<button class="bk-wa" onclick="window.open(\'https://wa.me/254700000000?text='+waMsg+'\',\'_blank\')">&#x1F4AC; Follow Up on WhatsApp</button>' +
        '<button class="bk-done" onclick="closeOverlay()">Done</button>' +
      '</div>';
  };
  xhr.send(JSON.stringify({
    name:name, phone:phone,
    message:'Type: '+(type||'Any')+' | Budget: '+(budget||'Flexible')+' | Location: '+(loc||'Malaba')+' | Move-in: '+(date||'ASAP')+(msg?' | '+msg:''),
  }));
}

/* ════════════════════════════════════════
   QUICK WHATSAPP
════════════════════════════════════════ */
function quickWA(ev, id, name, phone) {
  if (ev) ev.stopPropagation();
  var item = allHomes.find(function(h){ return h.id===id; }) || currentItem;
  if (!item) return;
  var txt = 'Hi! I\'m interested in *'+item.title+'*\nRent: '+item.price+'\nLocation: '+(item.location||'')+(name?'\n\nMy name: '+name:'')+(phone?'\nPhone: '+phone:'');
  var ph  = (item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'');
  var num = normWA(ph);
  window.open('https://wa.me/'+num+'?text='+encodeURIComponent(txt),'_blank');
}

/* ════════════════════════════════════════
   WISHLIST
════════════════════════════════════════ */
function toggleWish(ev, id, btn) {
  ev.stopPropagation();
  var i = wishlist.indexOf(id);
  if (i !== -1) { wishlist.splice(i,1); btn.innerHTML='&#x2661;'; btn.classList.remove('liked'); showToast('Removed from saved'); }
  else          { wishlist.unshift(id); btn.innerHTML='&#x2665;'; btn.classList.add('liked');    showToast('&#x2665; Saved!'); }
  localStorage.setItem('mh_h_wish', JSON.stringify(wishlist));
}

/* ════════════════════════════════════════
   BADGE HELPER
════════════════════════════════════════ */
function getBadgeCls(badge) {
  if (!badge) return 'hb-default';
  var b = String(badge).toLowerCase();
  if (b.indexOf('hot')!==-1||b.indexOf('popular')!==-1||b.indexOf('bestsell')!==-1) return 'hb-hot';
  if (b.indexOf('budget')!==-1||b.indexOf('studio')!==-1)  return 'hb-budget';
  if (b.indexOf('family')!==-1||b.indexOf('spacious')!==-1) return 'hb-family';
  if (b.indexOf('new')!==-1)  return 'hb-new';
  return 'hb-default';
}

/* ════════════════════════════════════════
   OVERLAY / SHEET HELPERS
════════════════════════════════════════ */
function openOverlay(){
  document.getElementById('overlay').classList.add('open');
  document.body.style.overflow='hidden';
}
function closeOverlay(){
  document.getElementById('overlay').classList.remove('open');
  document.body.style.overflow='';
}
function handleOvClick(e){
  if (e.target===e.currentTarget) closeOverlay();
}
// Swipe down to close
var tsY=0;
document.getElementById('mainSheet').addEventListener('touchstart',function(e){tsY=e.touches[0].clientY;},{passive:true});
document.getElementById('mainSheet').addEventListener('touchend',function(e){
  if(e.changedTouches[0].clientY-tsY>80&&document.getElementById('mainSheet').scrollTop===0) closeOverlay();
},{passive:true});

/* ════════════════════════════════════════
   SAVED DETAILS
════════════════════════════════════════ */
function saveMhUser(name, phone) {
  try {
    if (window.MhUser) MhUser.saveDetails({name:name,phone:phone});
    else localStorage.setItem('mh_user_details',JSON.stringify({name:name,phone:phone}));
  } catch(e){}
}
function prefillSaved(nameId, phoneId) {
  nameId  = nameId  || 'bk_name';
  phoneId = phoneId || 'bk_phone';
  var d = null;
  try {
    if (window.MhUser) d = MhUser.getDetails();
    else d = JSON.parse(localStorage.getItem('mh_user_details')||'null');
  } catch(e){}
  if (!d) return;
  var n = document.getElementById(nameId);
  var p = document.getElementById(phoneId);
  if (n && d.name  && !n.value) n.value = d.name;
  if (p && d.phone && !p.value) p.value = d.phone;
}

/* ════════════════════════════════════════
   UTILITIES
════════════════════════════════════════ */
function normWA(p) {
  var d = (p||'').replace(/\D/g,'');
  if (d.length===9)  return '254'+d;
  if (d.length===10 && d[0]==='0') return '254'+d.substring(1);
  if (d.length===12 && d.substring(0,3)==='254') return d;
  return d || '254700000000';
}
function esc(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function showToast(msg) {
  var t = document.getElementById('toast');
  t.innerHTML = msg; t.classList.add('show');
  setTimeout(function(){ t.classList.remove('show'); }, 2400);
}
</script>
</body>
</html>