<?php
require_once 'db.php';

try {
    $db = getDB();
    $stmt = $db->query('SELECT 1 AS ok');
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "✅ Connected! Result: " . htmlspecialchars((string)($row['ok'] ?? 'unknown'));
} catch (Exception $e) {
    echo "❌ Connection failed: " . htmlspecialchars($e->getMessage());
}

