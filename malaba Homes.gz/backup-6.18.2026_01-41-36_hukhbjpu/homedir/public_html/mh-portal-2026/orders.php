<?php
require_once 'auth.php';
require_once 'db.php';

// Load SMS helper if available
$smsHelperPath = __DIR__ . '/sms.php';
if (file_exists($smsHelperPath)) require_once $smsHelperPath;

$db  = getDB();
$msg = ''; $msgType = '';

// ── Handle POST actions ─────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Update order status
    if ($action === 'update_status') {
        $oid       = (int)$_POST['order_id'];
        $status    = $_POST['status'] ?? '';
        $payStatus = $_POST['payment_status'] ?? '';
        $note      = trim($_POST['note'] ?? '');
        $sendSMS   = isset($_POST['send_sms']);
        $validStatus = ['pending','confirmed','processing','dispatched','delivered','cancelled'];
        $validPay    = ['pending','received','failed','refunded'];

        if (in_array($status, $validStatus) && in_array($payStatus, $validPay)) {
            $delivered_at = ($status === 'delivered') ? ', delivered_at = NOW()' : '';
            $db->prepare("UPDATE orders SET status=?, payment_status=?, handled_by=?$delivered_at WHERE id=?")
               ->execute([$status, $payStatus, $_SESSION['admin_id'], $oid]);

            // Auto-log status change (trigger handles it, but explicit insert for note)
            try {
                $db->prepare("INSERT INTO order_status_history (order_id, new_status, note, changed_by) VALUES (?,?,?,?)")
                   ->execute([$oid, $status, $note ?: null, $_SESSION['admin_id']]);
            } catch (Throwable $_) {}

            // Send SMS if requested and helper exists
            if ($sendSMS && function_exists('smsOrderStatus')) {
                $orderRow = $db->prepare("SELECT * FROM orders WHERE id=?")->execute([$oid])
                           ? $db->query("SELECT * FROM orders WHERE id=$oid")->fetch()
                           : [];
                if ($orderRow) smsOrderStatus($orderRow, $status);
            }

            $msg = 'Order updated' . ($sendSMS && function_exists('smsOrderStatus') ? ' + SMS sent' : '');
            $msgType = 'success';
        }
    }

    // Mark WhatsApp sent
    if ($action === 'mark_wa_sent') {
        $oid    = (int)$_POST['order_id'];
        $wa_msg = trim($_POST['wa_message'] ?? '');
        $db->prepare("UPDATE orders SET wa_notified=1, wa_last_msg=?, wa_sent_at=NOW() WHERE id=?")
           ->execute([$wa_msg ?: null, $oid]);
        $msg = 'WhatsApp notification recorded'; $msgType = 'success';
    }

    // Create new order manually
    if ($action === 'create_order') {
        $cat = $_POST['category'] ?? 'items';
        $lid = trim($_POST['listing_id'] ?? '');
        $listing = null;
        if ($lid) {
            $ls = $db->prepare("SELECT title, price FROM listings WHERE id=?");
            $ls->execute([$lid]); $listing = $ls->fetch();
        }
        $amount = (float)preg_replace('/[^0-9.]/','',str_replace(',','',$_POST['total_amount']??'0'));
        $maxId  = (int)$db->query("SELECT COALESCE(MAX(id),0) FROM orders")->fetchColumn();
        $ref    = 'MH-'.date('Y').'-'.str_pad($maxId+1,4,'0',STR_PAD_LEFT);

        $db->prepare("INSERT INTO orders (order_ref,category,listing_id,listing_title,listing_price,customer_name,customer_phone,customer_address,customer_id_no,quantity,total_amount,payment_method,notes,status,payment_status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'pending','pending')")
           ->execute([
               $ref, $cat, $lid ?: null,
               $listing['title'] ?? ($_POST['listing_title'] ?? ''),
               $listing['price'] ?? ($_POST['listing_price'] ?? ''),
               trim($_POST['customer_name'] ?? ''),
               trim($_POST['customer_phone'] ?? ''),
               trim($_POST['customer_address'] ?? ''),
               trim($_POST['customer_id_no'] ?? ''),
               max(1,(int)($_POST['quantity']??1)),
               $amount,
               $_POST['payment_method'] ?? 'cash',
               trim($_POST['notes'] ?? ''),
           ]);

        // Optional: SMS confirmation to new order
        if (function_exists('smsOrderConfirmation')) {
            $newOrder = $db->query("SELECT * FROM orders WHERE order_ref='$ref' LIMIT 1")->fetch();
            if ($newOrder) smsOrderConfirmation($newOrder);
        }

        $msg = "Order $ref created"; $msgType = 'success';
    }
}

// ── Filters ────────────────────────────────────────────────
$filterCat    = $_GET['cat']    ?? '';
$filterStatus = $_GET['status'] ?? '';
$filterPay    = $_GET['pay']    ?? '';
$search       = trim($_GET['q'] ?? '');
$page         = max(1,(int)($_GET['p'] ?? 1));
$limit        = 25;
$offset       = ($page-1)*$limit;

$where  = ['1=1'];
$params = [];
if ($filterCat)    { $where[] = 'o.category = ?';       $params[] = $filterCat; }
if ($filterStatus) { $where[] = 'o.status = ?';          $params[] = $filterStatus; }
if ($filterPay)    { $where[] = 'o.payment_status = ?';  $params[] = $filterPay; }
if ($search) {
    $where[] = '(o.customer_name LIKE ? OR o.customer_phone LIKE ? OR o.order_ref LIKE ? OR o.listing_title LIKE ?)';
    $s = "%$search%"; $params = array_merge($params, [$s,$s,$s,$s]);
}
$whereSQL = implode(' AND ', $where);

$cntStmt = $db->prepare("SELECT COUNT(*) FROM orders o WHERE $whereSQL");
$cntStmt->execute($params); $total = (int)$cntStmt->fetchColumn();
$pages = max(1,(int)ceil($total/$limit));

$stmt = $db->prepare("
    SELECT o.*, c.icon AS cat_icon, c.name AS cat_name
    FROM orders o
    LEFT JOIN categories c ON c.slug = o.category
    WHERE $whereSQL
    ORDER BY o.created_at DESC
    LIMIT $limit OFFSET $offset
");
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Summary counts
$summary    = $db->query("SELECT status, COUNT(*) AS n FROM orders GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
$paySummary = $db->query("SELECT payment_status, COUNT(*) AS n FROM orders GROUP BY payment_status")->fetchAll(PDO::FETCH_KEY_PAIR);

// Today stats
$today = $db->query("
    SELECT COUNT(*) AS orders,
           SUM(CASE WHEN payment_status='received' THEN total_amount ELSE 0 END) AS revenue
    FROM orders WHERE DATE(created_at) = CURDATE()
")->fetch();

// All active listings for create-order dropdown
$allListings = $db->query("
    SELECT l.id, l.title, l.price, c.slug AS cat
    FROM listings l JOIN categories c ON c.id=l.category_id
    WHERE l.is_active=1 ORDER BY c.id, l.title
")->fetchAll();

$smsAvailable = function_exists('smsOrderStatus');

function statusColor(string $s): string {
    return match($s) {
        'pending'    => 'orange', 'confirmed'  => 'blue',
        'processing' => 'purple', 'dispatched' => 'teal',
        'delivered'  => 'green',  'cancelled'  => 'red',
        default      => 'gray',
    };
}
function payColor(string $s): string {
    return match($s) {
        'received' => 'green', 'pending' => 'orange',
        'failed'   => 'red',   'refunded' => 'blue',
        default    => 'gray',
    };
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Orders — Malaba Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
<?php include 'admin.css.php'; ?>

:root {
  --orange:#f59e0b; --teal:#0d9488; --purple2:#8b5cf6;
}
.status-badge {
  display:inline-flex;align-items:center;gap:5px;
  padding:4px 10px;border-radius:20px;font-size:11px;font-weight:700;
  text-transform:uppercase;letter-spacing:.4px;white-space:nowrap;
}
.sb-pending    {background:rgba(245,158,11,.15);color:#f59e0b;}
.sb-confirmed  {background:rgba(9,132,227,.15);color:#74b9ff;}
.sb-processing {background:rgba(139,92,246,.15);color:#a78bfa;}
.sb-dispatched {background:rgba(13,148,136,.15);color:#2dd4bf;}
.sb-delivered  {background:rgba(0,184,148,.15);color:var(--green);}
.sb-cancelled  {background:rgba(214,48,49,.15);color:#ff7675;}
.sb-received   {background:rgba(0,184,148,.15);color:var(--green);}
.sb-failed     {background:rgba(214,48,49,.15);color:#ff7675;}
.sb-refunded   {background:rgba(9,132,227,.15);color:#74b9ff;}
.sb-gray       {background:rgba(255,255,255,.06);color:var(--muted);}

/* Today strip */
.today-strip {
  display:flex;gap:12px;flex-wrap:wrap;margin-bottom:20px;
  background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px 20px;
  align-items:center;
}
.ts-item { display:flex;flex-direction:column;gap:2px; }
.ts-val  { font-size:22px;font-weight:800;color:#fff;letter-spacing:-0.5px; }
.ts-lbl  { font-size:11px;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:.5px; }
.ts-divider { width:1px;height:36px;background:var(--border);margin:0 4px; }

/* Summary strip */
.sum-strip { display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px; }
.sum-chip {
  display:flex;align-items:center;gap:7px;
  padding:9px 14px;background:var(--surface);
  border:1px solid var(--border);border-radius:10px;font-size:13px;
  text-decoration:none;color:var(--text);transition:border-color .2s;
}
.sum-chip:hover { border-color:var(--border2); }
.sum-chip strong { font-size:17px;font-weight:800;color:#fff; }
.sum-chip span   { color:var(--muted); }

/* Filter bar */
.filter-bar { display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px;align-items:center; }
.filter-bar input,.filter-bar select {
  padding:9px 14px;background:var(--surface);border:1px solid var(--border);
  border-radius:9px;color:var(--text);font-family:inherit;font-size:13px;outline:none;
}
.filter-bar input:focus,.filter-bar select:focus { border-color:var(--purple); }
.filter-bar select option { background:var(--surface); }

/* Table extras */
.order-ref  { font-size:11px;font-weight:700;color:var(--muted);letter-spacing:.5px; }
.order-meta { font-size:12px;color:var(--muted);margin-top:2px; }
.wa-sent    { font-size:11px;color:var(--green);display:flex;align-items:center;gap:3px; }
.wa-pending { font-size:11px;color:var(--muted); }
.track-link { font-size:11px;color:var(--purple);text-decoration:none; }
.track-link:hover { text-decoration:underline; }

/* Action buttons */
.td-actions { display:flex;gap:5px;align-items:center;flex-wrap:wrap; }
.act-select {
  padding:5px 9px;background:var(--surface);border:1px solid var(--border);
  border-radius:7px;color:var(--text);font-family:inherit;font-size:11px;outline:none;
}

/* SMS badge */
.sms-tag { font-size:10px;font-weight:700;padding:2px 7px;border-radius:8px;background:rgba(72,149,239,.15);color:#74b9ff; }

/* Modal */
.modal-overlay {
  position:fixed;inset:0;z-index:900;background:rgba(0,0,0,.72);
  backdrop-filter:blur(4px);display:none;align-items:center;justify-content:center;padding:20px;
}
.modal-overlay.open { display:flex; }
.modal {
  background:var(--surface);border:1px solid var(--border);border-radius:20px;
  padding:30px;max-width:560px;width:100%;max-height:92vh;overflow-y:auto;
  box-shadow:0 32px 80px rgba(0,0,0,.5);
}
.modal h2 { font-size:20px;font-weight:800;color:#fff;margin-bottom:4px; }
.modal .modal-sub { font-size:13px;color:var(--muted);margin-bottom:20px; }
.modal .form-group { margin-bottom:14px; }
.modal label { display:block;font-size:11px;font-weight:700;color:#aaa;margin-bottom:6px;letter-spacing:.3px;text-transform:uppercase; }
.modal input,.modal select,.modal textarea {
  width:100%;padding:11px 14px;background:#0f0f14;border:1px solid rgba(255,255,255,.1);
  border-radius:9px;color:#fff;font-size:14px;font-family:inherit;outline:none;transition:border-color .2s;
}
.modal input:focus,.modal select:focus,.modal textarea:focus { border-color:var(--purple); }
.modal textarea { resize:vertical;min-height:80px; }
.modal select option { background:#1a1a24; }
.modal-btns { display:flex;gap:10px;margin-top:18px;flex-wrap:wrap; }
.modal-btns .btn { flex:1;justify-content:center; }
.close-modal { float:right;background:none;border:none;color:var(--muted);font-size:20px;cursor:pointer;margin-top:-6px; }

/* SMS toggle in modal */
.sms-row {
  display:flex;align-items:center;gap:10px;padding:12px 14px;
  background:rgba(72,149,239,.08);border:1px solid rgba(72,149,239,.2);border-radius:10px;
  margin-top:6px;cursor:pointer;
}
.sms-row input[type=checkbox] { accent-color:#4895EF;width:16px;height:16px;cursor:pointer; }
.sms-row-label { font-size:13px;font-weight:600;color:#74b9ff; }
.sms-row-sub { font-size:11px;color:var(--muted); }

/* WhatsApp preview */
.wa-preview {
  background:#075e54;border-radius:12px;padding:16px;margin:12px 0;
  font-size:13px;color:#fff;line-height:1.55;white-space:pre-wrap;word-break:break-word;
}
.wa-preview strong { color:#25d366; }

/* Pagination */
.pagination { display:flex;gap:6px;margin-top:20px;flex-wrap:wrap; }
.page-btn {
  padding:7px 13px;background:var(--surface);border:1px solid var(--border);
  border-radius:8px;font-size:13px;color:var(--muted);text-decoration:none;transition:all .15s;
}
.page-btn.active,.page-btn:hover { background:var(--purple);color:#fff;border-color:var(--purple); }
</style>
</head>
<body>
<?php include 'nav.php'; ?>

<main class="main">
  <div class="page-header">
    <div>
      <h1 class="page-title">📦 Orders</h1>
      <p class="page-sub">Track, manage and notify customers</p>
    </div>
    <div style="display:flex;gap:8px;">
      <a href="../track_order.php" class="btn btn-secondary" target="_blank">🔍 Track Page</a>
      <button class="btn btn-primary" onclick="document.getElementById('createOrderModal').classList.add('open')">+ New Order</button>
    </div>
  </div>

  <?php if ($msg): ?>
  <div class="alert alert-<?= $msgType === 'success' ? 'success' : 'error' ?>" style="margin-bottom:18px;">
    <?= htmlspecialchars($msg) ?>
  </div>
  <?php endif; ?>

  <!-- Today strip -->
  <div class="today-strip">
    <div class="ts-item"><div class="ts-val"><?= $today['orders'] ?? 0 ?></div><div class="ts-lbl">Today's Orders</div></div>
    <div class="ts-divider"></div>
    <div class="ts-item"><div class="ts-val">KSH <?= number_format((float)($today['revenue']??0),0) ?></div><div class="ts-lbl">Today's Revenue</div></div>
    <div class="ts-divider"></div>
    <div class="ts-item"><div class="ts-val"><?= $summary['pending'] ?? 0 ?></div><div class="ts-lbl">Pending Now</div></div>
    <div class="ts-divider"></div>
    <div class="ts-item"><div class="ts-val"><?= $summary['dispatched'] ?? 0 ?></div><div class="ts-lbl">En Route</div></div>
    <?php if ($smsAvailable): ?>
    <div class="ts-divider"></div>
    <div class="ts-item"><div class="ts-val" style="color:#4895EF;">ON</div><div class="ts-lbl">SMS Active</div></div>
    <?php endif; ?>
  </div>

  <!-- Summary chips -->
  <div class="sum-strip">
    <?php foreach (['pending'=>'Pending','confirmed'=>'Confirmed','processing'=>'Preparing','dispatched'=>'Dispatched','delivered'=>'Delivered','cancelled'=>'Cancelled'] as $k=>$lbl): ?>
    <a href="?status=<?= $k ?>" class="sum-chip">
      <strong><?= $summary[$k] ?? 0 ?></strong>
      <span><?= $lbl ?></span>
      <span class="status-badge sb-<?= $k ?>">&nbsp;</span>
    </a>
    <?php endforeach; ?>
    <a href="?pay=pending" class="sum-chip"><strong><?= $paySummary['pending'] ?? 0 ?></strong><span>💳 Payment Due</span></a>
    <a href="?pay=received" class="sum-chip"><strong><?= $paySummary['received'] ?? 0 ?></strong><span>✅ Paid</span></a>
  </div>

  <!-- Filters -->
  <form method="GET" class="filter-bar">
    <input type="text" name="q" placeholder="🔍 Search ref, name, phone…" value="<?= htmlspecialchars($search) ?>">
    <select name="cat" onchange="this.form.submit()">
      <option value="">All Categories</option>
      <option value="houses" <?= $filterCat==='houses'?'selected':'' ?>>🏠 Homes</option>
      <option value="food"   <?= $filterCat==='food'  ?'selected':'' ?>>🍔 Food</option>
      <option value="items"  <?= $filterCat==='items' ?'selected':'' ?>>🛋️ Shop</option>
    </select>
    <select name="status" onchange="this.form.submit()">
      <option value="">All Statuses</option>
      <?php foreach (['pending','confirmed','processing','dispatched','delivered','cancelled'] as $s): ?>
      <option value="<?= $s ?>" <?= $filterStatus===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="pay" onchange="this.form.submit()">
      <option value="">All Payments</option>
      <option value="pending"  <?= $filterPay==='pending' ?'selected':'' ?>>Pending</option>
      <option value="received" <?= $filterPay==='received'?'selected':'' ?>>Received</option>
      <option value="failed"   <?= $filterPay==='failed'  ?'selected':'' ?>>Failed</option>
    </select>
    <button type="submit" class="btn btn-secondary">Search</button>
    <?php if ($filterCat||$filterStatus||$filterPay||$search): ?>
    <a href="orders.php" class="btn btn-secondary">✕ Clear</a>
    <?php endif; ?>
  </form>

  <p style="font-size:13px;color:var(--muted);margin-bottom:14px;">
    Showing <?= count($orders) ?> of <?= $total ?> orders
  </p>

  <!-- Orders Table -->
  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr>
          <th>Order</th>
          <th>Customer</th>
          <th>Category</th>
          <th>Amount</th>
          <th>Status</th>
          <th>Payment</th>
          <th>Notify</th>
          <th>Date</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$orders): ?>
        <tr><td colspan="9" style="text-align:center;color:var(--muted);padding:40px;">No orders found.</td></tr>
      <?php endif; ?>
      <?php foreach ($orders as $o): ?>
      <tr>
        <td>
          <div style="font-weight:700;color:#fff;font-size:14px;"><?= htmlspecialchars(mb_strimwidth($o['listing_title'] ?? 'Manual Order', 0, 32, '…')) ?></div>
          <div class="order-ref"><?= htmlspecialchars($o['order_ref']) ?></div>
          <a href="../track_order.php?ref=<?= urlencode($o['order_ref']) ?>" class="track-link" target="_blank">🔗 Track</a>
        </td>
        <td>
          <div style="font-weight:600;font-size:13px;"><?= htmlspecialchars($o['customer_name']) ?></div>
          <div class="order-meta"><?= htmlspecialchars($o['customer_phone']) ?></div>
          <?php if ($o['customer_address']): ?>
          <div class="order-meta">📍 <?= htmlspecialchars(mb_strimwidth($o['customer_address'],0,28,'…')) ?></div>
          <?php endif; ?>
        </td>
        <td>
          <span class="badge <?= match($o['category']){'houses'=>'purple','food'=>'pink',default=>'green'} ?>">
            <?= $o['cat_icon'] ?? '' ?> <?= ucfirst($o['category']) ?>
          </span>
        </td>
        <td>
          <?php if ($o['total_amount'] > 0): ?>
          <div style="font-weight:700;color:var(--green);font-size:14px;">KSH <?= number_format($o['total_amount'],0) ?></div>
          <?php else: ?>
          <div style="color:var(--muted);font-size:13px;"><?= htmlspecialchars($o['listing_price'] ?? '—') ?></div>
          <?php endif; ?>
          <div class="order-meta"><?= ucfirst(str_replace('_',' ',$o['payment_method'])) ?></div>
        </td>
        <td><span class="status-badge sb-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
        <td><span class="status-badge sb-<?= $o['payment_status'] ?>"><?= ucfirst($o['payment_status']) ?></span></td>
        <td>
          <?php if ($o['wa_notified']): ?>
            <div class="wa-sent">✅ WA Sent</div>
            <?php if ($o['wa_sent_at']): ?><div class="order-meta"><?= date('d M H:i',strtotime($o['wa_sent_at'])) ?></div><?php endif; ?>
          <?php else: ?>
            <div class="wa-pending">⏳ Not sent</div>
          <?php endif; ?>
        </td>
        <td class="td-date"><?= date('d M Y', strtotime($o['created_at'])) ?><br><span style="font-size:11px;color:var(--muted);"><?= date('H:i', strtotime($o['created_at'])) ?></span></td>
        <td class="td-actions">
          <button class="act-btn edit" onclick="openUpdateModal(<?= htmlspecialchars(json_encode($o)) ?>)">Update</button>
          <button class="act-btn edit" style="background:rgba(37,211,102,.1);color:#25D366;" onclick="openWAModal(<?= htmlspecialchars(json_encode($o)) ?>)">💬 WA</button>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($pages > 1): ?>
  <div class="pagination">
    <?php if ($page > 1): ?>
    <a href="?<?= http_build_query(array_merge($_GET,['p'=>$page-1])) ?>" class="page-btn">← Prev</a>
    <?php endif; ?>
    <?php
    $start = max(1, $page-2); $end = min($pages, $page+2);
    if ($start > 1) echo '<span class="page-btn" style="cursor:default;">…</span>';
    for ($i=$start;$i<=$end;$i++):
    ?>
    <a href="?<?= http_build_query(array_merge($_GET,['p'=>$i])) ?>" class="page-btn <?= $i===$page?'active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($end < $pages) echo '<span class="page-btn" style="cursor:default;">…</span>'; ?>
    <?php if ($page < $pages): ?>
    <a href="?<?= http_build_query(array_merge($_GET,['p'=>$page+1])) ?>" class="page-btn">Next →</a>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</main>

<!-- ══ UPDATE STATUS MODAL ══ -->
<div class="modal-overlay" id="updateModal">
  <div class="modal">
    <button class="close-modal" onclick="closeModal('updateModal')">✕</button>
    <h2>Update Order</h2>
    <p class="modal-sub" id="updateModalSub">Change status and notify customer</p>
    <form method="POST">
      <input type="hidden" name="action" value="update_status">
      <input type="hidden" name="order_id" id="upd_id">
      <div class="form-group">
        <label>Order Status</label>
        <select name="status" id="upd_status" onchange="updateSMSLabel()">
          <option value="pending">📋 Pending — Received</option>
          <option value="confirmed">✅ Confirmed</option>
          <option value="processing">🔄 Processing / Preparing</option>
          <option value="dispatched">🚚 Dispatched — On the Way</option>
          <option value="delivered">🎉 Delivered</option>
          <option value="cancelled">❌ Cancelled</option>
        </select>
      </div>
      <div class="form-group">
        <label>Payment Status</label>
        <select name="payment_status" id="upd_pay">
          <option value="pending">⏳ Pending</option>
          <option value="received">✅ Received</option>
          <option value="failed">❌ Failed</option>
          <option value="refunded">↩️ Refunded</option>
        </select>
      </div>
      <div class="form-group">
        <label>Internal Note (optional)</label>
        <textarea name="note" placeholder="e.g. Paid via M-Pesa, customer requested delay…"></textarea>
      </div>
      <?php if ($smsAvailable): ?>
      <label class="sms-row">
        <input type="checkbox" name="send_sms" id="smsCheckbox" checked>
        <div>
          <div class="sms-row-label">📱 Send SMS to customer</div>
          <div class="sms-row-sub" id="smsPreviewLabel">Customer will be notified of the new status</div>
        </div>
      </label>
      <?php endif; ?>
      <div class="modal-btns">
        <button type="submit" class="btn btn-primary">💾 Save Changes</button>
        <button type="button" class="btn btn-secondary" onclick="closeModal('updateModal')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- ══ WHATSAPP MODAL ══ -->
<div class="modal-overlay" id="waModal">
  <div class="modal">
    <button class="close-modal" onclick="closeModal('waModal')">✕</button>
    <h2>💬 Send WhatsApp Update</h2>
    <p class="modal-sub">Personalised message ready to send</p>
    <div class="form-group">
      <label>Customer Phone</label>
      <input type="tel" id="wa_phone_display" readonly style="background:#0a0a0f;opacity:.8;">
    </div>
    <div class="form-group">
      <label>Message (editable)</label>
      <textarea id="wa_message_text" style="min-height:130px;" oninput="updateWAPreview()"></textarea>
    </div>
    <div class="wa-preview" id="wa_preview">Preview…</div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      <a id="wa_open_link" href="#" target="_blank" class="btn btn-primary"
         style="flex:1;justify-content:center;background:#25D366;border-color:#25D366;text-decoration:none;"
         onclick="markWASent()">
        📲 Open WhatsApp
      </a>
      <button class="btn btn-secondary" onclick="closeModal('waModal')">Cancel</button>
    </div>
    <form method="POST" id="waForm" style="display:none;">
      <input type="hidden" name="action" value="mark_wa_sent">
      <input type="hidden" name="order_id" id="wa_order_id">
      <input type="hidden" name="wa_message" id="wa_message_hidden">
    </form>
  </div>
</div>

<!-- ══ CREATE ORDER MODAL ══ -->
<div class="modal-overlay" id="createOrderModal">
  <div class="modal" style="max-width:620px;">
    <button class="close-modal" onclick="closeModal('createOrderModal')">✕</button>
    <h2>➕ Create New Order</h2>
    <p class="modal-sub">Manually add an order from a phone or walk-in customer</p>
    <form method="POST">
      <input type="hidden" name="action" value="create_order">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div class="form-group">
          <label>Category *</label>
          <select name="category" id="newOrderCat" onchange="filterListings()">
            <option value="houses">🏠 Homes</option>
            <option value="food">🍔 Food</option>
            <option value="items">🛋️ Shop</option>
          </select>
        </div>
        <div class="form-group">
          <label>Listing / Product</label>
          <select name="listing_id" id="newOrderListing">
            <option value="">— Select listing —</option>
            <?php foreach ($allListings as $ll): ?>
            <option value="<?= $ll['id'] ?>" data-cat="<?= $ll['cat'] ?>" data-price="<?= htmlspecialchars($ll['price']) ?>">
              <?= htmlspecialchars($ll['title']) ?> — <?= htmlspecialchars($ll['price']) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Customer Name *</label>
          <input type="text" name="customer_name" placeholder="Full name" required>
        </div>
        <div class="form-group">
          <label>Customer Phone *</label>
          <input type="tel" name="customer_phone" placeholder="0712 345 678" required>
        </div>
        <div class="form-group" style="grid-column:1/-1;">
          <label>Delivery Address</label>
          <input type="text" name="customer_address" placeholder="e.g. Near Malaba Market, Gate 3">
        </div>
        <div class="form-group" id="idField">
          <label>ID Number (Homes only)</label>
          <input type="text" name="customer_id_no" placeholder="National ID">
        </div>
        <div class="form-group">
          <label>Quantity</label>
          <input type="number" name="quantity" value="1" min="1">
        </div>
        <div class="form-group">
          <label>Total Amount (KSH)</label>
          <input type="text" name="total_amount" id="newOrderAmount" placeholder="0">
        </div>
        <div class="form-group">
          <label>Payment Method</label>
          <select name="payment_method">
            <option value="cash">Cash on Delivery</option>
            <option value="mpesa">M-Pesa</option>
            <option value="cash_on_delivery">Cash on Move-in</option>
            <option value="mpesa_on_delivery">M-Pesa on Delivery</option>
          </select>
        </div>
        <div class="form-group" style="grid-column:1/-1;">
          <label>Notes</label>
          <textarea name="notes" placeholder="Any special instructions…"></textarea>
        </div>
      </div>
      <div class="modal-btns">
        <button type="submit" class="btn btn-primary">Create Order</button>
        <button type="button" class="btn btn-secondary" onclick="closeModal('createOrderModal')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
/* ── Modal helpers ── */
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.modal-overlay').forEach(ov => {
  ov.addEventListener('click', e => { if (e.target === ov) ov.classList.remove('open'); });
});

/* ── WA Templates ── */
const waT = {
  pending:    o => `Hello ${o.customer_name}! 📋 Your order *${o.listing_title||'your order'}* (${o.order_ref}) has been received and is pending confirmation. We'll be in touch shortly!`,
  confirmed:  o => `Hello ${o.customer_name}! ✅ Your order *${o.listing_title||'your order'}* (${o.order_ref}) is *confirmed*. We're getting it ready. Total: ${o.listing_price||'KSH '+Number(o.total_amount).toLocaleString()}. Thank you for choosing Malaba Homes!`,
  processing: o => `Hello ${o.customer_name}! 🔄 Your order *${o.listing_title||'your order'}* (${o.order_ref}) is now being *prepared*. We'll update you very soon!`,
  dispatched: o => `Hello ${o.customer_name}! 🚚 Great news — your order *${o.listing_title||'your order'}* (${o.order_ref}) is *on its way*! Please be ready to receive it. Payment: ${o.listing_price||'KSH '+Number(o.total_amount).toLocaleString()}.`,
  delivered:  o => `Hello ${o.customer_name}! 🎉 Your order *${o.listing_title||'your order'}* (${o.order_ref}) has been *delivered*. Enjoy! Please make payment of ${o.listing_price||'KSH '+Number(o.total_amount).toLocaleString()}. Thank you! 🏡`,
  cancelled:  o => `Hello ${o.customer_name}, we're sorry — your order *${o.listing_title||'your order'}* (${o.order_ref}) has been *cancelled*. Please contact us for assistance.`,
};

/* ── SMS label hints ── */
const smsHints = {
  pending:    'Customer will be told their order was received',
  confirmed:  'Customer will be told order is confirmed ✅',
  processing: 'Customer will be told order is being prepared 🔄',
  dispatched: 'Customer will be told order is on the way 🚚',
  delivered:  'Customer will be told order is delivered 🎉',
  cancelled:  'Customer will be told order was cancelled ❌',
};
function updateSMSLabel() {
  const v = document.getElementById('upd_status')?.value;
  const lbl = document.getElementById('smsPreviewLabel');
  if (lbl && v) lbl.textContent = smsHints[v] || 'Customer will be notified';
}

/* ── Update modal ── */
function openUpdateModal(o) {
  document.getElementById('upd_id').value     = o.id;
  document.getElementById('upd_status').value = o.status;
  document.getElementById('upd_pay').value    = o.payment_status;
  document.getElementById('updateModalSub').textContent = `${o.order_ref} — ${o.customer_name}`;
  updateSMSLabel();
  document.getElementById('updateModal').classList.add('open');
}

/* ── WA modal ── */
let _curWA = null;
function openWAModal(o) {
  _curWA = o;
  const tpl = (waT[o.status] || waT.pending)(o);
  let phone = (o.customer_phone||'').replace(/\D/g,'');
  if (!phone.startsWith('254')) phone = phone.startsWith('0') ? '254'+phone.slice(1) : '254'+phone;

  document.getElementById('wa_order_id').value      = o.id;
  document.getElementById('wa_phone_display').value = o.customer_phone;
  document.getElementById('wa_message_text').value  = tpl;
  document.getElementById('wa_open_link').href      = `https://wa.me/${phone}?text=${encodeURIComponent(tpl)}`;
  updateWAPreview();
  document.getElementById('waModal').classList.add('open');
}
document.getElementById('wa_message_text').addEventListener('input', function() {
  updateWAPreview();
  if (!_curWA) return;
  let phone = (_curWA.customer_phone||'').replace(/\D/g,'');
  if (!phone.startsWith('254')) phone = phone.startsWith('0') ? '254'+phone.slice(1) : '254'+phone;
  document.getElementById('wa_open_link').href = `https://wa.me/${phone}?text=${encodeURIComponent(this.value)}`;
});
function updateWAPreview() {
  const html = (document.getElementById('wa_message_text').value||'')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/\*(.*?)\*/g,'<strong>$1</strong>')
    .replace(/\n/g,'<br>');
  document.getElementById('wa_preview').innerHTML = html;
}
function markWASent() {
  document.getElementById('wa_message_hidden').value = document.getElementById('wa_message_text').value;
  setTimeout(() => document.getElementById('waForm').submit(), 600);
}

/* ── Create order listing filter ── */
function filterListings() {
  const cat = document.getElementById('newOrderCat').value;
  const sel = document.getElementById('newOrderListing');
  Array.from(sel.options).forEach(opt => {
    if (!opt.value) { opt.style.display=''; return; }
    opt.style.display = opt.dataset.cat === cat ? '' : 'none';
  });
  sel.value = '';
  document.getElementById('idField').style.display = cat === 'houses' ? '' : 'none';
}
document.getElementById('newOrderListing').addEventListener('change', function() {
  const price = this.options[this.selectedIndex]?.dataset.price || '';
  document.getElementById('newOrderAmount').value = price.replace(/[^0-9]/g,'');
});
filterListings();
</script>
</body>
</html>
