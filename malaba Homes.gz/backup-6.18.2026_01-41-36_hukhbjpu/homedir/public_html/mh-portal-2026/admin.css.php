/* admin/admin.css.php — shared styles for all admin pages */
:root {
    --bg:      #0f0f14;
    --surface: #18181f;
    --border:  rgba(255,255,255,0.07);
    --text:    #f0f0f5;
    --muted:   #888;
    --purple:  #6C5CE7;
    --pink:    #FD79A8;
    --green:   #00B894;
    --blue:    #0984e3;
    --red:     #d63031;
    --nav-w:   220px;
}
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Plus Jakarta Sans',sans-serif; background:var(--bg); color:var(--text); display:flex; min-height:100vh; }

/* ── Nav ── */
.nav { width:var(--nav-w); background:var(--surface); border-right:1px solid var(--border); display:flex; flex-direction:column; padding:24px 0; position:fixed; height:100vh; overflow-y:auto; }
.nav-brand { display:flex; align-items:center; gap:10px; padding:0 20px 28px; border-bottom:1px solid var(--border); margin-bottom:16px; }
.nav-brand-icon { font-size:22px; }
.nav-brand-name { font-size:15px; font-weight:800; color:#fff; letter-spacing:-0.3px; }
.nav-section { font-size:10px; font-weight:700; color:var(--muted); letter-spacing:1.5px; padding:8px 20px 6px; text-transform:uppercase; }
.nav a { display:flex; align-items:center; gap:10px; padding:10px 20px; color:var(--muted); text-decoration:none; font-size:14px; font-weight:500; border-radius:0; transition:all .15s; }
.nav a:hover, .nav a.active { color:#fff; background:rgba(108,92,231,0.12); border-left:3px solid var(--purple); padding-left:17px; }
.nav a .nav-icon { font-size:16px; width:20px; text-align:center; }
.nav-logout { margin-top:auto; padding:16px 20px 0; border-top:1px solid var(--border); }
.nav-logout a { color:var(--red) !important; }
.nav-logout a:hover { background:rgba(214,48,49,0.1) !important; border-left-color:var(--red) !important; }

/* ── Main ── */
.main { margin-left:var(--nav-w); flex:1; padding:36px 40px; max-width:1200px; }
.page-header { display:flex; align-items:flex-start; justify-content:space-between; margin-bottom:32px; gap:16px; }
.page-title { font-size:28px; font-weight:800; color:#fff; letter-spacing:-0.5px; }
.page-sub { color:var(--muted); font-size:14px; margin-top:4px; }

/* ── Buttons ── */
.btn { display:inline-flex; align-items:center; gap:8px; padding:10px 20px; border-radius:10px; font-size:14px; font-weight:600; text-decoration:none; cursor:pointer; border:none; font-family:inherit; transition:all .15s; }
.btn-primary { background:var(--purple); color:#fff; }
.btn-primary:hover { opacity:.88; transform:translateY(-1px); }
.btn-secondary { background:var(--surface); color:var(--text); border:1px solid var(--border); }
.btn-secondary:hover { border-color:var(--purple); color:var(--purple); }
.btn-danger { background:var(--red); color:#fff; }

/* ── Stats ── */
.stats-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:16px; margin-bottom:36px; }
.stat-card { background:var(--surface); border:1px solid var(--border); border-radius:16px; padding:24px 20px; display:flex; flex-direction:column; gap:8px; }
.stat-card.purple { border-top:3px solid var(--purple); }
.stat-card.pink   { border-top:3px solid var(--pink); }
.stat-card.green  { border-top:3px solid var(--green); }
.stat-card.blue   { border-top:3px solid var(--blue); }
.stat-icon { font-size:24px; }
.stat-val  { font-size:32px; font-weight:800; color:#fff; line-height:1; }
.stat-label { font-size:13px; color:var(--muted); font-weight:500; }

/* ── Quick Links ── */
.quick-links { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:14px; }
.ql-card { display:flex; align-items:center; gap:12px; padding:18px 20px; background:var(--surface); border:1px solid var(--border); border-radius:14px; text-decoration:none; color:var(--text); font-weight:600; font-size:14px; transition:all .15s; }
.ql-card:hover { transform:translateY(-2px); box-shadow:0 8px 24px rgba(0,0,0,0.3); }
.ql-card.purple:hover { border-color:var(--purple); }
.ql-card.pink:hover   { border-color:var(--pink); }
.ql-card.green:hover  { border-color:var(--green); }
.ql-card.blue:hover   { border-color:var(--blue); }
.ql-icon  { font-size:20px; }
.ql-label { flex:1; }
.ql-arrow { color:var(--muted); }

/* ── Section title ── */
.section-title { font-size:15px; font-weight:700; color:var(--muted); letter-spacing:0.5px; margin-bottom:14px; }

/* ── Table ── */
.table-wrap { background:var(--surface); border:1px solid var(--border); border-radius:16px; overflow:hidden; }
.table { width:100%; border-collapse:collapse; font-size:14px; }
.table th { text-align:left; padding:14px 20px; font-size:11px; font-weight:700; color:var(--muted); text-transform:uppercase; letter-spacing:0.8px; border-bottom:1px solid var(--border); }
.table td { padding:14px 20px; border-bottom:1px solid var(--border); vertical-align:middle; }
.table tr:last-child td { border-bottom:none; }
.table tr:hover td { background:rgba(255,255,255,0.02); }
.td-title { font-weight:600; color:#fff; max-width:220px; }
.td-price { font-weight:700; color:var(--purple); }
.td-date  { color:var(--muted); font-size:13px; }
.td-actions { display:flex; gap:8px; }
.act-btn { padding:5px 12px; border-radius:7px; font-size:12px; font-weight:600; text-decoration:none; cursor:pointer; border:none; font-family:inherit; }
.act-btn.edit { background:rgba(108,92,231,0.15); color:var(--purple); }
.act-btn.edit:hover { background:var(--purple); color:#fff; }
.act-btn.del  { background:rgba(214,48,49,0.12); color:var(--red); }
.act-btn.del:hover  { background:var(--red); color:#fff; }

/* ── Badges ── */
.badge { display:inline-flex; align-items:center; gap:5px; padding:4px 10px; border-radius:20px; font-size:12px; font-weight:600; }
.badge.purple { background:rgba(108,92,231,0.15); color:#a29bfe; }
.badge.pink   { background:rgba(253,121,168,0.15); color:var(--pink); }
.badge.green  { background:rgba(0,184,148,0.15);   color:var(--green); }
.badge.blue   { background:rgba(9,132,227,0.15);   color:#74b9ff; }
.badge.gray   { background:rgba(255,255,255,0.06); color:var(--muted); }

/* ── Forms ── */
.form-card { background:var(--surface); border:1px solid var(--border); border-radius:16px; padding:32px; max-width:720px; }
.form-group { margin-bottom:22px; }
.form-group label { display:block; font-size:13px; font-weight:600; color:#aaa; margin-bottom:8px; letter-spacing:0.2px; }
.form-control { width:100%; padding:12px 16px; background:#0f0f14; border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#fff; font-size:14px; font-family:inherit; outline:none; transition:border-color .2s; }
.form-control:focus { border-color:var(--purple); }
textarea.form-control { resize:vertical; min-height:100px; }
select.form-control option { background:#1a1a24; }
.form-row { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
.form-hint { font-size:12px; color:var(--muted); margin-top:5px; }
.toggle-wrap { display:flex; align-items:center; gap:12px; }
input[type=checkbox].toggle { width:40px; height:22px; accent-color:var(--purple); cursor:pointer; }

/* ── Alerts ── */
.alert { padding:14px 18px; border-radius:10px; font-size:14px; margin-bottom:24px; }
.alert-success { background:rgba(0,184,148,0.12); border:1px solid rgba(0,184,148,0.25); color:var(--green); }
.alert-error   { background:rgba(214,48,49,0.12); border:1px solid rgba(214,48,49,0.25); color:#ff7675; }

/* ── Filter bar ── */
.filter-bar { display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap; align-items:center; }
.filter-bar input, .filter-bar select { padding:9px 14px; background:var(--surface); border:1px solid var(--border); border-radius:9px; color:var(--text); font-family:inherit; font-size:13px; outline:none; }
.filter-bar input:focus, .filter-bar select:focus { border-color:var(--purple); }

/* ── Responsive ── */
@media(max-width:768px) {
    .nav { display:none; }
    .main { margin-left:0; padding:20px; }
    .form-row { grid-template-columns:1fr; }
}
