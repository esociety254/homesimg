<?php
// admin/listing_delete.php - PHP 5.6 compatible
require_once 'auth.php';
require_once 'db.php';

$id = isset($_GET['id']) ? trim($_GET['id']) : null;
if (!$id) { header('Location: listings.php'); exit; }

$db = getDB();
$s  = $db->prepare("SELECT title FROM listings WHERE id = ?");
$s->execute(array($id));
$item = $s->fetch(PDO::FETCH_ASSOC);

if (!$item) { header('Location: listings.php'); exit; }

// Cascade deletes images and features via FK ON DELETE CASCADE
$db->prepare("DELETE FROM listings WHERE id = ?")->execute(array($id));

header('Location: listings.php?deleted=' . urlencode($item['title']));
exit;
