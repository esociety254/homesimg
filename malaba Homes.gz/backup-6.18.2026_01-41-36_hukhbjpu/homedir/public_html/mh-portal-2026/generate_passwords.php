<?php
/**
 * generate_passwords.php
 * =============================================
 * Run this ONCE in your browser:
 *   localhost/homes/admin/generate_passwords.php
 *
 * It will show you the correct SQL to paste into phpMyAdmin.
 * DELETE this file immediately after use.
 * =============================================
 */

// Change these to whatever passwords you want
$accounts = array(
    array('username'=>'Odiedo', 'password'=>'1436123.', 'name'=>'superadmin', 'role'=>'superadmin'),
    array('username'=>'listings', 'password'=>'listings123', 'name'=>'Listings Manager', 'role'=>'listings_manager'),
    array('username'=>'orders',   'password'=>'orders123',   'name'=>'Orders Manager',   'role'=>'orders_manager'),
    array('username'=>'social',   'password'=>'social123',   'name'=>'Social Manager',   'role'=>'social_manager'),
);

echo '<html><head><meta charset="UTF-8"><style>
body{font-family:monospace;background:#0f0f14;color:#f0f0f5;padding:30px;font-size:14px;}
.card{background:#18181f;border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:24px;max-width:900px;margin-bottom:20px;}
h2{color:#6C5CE7;margin-bottom:12px;}
pre{background:#0a0a0f;padding:16px;border-radius:8px;overflow-x:auto;color:#a0e9a0;line-height:1.6;}
.warn{color:#ff7675;background:rgba(214,48,49,.1);padding:12px 16px;border-radius:8px;margin-bottom:20px;border:1px solid rgba(214,48,49,.2);}
.label{color:#888;font-size:12px;margin-bottom:6px;}
</style></head><body>';

echo '<div class="card">';
echo '<h2>&#x1F511; Malaba Homes - Password Hash Generator</h2>';
echo '<div class="warn">&#x26A0;&#xFE0F; DELETE this file immediately after copying the SQL below!</div>';

// First run the migration to expand the enum
$migrationSQL = "
-- Step 1: Expand role enum (run this first)
ALTER TABLE \`admins\` MODIFY COLUMN \`role\`
  ENUM('superadmin','admin','listings_manager','orders_manager','social_manager')
  DEFAULT 'listings_manager';

-- Step 2: Add avatar and last_login if missing
ALTER TABLE \`admins\` ADD COLUMN IF NOT EXISTS \`avatar\` VARCHAR(10) DEFAULT NULL;
ALTER TABLE \`admins\` ADD COLUMN IF NOT EXISTS \`last_login\` TIMESTAMP NULL DEFAULT NULL;
";

echo '<div class="label">Step 1 — Run this SQL in phpMyAdmin first:</div>';
echo '<pre>' . htmlspecialchars(trim($migrationSQL)) . '</pre>';

echo '<div class="label">Step 2 — Then run this SQL to create/update staff accounts:</div>';

$insertSQL = "-- Insert staff accounts with correct password hashes\n";
foreach ($accounts as $a) {
    $hash = password_hash($a['password'], PASSWORD_BCRYPT);
    $insertSQL .= "INSERT INTO \`admins\` (\`username\`, \`password_hash\`, \`name\`, \`role\`) VALUES\n";
    $insertSQL .= "  ('" . $a['username'] . "', '" . $hash . "', '" . $a['name'] . "', '" . $a['role'] . "')\n";
    $insertSQL .= "  ON DUPLICATE KEY UPDATE password_hash='" . $hash . "', role='" . $a['role'] . "';\n\n";
}

echo '<pre>' . htmlspecialchars($insertSQL) . '</pre>';

echo '<div class="label">Step 3 — Login credentials (share with each girl privately):</div>';
echo '<pre>';
foreach ($accounts as $a) {
    echo "Role: " . $a['role'] . "\n";
    echo "  Username : " . $a['username'] . "\n";
    echo "  Password : " . $a['password'] . "\n";
    echo "  Login URL: localhost/homes/admin/login.php\n\n";
}
echo '</pre>';

echo '<div class="label">&#x2705; Hash verification:</div>';
echo '<pre>';
foreach ($accounts as $a) {
    $hash = password_hash($a['password'], PASSWORD_BCRYPT);
    $ok   = password_verify($a['password'], $hash);
    echo $a['username'] . ' / ' . $a['password'] . '  =>  ' . ($ok ? 'HASH OK' : 'HASH FAILED') . "\n";
}
echo '</pre>';

echo '</div></body></html>';