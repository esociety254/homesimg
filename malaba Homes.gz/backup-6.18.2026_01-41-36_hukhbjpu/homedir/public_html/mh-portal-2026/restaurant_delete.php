<?php
/**
 * admin/restaurant_delete.php
 */
require_once 'auth.php';
require_once 'db.php';
requirePerm('listings');

$id = isset($_GET['id']) ? trim($_GET['id']) : '';
if (!$id) { header('Location: restaurants.php'); exit; }

$db = getDB();
try {
    /* Get all listing IDs for this restaurant */
    $s = $db->prepare("SELECT id FROM listings WHERE restaurant_id=?");
    $s->execute(array($id));
    $listingIds = $s->fetchAll(PDO::FETCH_COLUMN);

    foreach ($listingIds as $lid) {
        $db->prepare("DELETE FROM listing_images   WHERE listing_id=?")->execute(array($lid));
        $db->prepare("DELETE FROM listing_features WHERE listing_id=?")->execute(array($lid));
    }
    if ($listingIds) {
        $ph = implode(',', array_fill(0, count($listingIds), '?'));
        $db->prepare("DELETE FROM listings WHERE id IN ($ph)")->execute($listingIds);
    }
    $db->prepare("DELETE FROM restaurant_images WHERE restaurant_id=?")->execute(array($id));
    $db->prepare("DELETE FROM restaurants WHERE id=?")->execute(array($id));
} catch (Exception $e) {}

header('Location: restaurants.php?deleted=1');
exit;
