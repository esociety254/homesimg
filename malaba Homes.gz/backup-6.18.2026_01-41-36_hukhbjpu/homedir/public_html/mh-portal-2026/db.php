<?php
// admin/db.php -- PHP 5.6 compatible (no return type hints)
define('DB_HOST', 'localhost');
define('DB_USER', 'hukhbjpu_odiedo');
define('DB_PASS', 'emuriaodeke1436123..');  
define('DB_NAME', 'hukhbjpu_mh_portal_2026');

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, array(
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ));
    }
    return $pdo;
}