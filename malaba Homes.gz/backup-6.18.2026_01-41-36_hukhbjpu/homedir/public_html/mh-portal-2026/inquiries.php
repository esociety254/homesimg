<?php
// admin/inquiries.php - PHP 5.6 compatible
require_once 'auth.php';
require_once 'db.php';

$db = getDB();

// Handle delete action
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $db->prepare("DELETE FROM inquiries WHERE id = ?")->execute(array((int)$_GET['delete']));
    header('Location: inquiries.php?deleted=1'); exit;
}

// Filters
$search   = trim(isset($_GET['q'])   ? $_GET['q']   : '');
$catF     = trim(isset($_GET['cat']) ? $_GET['cat'] : '');
$page     = max(1, (int)(isset($_GET['p']) ? $_GET['p'] : 1));
$limit    = 30;
$offset   = ($page - 1) * $limit;

$where  = array('1=1');
$params = array();

if ($search !== '') {
    $where[]  = '(i.user_name LIKE ? OR i.user_phone LIKE ? OR i.message LIKE ? OR l.title LIKE ?)';
    $s = '%' . $search . '%';
    $params[] = $s; $params[] = $s; $params[] = $s; $params[] = $s;
}
if ($catF !== '') {
    $where[] = 'c.slug = ?';
    $params[] = $catF;
}
$whereSQL = implode(' AND ', $where);

$cntStmt = $db->prepare("SELECT COUNT(*) FROM inquiries i LEFT JOIN listings l ON i.listing_id=l.id LEFT JOIN categories c ON l.category_id=c.id WHERE $whereSQL");
$cntStmt->execute($params);
$total = (int)$cntStmt->fetchColumn();
$pages = max(1, (int)ceil($total / $limit));

$stmt = $db->prepare("
    SELECT i.*, l.title AS listing_title, c.name AS cat_name, c.slug AS cat_slug, c.icon
    FROM inquiries i
    LEFT JOIN listings l ON i.listing_id = l.id
    LEFT JOIN categories c ON l.category_id = c.id
    WHERE $whereSQL
    ORDER BY i.created_at DESC
    LIMIT $limit OFFSET $offset
");
$stmt->execute($params);
$inquiries = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Today count
$todayCount = (int)$db->query("SELECT COUNT(*) FROM inquiries WHERE DATE(created_at)=CURDATE()")->fetchColumn();
$totalCount = (int)$db->query("SELECT COUNT(*) FROM inquiries")->fetchColumn();

function catBadgeCls($slug) {
    if ($slug === 'houses') return 'purple';
    if ($slug === 'food')   return 'pink';
    return 'green';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Inquiries &mdash; Malaba Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style><?php include 'admin.css.php'; ?>

/* Inquiry-specific extras */
.inq-strip {
    display:flex; gap:12px; flex-wrap:wrap; margin-bottom:24px;
}
.inq-chip {
    display:flex; align-items:center; gap:8px;
    padding:10px 18px; background:var(--surface);
    border:1px solid var(--border); border-radius:10px; font-size:13px;
}
.inq-chip strong { font-size:20px; font-weight:800; color:#fff; }

.filter-bar { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:20px; align-items:center; }
.filter-bar input, .filter-bar select {
    padding:9px 14px; background:var(--surface); border:1px solid var(--border);
    border-radius:9px; color:var(--text); font-family:inherit; font-size:13px; outline:none;
}
.filter-bar input:focus, .filter-bar select:focus { border-color:var(--purple); }
.filter-bar select option { background:var(--surface); }

.msg-cell { max-width:260px; font-size:12px; color:var(--muted); cursor:pointer; }
.msg-cell:hover { color:var(--text); }

.wa-link {
    display:inline-flex; align-items:center; gap:5px;
    padding:5px 10px; border-radius:7px;
    background:rgba(37,211,102,.12); color:#25D366;
    font-size:12px; font-weight:700; text-decoration:none;
    transition:all .2s;
}
.wa-link:hover { background:rgba(37,211,102,.22); }

.pagination { display:flex; gap:6px; margin-top:20px; flex-wrap:wrap; }
.page-btn {
    padding:7px 13px; background:var(--surface); border:1px solid var(--border);
    border-radius:8px; font-size:13px; color:var(--muted);
    text-decoration:none; transition:all .15s;
}
.page-btn.active, .page-btn:hover { background:var(--purple); color:#fff; border-color:var(--purple); }

/* Full message modal */
.msg-modal {
    position:fixed; inset:0; z-index:900;
    background:rgba(0,0,0,.75); backdrop-filter:blur(4px);
    display:none; align-items:center; justify-content:center; padding:20px;
}
.msg-modal.open { display:flex; }
.msg-box {
    background:var(--surface); border:1px solid var(--border);
    border-radius:18px; padding:28px; max-width:520px; width:100%;
    box-shadow:0 24px 60px rgba(0,0,0,.5);
}
.msg-box h3 { font-size:16px; font-weight:700; color:#fff; margin-bottom:16px; }
.msg-body { font-size:14px; color:var(--text); line-height:1.65; white-space:pre-wrap; word-break:break-word; }
.msg-close {
    margin-top:20px; padding:10px 20px;
    background:var(--surface); border:1px solid var(--border);
    border-radius:9px; color:var(--text); font-size:13px; font-weight:600;
    cursor:pointer; font-family:inherit;
}
</style>
</head>
<body>
<?php include 'nav.php'; ?>

<main class="main">
    <div class="page-header">
        <div>
            <h1 class="page-title">&#x1F4AC; Inquiries</h1>
            <p class="page-sub">Customer messages, questions and order notes</p>
        </div>
    </div>

    <?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success" style="margin-bottom:18px;">Inquiry deleted.</div>
    <?php endif; ?>

    <!-- Stats strip -->
    <div class="inq-strip">
        <div class="inq-chip">
            <strong><?php echo $totalCount; ?></strong>
            <span style="color:var(--muted);">Total Inquiries</span>
        </div>
        <div class="inq-chip">
            <strong style="color:var(--green);"><?php echo $todayCount; ?></strong>
            <span style="color:var(--muted);">Today</span>
        </div>
        <div class="inq-chip">
            <strong><?php echo $total; ?></strong>
            <span style="color:var(--muted);">Showing (filtered)</span>
        </div>
    </div>

    <!-- Filter bar -->
    <form method="GET" class="filter-bar">
        <input type="text" name="q" placeholder="&#x1F50D; Search name, phone, message..."
               value="<?php echo htmlspecialchars($search); ?>">
        <select name="cat" onchange="this.form.submit()">
            <option value="">All Categories</option>
            <option value="houses" <?php echo $catF==='houses'?'selected':''; ?>>&#x1F3E0; Homes</option>
            <option value="food"   <?php echo $catF==='food'  ?'selected':''; ?>>&#x1F354; Food</option>
            <option value="items"  <?php echo $catF==='items' ?'selected':''; ?>>&#x1F6CB; Shop</option>
        </select>
        <button type="submit" class="btn btn-secondary">Search</button>
        <?php if ($search || $catF): ?>
        <a href="inquiries.php" class="btn btn-secondary">&#x2715; Clear</a>
        <?php endif; ?>
    </form>

    <p style="font-size:13px;color:var(--muted);margin-bottom:14px;">
        Showing <?php echo count($inquiries); ?> of <?php echo $total; ?> inquiries
    </p>

    <!-- Table -->
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Listing</th>
                    <th>Category</th>
                    <th>Customer</th>
                    <th>Phone</th>
                    <th>Message</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($inquiries)): ?>
                <tr>
                    <td colspan="7" style="text-align:center;color:var(--muted);padding:40px;">
                        No inquiries yet.
                    </td>
                </tr>
            <?php endif; ?>
            <?php foreach ($inquiries as $inq): ?>
            <?php
                $listingTitle = isset($inq['listing_title']) ? $inq['listing_title'] : 'N/A';
                $catName      = isset($inq['cat_name'])      ? $inq['cat_name']      : '';
                $catSlug      = isset($inq['cat_slug'])      ? $inq['cat_slug']      : '';
                $icon         = isset($inq['icon'])          ? $inq['icon']          : '';
                $userName     = isset($inq['user_name'])     ? $inq['user_name']     : '';
                $userPhone    = isset($inq['user_phone'])    ? $inq['user_phone']    : '';
                $message      = isset($inq['message'])       ? $inq['message']       : '';
                $msgShort     = mb_strimwidth($message, 0, 60, '...');

                // Build WhatsApp link
                $waPhone = preg_replace('/\D/', '', $userPhone);
                if (strlen($waPhone) === 10 && $waPhone[0] === '0') {
                    $waPhone = '254' . substr($waPhone, 1);
                } elseif (strlen($waPhone) === 9) {
                    $waPhone = '254' . $waPhone;
                }
            ?>
                <tr>
                    <td class="td-date">
                        <?php echo date('d M Y', strtotime($inq['created_at'])); ?><br>
                        <span style="font-size:11px;color:var(--muted);">
                            <?php echo date('H:i', strtotime($inq['created_at'])); ?>
                        </span>
                    </td>
                    <td class="td-title"><?php echo htmlspecialchars($listingTitle); ?></td>
                    <td>
                        <?php if ($catName): ?>
                        <span class="badge <?php echo catBadgeCls($catSlug); ?>">
                            <?php echo $icon; ?> <?php echo htmlspecialchars($catName); ?>
                        </span>
                        <?php endif; ?>
                    </td>
                    <td style="font-size:13px;font-weight:600;">
                        <?php echo htmlspecialchars($userName); ?>
                    </td>
                    <td>
                        <div style="font-size:13px;"><?php echo htmlspecialchars($userPhone); ?></div>
                        <?php if ($waPhone): ?>
                        <a href="https://wa.me/<?php echo $waPhone; ?>"
                           target="_blank" class="wa-link" style="margin-top:4px;">
                            &#x1F4AC; WhatsApp
                        </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="msg-cell" onclick="showMsg(<?php echo htmlspecialchars(json_encode($message)); ?>, <?php echo htmlspecialchars(json_encode($userName)); ?>)">
                            <?php echo htmlspecialchars($msgShort); ?>
                            <?php if (strlen($message) > 60): ?>
                            <span style="color:var(--purple);font-size:11px;"> Read more</span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td class="td-actions">
                        <a href="?delete=<?php echo $inq['id']; ?>&<?php echo http_build_query(array_filter(array('q'=>$search,'cat'=>$catF,'p'=>$page))); ?>"
                           class="act-btn del"
                           onclick="return confirm('Delete this inquiry?')">Del</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($pages > 1): ?>
    <div class="pagination">
        <?php if ($page > 1): ?>
        <a href="?<?php echo http_build_query(array_merge(array('q'=>$search,'cat'=>$catF), array('p'=>$page-1))); ?>" class="page-btn">&larr; Prev</a>
        <?php endif; ?>
        <?php
        $start = max(1, $page-2); $end = min($pages, $page+2);
        for ($i=$start; $i<=$end; $i++):
        ?>
        <a href="?<?php echo http_build_query(array_merge(array('q'=>$search,'cat'=>$catF), array('p'=>$i))); ?>"
           class="page-btn <?php echo $i===$page?'active':''; ?>"><?php echo $i; ?></a>
        <?php endfor; ?>
        <?php if ($page < $pages): ?>
        <a href="?<?php echo http_build_query(array_merge(array('q'=>$search,'cat'=>$catF), array('p'=>$page+1))); ?>" class="page-btn">Next &rarr;</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

</main>

<!-- Full message modal -->
<div class="msg-modal" id="msgModal" onclick="if(event.target===this)closeMsgModal()">
    <div class="msg-box">
        <h3 id="msgModalTitle">Message</h3>
        <div class="msg-body" id="msgModalBody"></div>
        <button class="msg-close" onclick="closeMsgModal()">Close</button>
    </div>
</div>

<script>
function showMsg(msg, name) {
    document.getElementById('msgModalTitle').textContent = 'Message from ' + (name||'Customer');
    document.getElementById('msgModalBody').textContent  = msg;
    document.getElementById('msgModal').classList.add('open');
}
function closeMsgModal() {
    document.getElementById('msgModal').classList.remove('open');
}
document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeMsgModal(); });
</script>
</body>
</html>
