<?php
require_once 'auth.php';
require_once 'db.php';

$db  = getDB();
$cat = $_GET['cat'] ?? '';
$q   = trim($_GET['q'] ?? '');

$where = ['1=1'];
$params = [];

if ($cat) {
    $where[] = 'c.slug = ?';
    $params[] = $cat;
}
if ($q) {
    $where[] = '(l.title LIKE ? OR l.location LIKE ? OR l.contact_name LIKE ?)';
    $params = array_merge($params, ["%$q%", "%$q%", "%$q%"]);
}

$sql = "
    SELECT l.*, c.slug AS cat_slug, c.name AS cat_name, c.icon
    FROM listings l
    JOIN categories c ON l.category_id = c.id
    WHERE " . implode(' AND ', $where) . "
    ORDER BY l.updated_at DESC
";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$listings = $stmt->fetchAll();

// Handle quick toggle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_id'])) {
    $db->prepare("UPDATE listings SET is_active = 1 - is_active WHERE id = ?")
       ->execute([$_POST['toggle_id']]);
    header('Location: ' . $_SERVER['REQUEST_URI']); exit;
}

$catLabel = match($cat) { 'houses' => '🏠 Homes', 'food' => '🍔 Food', 'items' => '🛋️ Shopping', default => 'All Listings' };
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $catLabel ?> — Malaba Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style><?php include 'admin.css.php'; ?></style>
</head>
<body>
<?php include 'nav.php'; ?>

<main class="main">
    <div class="page-header">
        <div>
            <h1 class="page-title"><?= $catLabel ?></h1>
            <p class="page-sub"><?= count($listings) ?> listing<?= count($listings) !== 1 ? 's' : '' ?> found</p>
        </div>
        <a href="listing_form.php<?= $cat ? "?cat=$cat" : '' ?>" class="btn btn-primary">+ Add Listing</a>
    </div>

    <!-- Filter Bar -->
    <form method="GET" class="filter-bar">
        <input type="hidden" name="cat" value="<?= htmlspecialchars($cat) ?>">
        <input type="text" name="q" placeholder="🔍 Search listings…" value="<?= htmlspecialchars($q) ?>">
        <select name="cat" onchange="this.form.submit()">
            <option value="">All Categories</option>
            <option value="houses" <?= $cat === 'houses' ? 'selected' : '' ?>>🏠 Homes</option>
            <option value="food"   <?= $cat === 'food'   ? 'selected' : '' ?>>🍔 Food</option>
            <option value="items"  <?= $cat === 'items'  ? 'selected' : '' ?>>🛋️ Shopping</option>
        </select>
        <button type="submit" class="btn btn-secondary">Search</button>
        <?php if ($q || $cat): ?>
            <a href="listings.php" class="btn btn-secondary">Clear</a>
        <?php endif; ?>
    </form>

    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Listing</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Location</th>
                    <th>Contact</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($listings)): ?>
                <tr><td colspan="8" style="text-align:center;color:var(--muted);padding:40px;">No listings found.</td></tr>
            <?php endif; ?>
            <?php foreach ($listings as $l): ?>
                <tr>
                    <td style="color:var(--muted);font-size:12px;"><?= $l['id'] ?></td>
                    <td class="td-title"><?= htmlspecialchars($l['title']) ?></td>
                    <td>
                        <span class="badge <?= catBadgeClass($l['cat_slug']) ?>">
                            <?= $l['icon'] ?> <?= $l['cat_name'] ?>
                        </span>
                    </td>
                    <td class="td-price"><?= htmlspecialchars($l['price']) ?></td>
                    <td style="font-size:13px;color:var(--muted);"><?= htmlspecialchars($l['location']) ?></td>
                    <td style="font-size:13px;"><?= htmlspecialchars($l['contact_name']) ?></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="toggle_id" value="<?= $l['id'] ?>">
                            <button type="submit" class="act-btn <?= $l['is_active'] ? 'edit' : 'del' ?>"
                                style="cursor:pointer;">
                                <?= $l['is_active'] ? '✅ Active' : '⛔ Hidden' ?>
                            </button>
                        </form>
                    </td>
                    <td class="td-actions">
                        <a href="listing_form.php?id=<?= $l['id'] ?>" class="act-btn edit">Edit</a>
                        <a href="listing_delete.php?id=<?= $l['id'] ?>" class="act-btn del"
                           onclick="return confirm('Delete \'<?= addslashes($l['title']) ?>\'?')">Del</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>
<?php
function catBadgeClass($slug) {
    return match($slug) { 'houses' => 'purple', 'food' => 'pink', 'items' => 'green', default => 'blue' };
}
?>
