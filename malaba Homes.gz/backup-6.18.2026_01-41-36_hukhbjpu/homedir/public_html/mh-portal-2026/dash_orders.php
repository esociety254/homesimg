<?php
require_once 'auth.php';
require_once 'db.php';
requirePerm('orders');

$db = getDB();
$msg = ''; $msgType = '';

// Handle status update (inline, no page refresh needed — AJAX below)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update_status') {
        $oid    = (int)(isset($_POST['order_id']) ? $_POST['order_id'] : 0);
        $status = isset($_POST['status']) ? $_POST['status'] : '';
        $pay    = isset($_POST['pay'])    ? $_POST['pay']    : '';
        $validS = array('pending','confirmed','processing','dispatched','delivered','cancelled');
        $validP = array('pending','received','failed','refunded');
        if (in_array($status,$validS) && in_array($pay,$validP) && $oid) {
            $delv = ($status === 'delivered') ? ', delivered_at=NOW()' : '';
            $db->prepare("UPDATE orders SET status=?, payment_status=?, handled_by=?$delv WHERE id=?")
               ->execute(array($status,$pay,$CURRENT_ID,$oid));
            // Log
            try {
                $db->prepare("INSERT INTO order_status_log (order_id,new_status,changed_by) VALUES (?,?,?)")
                   ->execute(array($oid,$status,$CURRENT_ID));
            } catch (Exception $e) {}
        }
        if (isset($_POST['ajax'])) {
            header('Content-Type: application/json');
            echo json_encode(array('success'=>true));
            exit;
        }
    }
}

// Stats
$stats = $db->query("
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN status='pending'    THEN 1 ELSE 0 END) AS pending,
        SUM(CASE WHEN status='dispatched' THEN 1 ELSE 0 END) AS dispatched,
        SUM(CASE WHEN status='delivered'  THEN 1 ELSE 0 END) AS delivered,
        SUM(CASE WHEN payment_status='pending' THEN 1 ELSE 0 END) AS unpaid,
        SUM(CASE WHEN DATE(created_at)=CURDATE() THEN 1 ELSE 0 END) AS today
    FROM orders
")->fetch(PDO::FETCH_ASSOC);

// Filters
$statusF = isset($_GET['s']) ? $_GET['s'] : 'pending';
$catF    = isset($_GET['c']) ? $_GET['c'] : '';
$q       = trim(isset($_GET['q']) ? $_GET['q'] : '');

$where  = array('1=1');
$params = array();
if ($statusF && $statusF !== 'all') { $where[] = 'o.status = ?'; $params[] = $statusF; }
if ($catF)    { $where[] = 'o.category = ?'; $params[] = $catF; }
if ($q)       {
    $where[] = '(o.customer_name LIKE ? OR o.customer_phone LIKE ? OR o.order_ref LIKE ?)';
    $s = "%$q%"; $params[] = $s; $params[] = $s; $params[] = $s;
}
$whereSQL = implode(' AND ', $where);

$orders = $db->prepare("
    SELECT o.*, c.icon AS cat_icon, c.name AS cat_name
    FROM orders o
    LEFT JOIN categories c ON c.slug = o.category
    WHERE $whereSQL
    ORDER BY o.created_at DESC LIMIT 60
");
$orders->execute($params);
$orders = $orders->fetchAll(PDO::FETCH_ASSOC);

$ri = roleInfo();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Orders Dashboard &mdash; Malaba</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<style>
:root{--bg:#0D0B08;--surface:#141210;--card:#1A1714;--border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);--text:#F2EDE6;--muted:#6E6560;--amber:#E8521A;--amber2:#FF7043;--green:#52B788;--blue:#4895EF;--red:#ef4444;--gold:#f59e0b;}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;-webkit-font-smoothing:antialiased;}
a{color:inherit;text-decoration:none;}
button{cursor:pointer;font-family:inherit;border:none;background:none;}

/* HEADER */
.header{background:var(--surface);border-bottom:1px solid var(--border);padding:0 24px;height:60px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;}
.h-brand{display:flex;align-items:center;gap:10px;}
.h-mark{width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,var(--amber),var(--amber2));display:flex;align-items:center;justify-content:center;font-size:16px;}
.h-title{font-family:'Syne',sans-serif;font-weight:800;font-size:16px;}
.h-role{font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:rgba(232,82,26,.15);color:var(--amber2);}
.h-right{display:flex;align-items:center;gap:12px;}
.h-name{font-size:13px;color:var(--muted);}
.h-logout{font-size:12px;font-weight:600;padding:6px 14px;border-radius:8px;background:rgba(255,255,255,.05);border:1px solid var(--border2);color:var(--muted);transition:all .2s;}
.h-logout:hover{color:var(--red);border-color:rgba(239,68,68,.3);}

/* LAYOUT */
.page{max-width:1200px;margin:0 auto;padding:24px;}

/* STAT CARDS */
.stats{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:24px;}
@media(max-width:900px){.stats{grid-template-columns:repeat(3,1fr);}}
@media(max-width:540px){.stats{grid-template-columns:repeat(2,1fr);}}
.sc{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:16px 14px;text-align:center;cursor:pointer;transition:all .2s;text-decoration:none;display:block;}
.sc:hover{border-color:var(--border2);transform:translateY(-2px);}
.sc.active{border-color:var(--amber);background:rgba(232,82,26,.08);}
.sc-val{font-family:'Syne',sans-serif;font-weight:800;font-size:26px;color:var(--text);line-height:1;margin-bottom:4px;}
.sc-lbl{font-size:10px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;}
.sc.pending   .sc-val{color:var(--gold);}
.sc.dispatched .sc-val{color:#2dd4bf;}
.sc.delivered  .sc-val{color:var(--green);}
.sc.unpaid     .sc-val{color:var(--red);}
.sc.today      .sc-val{color:var(--blue);}

/* FILTER ROW */
.filter-row{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;align-items:center;}
.filter-row input,.filter-row select{padding:9px 13px;background:var(--surface);border:1.5px solid var(--border2);border-radius:10px;color:var(--text);font-family:inherit;font-size:13px;outline:none;transition:border-color .2s;}
.filter-row input:focus,.filter-row select:focus{border-color:var(--amber);}
.filter-row select option{background:var(--surface);}
.fr-count{font-size:13px;color:var(--muted);margin-left:auto;}

/* ORDER CARDS */
.orders-list{display:flex;flex-direction:column;gap:10px;}
.ocard{background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden;transition:border-color .2s;}
.ocard:hover{border-color:var(--border2);}
.oc-top{display:flex;align-items:center;gap:12px;padding:14px 16px;}
.oc-cat{font-size:20px;flex-shrink:0;}
.oc-info{flex:1;min-width:0;}
.oc-ref{font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.5px;}
.oc-title{font-size:14px;font-weight:700;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.oc-customer{font-size:12px;color:var(--muted);}
.oc-right{display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0;}
.oc-price{font-family:'Syne',sans-serif;font-weight:800;font-size:14px;color:var(--amber2);}
.oc-date{font-size:11px;color:var(--muted);}
.status-pill{display:inline-flex;align-items:center;gap:4px;padding:3px 9px;border-radius:20px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.3px;}
.sp-pending   {background:rgba(245,158,11,.15);color:var(--gold);}
.sp-confirmed {background:rgba(72,149,239,.15);color:var(--blue);}
.sp-processing{background:rgba(139,92,246,.15);color:#c4b5fd;}
.sp-dispatched{background:rgba(13,148,136,.15);color:#2dd4bf;}
.sp-delivered {background:rgba(82,183,136,.15);color:var(--green);}
.sp-cancelled {background:rgba(239,68,68,.15);color:#fca5a5;}
.pay-pill{display:inline-flex;align-items:center;gap:4px;padding:3px 9px;border-radius:20px;font-size:10px;font-weight:700;}
.pp-pending {background:rgba(245,158,11,.12);color:var(--gold);}
.pp-received{background:rgba(82,183,136,.12);color:var(--green);}
.pp-failed  {background:rgba(239,68,68,.12);color:#fca5a5;}

/* QUICK ACTIONS */
.oc-actions{display:flex;gap:6px;padding:0 16px 14px;flex-wrap:wrap;}
.qa-btn{display:flex;align-items:center;gap:5px;padding:7px 12px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;transition:all .15s;border:none;font-family:inherit;}
.qa-btn:active{transform:scale(.96);}
.qa-confirm  {background:rgba(72,149,239,.15);color:var(--blue);}
.qa-process  {background:rgba(139,92,246,.15);color:#c4b5fd;}
.qa-dispatch {background:rgba(13,148,136,.15);color:#2dd4bf;}
.qa-deliver  {background:rgba(82,183,136,.15);color:var(--green);}
.qa-paid     {background:rgba(82,183,136,.12);color:var(--green);}
.qa-wa       {background:rgba(37,211,102,.12);color:#25D366;}
.qa-cancel   {background:rgba(239,68,68,.1);color:#fca5a5;}

/* Address + notes row */
.oc-detail{display:flex;gap:16px;padding:0 16px 10px;font-size:12px;color:var(--muted);flex-wrap:wrap;}
.oc-detail span{display:flex;align-items:center;gap:4px;}

/* Toast */
.toast{position:fixed;bottom:20px;left:50%;transform:translateX(-50%) translateY(10px);background:var(--text);color:var(--bg);padding:10px 20px;border-radius:20px;font-size:13px;font-weight:600;z-index:999;opacity:0;pointer-events:none;transition:all .25s;white-space:nowrap;box-shadow:0 8px 24px rgba(0,0,0,.4);}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}

/* Empty */
.empty{text-align:center;padding:60px 20px;color:var(--muted);}
.empty-icon{font-size:48px;margin-bottom:14px;}
.empty-title{font-family:'Syne',sans-serif;font-weight:800;font-size:18px;color:var(--text);margin-bottom:8px;}

/* Loading spinner on buttons */
@keyframes spin{to{transform:rotate(360deg)}}
.spinning::after{content:'';display:inline-block;width:10px;height:10px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .5s linear infinite;margin-left:4px;vertical-align:middle;}
</style>
</head>
<body>

<header class="header">
  <div class="h-brand">
    <div class="h-mark">&#x1F4E6;</div>
    <span class="h-title">Orders</span>
    <span class="h-role">&#x1F4E6; Orders Manager</span>
  </div>
  <div class="h-right">
    <span class="h-name">&#x1F44B; <?php echo htmlspecialchars($CURRENT_NAME); ?></span>
    <a href="logout.php" class="h-logout">Logout</a>
  </div>
</header>

<div class="page">

  <!-- Stats clickable filter pills -->
  <div class="stats">
    <a href="?s=all" class="sc today <?php echo ($statusF==='all'?'active':''); ?>">
      <div class="sc-val"><?php echo (int)(isset($stats['today'])?$stats['today']:0); ?></div>
      <div class="sc-lbl">Today</div>
    </a>
    <a href="?s=pending" class="sc pending <?php echo ($statusF==='pending'?'active':''); ?>">
      <div class="sc-val"><?php echo (int)(isset($stats['pending'])?$stats['pending']:0); ?></div>
      <div class="sc-lbl">Pending</div>
    </a>
    <a href="?s=dispatched" class="sc dispatched <?php echo ($statusF==='dispatched'?'active':''); ?>">
      <div class="sc-val"><?php echo (int)(isset($stats['dispatched'])?$stats['dispatched']:0); ?></div>
      <div class="sc-lbl">Dispatched</div>
    </a>
    <a href="?s=delivered" class="sc delivered <?php echo ($statusF==='delivered'?'active':''); ?>">
      <div class="sc-val"><?php echo (int)(isset($stats['delivered'])?$stats['delivered']:0); ?></div>
      <div class="sc-lbl">Delivered</div>
    </a>
    <a href="?s=all&pay=pending" class="sc unpaid <?php echo (isset($_GET['pay'])&&$_GET['pay']==='pending'?'active':''); ?>">
      <div class="sc-val"><?php echo (int)(isset($stats['unpaid'])?$stats['unpaid']:0); ?></div>
      <div class="sc-lbl">Unpaid</div>
    </a>
    <a href="?s=all" class="sc">
      <div class="sc-val"><?php echo (int)(isset($stats['total'])?$stats['total']:0); ?></div>
      <div class="sc-lbl">All Time</div>
    </a>
  </div>

  <!-- Search + filter -->
  <div class="filter-row">
    <input type="text" id="searchInput" placeholder="&#x1F50D; Search name, phone, ref..." value="<?php echo htmlspecialchars($q); ?>" oninput="filterCards(this.value)">
    <select onchange="location.href='?s=<?php echo htmlspecialchars($statusF); ?>&c='+this.value+'&q=<?php echo urlencode($q); ?>'">
      <option value="">All Categories</option>
      <option value="food"   <?php echo $catF==='food'   ?'selected':''; ?>>&#x1F354; Food</option>
      <option value="items"  <?php echo $catF==='items'  ?'selected':''; ?>>&#x1F6CB; Shop</option>
      <option value="houses" <?php echo $catF==='houses' ?'selected':''; ?>>&#x1F3E0; Homes</option>
    </select>
    <span class="fr-count" id="orderCount"><?php echo count($orders); ?> orders</span>
  </div>

  <!-- Orders -->
  <div class="orders-list" id="ordersList">
  <?php if (empty($orders)): ?>
    <div class="empty">
      <div class="empty-icon">&#x1F389;</div>
      <div class="empty-title">All clear!</div>
      <p>No orders match this filter.</p>
    </div>
  <?php endif; ?>
  <?php foreach ($orders as $o):
    $s       = isset($o['status'])         ? $o['status']         : 'pending';
    $pay     = isset($o['payment_status']) ? $o['payment_status'] : 'pending';
    $total   = floatval(isset($o['total_amount']) ? $o['total_amount'] : 0);
    $price   = $total > 0 ? 'KSH '.number_format($total,0) : (isset($o['listing_price'])?$o['listing_price']:'—');
    $title   = isset($o['listing_title']) ? $o['listing_title'] : 'Order';
    $catIcon = isset($o['cat_icon'])      ? $o['cat_icon']      : '&#x1F4E6;';
    $name    = isset($o['customer_name']) ? $o['customer_name'] : '';
    $phone   = isset($o['customer_phone'])? $o['customer_phone']: '';
    $addr    = isset($o['customer_address'])? $o['customer_address']:'';
    $ref     = isset($o['order_ref'])     ? $o['order_ref']     : '';
    $dt      = date('d M H:i', strtotime(isset($o['created_at'])?$o['created_at']:'now'));

    // WA message
    $waMsg = urlencode("Hello $name! Your order *$title* ($ref) status: $s. Total: $price.");
    $waNum = preg_replace('/\D/','',$phone);
    if (strlen($waNum)===10 && $waNum[0]==='0') $waNum='254'.substr($waNum,1);
    elseif (strlen($waNum)===9) $waNum='254'.$waNum;
  ?>
  <div class="ocard" data-ref="<?php echo htmlspecialchars($ref); ?>" data-name="<?php echo htmlspecialchars(strtolower($name)); ?>" data-phone="<?php echo htmlspecialchars($phone); ?>">
    <div class="oc-top">
      <div class="oc-cat"><?php echo $catIcon; ?></div>
      <div class="oc-info">
        <div class="oc-ref"><?php echo htmlspecialchars($ref); ?></div>
        <div class="oc-title"><?php echo htmlspecialchars($title); ?></div>
        <div class="oc-customer">
          &#x1F464; <?php echo htmlspecialchars($name); ?> &nbsp;&#x1F4DE; <?php echo htmlspecialchars($phone); ?>
        </div>
      </div>
      <div class="oc-right">
        <div class="oc-price"><?php echo $price; ?></div>
        <span class="status-pill sp-<?php echo $s; ?>" id="sp-<?php echo $o['id']; ?>"><?php echo ucfirst($s); ?></span>
        <span class="pay-pill pp-<?php echo $pay; ?>" id="pp-<?php echo $o['id']; ?>"><?php echo $pay==='received'?'&#x1F4B0; Paid':'&#x23F3; '.ucfirst($pay); ?></span>
        <div class="oc-date"><?php echo $dt; ?></div>
      </div>
    </div>
    <?php if ($addr): ?>
    <div class="oc-detail">
      <span>&#x1F4CD; <?php echo htmlspecialchars(mb_strimwidth($addr,0,50,'...')); ?></span>
      <span>&#x1F4B3; <?php echo ucfirst(str_replace('_',' ',isset($o['payment_method'])?$o['payment_method']:'cash')); ?></span>
    </div>
    <?php endif; ?>
    <!-- Quick action buttons -->
    <div class="oc-actions">
      <?php if ($s==='pending'): ?>
      <button class="qa-btn qa-confirm"  onclick="updateOrder(<?php echo $o['id']; ?>,'confirmed','<?php echo $pay; ?>',this)">&#x2705; Confirm</button>
      <?php endif; ?>
      <?php if ($s==='confirmed'): ?>
      <button class="qa-btn qa-process"  onclick="updateOrder(<?php echo $o['id']; ?>,'processing','<?php echo $pay; ?>',this)">&#x1F504; Preparing</button>
      <?php endif; ?>
      <?php if (in_array($s,array('confirmed','processing'))): ?>
      <button class="qa-btn qa-dispatch" onclick="updateOrder(<?php echo $o['id']; ?>,'dispatched','<?php echo $pay; ?>',this)">&#x1F69A; Dispatched</button>
      <?php endif; ?>
      <?php if ($s==='dispatched'): ?>
      <button class="qa-btn qa-deliver"  onclick="updateOrder(<?php echo $o['id']; ?>,'delivered','received',this)">&#x1F389; Delivered + Paid</button>
      <?php endif; ?>
      <?php if ($pay==='pending' && $s!=='cancelled'): ?>
      <button class="qa-btn qa-paid"     onclick="updateOrder(<?php echo $o['id']; ?>,'<?php echo $s; ?>','received',this)">&#x1F4B0; Mark Paid</button>
      <?php endif; ?>
      <a href="https://wa.me/<?php echo $waNum; ?>?text=<?php echo $waMsg; ?>" target="_blank" class="qa-btn qa-wa">&#x1F4AC; WhatsApp</a>
      <?php if (!in_array($s,array('delivered','cancelled'))): ?>
      <button class="qa-btn qa-cancel"   onclick="updateOrder(<?php echo $o['id']; ?>,'cancelled','<?php echo $pay; ?>',this)">&#x274C; Cancel</button>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
  </div>

</div>

<div class="toast" id="toast"></div>

<script>
var BASE = <?php echo json_encode(rtrim(dirname($_SERVER['PHP_SELF']),'/')); ?>;

function updateOrder(id, status, pay, btn) {
  btn.classList.add('spinning');
  btn.disabled = true;

  var xhr = new XMLHttpRequest();
  xhr.open('POST', BASE + '/dash_orders.php', true);
  xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
  xhr.onload = function() {
    btn.classList.remove('spinning');
    btn.disabled = false;
    try {
      var d = JSON.parse(xhr.responseText);
      if (d.success) {
        // Update pills in place
        var sp = document.getElementById('sp-'+id);
        var pp = document.getElementById('pp-'+id);
        var labels = {pending:'Pending',confirmed:'Confirmed',processing:'Processing',dispatched:'Dispatched',delivered:'Delivered',cancelled:'Cancelled'};
        if (sp) { sp.className = 'status-pill sp-'+status; sp.textContent = labels[status]||status; }
        if (pp) { pp.className = 'pay-pill pp-'+pay; pp.innerHTML = pay==='received'?'&#x1F4B0; Paid':'&#x23F3; '+pay; }
        // Hide/show buttons
        var card = btn.closest('.ocard');
        if (card) {
          var acts = card.querySelector('.oc-actions');
          if (acts) acts.querySelectorAll('.qa-btn').forEach(function(b){ b.style.display='none'; });
        }
        showToast(labels[status] + ' ✅');
        // Reload after 1.5s to refresh the list
        setTimeout(function(){ location.reload(); }, 1500);
      }
    } catch(e) { showToast('Updated!'); setTimeout(function(){ location.reload(); },1000); }
  };
  xhr.onerror = function(){ btn.classList.remove('spinning'); btn.disabled=false; showToast('Error - try again'); };
  xhr.send('action=update_status&ajax=1&order_id='+id+'&status='+encodeURIComponent(status)+'&pay='+encodeURIComponent(pay));
}

function filterCards(q) {
  q = q.toLowerCase();
  var cards = document.querySelectorAll('.ocard');
  var shown = 0;
  cards.forEach(function(c) {
    var ref   = (c.dataset.ref   || '').toLowerCase();
    var name  = (c.dataset.name  || '').toLowerCase();
    var phone = (c.dataset.phone || '').toLowerCase();
    var match = !q || ref.includes(q) || name.includes(q) || phone.includes(q);
    c.style.display = match ? '' : 'none';
    if (match) shown++;
  });
  var ct = document.getElementById('orderCount');
  if (ct) ct.textContent = shown + ' orders';
}

function showToast(msg) {
  var t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(function(){ t.classList.remove('show'); }, 2000);
}
</script>
</body>
</html>
