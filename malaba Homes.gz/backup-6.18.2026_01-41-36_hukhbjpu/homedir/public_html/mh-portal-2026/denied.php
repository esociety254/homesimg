<?php
require_once 'auth.php';
$ri = roleInfo();
$home = roleDashboard();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Access Denied &mdash; Malaba Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'DM Sans',sans-serif;background:#080604;color:#F2EDE6;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
.card{background:#141210;border:1px solid rgba(239,68,68,.2);border-radius:24px;padding:48px 40px;max-width:400px;width:100%;text-align:center;}
.icon{font-size:52px;margin-bottom:20px;}
h1{font-family:'Syne',sans-serif;font-weight:800;font-size:24px;margin-bottom:8px;}
p{color:#6E6560;font-size:14px;line-height:1.6;margin-bottom:28px;}
.role-tag{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:700;margin-bottom:24px;background:rgba(239,68,68,.1);color:#fca5a5;}
a{display:inline-flex;align-items:center;gap:8px;padding:13px 24px;background:linear-gradient(135deg,#E8521A,#FF7043);color:#fff;border-radius:12px;font-weight:700;font-size:14px;font-family:inherit;text-decoration:none;transition:all .2s;}
a:hover{transform:translateY(-1px);}
</style>
</head>
<body>
<div class="card">
  <div class="icon">&#x26D4;</div>
  <h1>Access Denied</h1>
  <div class="role-tag"><?php echo $ri['icon']; ?> <?php echo $ri['label']; ?></div>
  <p>You don't have permission to view this page.<br>You can only access pages assigned to your role.</p>
  <a href="<?php echo $home; ?>">&#x2190; Go to My Dashboard</a>
</div>
</body>
</html>
