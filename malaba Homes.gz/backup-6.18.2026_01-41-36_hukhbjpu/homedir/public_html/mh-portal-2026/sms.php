<?php
/**
 * admin/sms.php — SMS notification helper
 *
 * Provider: Africa's Talking (africastalking.com)
 *   - Free sandbox for testing
 *   - Live: KES ~1–1.5/SMS in Kenya
 *   - API docs: https://developers.africastalking.com/docs/sms/sending
 *
 * Usage (anywhere in admin or order pipeline):
 *   require_once 'sms.php';
 *   sendSms('0712345678', "Hi John, your order MH-2026-0001 has been dispatched!");
 *
 * OR use the template helpers:
 *   smsOrderStatus($order, 'dispatched');
 */

// ── Config ── (move to a .env or config.php in production) ──
define('AT_API_KEY',   getenv('AT_API_KEY')   ?: 'your_africastalking_api_key');
define('AT_USERNAME',  getenv('AT_USERNAME')   ?: 'sandbox');   // 'sandbox' for testing
define('AT_SENDER_ID', getenv('AT_SENDER_ID')  ?: 'Malaba');    // registered short-code / name
define('SMS_ENABLED',  getenv('SMS_ENABLED')   ?: false);       // set to true in production
// ────────────────────────────────────────────────────────────

/**
 * Send a single SMS.
 * Returns ['success' => bool, 'message_id' => string|null, 'error' => string|null]
 */
function sendSms(string $phone, string $message, ?int $orderId = null): array {
    // Normalise Kenyan numbers → international 254…
    $phone = normaliseKenyanPhone($phone);
    if (!$phone) return ['success' => false, 'error' => 'Invalid phone number'];

    // Truncate message to 160 chars (1 SMS unit)
    $message = mb_substr($message, 0, 459);  // 459 = 3 concatenated SMS units

    // Log attempt regardless of whether we send
    $logId = logSms($phone, $message, $orderId);

    if (!SMS_ENABLED) {
        // In dev mode: log to PHP error_log so you can see without paying
        error_log("[SMS-DEV] To: $phone | $message");
        updateSmsLog($logId, 'sent', 'DEV-' . time());
        return ['success' => true, 'dev' => true, 'message_id' => null];
    }

    $payload = http_build_query([
        'username'    => AT_USERNAME,
        'to'          => $phone,
        'message'     => $message,
        'from'        => AT_SENDER_ID,
    ]);

    $ctx = stream_context_create(['http' => [
        'method'  => 'POST',
        'header'  => "Content-Type: application/x-www-form-urlencoded\r\nApiKey: " . AT_API_KEY . "\r\nAccept: application/json\r\n",
        'content' => $payload,
        'timeout' => 10,
    ]]);

    $url = AT_USERNAME === 'sandbox'
        ? 'https://api.sandbox.africastalking.com/version1/messaging'
        : 'https://api.africastalking.com/version1/messaging';

    $raw = @file_get_contents($url, false, $ctx);
    if (!$raw) {
        updateSmsLog($logId, 'failed', null);
        return ['success' => false, 'error' => 'HTTP request failed'];
    }

    $data = json_decode($raw, true);
    $recipients = $data['SMSMessageData']['Recipients'] ?? [];
    $first      = $recipients[0] ?? [];
    $msgId      = $first['messageId'] ?? null;
    $status     = strtolower($first['status'] ?? '');
    $ok         = in_array($status, ['success', 'queued']);

    updateSmsLog($logId, $ok ? 'sent' : 'failed', $msgId);
    return ['success' => $ok, 'message_id' => $msgId, 'error' => $ok ? null : ($first['status'] ?? 'Unknown')];
}

// ── SMS templates ────────────────────────────────────────────

/**
 * Send a status-update SMS for a given order.
 * $order = row from `orders` table.
 * $newStatus = 'confirmed' | 'processing' | 'dispatched' | 'delivered' | 'cancelled'
 */
function smsOrderStatus(array $order, string $newStatus): array {
    $name = $order['customer_name'] ?? 'Customer';
    $ref  = $order['order_ref']     ?? '';
    $item = mb_strimwidth($order['listing_title'] ?? 'your order', 0, 30, '…');
    $wa   = 'wa.me/254700000000';   // ← replace with your WhatsApp

    $messages = [
        'confirmed'  => "Hi $name! ✅ Order $ref ($item) confirmed. We'll start preparing shortly. Track: malaba.co.ke/track?ref=$ref",
        'processing' => "Hi $name! 🔄 Your order $ref is being prepared. Estimated 20–40 min. Questions? WhatsApp us: $wa",
        'dispatched' => "Hi $name! 🚚 Order $ref is on the way! Expected soon. Track: malaba.co.ke/track?ref=$ref",
        'delivered'  => "Hi $name! 🎉 Order $ref delivered. Enjoy! Rate us on WhatsApp: $wa",
        'cancelled'  => "Hi $name, order $ref was cancelled. Contact us on WhatsApp for help: $wa",
    ];

    $msg = $messages[$newStatus] ?? null;
    if (!$msg) return ['success' => false, 'error' => 'No template for status: ' . $newStatus];

    return sendSms($order['customer_phone'], $msg, $order['id'] ?? null);
}

/**
 * Send confirmation SMS immediately after an order is placed.
 */
function smsOrderConfirmation(array $order): array {
    $name = $order['customer_name'] ?? 'Customer';
    $ref  = $order['order_ref']     ?? '';
    $item = mb_strimwidth($order['listing_title'] ?? 'your order', 0, 30, '…');
    $amt  = number_format((float)($order['total_amount'] ?? 0));
    $pay  = strtoupper(str_replace('_', ' ', $order['payment_method'] ?? 'CASH'));

    $msg  = "Hi $name! 📋 Order $ref received: $item. Total: KSH $amt ($pay). Track: malaba.co.ke/track?ref=$ref";
    return sendSms($order['customer_phone'], $msg, $order['id'] ?? null);
}

// ── Internals ────────────────────────────────────────────────

function normaliseKenyanPhone(string $phone): string {
    $digits = preg_replace('/\D/', '', $phone);
    if (strlen($digits) === 9) $digits = '254' . $digits;          // 712345678 → 254…
    if (strlen($digits) === 10 && $digits[0] === '0')               // 0712345678 → 254…
        $digits = '254' . substr($digits, 1);
    if (strlen($digits) === 12 && str_starts_with($digits, '254'))  // already correct
        return '+' . $digits;
    return '';  // invalid
}

function logSms(string $phone, string $message, ?int $orderId): ?int {
    try {
        $db = getDB();
        $db->prepare("INSERT INTO sms_log (order_id, phone, message, status) VALUES (?,?,?,'queued')")
           ->execute([$orderId, $phone, $message]);
        return (int)$db->lastInsertId();
    } catch (Throwable $_) { return null; }
}

function updateSmsLog(?int $id, string $status, ?string $providerId): void {
    if (!$id) return;
    try {
        $db = getDB();
        $db->prepare("UPDATE sms_log SET status=?, provider_id=? WHERE id=?")
           ->execute([$status, $providerId, $id]);
    } catch (Throwable $_) {}
}
