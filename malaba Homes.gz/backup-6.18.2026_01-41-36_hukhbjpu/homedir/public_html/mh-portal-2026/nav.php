<?php
// admin/nav.php — PHP 5.6 compatible shared sidebar
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$current = basename($_SERVER['PHP_SELF']);
$catGet  = isset($_GET['cat']) ? $_GET['cat'] : '';

function navActive($file) {
    global $current;
    return $current === $file ? 'active' : '';
}
function navCatActive($cat) {
    global $catGet;
    return $catGet === $cat ? 'active' : '';
}

// Live counts for badges
$db = getDB();
$pendingOrders  = 0;
$newInquiries   = 0;
try {
    $pendingOrders = (int)$db->query("SELECT COUNT(*) FROM orders WHERE status='pending'")->fetchColumn();
    $newInquiries  = (int)$db->query("SELECT COUNT(*) FROM inquiries WHERE DATE(created_at)=CURDATE()")->fetchColumn();
} catch (Exception $e) {}
?>
<nav class="nav">
  <div class="nav-brand">
    <span class="nav-brand-icon">&#x1F3E1;</span>
    <span class="nav-brand-name">Malaba Admin</span>
  </div>

  <div class="nav-section">Overview</div>
  <a href="index.php" class="<?php echo navActive('index.php'); ?>">
    <span class="nav-icon">&#x1F4CA;</span> Dashboard
  </a>
  <a href="analytics.php" class="<?php echo navActive('analytics.php'); ?>">
    <span class="nav-icon">&#x1F4C8;</span> Analytics
  </a>

  <div class="nav-section" style="margin-top:16px;">Orders</div>
  <a href="orders.php" class="<?php echo navActive('orders.php'); ?>" style="justify-content:space-between;">
    <span><span class="nav-icon">&#x1F4E6;</span> All Orders</span>
    <?php if ($pendingOrders > 0): ?>
    <span style="background:#E8521A;color:#fff;font-size:10px;font-weight:800;padding:2px 7px;border-radius:10px;"><?php echo $pendingOrders; ?></span>
    <?php endif; ?>
  </a>
  <a href="orders.php?status=pending">
    <span class="nav-icon">&#x23F3;</span> Pending
  </a>
  <a href="orders.php?status=dispatched">
    <span class="nav-icon">&#x1F69A;</span> Dispatched
  </a>
  <a href="orders.php?pay=pending">
    <span class="nav-icon">&#x1F4B3;</span> Payment Due
  </a>
  <a href="inquiries.php" class="<?php echo navActive('inquiries.php'); ?>" style="justify-content:space-between;">
    <span><span class="nav-icon">&#x1F4AC;</span> Inquiries</span>
    <?php if ($newInquiries > 0): ?>
    <span style="background:#4895EF;color:#fff;font-size:10px;font-weight:800;padding:2px 7px;border-radius:10px;"><?php echo $newInquiries; ?></span>
    <?php endif; ?>
  </a>

  <div class="nav-section" style="margin-top:16px;">Listings</div>
  <a href="listings.php" class="<?php echo navActive('listings.php'); ?>">
    <span class="nav-icon">&#x1F4CB;</span> All Listings
  </a>
  <a href="listings.php?cat=houses" class="<?php echo navCatActive('houses'); ?>">
    <span class="nav-icon">&#x1F3E0;</span> Homes
  </a>
  <a href="listings.php?cat=food" class="<?php echo navCatActive('food'); ?>">
    <span class="nav-icon">&#x1F354;</span> Food
  </a>
  <a href="listings.php?cat=items" class="<?php echo navCatActive('items'); ?>">
    <span class="nav-icon">&#x1F6CB;&#xFE0F;</span> Shopping
  </a>

  <div class="nav-section" style="margin-top:16px;">Actions</div>
  <a href="listing_form.php" class="<?php echo navActive('listing_form.php'); ?>">
    <span class="nav-icon">&#x2795;</span> Add Listing
  </a>
  <a href="../video_feed.php" target="_blank">
    <span class="nav-icon">&#x25B6;</span> Watch &amp; Shop
  </a>
  <a href="push_notifications.php" class="nav-link">
      <span class="nav-icon">🔔</span> Push Notifications
    </a>
  <a href="../index.php" target="_blank">
    <span class="nav-icon">&#x1F310;</span> View Site
  </a>

  <div class="nav-logout">
    <a href="logout.php">
      <span class="nav-icon">&#x1F6AA;</span>
      Logout
      <span style="margin-left:auto;font-size:11px;color:rgba(255,255,255,.3);">
        <?php echo htmlspecialchars(isset($_SESSION['admin_name']) ? $_SESSION['admin_name'] : ''); ?>
      </span>
    </a>
  </div>
</nav>
