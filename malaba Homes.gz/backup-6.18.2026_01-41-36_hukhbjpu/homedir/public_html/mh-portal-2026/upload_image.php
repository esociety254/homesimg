<?php
/**
 * admin/upload_image.php
 * POST multipart: field name = "image"
 * Returns JSON { success, url }
 *
 * Requirements: PHP GD extension (bundled with XAMPP)
 * Upload directory: /uploads/listings/ (web-accessible)
 */
require_once 'auth.php';   // must be admin

header('Content-Type: application/json');

// ── Config ──────────────────────────────────────────────
$UPLOAD_DIR  = __DIR__ . '/../uploads/listings/';
$WEB_PATH    = '/uploads/listings/';          // web URL path
$MAX_BYTES   = 5 * 1024 * 1024;              // 5 MB
$ALLOWED     = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
$MAX_WIDTH   = 1200;                          // resize if wider
$JPEG_QUAL   = 82;
// ────────────────────────────────────────────────────────

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(array('success' => false, 'error' => 'POST required']);
    exit;
}
if (empty($_FILES['image'])) {
    echo json_encode(array('success' => false, 'error' => 'No file uploaded']);
    exit;
}

$file = $_FILES['image'];

// Basic error check
if ($file['error'] !== UPLOAD_ERR_OK) {
    $msgs = [1=>'File too large (php.ini)',2=>'File too large (form)',3=>'Partial upload',4=>'No file',6=>'No tmp',7=>'Write fail',8=>'PHP extension'];
    echo json_encode(array('success' => false, 'error' => isset(\$msgs[\$file['error']]) ? \$msgs[\$file['error']] : 'Upload error']);
    exit;
}

// Size guard
if ($file['size'] > $MAX_BYTES) {
    echo json_encode(array('success' => false, 'error' => 'Max 5 MB allowed']);
    exit;
}

// MIME check (via finfo — more secure than relying on browser type)
$finfo    = new finfo(FILEINFO_MIME_TYPE);
$mimeType = $finfo->file($file['tmp_name']);
if (!in_array($mimeType, $ALLOWED, true)) {
    echo json_encode(array('success' => false, 'error' => 'Only JPEG, PNG, WebP or GIF allowed']);
    exit;
}

// Create upload directory if missing
if (!is_dir($UPLOAD_DIR)) {
    mkdir($UPLOAD_DIR, 0755, true);
}

// Generate safe unique filename
$ext      = match ($mimeType) {
    'image/png'  => 'png',
    'image/gif'  => 'gif',
    'image/webp' => 'webp',
    default      => 'jpg',
};
$filename = date('Ymd') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
$destPath = $UPLOAD_DIR . $filename;

// Resize if needed (JPEG/PNG/WebP only; GIF passed through)
$resized = false;
if ($mimeType !== 'image/gif' && extension_loaded('gd')) {
    $src = match ($mimeType) {
        'image/png'  => imagecreatefrompng($file['tmp_name']),
        'image/webp' => imagecreatefromwebp($file['tmp_name']),
        default      => imagecreatefromjpeg($file['tmp_name']),
    };
    if ($src) {
        $w = imagesx($src);
        $h = imagesy($src);
        if ($w > $MAX_WIDTH) {
            $newH = (int)round($h * $MAX_WIDTH / $w);
            $dst  = imagecreatetruecolor($MAX_WIDTH, $newH);

            // Preserve alpha for PNG/WebP
            if (in_array($mimeType, ['image/png', 'image/webp'])) {
                imagealphablending($dst, false);
                imagesavealpha($dst, true);
                $trans = imagecolorallocatealpha($dst, 0, 0, 0, 127);
                imagefilledrectangle($dst, 0, 0, $MAX_WIDTH, $newH, $trans);
            }

            imagecopyresampled($dst, $src, 0, 0, 0, 0, $MAX_WIDTH, $newH, $w, $h);
            imagedestroy($src);
            $src = $dst;
            $resized = true;
        }

        // Save
        $ok = match ($mimeType) {
            'image/png'  => imagepng($src, $destPath, 6),
            'image/webp' => imagewebp($src, $destPath, 85),
            default      => imagejpeg($src, $destPath, $JPEG_QUAL),
        };
        imagedestroy($src);

        if (!$ok) {
            echo json_encode(array('success' => false, 'error' => 'Failed to save image']);
            exit;
        }
    }
} else {
    // GIF or no GD: just move as-is
    if (!move_uploaded_file($file['tmp_name'], $destPath)) {
        echo json_encode(array('success' => false, 'error' => 'Failed to move upload']);
        exit;
    }
}

// If we processed via GD, tmp is still around; if not, it was moved above.
// For GD path, tmp_name stays in /tmp and will be cleaned by PHP — no action needed.

$url = $WEB_PATH . $filename;
echo json_encode(array(
    'success'  => true,
    'url'      => $url,
    'filename' => $filename,
    'resized'  => $resized,
));
