<?php
// admin/listing_form.php
require_once 'auth.php';
require_once 'db.php';

$db       = getDB();
$id       = isset($_GET['id']) ? trim($_GET['id']) : null;
$cat      = isset($_GET['cat']) ? trim($_GET['cat']) : 'houses';
$item     = null;
$images   = [];
$features = [];
$success  = '';
$error    = '';

$CLOUDINARY_CLOUD_NAME    = 'dsqo3yxkz';
$CLOUDINARY_UPLOAD_PRESET = 'malaba_default';

if ($id) {
    $s = $db->prepare("SELECT * FROM listings WHERE id = ?");
    $s->execute([$id]);
    $item = $s->fetch(PDO::FETCH_ASSOC);
    if (!$item) { header('Location: listings.php'); exit; }
    $s2 = $db->prepare("SELECT * FROM listing_images WHERE listing_id = ? ORDER BY sort_order");
    $s2->execute([$id]);
    $images = $s2->fetchAll(PDO::FETCH_ASSOC);
    $s3 = $db->prepare("SELECT * FROM listing_features WHERE listing_id = ? ORDER BY sort_order");
    $s3->execute([$id]);
    $features = $s3->fetchAll(PDO::FETCH_ASSOC);
    $sc = $db->prepare("SELECT slug FROM categories WHERE id = ?");
    $sc->execute([$item['category_id']]);
    $cat = $sc->fetchColumn();
}

$categories = $db->query("SELECT * FROM categories ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);

$hasVideoCol   = false;
$hasPremiumCol = false;
try { $db->query("SELECT video_url FROM listings LIMIT 0");  $hasVideoCol   = true; } catch (Exception $e) {}
try { $db->query("SELECT is_premium FROM listings LIMIT 0"); $hasPremiumCol = true; } catch (Exception $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title   = trim($_POST['title']         ?? '');
    $desc    = trim($_POST['description']   ?? '');
    $price   = trim($_POST['price']         ?? '');
    $loc     = trim($_POST['location']      ?? '');
    $img     = trim($_POST['image_url']     ?? '');
    $video   = trim($_POST['video_url']     ?? '');
    $cphone  = trim($_POST['contact_phone'] ?? '');
    $cname   = trim($_POST['contact_name']  ?? '');
    $badge   = trim($_POST['badge']         ?? '');
    $cat_id  = (int)($_POST['category_id']  ?? 1);
    $active  = isset($_POST['is_active'])   ? 1 : 0;
    $premium = isset($_POST['is_premium'])  ? 1 : 0;
    $featured= isset($_POST['is_featured']) ? 1 : 0;
    $extra_imgs = isset($_POST['extra_images']) && is_array($_POST['extra_images'])
                  ? array_filter(array_map('trim', $_POST['extra_images'])) : [];
    $feat_icons = $_POST['feat_icon'] ?? [];
    $feat_texts = array_map('trim', $_POST['feat_text'] ?? []);
    if (!$title || !$price) {
        $error = 'Title and Price are required.';
    } else {
        try {
            if ($item) {
                if ($hasVideoCol && $hasPremiumCol) {
                    $db->prepare("UPDATE listings SET category_id=?,title=?,description=?,price=?,location=?,
                        image_url=?,video_url=?,contact_phone=?,contact_name=?,badge=?,is_active=?,
                        is_premium=?,is_featured=?,updated_at=NOW() WHERE id=?")
                       ->execute([$cat_id,$title,$desc,$price,$loc,$img,$video,$cphone,$cname,$badge,$active,$premium,$featured,$id]);
                } else {
                    $db->prepare("UPDATE listings SET category_id=?,title=?,description=?,price=?,location=?,
                        image_url=?,contact_phone=?,contact_name=?,badge=?,is_active=?,is_featured=?,updated_at=NOW() WHERE id=?")
                       ->execute([$cat_id,$title,$desc,$price,$loc,$img,$cphone,$cname,$badge,$active,$featured,$id]);
                }
                $db->prepare("DELETE FROM listing_images WHERE listing_id=?")->execute([$id]);
                $db->prepare("DELETE FROM listing_features WHERE listing_id=?")->execute([$id]);
                saveImagesAndFeatures($db, $id, $extra_imgs, $feat_icons, $feat_texts);
                $success = 'Listing updated successfully!';
            } else {
                if ((int)$cat_id === 1) $prefix = 'h';
                elseif ((int)$cat_id === 2) $prefix = 'f';
                else $prefix = 'i';
                $count = (int)$db->query("SELECT COUNT(*) FROM listings WHERE category_id=".(int)$cat_id)->fetchColumn();
                $newId = $prefix.($count + 1 + rand(10,99));
                if ($hasVideoCol && $hasPremiumCol) {
                    $db->prepare("INSERT INTO listings (id,category_id,title,description,price,location,image_url,video_url,
                        contact_phone,contact_name,badge,is_active,is_premium,is_featured) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
                       ->execute([$newId,$cat_id,$title,$desc,$price,$loc,$img,$video,$cphone,$cname,$badge,$active,$premium,$featured]);
                } else {
                    $db->prepare("INSERT INTO listings (id,category_id,title,description,price,location,image_url,
                        contact_phone,contact_name,badge,is_active,is_featured) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)")
                       ->execute([$newId,$cat_id,$title,$desc,$price,$loc,$img,$cphone,$cname,$badge,$active,$featured]);
                }
                saveImagesAndFeatures($db, $newId, $extra_imgs, $feat_icons, $feat_texts);
                header('Location: listing_form.php?id='.urlencode($newId).'&added=1');
                exit;
            }
        } catch (Exception $e) { $error = 'Database error: '.$e->getMessage(); }
    }
}

function saveImagesAndFeatures($db, $lid, $imgs, $icons, $texts) {
    $si = $db->prepare("INSERT INTO listing_images (listing_id,image_url,sort_order) VALUES (?,?,?)");
    foreach (array_values($imgs) as $i => $url) { if ($url) $si->execute([$lid,$url,$i]); }
    $sf = $db->prepare("INSERT INTO listing_features (listing_id,icon,feature_text,sort_order) VALUES (?,?,?,?)");
    foreach ($texts as $i => $txt) {
        if (trim($txt)) $sf->execute([$lid, $icons[$i] ?? '✅', $txt, $i]);
    }
}

$pageTitle = $item ? 'Edit Listing' : 'Add Listing';
$isEdit    = ($item !== null);
$itemTitle = $isEdit ? htmlspecialchars($item['title'])        : '';
$itemDesc  = $isEdit ? htmlspecialchars($item['description'])  : '';
$itemPrice = $isEdit ? htmlspecialchars($item['price'])        : '';
$itemLoc   = $isEdit ? htmlspecialchars($item['location'])     : '';
$itemImg   = $isEdit ? htmlspecialchars($item['image_url'])    : '';
$itemVideo = ($isEdit && $hasVideoCol && isset($item['video_url'])) ? htmlspecialchars($item['video_url']) : '';
$itemPhone = $isEdit ? htmlspecialchars($item['contact_phone']): '';
$itemCname = $isEdit ? htmlspecialchars($item['contact_name']) : '';
$itemBadge = ($isEdit && isset($item['badge'])) ? htmlspecialchars($item['badge']) : '';
$itemCatId = $isEdit ? (int)$item['category_id'] : 0;
$itemActive= !$isEdit || (int)$item['is_active'];
$itemFeat  = $isEdit && isset($item['is_featured'])  ? (int)$item['is_featured']  : 0;
$itemPrem  = ($isEdit && $hasPremiumCol && isset($item['is_premium'])) ? (int)$item['is_premium'] : 0;
if (isset($_GET['added'])) $success = 'Listing created! Edit details below.';

$totalSteps = $hasVideoCol ? 5 : 4;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title><?= htmlspecialchars($pageTitle) ?> — Malaba Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.2/cropper.min.css"/>
<style>
<?php include 'admin.css.php'; ?>

/* ════════════════════════════════════════
   MALABA LISTING FORM — MOBILE-FIRST v3
════════════════════════════════════════ */
*, *::before, *::after { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }

/* ── Outer shell ── */
.lf-shell {
  max-width: 540px;
  margin: 0 auto;
  padding-bottom: 100px;
  padding-left: 12px;
  padding-right: 12px;
}

/* ══════════════════════════════════════
   STEP WIZARD HEADER
══════════════════════════════════════ */
.wizard-head {
  position: sticky;
  top: 0;
  z-index: 90;
  background: var(--bg);
  padding: 10px 12px 0;
  border-bottom: 1px solid var(--border);
}

/* Top row: back + title + save */
.wh-toprow {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 10px;
}
.wh-back {
  width: 36px; height: 36px;
  border-radius: 10px;
  border: 1.5px solid var(--border2);
  background: var(--surface);
  color: var(--text);
  font-size: 16px;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer;
  text-decoration: none;
  flex-shrink: 0;
  transition: all .15s;
}
.wh-back:hover { border-color: rgba(255,255,255,.3); }
.wh-title {
  flex: 1;
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 15px;
  color: var(--text);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.wh-quicksave {
  flex-shrink: 0;
  padding: 8px 14px;
  border-radius: 10px;
  background: rgba(232,82,26,.12);
  border: 1.5px solid rgba(232,82,26,.25);
  color: #E8521A;
  font-size: 12px;
  font-weight: 700;
  cursor: pointer;
  font-family: inherit;
  transition: all .15s;
  display: none;
}
.wh-quicksave.visible { display: block; }
.wh-quicksave:active  { background: rgba(232,82,26,.25); }

/* Step rail */
.step-rail {
  display: flex;
  gap: 0;
  overflow-x: auto;
  scrollbar-width: none;
  padding-bottom: 12px;
  scroll-snap-type: x mandatory;
}
.step-rail::-webkit-scrollbar { display: none; }

.sr-step {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 5px;
  flex: 1;
  min-width: 60px;
  cursor: pointer;
  scroll-snap-align: center;
  padding: 0 4px;
  position: relative;
}

/* connector line between steps */
.sr-step:not(:last-child)::after {
  content: '';
  position: absolute;
  top: 13px;
  right: -50%;
  width: 100%;
  height: 2px;
  background: var(--border);
  z-index: 0;
  transition: background .3s;
}
.sr-step.done:not(:last-child)::after { background: #52B788; }

.sr-circle {
  width: 26px; height: 26px;
  border-radius: 50%;
  background: var(--border);
  color: var(--muted);
  font-size: 10px;
  font-weight: 800;
  display: flex; align-items: center; justify-content: center;
  transition: all .25s;
  position: relative;
  z-index: 1;
  flex-shrink: 0;
  border: 2px solid transparent;
}
.sr-label {
  font-size: 9px;
  font-weight: 700;
  color: var(--muted);
  text-transform: uppercase;
  letter-spacing: .4px;
  white-space: nowrap;
  transition: color .25s;
  text-align: center;
}

.sr-step.active .sr-circle {
  background: #E8521A;
  color: #fff;
  border-color: rgba(232,82,26,.35);
  box-shadow: 0 0 0 4px rgba(232,82,26,.15);
}
.sr-step.active .sr-label { color: #E8521A; }

.sr-step.done .sr-circle {
  background: #52B788;
  color: #fff;
  border-color: rgba(82,183,136,.3);
}
.sr-step.done .sr-label { color: #52B788; }

/* Progress bar under rail */
.wh-progress-bar {
  height: 3px;
  background: var(--border);
  border-radius: 3px;
  margin: 0 -12px;
  overflow: hidden;
  display: none;
}
.wh-progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #E8521A, #FF7043);
  border-radius: 3px;
  transition: width .35s ease;
}

/* ══════════════════════════════════════
   STEP PANELS
══════════════════════════════════════ */
.form-step {
  display: none;
}
.form-step.active {
  display: block;
  animation: fadeUp .22s ease both;
}
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(12px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* ── Cards ── */
.lf-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 18px;
  padding: 18px 16px;
  margin: 14px 0;
}
.lf-card:focus-within { border-color: rgba(232,82,26,.3); }

.card-title {
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 1px;
  color: var(--muted);
  margin-bottom: 16px;
  padding-bottom: 10px;
  border-bottom: 1px solid var(--border);
  display: flex; align-items: center; gap: 6px;
}

/* ── Fields ── */
.fg { margin-bottom: 14px; }
.fg:last-child { margin-bottom: 0; }

.fg > label {
  display: flex; align-items: center; gap: 4px;
  font-size: 10px; font-weight: 700;
  text-transform: uppercase; letter-spacing: .7px;
  color: var(--muted);
  margin-bottom: 6px;
}
.req { color: #f87171; font-size: 12px; }
.fg-hint { font-size: 11px; color: var(--muted); margin-top: 5px; line-height: 1.5; }

.fc {
  width: 100%;
  padding: 13px 14px;
  background: var(--bg);
  border: 1.5px solid var(--border2);
  border-radius: 12px;
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: 15px;
  outline: none;
  transition: border-color .18s, box-shadow .18s;
  -webkit-appearance: none;
  appearance: none;
}
.fc:focus { border-color: #E8521A; box-shadow: 0 0 0 3px rgba(232,82,26,.1); }
.fc::placeholder { color: var(--muted); opacity: .5; }
textarea.fc { resize: vertical; min-height: 80px; line-height: 1.6; }
select.fc   { cursor: pointer; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23888' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 12px center; padding-right: 36px; }

.fc-big {
  font-family: 'Syne', sans-serif;
  font-weight: 700;
  font-size: 20px;
  padding: 14px 15px;
}

.fg-row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
@media (max-width: 420px) { .fg-row { grid-template-columns: 1fr; } }

/* ── Category Pills ── */
.cat-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(110px,1fr));
  gap: 8px;
}
.cat-pill {
  padding: 12px 10px;
  border-radius: 14px;
  border: 2px solid var(--border);
  background: var(--bg);
  color: var(--muted);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all .18s;
  display: flex; flex-direction: column; align-items: center; gap: 4px;
  font-family: inherit;
  text-align: center;
  line-height: 1.3;
  -webkit-tap-highlight-color: transparent;
}
.cat-pill .cp-icon { font-size: 22px; line-height: 1; }
.cat-pill .cp-name { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .4px; }
.cat-pill.selected {
  border-color: #E8521A;
  background: rgba(232,82,26,.08);
  color: #E8521A;
}
.cat-pill:active { transform: scale(.96); }

/* ══════════════════════════════════════
   IMAGE UPLOAD SYSTEM
══════════════════════════════════════ */

/* Drop zone */
.drop-zone {
  border: 2px dashed var(--border2);
  border-radius: 16px;
  padding: 26px 16px;
  text-align: center;
  cursor: pointer;
  transition: all .2s;
  background: rgba(255,255,255,.01);
  position: relative;
  overflow: hidden;
}
.drop-zone input[type=file] {
  position: absolute; inset: 0; opacity: 0; cursor: pointer;
  width: 100%; height: 100%;
}
.drop-zone:hover,
.drop-zone.dragover { border-color: #E8521A; background: rgba(232,82,26,.05); }
.drop-zone:active   { background: rgba(232,82,26,.08); }

.dz-icon  { font-size: 34px; line-height: 1; margin-bottom: 6px; }
.dz-title { font-weight: 700; font-size: 15px; color: var(--text); margin-bottom: 3px; }
.dz-sub   { font-size: 12px; color: var(--muted); margin-bottom: 12px; }
.dz-cta {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 10px 20px;
  background: rgba(232,82,26,.12);
  border: 1.5px solid rgba(232,82,26,.25);
  border-radius: 10px;
  font-size: 13px; font-weight: 700; color: #E8521A;
}
.drop-zone:hover .dz-cta,
.drop-zone:active .dz-cta { background: rgba(232,82,26,.22); }

/* Upload queue — for multiple files picked before crop */
.upload-queue {
  margin-top: 14px;
  display: flex;
  flex-direction: column;
  gap: 0;
  border-radius: 14px;
  overflow: hidden;
  border: 1px solid var(--border);
}
.uq-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  transition: background .15s;
}
.uq-item:last-child { border-bottom: none; }
.uq-thumb {
  width: 46px; height: 46px;
  border-radius: 8px;
  object-fit: cover;
  flex-shrink: 0;
  border: 1px solid var(--border);
}
.uq-info { flex: 1; min-width: 0; }
.uq-name {
  font-size: 13px; font-weight: 600; color: var(--text);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  max-width: 100%;
}
.uq-size { font-size: 11px; color: var(--muted); margin-top: 1px; }
.uq-actions { display: flex; gap: 6px; flex-shrink: 0; }
.uq-btn {
  padding: 7px 12px;
  border-radius: 8px;
  font-size: 12px; font-weight: 700;
  cursor: pointer; font-family: inherit;
  transition: all .15s; border: none;
}
.uq-crop { background: rgba(139,92,246,.12); color: #c4b5fd; }
.uq-crop:hover { background: rgba(139,92,246,.25); }
.uq-use  { background: rgba(82,183,136,.12); color: #52B788; }
.uq-use:hover  { background: rgba(82,183,136,.25); }
.uq-rm   { background: rgba(239,68,68,.1); color: #fca5a5; }
.uq-rm:hover   { background: rgba(239,68,68,.25); }

/* Progress bar */
.uprog-wrap { margin-top: 10px; display: none; }
.uprog-bar  { height: 5px; border-radius: 5px; background: var(--border); overflow: hidden; }
.uprog-fill {
  height: 100%; border-radius: 5px; width: 0%;
  background: linear-gradient(90deg,#E8521A,#FF7043);
  transition: width .25s ease;
}
.uprog-txt  { font-size: 11px; color: var(--muted); margin-top: 5px; text-align: center; }

/* OR divider */
.or-line {
  display: flex; align-items: center; gap: 10px;
  margin: 12px 0;
  color: var(--muted); font-size: 10px; font-weight: 700;
  text-transform: uppercase; letter-spacing: .8px;
}
.or-line::before, .or-line::after {
  content: ''; flex: 1; height: 1px; background: var(--border);
}

/* URL row */
.url-row { display: flex; gap: 8px; }
.url-row .fc { flex: 1; min-width: 0; font-size: 13px; }
.url-go {
  flex-shrink: 0;
  padding: 0 14px; height: 48px;
  background: rgba(139,92,246,.12);
  border: 1.5px solid rgba(139,92,246,.2);
  border-radius: 12px;
  color: #c4b5fd; font-size: 13px; font-weight: 700;
  cursor: pointer; font-family: inherit;
  white-space: nowrap;
  transition: all .15s;
}
.url-go:hover { background: rgba(139,92,246,.22); }

/* Image confirmed strip — compact, NO long URL shown */
.img-confirmed {
  display: none;
  margin-top: 12px;
  border-radius: 14px;
  overflow: hidden;
  border: 1px solid rgba(82,183,136,.25);
  background: rgba(82,183,136,.06);
}
.img-confirmed.show { display: block; }

.ic-header {
  display: flex; align-items: center; gap: 10px;
  padding: 10px 12px;
}
.ic-thumb {
  width: 52px; height: 38px;
  border-radius: 8px; object-fit: cover; flex-shrink: 0;
  border: 1px solid rgba(82,183,136,.2);
}
.ic-info { flex: 1; min-width: 0; }
.ic-status { font-size: 11px; font-weight: 800; color: #52B788; text-transform: uppercase; letter-spacing: .5px; margin-bottom: 1px; }
/* Filename shown short — no scrolling URL */
.ic-filename {
  font-size: 12px; color: var(--muted);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  max-width: 100%;
}
.ic-actions { display: flex; gap: 6px; flex-shrink: 0; }
.ic-change {
  padding: 6px 10px; border-radius: 8px;
  font-size: 11px; font-weight: 700; cursor: pointer; font-family: inherit;
  background: rgba(255,255,255,.08); border: 1px solid var(--border2); color: var(--muted);
  transition: all .15s;
}
.ic-change:hover { color: var(--text); }
.ic-remove {
  padding: 6px 10px; border-radius: 8px;
  font-size: 11px; font-weight: 700; cursor: pointer; font-family: inherit;
  background: rgba(239,68,68,.1); border: none; color: #fca5a5;
  transition: all .15s;
}
.ic-remove:hover { background: #ef4444; color: #fff; }

/* ══════════════════════════════════════
   GALLERY
══════════════════════════════════════ */
.gallery-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;
  margin-bottom: 12px;
}
@media (min-width: 400px) { .gallery-grid { grid-template-columns: repeat(4, 1fr); } }

.gal-item {
  position: relative;
  aspect-ratio: 1;
  border-radius: 10px;
  overflow: hidden;
  border: 1px solid var(--border2);
  background: var(--bg);
}
.gal-item img { width: 100%; height: 100%; object-fit: cover; display: block; }
.gal-rm {
  position: absolute; top: 3px; right: 3px;
  width: 20px; height: 20px; border-radius: 50%;
  background: rgba(0,0,0,.65); color: #fff;
  border: none; cursor: pointer; font-size: 10px;
  display: flex; align-items: center; justify-content: center;
  transition: background .15s; line-height: 1;
}
.gal-rm:hover { background: #ef4444; }
.gal-pending-label {
  position: absolute; bottom: 0; left: 0; right: 0;
  background: rgba(232,82,26,.85); color: #fff;
  font-size: 9px; font-weight: 700; text-align: center;
  padding: 3px; text-transform: uppercase; letter-spacing: .3px;
}

.gal-add-row { display: flex; gap: 8px; flex-wrap: wrap; }
.gal-url-row { display: none; margin-top: 10px; gap: 8px; align-items: center; }
.gal-url-row.visible { display: flex; }

/* ══════════════════════════════════════
   FEATURES
══════════════════════════════════════ */
.feat-row {
  display: flex; gap: 8px; align-items: center;
  margin-bottom: 8px;
  background: var(--bg);
  border: 1.5px solid var(--border);
  border-radius: 12px;
  padding: 8px 10px;
  transition: border-color .18s;
}
.feat-row:focus-within { border-color: rgba(232,82,26,.3); }
.feat-icon { width: 52px; flex-shrink: 0; text-align: center; font-size: 16px; }
.feat-text { flex: 1; }
.feat-rm {
  flex-shrink: 0;
  background: rgba(239,68,68,.1); color: #fca5a5;
  border: none; border-radius: 8px;
  padding: 8px 10px; cursor: pointer; font-size: 13px; line-height: 1;
  transition: all .15s;
}
.feat-rm:hover { background: #ef4444; color: #fff; }

/* ══════════════════════════════════════
   TOGGLES
══════════════════════════════════════ */
.toggle-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 16px;
  background: var(--bg);
  border: 1.5px solid var(--border);
  border-radius: 14px;
  margin-bottom: 10px;
  cursor: pointer;
  transition: border-color .18s;
  -webkit-tap-highlight-color: transparent;
}
.toggle-row:last-child { margin-bottom: 0; }
.toggle-row:hover { border-color: var(--border2); }
.tr-body { flex: 1; padding-right: 14px; }
.tr-title { font-weight: 700; font-size: 14px; color: var(--text); margin-bottom: 2px; }
.tr-sub   { font-size: 12px; color: var(--muted); }
.tswitch { position: relative; width: 46px; height: 26px; flex-shrink: 0; }
.tswitch input { opacity: 0; width: 0; height: 0; position: absolute; }
.tslider {
  position: absolute; inset: 0; border-radius: 26px;
  background: rgba(255,255,255,.1); cursor: pointer; transition: background .2s;
}
.tslider::before {
  content: ''; position: absolute;
  width: 20px; height: 20px; border-radius: 50%;
  background: #fff; top: 3px; left: 3px;
  transition: transform .2s;
  box-shadow: 0 1px 4px rgba(0,0,0,.3);
}
.tswitch input:checked + .tslider { background: #E8521A; }
.tswitch input:checked + .tslider::before { transform: translateX(20px); }

/* ══════════════════════════════════════
   VIDEO
══════════════════════════════════════ */
.vid-tabs { display: flex; border-radius: 12px; overflow: hidden; border: 1.5px solid var(--border2); margin-bottom: 14px; }
.vid-tab {
  flex: 1; padding: 10px 8px; text-align: center;
  font-size: 12px; font-weight: 700; color: var(--muted);
  background: var(--bg); border: none; cursor: pointer; font-family: inherit;
  transition: all .18s;
}
.vid-tab.active { color: #ff7043; background: rgba(255,112,67,.08); }
.vid-panel { display: none; }
.vid-panel.active { display: block; }
.vid-drop {
  border: 2px dashed rgba(255,112,67,.25);
  border-radius: 14px; padding: 26px 16px;
  text-align: center; cursor: pointer;
  transition: all .2s; background: rgba(255,112,67,.03);
  position: relative;
}
.vid-drop:hover { border-color: #ff7043; background: rgba(255,112,67,.07); }
.vid-drop input { position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%; }
.vid-preview-wrap { display: none; margin-top: 12px; border-radius: 12px; overflow: hidden; border: 1px solid var(--border); }
.vid-preview-wrap.show { display: block; }
.vid-preview-wrap video { width: 100%; max-height: 200px; object-fit: contain; background: #000; display: block; }
.vid-confirmed {
  margin-top: 10px; padding: 10px 12px;
  background: rgba(255,112,67,.08); border: 1px solid rgba(255,112,67,.2);
  border-radius: 12px; display: none;
  align-items: center; gap: 8px;
}
.vid-confirmed.show { display: flex; }
.vid-confirmed-icon { font-size: 20px; flex-shrink: 0; }
.vid-confirmed-name {
  flex: 1; font-size: 12px; font-weight: 600; color: var(--text);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.vid-rm {
  padding: 6px 10px; border-radius: 8px; font-size: 11px; font-weight: 700;
  background: rgba(239,68,68,.1); border: none; color: #fca5a5; cursor: pointer;
  font-family: inherit; flex-shrink: 0; transition: all .15s;
}
.vid-rm:hover { background: #ef4444; color: #fff; }

/* ══════════════════════════════════════
   STEP NAVIGATION
══════════════════════════════════════ */
.step-nav {
  display: flex; gap: 10px; align-items: center;
  margin: 20px 0 8px;
}
.btn-prev {
  width: 48px; height: 52px; flex-shrink: 0;
  border-radius: 14px; border: 1.5px solid var(--border2);
  background: var(--surface); color: var(--muted);
  font-size: 18px; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: all .15s;
}
.btn-prev:hover { color: var(--text); border-color: rgba(255,255,255,.25); }
.btn-next {
  flex: 1; height: 52px;
  border-radius: 14px;
  background: linear-gradient(135deg, #E8521A, #FF7043);
  color: #fff; border: none;
  font-family: 'Syne', sans-serif; font-weight: 800; font-size: 16px;
  cursor: pointer; transition: all .2s;
  box-shadow: 0 4px 18px rgba(232,82,26,.28);
  display: flex; align-items: center; justify-content: center; gap: 8px;
}
.btn-next:hover { transform: translateY(-1px); box-shadow: 0 8px 24px rgba(232,82,26,.35); }
.btn-next:active { transform: scale(.98); }

/* ══════════════════════════════════════
   REVIEW STEP
══════════════════════════════════════ */
.review-card {
  border-radius: 18px;
  overflow: hidden;
  border: 1px solid var(--border);
  background: var(--surface);
  margin: 14px 0;
}
.rc-hero {
  width: 100%; height: 180px;
  background: var(--border);
  position: relative; overflow: hidden;
}
.rc-hero img { width: 100%; height: 100%; object-fit: cover; display: block; }
.rc-hero-empty {
  width: 100%; height: 100%;
  display: flex; align-items: center; justify-content: center;
  font-size: 48px; opacity: .2; color: var(--muted);
}
.rc-cat-badge {
  position: absolute; top: 10px; left: 10px;
  padding: 4px 10px; border-radius: 20px;
  background: rgba(0,0,0,.6); color: #fff;
  font-size: 11px; font-weight: 700;
  backdrop-filter: blur(4px);
}
.rc-body { padding: 16px; }
.rc-title { font-family: 'Syne', sans-serif; font-weight: 800; font-size: 19px; color: var(--text); margin-bottom: 4px; }
.rc-price { font-size: 18px; font-weight: 700; color: #E8521A; margin-bottom: 12px; }
.rc-chips { display: flex; flex-wrap: wrap; gap: 8px; }
.rc-chip {
  padding: 5px 12px; border-radius: 20px;
  background: var(--bg); border: 1px solid var(--border);
  font-size: 12px; color: var(--muted);
  display: flex; align-items: center; gap: 5px;
}

/* ══════════════════════════════════════
   FLOATING SAVE BAR
══════════════════════════════════════ */
.float-save {
  position: fixed; bottom: 0; left: 0; right: 0; z-index: 200;
  padding: 12px 16px;
  background: var(--bg); border-top: 1px solid var(--border);
  display: none; gap: 10px; align-items: center;
  padding-bottom: calc(12px + env(safe-area-inset-bottom));
}
.float-save.show { display: flex; }
.btn-publish {
  flex: 1; height: 54px;
  border-radius: 15px;
  background: linear-gradient(135deg, #E8521A, #FF7043);
  color: #fff; border: none;
  font-family: 'Syne', sans-serif; font-weight: 800; font-size: 16px;
  cursor: pointer; transition: all .2s;
  box-shadow: 0 4px 20px rgba(232,82,26,.3);
  display: flex; align-items: center; justify-content: center; gap: 8px;
}
.btn-publish:hover { transform: translateY(-1px); }
.btn-publish:active { transform: scale(.98); }
.btn-del {
  width: 54px; height: 54px; flex-shrink: 0;
  border-radius: 15px;
  background: rgba(239,68,68,.1); color: #fca5a5;
  border: 1px solid rgba(239,68,68,.2);
  font-size: 20px; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  text-decoration: none; transition: all .2s;
}
.btn-del:hover { background: #ef4444; color: #fff; border-color: #ef4444; }

/* ══════════════════════════════════════
   ALERTS
══════════════════════════════════════ */
.alert {
  padding: 13px 16px; border-radius: 14px;
  margin: 14px 0; font-size: 14px; font-weight: 500;
  display: flex; align-items: center; gap: 10px;
}
.alert-ok  { background: rgba(82,183,136,.1); border: 1px solid rgba(82,183,136,.25); color: #52B788; }
.alert-err { background: rgba(239,68,68,.1);  border: 1px solid rgba(239,68,68,.2);  color: #fca5a5; }

/* ══════════════════════════════════════
   QUICK BUTTONS
══════════════════════════════════════ */
.btn-sm {
  display: inline-flex; align-items: center; gap: 5px;
  padding: 9px 14px; border-radius: 10px;
  font-size: 12px; font-weight: 700; cursor: pointer; font-family: inherit;
  transition: all .15s; border: none;
}
.btn-add { background: rgba(139,92,246,.1); color: #c4b5fd; border: 1px solid rgba(139,92,246,.2); }
.btn-add:hover { background: rgba(139,92,246,.2); }
.btn-ghost { background: var(--surface); color: var(--muted); border: 1px solid var(--border2); }
.btn-ghost:hover { color: var(--text); }

/* ══════════════════════════════════════
   CROPPER MODAL
══════════════════════════════════════ */
.crop-modal {
  display: none; position: fixed; inset: 0; z-index: 9999;
  background: rgba(0,0,0,.95);
  align-items: flex-end; justify-content: center;
  padding: 0;
}
.crop-modal.open { display: flex; }
.crop-sheet {
  background: var(--surface);
  border-radius: 24px 24px 0 0;
  width: 100%; max-height: 92vh;
  overflow: auto;
  padding: 0 0 20px;
}
.crop-handle {
  width: 36px; height: 4px; border-radius: 4px;
  background: var(--border2); margin: 12px auto 8px;
}
.crop-header {
  padding: 0 16px 14px;
  border-bottom: 1px solid var(--border);
  display: flex; align-items: center; justify-content: space-between;
}
.crop-title {
  font-family: 'Syne', sans-serif; font-weight: 800; font-size: 16px; color: var(--text);
}
.crop-close {
  width: 32px; height: 32px; border-radius: 10px;
  background: rgba(255,255,255,.08); border: none; color: var(--muted);
  font-size: 16px; cursor: pointer; display: flex; align-items: center; justify-content: center;
}
.crop-img-wrap { padding: 14px 16px; }
#cropperImage { max-width: 100%; display: block; max-height: 50vh; margin: 0 auto; }
.crop-ratio-row {
  display: flex; gap: 8px; padding: 0 16px 12px; flex-wrap: wrap;
}
.crop-ratio-btn {
  padding: 7px 14px; border-radius: 20px;
  font-size: 12px; font-weight: 700; cursor: pointer; font-family: inherit;
  border: 1.5px solid var(--border2); background: var(--bg); color: var(--muted);
  transition: all .15s;
}
.crop-ratio-btn.active {
  border-color: rgba(139,92,246,.5); background: rgba(139,92,246,.1); color: #c4b5fd;
}
.crop-actions {
  display: flex; gap: 10px; padding: 0 16px;
}
.btn-crop-cancel {
  flex: 0; padding: 13px 18px; border-radius: 12px;
  background: var(--surface); border: 1.5px solid var(--border2);
  color: var(--muted); font-size: 14px; font-weight: 700;
  cursor: pointer; font-family: inherit; transition: all .15s;
}
.btn-crop-ok {
  flex: 1; padding: 13px 18px; border-radius: 12px;
  background: #E8521A; border: none; color: #fff;
  font-family: 'Syne', sans-serif; font-weight: 800; font-size: 15px;
  cursor: pointer; transition: all .15s;
  display: flex; align-items: center; justify-content: center; gap: 6px;
}
.btn-crop-ok:active { transform: scale(.98); }

/* Destination choice inside crop modal */
.crop-dest {
  padding: 0 16px 14px;
  display: flex; gap: 8px;
}
.crop-dest-btn {
  flex: 1; padding: 10px 8px; border-radius: 12px;
  font-size: 12px; font-weight: 700; cursor: pointer; font-family: inherit;
  border: 1.5px solid var(--border2); background: var(--bg); color: var(--muted);
  text-align: center; transition: all .15s; line-height: 1.4;
}
.crop-dest-btn.selected { border-color: #E8521A; background: rgba(232,82,26,.08); color: #E8521A; }

@media (min-width: 540px) {
  .crop-sheet { border-radius: 20px; margin: auto; max-width: 520px; margin-bottom: 20px; }
  .crop-modal { align-items: center; }
}
</style>
</head>
<body>
<?php include 'nav.php'; ?>

<main class="main" style="padding-top:4px">
<div class="lf-shell">

  <!-- Alerts -->
  <?php if ($success): ?>
  <div class="alert alert-ok">✅ <?= htmlspecialchars($success) ?></div>
  <?php endif; ?>
  <?php if ($error): ?>
  <div class="alert alert-err">⚠️ <?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <!-- ══ WIZARD HEADER ══ -->
  <div class="wizard-head" id="wizardHead">
    <div class="wh-toprow">
      <a href="listings.php" class="wh-back">←</a>
      <div class="wh-title" id="whTitle"><?= $isEdit ? '✏️ '.$itemTitle : '➕ New Listing' ?></div>
      <button type="button" class="wh-quicksave" id="whQuickSave"
        onclick="submitForm()">Save</button>
    </div>
    <div class="step-rail" id="stepRail">
      <!-- Injected by JS -->
    </div>
  </div>

  <!-- ══ FORM ══ -->
  <form method="POST" id="listingForm">
    <input type="hidden" name="image_url"   id="mainImgUrl"    value="<?= $itemImg ?>">
    <input type="hidden" name="video_url"   id="videoUrlField" value="<?= $itemVideo ?>">
    <input type="hidden" name="category_id" id="catIdInput"    value="<?= $itemCatId ?: 1 ?>">

    <!-- ════════ STEP 1: BASICS ════════ -->
    <div class="form-step active" id="step1">
      <!-- Category -->
      <div class="lf-card">
        <div class="card-title">📋 What are you listing?</div>
        <div class="cat-grid" id="catGrid">
          <?php foreach ($categories as $c):
            $sel = ($itemCatId === (int)$c['id'] || (!$isEdit && $cat === $c['slug']));
          ?>
          <button type="button" class="cat-pill <?= $sel ? 'selected' : '' ?>"
            data-id="<?= (int)$c['id'] ?>"
            onclick="pickCat(this, <?= (int)$c['id'] ?>)">
            <span class="cp-icon"><?= htmlspecialchars($c['icon']) ?></span>
            <span class="cp-name"><?= htmlspecialchars($c['name']) ?></span>
          </button>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Core info -->
      <div class="lf-card">
        <div class="card-title">📝 Listing Details</div>
        <div class="fg">
          <label>Title <span class="req">*</span></label>
          <input type="text" name="title" class="fc" required autocomplete="off"
            placeholder="e.g. 2 Bedroom Apartment, Chicken Burger…"
            value="<?= $itemTitle ?>"
            oninput="syncTitle(this.value)">
        </div>
        <div class="fg">
          <label>Price <span class="req">*</span></label>
          <input type="text" name="price" class="fc fc-big" required autocomplete="off"
            placeholder="KSH 15,000 / month"
            value="<?= $itemPrice ?>"
            oninput="syncPrice(this.value)">
        </div>
        <div class="fg-row">
          <div class="fg">
            <label>Location</label>
            <input type="text" name="location" class="fc" autocomplete="off"
              placeholder="Near Malaba Market"
              value="<?= $itemLoc ?>"
              oninput="syncLoc(this.value)">
          </div>
          <div class="fg">
            <label>Badge</label>
            <input type="text" name="badge" class="fc" autocomplete="off"
              placeholder="Hot Deal, New…"
              value="<?= $itemBadge ?>">
            <span class="fg-hint">Short label on card</span>
          </div>
        </div>
        <div class="fg">
          <label>Description</label>
          <textarea name="description" class="fc"
            placeholder="Describe this listing in a few sentences…"><?= $itemDesc ?></textarea>
        </div>
      </div>

      <!-- Contact -->
      <div class="lf-card">
        <div class="card-title">📞 Seller Contact</div>
        <div class="fg-row">
          <div class="fg">
            <label>Name</label>
            <input type="text" name="contact_name" class="fc" autocomplete="off"
              placeholder="John Kamau" value="<?= $itemCname ?>">
          </div>
          <div class="fg">
            <label>WhatsApp</label>
            <input type="tel" name="contact_phone" class="fc" autocomplete="off"
              placeholder="254712…" value="<?= $itemPhone ?>">
            <span class="fg-hint">Start with 254</span>
          </div>
        </div>
      </div>

      <div class="step-nav">
        <button type="button" class="btn-next" onclick="goStep(2)">
          📸 Add Photos →
        </button>
      </div>
    </div>

    <!-- ════════ STEP 2: IMAGES ════════ -->
    <div class="form-step" id="step2">

      <!-- MAIN IMAGE -->
      <div class="lf-card">
        <div class="card-title">🖼️ Main Cover Photo</div>

        <!-- Drop zone — hidden when image confirmed -->
        <div id="mainDropZone">
          <div class="drop-zone" id="mainDz"
            ondragover="dzOver(event,this)"
            ondragleave="dzLeave(event,this)"
            ondrop="dzDrop(event,'main')">
            <input type="file" id="mainFileInp" accept="image/*" multiple
              onchange="queueFiles(this.files,'main')">
            <div class="dz-icon">📷</div>
            <div class="dz-title">Tap to choose photo(s)</div>
            <div class="dz-sub">JPG, PNG, WEBP — you can select multiple then crop each</div>
            <div class="dz-cta">📂 Choose Photo</div>
          </div>

          <!-- Queue of selected files waiting for crop -->
          <div class="upload-queue" id="mainQueue" style="display:none"></div>
          <div class="uprog-wrap" id="mainProg">
            <div class="uprog-bar"><div class="uprog-fill" id="mainProgFill"></div></div>
            <div class="uprog-txt" id="mainProgTxt">Uploading…</div>
          </div>

          <div class="or-line">or paste a URL</div>
          <div class="url-row">
            <input type="url" class="fc" id="mainUrlInp"
              placeholder="https://example.com/photo.jpg"
              value="<?= $itemImg ?>"
              oninput="onMainUrlType(this.value)">
            <button type="button" class="url-go" onclick="useMainUrl()">Use →</button>
          </div>
        </div>

        <!-- Confirmed strip — compact, shows just filename not full URL -->
        <div class="img-confirmed <?= $itemImg ? 'show' : '' ?>" id="mainConfirmed">
          <div class="ic-header">
            <img class="ic-thumb" id="mainThumb" src="<?= $itemImg ?>" alt="">
            <div class="ic-info">
              <div class="ic-status">✅ Cover photo set</div>
              <div class="ic-filename" id="mainFilename"><?= $itemImg ? basename(parse_url($itemImg, PHP_URL_PATH)) : '' ?></div>
            </div>
            <div class="ic-actions">
              <button type="button" class="ic-change" onclick="changeMainImg()">Change</button>
              <button type="button" class="ic-remove" onclick="clearMainImg()">✕</button>
            </div>
          </div>
        </div>
      </div>

      <!-- GALLERY -->
      <div class="lf-card">
        <div class="card-title">📸 Gallery
          <span style="font-family:'DM Sans',sans-serif;font-weight:400;font-size:11px;color:var(--muted);text-transform:none;letter-spacing:0;">up to 8 extra photos</span>
        </div>

        <div class="gallery-grid" id="galGrid">
          <?php foreach ($images as $gi): ?>
          <div class="gal-item">
            <img src="<?= htmlspecialchars($gi['image_url']) ?>" alt="">
            <input type="hidden" name="extra_images[]" value="<?= htmlspecialchars($gi['image_url']) ?>">
            <button type="button" class="gal-rm" onclick="removeGal(this)">✕</button>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- Gallery upload queue -->
        <div class="upload-queue" id="galQueue" style="display:none;margin-bottom:10px"></div>
        <div class="uprog-wrap" id="galProg" style="margin-bottom:10px">
          <div class="uprog-bar"><div class="uprog-fill" id="galProgFill"></div></div>
          <div class="uprog-txt" id="galProgTxt">Uploading…</div>
        </div>

        <div class="gal-add-row">
          <button type="button" class="btn-sm btn-add" onclick="document.getElementById('galFileInp').click()">
            ⬆ Upload Photos
          </button>
          <button type="button" class="btn-sm btn-ghost" onclick="toggleGalUrl()">🔗 URL</button>
          <input type="file" id="galFileInp" accept="image/*" multiple style="display:none"
            onchange="queueFiles(this.files,'gallery')">
        </div>

        <div class="gal-url-row" id="galUrlRow">
          <input type="url" class="fc" id="galUrlInp" placeholder="https://…/photo.jpg"
            onkeydown="if(event.key==='Enter'){event.preventDefault();addGalUrl();}">
          <button type="button" class="url-go" onclick="addGalUrl()">Add</button>
          <button type="button" class="feat-rm" onclick="toggleGalUrl()">✕</button>
        </div>

        <span class="fg-hint" style="display:block;margin-top:8px">Shown as swipeable carousel in Watch & Shop.</span>
      </div>

      <div class="step-nav">
        <button type="button" class="btn-prev" onclick="goStep(1)">←</button>
        <button type="button" class="btn-next" onclick="goStep(3)">✨ Features →</button>
      </div>
    </div>

    <!-- ════════ STEP 3: FEATURES + VISIBILITY ════════ -->
    <div class="form-step" id="step3">

      <div class="lf-card">
        <div class="card-title">✨ Key Features</div>
        <span class="fg-hint" style="display:block;margin-bottom:14px;">
          Add highlights with an emoji + short text.<br>
          e.g. 🛏 2 Bedrooms &nbsp;·&nbsp; 🚿 Hot Shower &nbsp;·&nbsp; 🅿️ Parking
        </span>
        <div id="featCont">
          <?php foreach ($features as $f): ?>
          <div class="feat-row">
            <input type="text" name="feat_icon[]" class="fc feat-icon" style="text-align:center"
              value="<?= htmlspecialchars($f['icon'] ?? '') ?>" placeholder="✅">
            <input type="text" name="feat_text[]" class="fc feat-text"
              value="<?= htmlspecialchars($f['feature_text'] ?? '') ?>"
              placeholder="Feature description">
            <button type="button" class="feat-rm" onclick="this.parentElement.remove()">✕</button>
          </div>
          <?php endforeach; ?>
        </div>
        <button type="button" class="btn-sm btn-add" onclick="addFeat()" style="margin-top:4px">
          ➕ Add Feature
        </button>
      </div>

      <div class="lf-card">
        <div class="card-title">⚙️ Visibility</div>

        <label class="toggle-row">
          <div class="tr-body">
            <div class="tr-title">🟢 Active</div>
            <div class="tr-sub">Visible to customers on the site</div>
          </div>
          <div class="tswitch">
            <input type="checkbox" name="is_active" <?= $itemActive ? 'checked' : '' ?>>
            <span class="tslider"></span>
          </div>
        </label>
        <label class="toggle-row">
          <div class="tr-body">
            <div class="tr-title">⭐ Featured</div>
            <div class="tr-sub">Pinned at top of category</div>
          </div>
          <div class="tswitch">
            <input type="checkbox" name="is_featured" <?= $itemFeat ? 'checked' : '' ?>>
            <span class="tslider"></span>
          </div>
        </label>
        <?php if ($hasPremiumCol): ?>
        <label class="toggle-row">
          <div class="tr-body">
            <div class="tr-title">✨ Premium</div>
            <div class="tr-sub">Premium badge on Watch & Shop</div>
          </div>
          <div class="tswitch">
            <input type="checkbox" name="is_premium" <?= $itemPrem ? 'checked' : '' ?>>
            <span class="tslider"></span>
          </div>
        </label>
        <?php endif; ?>
      </div>

      <div class="step-nav">
        <button type="button" class="btn-prev" onclick="goStep(2)">←</button>
        <button type="button" class="btn-next" onclick="goStep(<?= $hasVideoCol ? 4 : $totalSteps ?>)">
          <?= $hasVideoCol ? '🎬 Add Video →' : '👁 Review →' ?>
        </button>
      </div>
    </div>

    <!-- ════════ STEP 4: VIDEO ════════ -->
    <?php if ($hasVideoCol): ?>
    <div class="form-step" id="step4">
      <div class="lf-card">
        <div class="card-title">▶️ Watch & Shop Video</div>
        <div style="padding:12px 14px;border-radius:12px;background:rgba(139,92,246,.07);border:1px solid rgba(139,92,246,.15);font-size:12px;font-weight:600;color:#c4b5fd;margin-bottom:16px;display:flex;align-items:center;gap:8px;">
          📹 Listings with video get significantly more views in the feed.
        </div>

        <div class="vid-tabs">
          <button type="button" class="vid-tab active" onclick="switchVTab('upload',this)">⬆ Upload</button>
          <button type="button" class="vid-tab" onclick="switchVTab('url',this)">🔗 Paste Link</button>
        </div>

        <div class="vid-panel active" id="vp-upload">
          <div class="vid-drop" id="vidDz"
            ondragover="dzOver(event,this)"
            ondragleave="dzLeave(event,this)"
            ondrop="vidDrop(event)">
            <input type="file" id="vidFileInp" accept="video/*"
              onchange="handleVidFile(this)">
            <div class="dz-icon">🎬</div>
            <div class="dz-title">Drop video or tap to choose</div>
            <div class="dz-sub">MP4, MOV, WEBM · Max 100 MB</div>
            <div class="dz-cta" style="background:rgba(255,112,67,.15);color:#ff7043;border-color:rgba(255,112,67,.25);">Choose Video</div>
          </div>
          <div class="uprog-wrap" id="vidProg" style="margin-top:12px">
            <div class="uprog-bar">
              <div class="uprog-fill" id="vidProgFill" style="background:linear-gradient(90deg,#E8521A,#ff7043)"></div>
            </div>
            <div class="uprog-txt" id="vidProgTxt">Uploading video…</div>
          </div>
        </div>

        <div class="vid-panel" id="vp-url">
          <input type="url" class="fc" id="vidUrlInp"
            placeholder="https://…/video.mp4 or YouTube link"
            value="<?= $itemVideo ?>"
            oninput="setVidUrl(this.value)">
          <span class="fg-hint" style="display:block;margin-top:6px">Direct .mp4 works best for in-feed playback.</span>
        </div>

        <!-- Preview -->
        <div class="vid-preview-wrap <?= $itemVideo ? 'show' : '' ?>" id="vidPreview">
          <video id="vidEl" src="<?= $itemVideo ?>" controls muted playsinline></video>
        </div>
        <!-- Confirmed label — no long URL -->
        <div class="vid-confirmed <?= $itemVideo ? 'show' : '' ?>" id="vidConfirmed">
          <span class="vid-confirmed-icon">🎬</span>
          <span class="vid-confirmed-name" id="vidName"><?= $itemVideo ? basename(parse_url($itemVideo, PHP_URL_PATH)) : '' ?></span>
          <button type="button" class="vid-rm" onclick="clearVid()">Remove</button>
        </div>
      </div>

      <div class="step-nav">
        <button type="button" class="btn-prev" onclick="goStep(3)">←</button>
        <button type="button" class="btn-next" onclick="goStep(<?= $totalSteps ?>)">👁 Review →</button>
      </div>
    </div>
    <?php endif; ?>

    <!-- ════════ FINAL: REVIEW ════════ -->
    <div class="form-step" id="step<?= $totalSteps ?>">

      <div class="review-card">
        <div class="rc-hero">
          <img id="rv-img" src="<?= $itemImg ?>" alt="" style="<?= $itemImg ? '' : 'display:none' ?>">
          <div class="rc-hero-empty" id="rv-img-ph" style="<?= $itemImg ? 'display:none' : '' ?>">🖼️</div>
          <div class="rc-cat-badge" id="rv-cat">
            <?php
              $catName = '';
              foreach ($categories as $c) {
                if ((int)$c['id'] === $itemCatId) { $catName = $c['icon'].' '.$c['name']; break; }
              }
              echo htmlspecialchars($catName ?: 'Select category');
            ?>
          </div>
        </div>
        <div class="rc-body">
          <div class="rc-title" id="rv-title"><?= $itemTitle ?: 'Your listing title' ?></div>
          <div class="rc-price" id="rv-price"><?= $itemPrice ?: 'Add a price' ?></div>
          <div class="rc-chips">
            <span class="rc-chip">📍 <span id="rv-loc"><?= $itemLoc ?: '—' ?></span></span>
            <span class="rc-chip">📱 <span id="rv-phone"><?= $itemPhone ?: '—' ?></span></span>
          </div>
        </div>
      </div>

      <div class="lf-card" style="text-align:center;padding:20px 16px">
        <div style="font-size:32px;margin-bottom:8px"><?= $isEdit ? '💾' : '🚀' ?></div>
        <div style="font-weight:700;font-size:16px;color:var(--text);margin-bottom:4px">
          <?= $isEdit ? 'Ready to save changes?' : 'Ready to publish?' ?>
        </div>
        <div style="font-size:13px;color:var(--muted)">
          Tap any step above to edit, or hit <?= $isEdit ? 'Save' : 'Publish' ?> below.
        </div>
      </div>

      <!-- Step nav still shown so user can go back -->
      <div class="step-nav" style="margin-bottom:80px">
        <button type="button" class="btn-prev" onclick="goStep(<?= $totalSteps - 1 ?>)">←</button>
        <button type="submit" class="btn-next">
          <?= $isEdit ? '💾 Save Changes' : '🚀 Publish Listing' ?>
        </button>
      </div>
    </div>

  </form>
</div>
</main>

<!-- ══ FLOATING SAVE BAR (final step only) ══ -->
<div class="float-save" id="floatSave">
  <button type="submit" form="listingForm" class="btn-publish">
    <?= $isEdit ? '💾 Save Changes' : '🚀 Publish' ?>
  </button>
  <?php if ($isEdit): ?>
  <a href="listing_delete.php?id=<?= htmlspecialchars($item['id']) ?>"
    class="btn-del"
    onclick="return confirm('Permanently delete this listing?')">🗑</a>
  <?php endif; ?>
</div>

<!-- ══ CROP MODAL (bottom sheet) ══ -->
<div id="cropModal" class="crop-modal">
  <div class="crop-sheet">
    <div class="crop-handle"></div>
    <div class="crop-header">
      <div class="crop-title" id="cropModalTitle">✂️ Crop Photo</div>
      <button type="button" class="crop-close" onclick="closeCrop()">✕</button>
    </div>

    <!-- Destination choice -->
    <div class="crop-dest" id="cropDestRow">
      <button type="button" class="crop-dest-btn selected" id="cdMain" onclick="setCropDest('main',this)">
        🖼️ Set as<br>Cover Photo
      </button>
      <button type="button" class="crop-dest-btn" id="cdGal" onclick="setCropDest('gallery',this)">
        📸 Add to<br>Gallery
      </button>
    </div>

    <!-- Ratio buttons -->
    <div class="crop-ratio-row">
      <button type="button" class="crop-ratio-btn active" onclick="setRatio(16/9,this)">16:9</button>
      <button type="button" class="crop-ratio-btn" onclick="setRatio(4/3,this)">4:3</button>
      <button type="button" class="crop-ratio-btn" onclick="setRatio(1,this)">1:1</button>
      <button type="button" class="crop-ratio-btn" onclick="setRatio(NaN,this)">Free</button>
    </div>

    <div class="crop-img-wrap">
      <img id="cropperImage" alt="">
    </div>

    <div class="crop-actions">
      <button type="button" class="btn-crop-cancel" onclick="skipCropUpload()">Skip crop</button>
      <button type="button" class="btn-crop-ok" onclick="saveCrop()">✅ Use this crop</button>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.2/cropper.min.js"></script>
<script>
/* ═══════════════════════════════════════════════════════
   MALABA LISTING FORM JS — v3
   Progressive steps · multi-file queue · crop-before-upload
   Compact image labels — no long URLs shown to user
═══════════════════════════════════════════════════════ */
const CLOUD  = '<?= $CLOUDINARY_CLOUD_NAME ?>';
const PRESET = '<?= $CLOUDINARY_UPLOAD_PRESET ?>';
const TOTAL  = <?= $totalSteps ?>;
const IS_EDIT = <?= $isEdit ? 'true' : 'false' ?>;

/* ── State ── */
let curStep     = 1;
let doneSteps   = new Set(IS_EDIT ? [1,2,3,4,5] : []);
let cropInst    = null;
let cropQueue   = [];   // [{file, objectUrl, target}]
let cropIdx     = 0;
let cropDest    = 'main';   // 'main' | 'gallery'

/* ══ STEP CONFIG ══ */
const STEPS = [
  { label:'Basics',  icon:'📋' },
  { label:'Photos',  icon:'📸' },
  { label:'Details', icon:'✨' },
  <?= $hasVideoCol ? "{ label:'Video', icon:'🎬' }," : '' ?>
  { label:'Review',  icon:'👁' },
];

/* ══════════════════════════════════════
   WIZARD INIT & NAVIGATION
══════════════════════════════════════ */
(function buildRail() {
  var rail = document.getElementById('stepRail');
  STEPS.forEach(function(s, i) {
    var n   = i + 1;
    var div = document.createElement('div');
    div.className = 'sr-step' + (n === 1 ? ' active' : '') + (IS_EDIT ? ' done' : '');
    div.dataset.step = n;
    div.onclick = function() { goStep(n); };
    div.innerHTML =
      '<div class="sr-circle" id="src'+n+'">' +
        (IS_EDIT ? '✓' : n) +
      '</div>' +
      '<div class="sr-label">'+s.label+'</div>';
    rail.appendChild(div);
  });
})();

function goStep(n) {
  if (n < 1 || n > TOTAL) return;
  doneSteps.add(curStep);
  curStep = n;

  document.querySelectorAll('.form-step').forEach(function(el){ el.classList.remove('active'); });
  var el = document.getElementById('step' + n);
  if (el) el.classList.add('active');

  updateRail();
  updateReview();

  // Floating save bar on last step
  var fsave = document.getElementById('floatSave');
  fsave.classList.toggle('show', n === TOTAL);

  // Quick-save button visible after step 1
  document.getElementById('whQuickSave').classList.toggle('visible', n > 1);

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function updateRail() {
  document.querySelectorAll('.sr-step').forEach(function(el) {
    var n   = parseInt(el.dataset.step);
    var cir = document.getElementById('src' + n);
    el.classList.remove('active','done');
    if (n === curStep) {
      el.classList.add('active');
      cir.textContent = STEPS[n-1].icon;
    } else if (doneSteps.has(n)) {
      el.classList.add('done');
      cir.textContent = '✓';
    } else {
      cir.textContent = n;
    }
  });
}

function submitForm() { document.getElementById('listingForm').submit(); }

/* ══════════════════════════════════════
   CATEGORY
══════════════════════════════════════ */
var catNames = {};
<?php foreach ($categories as $c): ?>
catNames[<?= (int)$c['id'] ?>] = '<?= addslashes($c['icon'].' '.$c['name']) ?>';
<?php endforeach; ?>

function pickCat(btn, id) {
  document.querySelectorAll('.cat-pill').forEach(function(p){ p.classList.remove('selected'); });
  btn.classList.add('selected');
  document.getElementById('catIdInput').value = id;
  document.getElementById('rv-cat').textContent = catNames[id] || '';
}

/* ══════════════════════════════════════
   REVIEW SYNC
══════════════════════════════════════ */
function syncTitle(v)  { document.getElementById('rv-title').textContent = v || 'Your listing title'; }
function syncPrice(v)  { document.getElementById('rv-price').textContent = v || 'Add a price'; }
function syncLoc(v)    { document.getElementById('rv-loc').textContent   = v || '—'; }

function updateReview() {
  if (curStep !== TOTAL) return;
  var f = document.getElementById('listingForm');
  syncTitle(f.querySelector('[name="title"]').value);
  syncPrice(f.querySelector('[name="price"]').value);
  syncLoc(f.querySelector('[name="location"]').value);
  document.getElementById('rv-phone').textContent = f.querySelector('[name="contact_phone"]').value || '—';
  var imgUrl = document.getElementById('mainImgUrl').value;
  var rvi = document.getElementById('rv-img');
  var rvp = document.getElementById('rv-img-ph');
  if (imgUrl) { rvi.src = imgUrl; rvi.style.display = 'block'; rvp.style.display = 'none'; }
  else        { rvi.style.display = 'none'; rvp.style.display = 'flex'; }
}

/* ══════════════════════════════════════
   DRAG & DROP HELPERS
══════════════════════════════════════ */
function dzOver(e, el)  { e.preventDefault(); el.classList.add('dragover'); }
function dzLeave(e, el) { el.classList.remove('dragover'); }
function dzDrop(e, target) {
  e.preventDefault(); e.currentTarget.classList.remove('dragover');
  var file = e.dataTransfer.files[0];
  if (file && file.type.startsWith('image/')) openCropSingle(file, target);
}
function vidDrop(e) {
  e.preventDefault(); e.currentTarget.classList.remove('dragover');
  var file = e.dataTransfer.files[0];
  if (file && file.type.startsWith('video/')) uploadVideo(file);
}

/* ══════════════════════════════════════
   MULTI-FILE QUEUE SYSTEM
   User picks N files → queue renders with thumb + Crop / Use As-Is / Remove
══════════════════════════════════════ */
function queueFiles(files, target) {
  if (!files || !files.length) return;
  cropQueue = [];
  cropIdx   = 0;

  // Build queue array
  Array.from(files).forEach(function(f) {
    if (!f.type.startsWith('image/')) return;
    cropQueue.push({ file: f, objectUrl: URL.createObjectURL(f), target: target });
  });

  renderQueue(target);

  // Reset input
  if (target === 'main') document.getElementById('mainFileInp').value = '';
  else                   document.getElementById('galFileInp').value  = '';
}

function renderQueue(target) {
  var isMain = (target === 'main');
  var qEl = document.getElementById(isMain ? 'mainQueue' : 'galQueue');
  qEl.innerHTML = '';

  if (!cropQueue.length) { qEl.style.display = 'none'; return; }
  qEl.style.display = 'flex';
  qEl.style.flexDirection = 'column';

  cropQueue.forEach(function(item, i) {
    var div = document.createElement('div');
    div.className = 'uq-item';
    div.id = 'qitem' + i;

    var shortName = item.file.name.length > 28
      ? item.file.name.substring(0,25) + '…'
      : item.file.name;
    var sizeTxt = (item.file.size / 1024 / 1024).toFixed(1) + ' MB';

    div.innerHTML =
      '<img class="uq-thumb" src="'+item.objectUrl+'" alt="">' +
      '<div class="uq-info">' +
        '<div class="uq-name">'+escH(shortName)+'</div>' +
        '<div class="uq-size">'+sizeTxt+'</div>' +
      '</div>' +
      '<div class="uq-actions">' +
        '<button type="button" class="uq-btn uq-crop" onclick="openCropFromQueue('+i+',\''+target+'\')">✂️ Crop</button>' +
        '<button type="button" class="uq-btn uq-use"  onclick="useAsIs('+i+',\''+target+'\')">⬆ Upload</button>' +
        '<button type="button" class="uq-btn uq-rm"   onclick="removeFromQueue('+i+',\''+target+'\')">✕</button>' +
      '</div>';
    qEl.appendChild(div);
  });
}

function removeFromQueue(i, target) {
  URL.revokeObjectURL(cropQueue[i].objectUrl);
  cropQueue.splice(i, 1);
  renderQueue(target);
}

/* Upload file as-is (no crop) */
function useAsIs(i, target) {
  var item = cropQueue[i];
  uploadToCloudinary(item.file, target, function() {
    removeFromQueue(i, target);
  });
}

/* Open crop modal for a specific queue item */
function openCropFromQueue(i, target) {
  cropIdx  = i;
  cropDest = target;
  // Pre-select dest button
  document.getElementById('cdMain').classList.toggle('selected', target === 'main');
  document.getElementById('cdGal').classList.toggle('selected', target === 'gallery');
  var item = cropQueue[i];
  _openCropModal(item.objectUrl, target, item.file.name);
}

/* Open crop for a single dropped file */
function openCropSingle(file, target) {
  cropQueue = [{ file: file, objectUrl: URL.createObjectURL(file), target: target }];
  cropIdx   = 0;
  cropDest  = target;
  document.getElementById('cdMain').classList.toggle('selected', target === 'main');
  document.getElementById('cdGal').classList.toggle('selected', target === 'gallery');
  _openCropModal(URL.createObjectURL(file), target, file.name);
}

function _openCropModal(src, target, name) {
  var modal = document.getElementById('cropModal');
  var img   = document.getElementById('cropperImage');
  img.src   = src;
  modal.classList.add('open');
  if (cropInst) { cropInst.destroy(); cropInst = null; }
  var ratio = (target === 'main') ? 16/9 : 4/3;
  cropInst = new Cropper(img, {
    aspectRatio: ratio,
    viewMode: 2,
    autoCropArea: .9,
    movable: true,
    zoomable: true,
  });
  // Mark active ratio button
  document.querySelectorAll('.crop-ratio-btn').forEach(function(b){ b.classList.remove('active'); });
  var ratioLabel = (target === 'main') ? '16:9' : '4:3';
  document.querySelectorAll('.crop-ratio-btn').forEach(function(b){
    if (b.textContent === ratioLabel) b.classList.add('active');
  });
}

function closeCrop() {
  document.getElementById('cropModal').classList.remove('open');
  if (cropInst) { cropInst.destroy(); cropInst = null; }
}

function setCropDest(dest, btn) {
  cropDest = dest;
  document.querySelectorAll('.crop-dest-btn').forEach(function(b){ b.classList.remove('selected'); });
  btn.classList.add('selected');
  var ratio = (dest === 'main') ? 16/9 : 4/3;
  if (cropInst) cropInst.setAspectRatio(ratio);
}

function setRatio(r, btn) {
  document.querySelectorAll('.crop-ratio-btn').forEach(function(b){ b.classList.remove('active'); });
  btn.classList.add('active');
  if (cropInst) cropInst.setAspectRatio(isNaN(r) ? NaN : r);
}

function saveCrop() {
  if (!cropInst) return;
  var isMain = (cropDest === 'main');
  var canvas = cropInst.getCroppedCanvas({
    width:  isMain ? 1200 : 800,
    height: isMain ? 675  : 600,
  });
  var qItem = cropQueue[cropIdx];
  var fname = qItem ? qItem.file.name : 'cropped.jpg';
  canvas.toBlob(function(blob) {
    blob._name = fname;
    closeCrop();
    uploadToCloudinary(blob, cropDest, function() {
      // Remove from queue after upload
      if (qItem) {
        URL.revokeObjectURL(qItem.objectUrl);
        cropQueue.splice(cropIdx, 1);
        renderQueue(qItem.target);
      }
    });
  }, 'image/jpeg', .88);
}

/* Skip crop — upload original */
function skipCropUpload() {
  var qItem = cropQueue[cropIdx];
  if (!qItem) { closeCrop(); return; }
  closeCrop();
  uploadToCloudinary(qItem.file, cropDest, function() {
    URL.revokeObjectURL(qItem.objectUrl);
    cropQueue.splice(cropIdx, 1);
    renderQueue(qItem.target);
  });
}

/* ══════════════════════════════════════
   CLOUDINARY IMAGE UPLOAD
══════════════════════════════════════ */
function uploadToCloudinary(blob, target, cb) {
  var isMain = (target === 'main');
  var pw = document.getElementById(isMain ? 'mainProg' : 'galProg');
  var pf = document.getElementById(isMain ? 'mainProgFill' : 'galProgFill');
  var pt = document.getElementById(isMain ? 'mainProgTxt'  : 'galProgTxt');

  var fd = new FormData();
  fd.append('file', blob, blob._name || 'photo.jpg');
  fd.append('upload_preset', PRESET);

  var xhr = new XMLHttpRequest();
  xhr.open('POST', 'https://api.cloudinary.com/v1_1/'+CLOUD+'/image/upload');
  xhr.upload.onprogress = function(e) {
    if (!e.lengthComputable) return;
    var p = Math.round(e.loaded/e.total*100);
    pw.style.display  = 'block';
    pf.style.width    = p+'%';
    pt.textContent    = 'Uploading… '+p+'%';
  };
  xhr.onload = function() {
    pw.style.display = 'none';
    try {
      var d = JSON.parse(xhr.responseText);
      if (d.secure_url) {
        if (isMain) setMainImg(d.secure_url, d.original_filename || 'photo');
        else        addGalImg(d.secure_url, d.original_filename || 'photo');
        if (cb) cb();
      } else {
        alert('Upload error: '+(d.error ? d.error.message : 'Unknown'));
      }
    } catch(e) { alert('Upload failed. Try again.'); }
  };
  xhr.onerror = function() { pw.style.display = 'none'; alert('Network error.'); };
  xhr.send(fd);
}

/* ══════════════════════════════════════
   MAIN IMAGE HELPERS
══════════════════════════════════════ */
function setMainImg(url, label) {
  document.getElementById('mainImgUrl').value   = url;
  document.getElementById('mainThumb').src       = url;
  // Show ONLY short filename — not the full URL
  var short = label || extractShortName(url);
  document.getElementById('mainFilename').textContent = short;
  document.getElementById('mainConfirmed').classList.add('show');
  document.getElementById('mainDropZone').style.display = 'none';
}
function clearMainImg() {
  document.getElementById('mainImgUrl').value   = '';
  document.getElementById('mainUrlInp').value   = '';
  document.getElementById('mainConfirmed').classList.remove('show');
  document.getElementById('mainDropZone').style.display = 'block';
}
function changeMainImg() {
  clearMainImg();
}
function onMainUrlType(v) {
  document.getElementById('mainImgUrl').value = v;
}
function useMainUrl() {
  var url = document.getElementById('mainUrlInp').value.trim();
  if (!url) { alert('Paste a URL first.'); return; }
  var img = new Image();
  img.onload  = function() { setMainImg(url, extractShortName(url)); };
  img.onerror = function() { alert('Could not load image from that URL.'); };
  img.src = url;
}

/* ══════════════════════════════════════
   GALLERY HELPERS
══════════════════════════════════════ */
function addGalImg(url, label) {
  var grid = document.getElementById('galGrid');
  var div  = document.createElement('div');
  div.className = 'gal-item';
  div.innerHTML =
    '<img src="'+escH(url)+'" alt="">' +
    '<input type="hidden" name="extra_images[]" value="'+escH(url)+'">' +
    '<button type="button" class="gal-rm" onclick="removeGal(this)">✕</button>';
  grid.appendChild(div);
}
function removeGal(btn) { btn.closest('.gal-item').remove(); }
function toggleGalUrl() {
  var r = document.getElementById('galUrlRow');
  r.classList.toggle('visible');
  if (r.classList.contains('visible')) document.getElementById('galUrlInp').focus();
}
function addGalUrl() {
  var inp = document.getElementById('galUrlInp');
  var url = inp.value.trim();
  if (!url) { alert('Paste a URL first.'); return; }
  addGalImg(url, extractShortName(url));
  inp.value = '';
  document.getElementById('galUrlRow').classList.remove('visible');
}

/* ══════════════════════════════════════
   VIDEO
══════════════════════════════════════ */
function switchVTab(tab, btn) {
  document.querySelectorAll('.vid-tab').forEach(function(t){ t.classList.remove('active'); });
  document.querySelectorAll('.vid-panel').forEach(function(p){ p.classList.remove('active'); });
  btn.classList.add('active');
  document.getElementById('vp-'+tab).classList.add('active');
}
function handleVidFile(input) {
  var file = input.files[0];
  if (!file) return;
  uploadVideo(file);
  input.value = '';
}
function uploadVideo(file) {
  var pw = document.getElementById('vidProg');
  var pf = document.getElementById('vidProgFill');
  var pt = document.getElementById('vidProgTxt');
  var fd = new FormData();
  fd.append('file', file);
  fd.append('upload_preset', PRESET);
  var xhr = new XMLHttpRequest();
  xhr.open('POST', 'https://api.cloudinary.com/v1_1/'+CLOUD+'/video/upload');
  xhr.upload.onprogress = function(e) {
    if (!e.lengthComputable) return;
    var p = Math.round(e.loaded/e.total*100);
    pw.style.display = 'block';
    pf.style.width   = p+'%';
    pt.textContent   = 'Uploading video… '+p+'%';
  };
  xhr.onload = function() {
    pw.style.display = 'none';
    try {
      var d = JSON.parse(xhr.responseText);
      if (d.secure_url) setVidUrl(d.secure_url, file.name);
      else alert('Video error: '+(d.error ? d.error.message : 'Unknown'));
    } catch(e) { alert('Video upload failed.'); }
  };
  xhr.onerror = function() { pw.style.display = 'none'; alert('Network error.'); };
  xhr.send(fd);
}
function setVidUrl(url, label) {
  document.getElementById('videoUrlField').value = url;
  var vi = document.getElementById('vidUrlInp');
  if (vi) vi.value = url;
  var wrap = document.getElementById('vidPreview');
  var vid  = document.getElementById('vidEl');
  var conf = document.getElementById('vidConfirmed');
  var nm   = document.getElementById('vidName');
  if (url) {
    vid.src = url;
    wrap.classList.add('show');
    conf.classList.add('show');
    // Show only short name, not full Cloudinary URL
    nm.textContent = label || extractShortName(url);
  } else {
    wrap.classList.remove('show');
    conf.classList.remove('show');
  }
}
function clearVid() {
  setVidUrl('');
  document.getElementById('vidEl').src = '';
}

/* ══════════════════════════════════════
   FEATURES
══════════════════════════════════════ */
function addFeat() {
  var c   = document.getElementById('featCont');
  var row = document.createElement('div');
  row.className = 'feat-row';
  row.innerHTML =
    '<input type="text" name="feat_icon[]" class="fc feat-icon" placeholder="✅" style="text-align:center">' +
    '<input type="text" name="feat_text[]" class="fc feat-text" placeholder="Feature description">' +
    '<button type="button" class="feat-rm" onclick="this.parentElement.remove()">✕</button>';
  c.appendChild(row);
  row.querySelector('.feat-text').focus();
}

/* ══════════════════════════════════════
   UTILS
══════════════════════════════════════ */
function escH(s) {
  return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

/* Extract a short human-readable name from a URL — no query params, no long IDs */
function extractShortName(url) {
  try {
    var u    = new URL(url);
    var path = u.pathname;
    var seg  = path.split('/').filter(Boolean);
    var last = seg[seg.length - 1] || 'image';
    // Strip Cloudinary version prefix like "v1234567890/"
    last = last.replace(/^v\d+_/, '');
    // Truncate if too long
    if (last.length > 36) last = last.substring(0, 33) + '…';
    return last;
  } catch(e) {
    return url.length > 36 ? url.substring(0,33)+'…' : url;
  }
}

/* Close crop modal on backdrop tap */
document.getElementById('cropModal').addEventListener('click', function(e) {
  if (e.target === this) closeCrop();
});

/* ══════════════════════════════════════
   INIT
══════════════════════════════════════ */
(function init() {
  // If edit mode, all steps already done
  if (IS_EDIT) {
    for (var i = 1; i <= TOTAL; i++) doneSteps.add(i);
  }
  updateRail();

  // Restore category selection highlight
  var catId = parseInt(document.getElementById('catIdInput').value);
  if (catId) {
    document.querySelectorAll('.cat-pill').forEach(function(p) {
      if (parseInt(p.dataset.id) === catId) p.classList.add('selected');
    });
  }

  // If main image already set, show confirmed strip
  var existingImg = document.getElementById('mainImgUrl').value;
  if (existingImg) {
    document.getElementById('mainDropZone').style.display = 'none';
    document.getElementById('mainConfirmed').classList.add('show');
  }
})();
</script>
</body>
</html>