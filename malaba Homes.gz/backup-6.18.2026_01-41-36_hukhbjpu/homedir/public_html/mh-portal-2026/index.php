<?php
require_once 'auth.php';
require_once 'db.php';

$db    = getDB();
$stats = $db->query("SELECT * FROM v_dashboard_stats")->fetch();
$recent = $db->query("
    SELECT l.id, l.title, l.price, l.is_active, l.updated_at, c.name AS cat, c.icon
    FROM listings l JOIN categories c ON l.category_id = c.id
    ORDER BY l.updated_at DESC LIMIT 6
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — Malaba Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
<?php include 'admin.css.php'; ?>
</style>
</head>
<body>
<?php include 'nav.php'; ?>

<main class="main">
    <div class="page-header">
        <div>
            <h1 class="page-title">Dashboard</h1>
            <p class="page-sub">Welcome back, <?= htmlspecialchars($_SESSION['admin_name']) ?> 👋</p>
        </div>
        <a href="listing_form.php" class="btn btn-primary">+ Add Listing</a>
    </div>

    <!-- Stats Grid -->
    <div class="stats-grid">
        <div class="stat-card purple">
            <div class="stat-icon">🏠</div>
            <div class="stat-val"><?= $stats['total_houses'] ?></div>
            <div class="stat-label">Homes</div>
        </div>
        <div class="stat-card pink">
            <div class="stat-icon">🍔</div>
            <div class="stat-val"><?= $stats['total_food'] ?></div>
            <div class="stat-label">Food Items</div>
        </div>
        <div class="stat-card green">
            <div class="stat-icon">🛋️</div>
            <div class="stat-val"><?= $stats['total_items'] ?></div>
            <div class="stat-label">Shop Items</div>
        </div>
        <div class="stat-card blue">
            <div class="stat-icon">💬</div>
            <div class="stat-val"><?= $stats['total_inquiries'] ?></div>
            <div class="stat-label">Total Inquiries</div>
        </div>
    </div>

    <!-- Quick Links -->
    <div class="section-title">Browse by Category</div>
    <div class="quick-links">
        <a href="listings.php?cat=houses" class="ql-card purple">
            <span class="ql-icon">🏠</span>
            <span class="ql-label">Manage Homes</span>
            <span class="ql-arrow">→</span>
        </a>
        <a href="listings.php?cat=food" class="ql-card pink">
            <span class="ql-icon">🍔</span>
            <span class="ql-label">Manage Food</span>
            <span class="ql-arrow">→</span>
        </a>
        <a href="listings.php?cat=items" class="ql-card green">
            <span class="ql-icon">🛋️</span>
            <span class="ql-label">Manage Shopping</span>
            <span class="ql-arrow">→</span>
        </a>
        <a href="inquiries.php" class="ql-card blue">
            <span class="ql-icon">💬</span>
            <span class="ql-label">View Inquiries</span>
            <span class="ql-arrow">→</span>
        </a>
    </div>

    <!-- Recent Listings -->
    <div class="section-title" style="margin-top:40px;">Recent Listings</div>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Listing</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Updated</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($recent as $r): ?>
                <tr>
                    <td class="td-title"><?= htmlspecialchars($r['title']) ?></td>
                    <td><span class="badge <?= getCatClass($r['cat']) ?>"><?= $r['icon'] ?> <?= $r['cat'] ?></span></td>
                    <td class="td-price"><?= htmlspecialchars($r['price']) ?></td>
                    <td><?= $r['is_active'] ? '<span class="badge green">Active</span>' : '<span class="badge gray">Hidden</span>' ?></td>
                    <td class="td-date"><?= date('d M Y', strtotime($r['updated_at'])) ?></td>
                    <td class="td-actions">
                        <a href="listing_form.php?id=<?= $r['id'] ?>" class="act-btn edit">Edit</a>
                        <a href="listing_delete.php?id=<?= $r['id'] ?>" class="act-btn del" onclick="return confirm('Delete this listing?')">Del</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>
<?php
function getCatClass($cat) {
    return match(strtolower($cat)) {
        'homes'    => 'purple',
        'food'     => 'pink',
        'shopping' => 'green',
        default    => 'blue'
    };
}
?>
