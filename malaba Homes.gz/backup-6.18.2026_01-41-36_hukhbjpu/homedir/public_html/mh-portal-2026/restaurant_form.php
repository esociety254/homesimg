<?php
/**
 * admin/restaurant_form.php
 * Add or edit a restaurant + manage its menu items
 */
require_once 'auth.php';
require_once 'db.php';
requirePerm('listings');

$db    = getDB();
$id    = isset($_GET['id']) ? trim($_GET['id']) : null;
$rest  = null;
$items = array();
$msg   = '';
$err   = '';

$CLOUDINARY_CLOUD_NAME   = 'dsqo3yxkz';
$CLOUDINARY_UPLOAD_PRESET= 'malaba_default';

/* ── Load existing restaurant ── */
if ($id) {
    $s = $db->prepare("SELECT * FROM restaurants WHERE id = ?");
    $s->execute(array($id));
    $rest = $s->fetch(PDO::FETCH_ASSOC);
    if (!$rest) { header('Location: restaurants.php'); exit; }

    /* Load menu items */
    $si = $db->prepare(
        "SELECT l.*, GROUP_CONCAT(li.image_url ORDER BY li.sort_order SEPARATOR '||') AS gallery
         FROM listings l
         LEFT JOIN listing_images li ON li.listing_id = l.id
         WHERE l.restaurant_id = ? AND l.category_id = 2
         GROUP BY l.id
         ORDER BY l.is_featured DESC, l.views DESC"
    );
    $si->execute(array($id));
    $items = $si->fetchAll(PDO::FETCH_ASSOC);
}

/* ── Handle restaurant save ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    /* ── SAVE RESTAURANT ── */
    if ($_POST['action'] === 'save_restaurant') {
        $name    = trim($_POST['name']         ?? '');
        $desc    = trim($_POST['description']  ?? '');
        $img     = trim($_POST['image_url']    ?? '');
        $loc     = trim($_POST['location']     ?? '');
        $phone   = trim($_POST['contact_phone']?? '');
        $cname   = trim($_POST['contact_name'] ?? '');
        $cuisine = trim($_POST['cuisine']      ?? '');
        $delTime = trim($_POST['delivery_time']?? '');
        $hours   = trim($_POST['opening_hours']?? '');
        $badge   = trim($_POST['badge']        ?? '');
        $minOrd  = (int)($_POST['min_order']   ?? 0);
        $delFee  = (int)($_POST['delivery_fee']?? 50);
        $feat    = isset($_POST['is_featured']) ? 1 : 0;
        $active  = isset($_POST['is_active'])   ? 1 : 0;

        if (!$name) { $err = 'Restaurant name is required.'; }
        else {
            try {
                if ($rest) {
                    /* Update */
                    $db->prepare(
                        "UPDATE restaurants SET name=?,description=?,image_url=?,location=?,
                         contact_phone=?,contact_name=?,cuisine=?,delivery_time=?,opening_hours=?,
                         badge=?,min_order=?,delivery_fee=?,is_featured=?,is_active=?,updated_at=NOW()
                         WHERE id=?"
                    )->execute(array($name,$desc,$img,$loc,$phone,$cname,$cuisine,$delTime,
                                     $hours,$badge,$minOrd,$delFee,$feat,$active,$id));
                    $msg = 'Restaurant updated successfully!';
                    /* Reload */
                    $rest = $db->prepare("SELECT * FROM restaurants WHERE id=?")->execute(array($id)) ? null : $rest;
                    $s2=$db->prepare("SELECT * FROM restaurants WHERE id=?"); $s2->execute(array($id)); $rest=$s2->fetch(PDO::FETCH_ASSOC);
                } else {
                    /* Insert — generate ID */
                    $count = (int)$db->query("SELECT COUNT(*) FROM restaurants")->fetchColumn();
                    $newId = 'r'.($count+1).rand(10,99);
                    $db->prepare(
                        "INSERT INTO restaurants (id,name,description,image_url,location,
                         contact_phone,contact_name,cuisine,delivery_time,opening_hours,
                         badge,min_order,delivery_fee,is_featured,is_active)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    )->execute(array($newId,$name,$desc,$img,$loc,$phone,$cname,$cuisine,
                                     $delTime,$hours,$badge,$minOrd,$delFee,$feat,$active));
                    header('Location: restaurant_form.php?id='.urlencode($newId).'&added=1');
                    exit;
                }
            } catch (Exception $e) { $err = 'DB error: '.$e->getMessage(); }
        }
    }

    /* ── ADD / UPDATE MENU ITEM ── */
    if ($_POST['action'] === 'save_item' && $id) {
        $iId    = trim($_POST['item_id']  ?? '');
        $iTitle = trim($_POST['item_title']?? '');
        $iDesc  = trim($_POST['item_desc'] ?? '');
        $iPrice = trim($_POST['item_price']?? '');
        $iImg   = trim($_POST['item_image']?? '');
        $iBadge = trim($_POST['item_badge']?? '');
        $iPrepT = trim($_POST['item_prep'] ?? '');
        $iCat   = trim($_POST['item_category']?? '');
        $iFeat  = isset($_POST['item_featured']) ? 1 : 0;
        $iActive= isset($_POST['item_active'])   ? 1 : 0;
        $iExtraImgs = isset($_POST['item_extra_images']) && is_array($_POST['item_extra_images'])
                    ? array_filter(array_map('trim',$_POST['item_extra_images'])) : array();

        if (!$iTitle || !$iPrice) { $err = 'Item title and price are required.'; }
        else {
            try {
                if ($iId) {
                    /* Update existing item */
                    $db->prepare(
                        "UPDATE listings SET title=?,description=?,price=?,image_url=?,badge=?,
                         prep_time=?,sub_category=?,is_featured=?,is_active=?,
                         contact_phone=?,updated_at=NOW()
                         WHERE id=? AND restaurant_id=?"
                    )->execute(array($iTitle,$iDesc,$iPrice,$iImg,$iBadge,$iPrepT,
                                     $iCat,$iFeat,$iActive,$rest['contact_phone'],$iId,$id));
                    /* Refresh gallery */
                    $db->prepare("DELETE FROM listing_images WHERE listing_id=?")->execute(array($iId));
                } else {
                    /* Insert new item */
                    $iCount = (int)$db->query("SELECT COUNT(*) FROM listings WHERE category_id=2")->fetchColumn();
                    $iId = 'f'.($iCount+1+rand(10,99));
                    $db->prepare(
                        "INSERT INTO listings (id,category_id,restaurant_id,title,description,price,
                         image_url,badge,prep_time,sub_category,is_featured,is_active,
                         location,contact_phone,contact_name)
                         VALUES (?,2,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    )->execute(array($iId,$id,$iTitle,$iDesc,$iPrice,$iImg,$iBadge,
                                     $iPrepT,$iCat,$iFeat,$iActive,
                                     $rest['location'],$rest['contact_phone'],$rest['name']));
                }
                /* Save gallery images */
                $si = $db->prepare("INSERT INTO listing_images (listing_id,image_url,sort_order) VALUES (?,?,?)");
                foreach (array_values($iExtraImgs) as $k => $url) {
                    if ($url) $si->execute(array($iId,$url,$k));
                }
                $msg = $iId ? 'Menu item saved!' : 'Menu item added!';
                /* Reload items */
                $siR=$db->prepare("SELECT l.*,GROUP_CONCAT(li.image_url ORDER BY li.sort_order SEPARATOR '||') AS gallery FROM listings l LEFT JOIN listing_images li ON li.listing_id=l.id WHERE l.restaurant_id=? AND l.category_id=2 GROUP BY l.id ORDER BY l.is_featured DESC,l.views DESC");
                $siR->execute(array($id)); $items=$siR->fetchAll(PDO::FETCH_ASSOC);
            } catch (Exception $e) { $err = 'DB error: '.$e->getMessage(); }
        }
    }

    /* ── DELETE MENU ITEM ── */
    if ($_POST['action'] === 'delete_item' && $id) {
        $dId = trim($_POST['item_id'] ?? '');
        if ($dId) {
            try {
                $db->prepare("DELETE FROM listing_images WHERE listing_id=?")->execute(array($dId));
                $db->prepare("DELETE FROM listing_features WHERE listing_id=?")->execute(array($dId));
                $db->prepare("DELETE FROM listings WHERE id=? AND restaurant_id=?")->execute(array($dId,$id));
                $msg = 'Item deleted.';
                $siR=$db->prepare("SELECT l.*,GROUP_CONCAT(li.image_url ORDER BY li.sort_order SEPARATOR '||') AS gallery FROM listings l LEFT JOIN listing_images li ON li.listing_id=l.id WHERE l.restaurant_id=? AND l.category_id=2 GROUP BY l.id ORDER BY l.is_featured DESC,l.views DESC");
                $siR->execute(array($id)); $items=$siR->fetchAll(PDO::FETCH_ASSOC);
            } catch (Exception $e) { $err = 'DB error: '.$e->getMessage(); }
        }
    }
}

if (isset($_GET['added'])) $msg = 'Restaurant added! Now add menu items below.';

/* Helpers */
$v = function($k) use ($rest) {
    return $rest && isset($rest[$k]) ? htmlspecialchars($rest[$k]) : '';
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo $rest ? 'Edit: '.htmlspecialchars($rest['name']) : 'Add Restaurant'; ?> — Malaba Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.2/cropper.min.css"/>
<style>
<?php include 'admin.css.php'; ?>
.wrap{max-width:900px;}
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:24px;margin-bottom:16px;}
.sec-title{font-family:'Syne',sans-serif;font-weight:800;font-size:12px;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid var(--border);}
.fg{display:flex;flex-direction:column;margin-bottom:16px;}
.fg label{font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px;}
.fc{width:100%;padding:10px 13px;background:var(--bg);border:1.5px solid var(--border2);border-radius:10px;color:var(--text);font-family:inherit;font-size:14px;outline:none;transition:border-color .2s;}
.fc:focus{border-color:var(--purple);}
textarea.fc{resize:vertical;min-height:80px;}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.row3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;}
.toggle-row{display:flex;align-items:center;gap:10px;}
.toggle-row label{font-size:14px;color:var(--text);margin:0;text-transform:none;letter-spacing:0;font-weight:500;}
.btn-primary{padding:12px 22px;background:linear-gradient(135deg,#E8521A,#FF7043);color:#fff;border:none;border-radius:12px;font-family:'Syne',sans-serif;font-weight:800;font-size:14px;cursor:pointer;transition:all .2s;box-shadow:0 4px 14px rgba(232,82,26,.3);}
.btn-primary:hover{transform:translateY(-1px);}
.btn-secondary{padding:10px 18px;background:var(--surface);border:1px solid var(--border2);color:var(--muted);border-radius:10px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;text-decoration:none;display:inline-flex;align-items:center;gap:6px;transition:all .2s;}
.btn-purple{padding:10px 18px;background:rgba(139,92,246,.15);border:1px solid rgba(139,92,246,.2);color:#c4b5fd;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;transition:all .2s;}
.btn-purple:hover{background:rgba(139,92,246,.25);}
.btn-danger{padding:7px 12px;background:rgba(239,68,68,.12);color:#fca5a5;border:1px solid rgba(239,68,68,.2);border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;font-family:inherit;transition:all .2s;}
.btn-danger:hover{background:#ef4444;color:#fff;}
.alert{padding:13px 16px;border-radius:11px;margin-bottom:18px;font-size:14px;font-weight:500;}
.alert-ok{background:rgba(82,183,136,.12);border:1px solid rgba(82,183,136,.25);color:#52B788;}
.alert-err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);color:#fca5a5;}
.hint{font-size:11px;color:var(--muted);margin-top:4px;}

/* Image uploader */
.img-upload-area{
  border:2px dashed var(--border2);border-radius:12px;padding:20px;
  text-align:center;cursor:pointer;transition:all .2s;
  background:rgba(255,255,255,.02);
}
.img-upload-area:hover{border-color:var(--purple);background:rgba(139,92,246,.05);}
.img-upload-area.has-img{border-style:solid;border-color:var(--green);}
.img-preview-thumb{width:100%;max-height:140px;object-fit:cover;border-radius:9px;margin-top:10px;display:none;}
.img-preview-thumb.show{display:block;}
.upload-status{font-size:12px;color:var(--muted);margin-top:6px;}
.upload-status.uploading{color:var(--amber);}
.upload-status.done{color:var(--green);}

/* Menu items table */
.menu-table{width:100%;border-collapse:collapse;margin-top:8px;}
.menu-table th{text-align:left;font-size:11px;font-weight:700;color:var(--muted);
  text-transform:uppercase;letter-spacing:.5px;padding:8px 10px;
  border-bottom:1px solid var(--border);}
.menu-table td{padding:10px;border-bottom:1px solid var(--border);font-size:13px;vertical-align:middle;}
.menu-table tr:last-child td{border-bottom:none;}
.menu-table tr:hover td{background:rgba(255,255,255,.02);}
.item-img-thumb{width:46px;height:40px;object-fit:cover;border-radius:7px;flex-shrink:0;background:var(--bg);}
.item-name{font-weight:600;color:var(--text);}
.item-price{font-family:'Syne',sans-serif;font-weight:800;color:#FF7043;}
.item-badge{font-size:10px;padding:2px 7px;border-radius:8px;background:rgba(245,158,11,.15);color:#fcd34d;font-weight:700;}
.item-actions{display:flex;gap:6px;align-items:center;}
.empty-menu{text-align:center;padding:28px;color:var(--muted);font-size:14px;}

/* Add/Edit item modal */
.item-modal{display:none;position:fixed;inset:0;z-index:500;background:rgba(0,0,0,.75);
  backdrop-filter:blur(6px);align-items:flex-end;justify-content:center;}
.item-modal.open{display:flex;animation:fadeIn .2s ease;}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
.item-modal-card{
  width:100%;max-width:680px;
  background:var(--bg);border-radius:20px 20px 0 0;
  border:1px solid rgba(255,255,255,.08);
  max-height:92vh;overflow-y:auto;
  padding:20px 20px calc(20px + env(safe-area-inset-bottom,0px));
  animation:slideUp .3s cubic-bezier(.32,1,.68,1);
}
@keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
.modal-title{font-family:'Syne',sans-serif;font-weight:800;font-size:16px;margin-bottom:18px;display:flex;align-items:center;justify-content:space-between;}
.modal-close{width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.07);border:none;color:rgba(255,255,255,.5);font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;}

/* Gallery images */
.gallery-grid{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;}
.gallery-thumb{position:relative;width:70px;height:60px;}
.gallery-thumb img{width:100%;height:100%;object-fit:cover;border-radius:8px;}
.gallery-thumb button{position:absolute;top:-5px;right:-5px;width:18px;height:18px;border-radius:50%;background:#ef4444;color:#fff;border:none;font-size:10px;cursor:pointer;display:flex;align-items:center;justify-content:center;}
.add-gallery-btn{width:70px;height:60px;border-radius:8px;border:2px dashed var(--border2);display:flex;align-items:center;justify-content:center;font-size:22px;color:var(--muted);cursor:pointer;transition:all .2s;background:rgba(255,255,255,.02);}
.add-gallery-btn:hover{border-color:var(--purple);color:var(--purple);}

/* Crop modal */
.crop-modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.9);z-index:9999;align-items:center;justify-content:center;}
.crop-container{background:#1a1a1a;padding:20px;border-radius:14px;max-width:92%;max-height:90%;overflow:auto;}
#cropperImage{max-width:100%;max-height:65vh;}
.crop-actions{display:flex;gap:10px;margin-top:14px;justify-content:flex-end;}

@media(max-width:640px){.row2,.row3{grid-template-columns:1fr;}.menu-table th:nth-child(3),.menu-table td:nth-child(3){display:none;}}
</style>
</head>
<body>
<?php include 'nav.php'; ?>
<main class="main">
<div class="wrap">

  <div class="page-header">
    <div>
      <h1 class="page-title"><?php echo $rest ? '&#x270F; Edit Restaurant' : '&#x2795; Add Restaurant'; ?></h1>
      <p class="page-sub"><?php echo $rest ? htmlspecialchars($rest['name']) : 'Fill in the restaurant details then add menu items'; ?></p>
    </div>
    <a href="restaurants.php" class="btn-secondary">&#x2190; All Restaurants</a>
  </div>

  <?php if ($msg): ?><div class="alert alert-ok">&#x2705; <?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
  <?php if ($err): ?><div class="alert alert-err">&#x26A0; <?php echo htmlspecialchars($err); ?></div><?php endif; ?>

  <!-- ══ RESTAURANT FORM ══ -->
  <form method="POST" id="restForm">
    <input type="hidden" name="action" value="save_restaurant">

    <div class="form-card">
      <div class="sec-title">&#x1F3E9; Restaurant Information</div>
      <div class="row2">
        <div class="fg">
          <label>Restaurant Name *</label>
          <input type="text" name="name" class="fc" required
            placeholder="e.g. Malaba Pizza House"
            value="<?php echo $v('name'); ?>">
        </div>
        <div class="fg">
          <label>Cuisine Type</label>
          <input type="text" name="cuisine" class="fc"
            placeholder="e.g. Pizza, Burgers, Local Food"
            value="<?php echo $v('cuisine'); ?>">
        </div>
      </div>
      <div class="fg">
        <label>Description</label>
        <textarea name="description" class="fc"
          placeholder="What makes this restaurant special?"><?php echo $v('description'); ?></textarea>
      </div>
      <div class="row3">
        <div class="fg">
          <label>Location</label>
          <input type="text" name="location" class="fc"
            placeholder="e.g. Malaba CBD, Market Road"
            value="<?php echo $v('location'); ?>">
        </div>
        <div class="fg">
          <label>Delivery Time</label>
          <input type="text" name="delivery_time" class="fc"
            placeholder="e.g. 15-25 min"
            value="<?php echo $v('delivery_time'); ?>">
        </div>
        <div class="fg">
          <label>Opening Hours</label>
          <input type="text" name="opening_hours" class="fc"
            placeholder="e.g. 7am - 10pm daily"
            value="<?php echo $v('opening_hours'); ?>">
        </div>
      </div>
      <div class="row3">
        <div class="fg">
          <label>Contact Phone (WhatsApp)</label>
          <input type="text" name="contact_phone" class="fc"
            placeholder="254712345678"
            value="<?php echo $v('contact_phone'); ?>">
          <span class="hint">Must start with 254 (no +)</span>
        </div>
        <div class="fg">
          <label>Contact Name</label>
          <input type="text" name="contact_name" class="fc"
            placeholder="Owner or manager name"
            value="<?php echo $v('contact_name'); ?>">
        </div>
        <div class="fg">
          <label>Badge (optional)</label>
          <input type="text" name="badge" class="fc"
            placeholder="e.g. Popular, New, Top Rated"
            value="<?php echo $v('badge'); ?>">
        </div>
      </div>
      <div class="row2">
        <div class="fg">
          <label>Min Order (KSH)</label>
          <input type="number" name="min_order" class="fc"
            placeholder="0" min="0"
            value="<?php echo $v('min_order') ?: '0'; ?>">
        </div>
        <div class="fg">
          <label>Delivery Fee (KSH, 0 = free)</label>
          <input type="number" name="delivery_fee" class="fc"
            placeholder="50" min="0"
            value="<?php echo $v('delivery_fee') ?: '50'; ?>">
        </div>
      </div>
    </div>

    <!-- ── Restaurant Photo ── -->
    <div class="form-card">
      <div class="sec-title">&#x1F4F7; Restaurant Cover Photo</div>
      <input type="hidden" name="image_url" id="restImgUrl" value="<?php echo $v('image_url'); ?>">

      <div class="img-upload-area <?php echo $rest && $rest['image_url'] ? 'has-img' : ''; ?>"
           id="restImgArea" onclick="document.getElementById('restImgFile').click()">
        <div style="font-size:28px;margin-bottom:6px;">&#x1F4F7;</div>
        <div style="font-size:13px;font-weight:700;color:var(--text);">Click to upload restaurant photo</div>
        <div class="hint">Cloudinary • Auto-optimised • Max 5MB</div>
      </div>
      <input type="file" id="restImgFile" accept="image/*" style="display:none"
             onchange="handleRestImg(this)">
      <div class="upload-status" id="restImgStatus">
        <?php if ($rest && $rest['image_url']): ?>
          <span style="color:var(--green);">&#x2705; Photo uploaded</span>
        <?php endif; ?>
      </div>
      <img id="restImgPreview"
           src="<?php echo $v('image_url'); ?>"
           class="img-preview-thumb <?php echo $rest && $rest['image_url'] ? 'show' : ''; ?>"
           alt="Restaurant photo">

      <!-- Or paste URL -->
      <div class="fg" style="margin-top:12px;margin-bottom:0;">
        <label>Or paste image URL</label>
        <input type="text" class="fc" placeholder="https://..."
               oninput="setRestImg(this.value)"
               value="<?php echo $v('image_url'); ?>">
      </div>
    </div>

    <!-- ── Visibility ── -->
    <div class="form-card">
      <div class="sec-title">&#x2699; Visibility</div>
      <div class="fg">
        <div class="toggle-row">
          <input type="checkbox" id="is_active" name="is_active"
            <?php echo (!$rest || (int)$rest['is_active']) ? 'checked' : ''; ?>>
          <label for="is_active"><strong>Active</strong> — Visible to customers</label>
        </div>
      </div>
      <div class="fg" style="margin-bottom:0;">
        <div class="toggle-row">
          <input type="checkbox" id="is_featured" name="is_featured"
            <?php echo ($rest && (int)$rest['is_featured']) ? 'checked' : ''; ?>>
          <label for="is_featured"><strong>Featured</strong> — Shown at top of food page</label>
        </div>
      </div>
    </div>

    <div style="display:flex;gap:10px;margin-bottom:24px;">
      <button type="submit" class="btn-primary">
        <?php echo $rest ? '&#x1F4BE; Save Restaurant' : '&#x2795; Create Restaurant'; ?>
      </button>
      <?php if ($rest): ?>
      <a href="restaurant_delete.php?id=<?php echo urlencode($id); ?>"
         class="btn-danger"
         onclick="return confirm('Delete this restaurant and all its menu items?')">
        &#x1F5D1; Delete
      </a>
      <?php endif; ?>
    </div>
  </form>

  <?php if ($rest): ?>
  <!-- ══ MENU ITEMS ══ -->
  <div class="form-card">
    <div class="sec-title" style="display:flex;align-items:center;justify-content:space-between;">
      <span>&#x1F374; Menu Items (<?php echo count($items); ?>)</span>
      <button class="btn-purple" onclick="openItemModal(null)">&#x2795; Add Item</button>
    </div>

    <?php if (empty($items)): ?>
    <div class="empty-menu">
      <div style="font-size:36px;margin-bottom:10px;">&#x1F37D;</div>
      <div style="font-weight:700;margin-bottom:6px;">No menu items yet</div>
      <div>Click "Add Item" to add your first dish</div>
    </div>
    <?php else: ?>
    <div style="overflow-x:auto;">
    <table class="menu-table">
      <thead>
        <tr>
          <th>Photo</th>
          <th>Item</th>
          <th>Price</th>
          <th>Badge</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $item): ?>
        <tr>
          <td>
            <?php if ($item['image_url']): ?>
            <img src="<?php echo htmlspecialchars($item['image_url']); ?>"
                 class="item-img-thumb" alt="">
            <?php else: ?>
            <div class="item-img-thumb" style="display:flex;align-items:center;justify-content:center;font-size:20px;">&#x1F374;</div>
            <?php endif; ?>
          </td>
          <td>
            <div class="item-name"><?php echo htmlspecialchars($item['title']); ?></div>
            <div style="font-size:11px;color:var(--muted);">
              <?php echo htmlspecialchars($item['sub_category'] ?: ''); ?>
              <?php if ($item['prep_time']): ?>
                &bull; &#x23F1; <?php echo htmlspecialchars($item['prep_time']); ?>
              <?php endif; ?>
            </div>
          </td>
          <td class="item-price"><?php echo htmlspecialchars($item['price']); ?></td>
          <td>
            <?php if ($item['badge']): ?>
            <span class="item-badge"><?php echo htmlspecialchars($item['badge']); ?></span>
            <?php else: ?><span style="color:var(--dim);">—</span><?php endif; ?>
          </td>
          <td>
            <span style="font-size:11px;font-weight:700;padding:2px 8px;border-radius:8px;
              background:<?php echo $item['is_active'] ? 'rgba(34,197,94,.15)' : 'rgba(100,100,100,.15)'; ?>;
              color:<?php echo $item['is_active'] ? '#4ade80' : 'var(--muted)'; ?>;">
              <?php echo $item['is_active'] ? 'Active' : 'Hidden'; ?>
            </span>
          </td>
          <td>
            <div class="item-actions">
              <button class="btn-purple" style="padding:5px 10px;font-size:11px;"
                onclick="openItemModal(<?php echo htmlspecialchars(json_encode($item), ENT_QUOTES); ?>)">
                &#x270F; Edit
              </button>
              <form method="POST" style="margin:0;" onsubmit="return confirm('Delete this menu item?')">
                <input type="hidden" name="action" value="delete_item">
                <input type="hidden" name="item_id" value="<?php echo htmlspecialchars($item['id']); ?>">
                <button type="submit" class="btn-danger">&#x2715;</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

</div>
</main>

<!-- ══ ADD/EDIT ITEM MODAL ══ -->
<div class="item-modal" id="itemModal" onclick="closeItemModalIfBg(event)">
  <div class="item-modal-card">
    <div class="modal-title">
      <span id="modalTitle">&#x2795; Add Menu Item</span>
      <button class="modal-close" onclick="closeItemModal()">&#x2715;</button>
    </div>
    <form method="POST" id="itemForm">
      <input type="hidden" name="action" value="save_item">
      <input type="hidden" name="item_id" id="itemId" value="">

      <div class="row2">
        <div class="fg">
          <label>Item Name *</label>
          <input type="text" name="item_title" id="itemTitle" class="fc" required
            placeholder="e.g. Margherita Pizza">
        </div>
        <div class="fg">
          <label>Price *</label>
          <input type="text" name="item_price" id="itemPrice" class="fc" required
            placeholder="e.g. KSH 650">
        </div>
      </div>
      <div class="fg">
        <label>Description</label>
        <textarea name="item_desc" id="itemDesc" class="fc"
          placeholder="What's in this dish? Ingredients, size, taste…"></textarea>
      </div>
      <div class="row3">
        <div class="fg">
          <label>Category</label>
          <input type="text" name="item_category" id="itemCategory" class="fc"
            placeholder="e.g. Pizza, Drinks, Sides">
        </div>
        <div class="fg">
          <label>Prep Time</label>
          <input type="text" name="item_prep" id="itemPrep" class="fc"
            placeholder="e.g. 20 min">
        </div>
        <div class="fg">
          <label>Badge</label>
          <select name="item_badge" id="itemBadge" class="fc">
            <option value="">None</option>
            <option value="Hot">&#x1F525; Hot</option>
            <option value="New">&#x1F195; New</option>
            <option value="Offer">&#x1F4B0; Offer</option>
            <option value="BOGO">&#x1F355; BOGO</option>
            <option value="Bestseller">&#x2B50; Bestseller</option>
          </select>
        </div>
      </div>

      <!-- Item main photo -->
      <div class="fg">
        <label>Main Photo</label>
        <input type="hidden" name="item_image" id="itemImageUrl" value="">
        <div class="img-upload-area" id="itemImgArea" onclick="document.getElementById('itemImgFile').click()">
          <div style="font-size:22px;margin-bottom:4px;">&#x1F4F7;</div>
          <div style="font-size:12px;color:var(--muted);">Click to upload item photo</div>
        </div>
        <input type="file" id="itemImgFile" accept="image/*" style="display:none" onchange="handleItemImg(this)">
        <div class="upload-status" id="itemImgStatus"></div>
        <img id="itemImgPreview" src="" class="img-preview-thumb" alt="">
        <div class="fg" style="margin-top:8px;margin-bottom:0;">
          <input type="text" class="fc" placeholder="Or paste image URL…"
                 oninput="setItemImg(this.value)" id="itemImgPaste">
        </div>
      </div>

      <!-- Gallery images -->
      <div class="fg">
        <label>Gallery Images (optional)</label>
        <div class="gallery-grid" id="galleryGrid"></div>
        <input type="file" id="galleryImgFile" accept="image/*" style="display:none"
               onchange="handleGalleryImg(this)">
        <div class="hint" style="margin-top:6px;">Add extra photos for this item</div>
        <div id="galleryInputs"></div>
      </div>

      <!-- Toggles -->
      <div style="display:flex;gap:24px;margin-bottom:16px;">
        <div class="toggle-row">
          <input type="checkbox" id="itemFeatured" name="item_featured" checked>
          <label for="itemFeatured">Featured</label>
        </div>
        <div class="toggle-row">
          <input type="checkbox" id="itemActive" name="item_active" checked>
          <label for="itemActive">Active</label>
        </div>
      </div>

      <div style="display:flex;gap:10px;">
        <button type="submit" class="btn-primary" style="flex:1;">&#x1F4BE; Save Item</button>
        <button type="button" class="btn-secondary" onclick="closeItemModal()">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- ══ CROP MODAL ══ -->
<div id="cropModal" class="crop-modal">
  <div class="crop-container">
    <div style="font-weight:700;font-size:15px;color:#fff;margin-bottom:12px;">&#x2702; Crop Image</div>
    <img id="cropperImage" alt="">
    <div class="crop-actions">
      <button onclick="cancelCrop()" class="btn-secondary">Cancel</button>
      <button onclick="saveCrop()" class="btn-primary">&#x2705; Use This Image</button>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.2/cropper.min.js"></script>
<script>
var CLOUD  = '<?php echo $CLOUDINARY_CLOUD_NAME; ?>';
var PRESET = '<?php echo $CLOUDINARY_UPLOAD_PRESET; ?>';

var cropper      = null;
var cropTarget   = null; /* 'rest' | 'item' | 'gallery' */
var galleryUrls  = [];
var currentItemData = null;

/* ════ RESTAURANT IMAGE ════ */
function handleRestImg(input) {
  var file = input.files[0]; if(!file) return;
  var reader = new FileReader();
  reader.onload = function(e){ showCropper(e.target.result, 'rest'); };
  reader.readAsDataURL(file);
  input.value='';
}
function setRestImg(url) {
  document.getElementById('restImgUrl').value = url;
  var p = document.getElementById('restImgPreview');
  p.src = url; p.classList.toggle('show', !!url);
  document.getElementById('restImgArea').classList.toggle('has-img', !!url);
}

/* ════ ITEM IMAGE ════ */
function handleItemImg(input) {
  var file = input.files[0]; if(!file) return;
  var reader = new FileReader();
  reader.onload = function(e){ showCropper(e.target.result, 'item'); };
  reader.readAsDataURL(file);
  input.value='';
}
function setItemImg(url) {
  document.getElementById('itemImageUrl').value = url;
  document.getElementById('itemImgPaste').value = url;
  var p = document.getElementById('itemImgPreview');
  p.src = url; p.classList.toggle('show', !!url);
  document.getElementById('itemImgArea').classList.toggle('has-img', !!url);
}

/* ════ GALLERY IMAGE ════ */
function handleGalleryImg(input) {
  var file = input.files[0]; if(!file) return;
  var reader = new FileReader();
  reader.onload = function(e){ showCropper(e.target.result, 'gallery'); };
  reader.readAsDataURL(file);
  input.value='';
}

/* ════ CROPPER ════ */
function showCropper(src, target) {
  cropTarget = target;
  var modal = document.getElementById('cropModal');
  var img   = document.getElementById('cropperImage');
  img.src   = src;
  modal.style.display = 'flex';
  if(cropper) cropper.destroy();
  var ratio = (target === 'rest') ? 16/9 : (target === 'gallery' ? 4/3 : 1/1);
  cropper = new Cropper(img, {aspectRatio:ratio, viewMode:2, autoCropArea:.9});
}
function cancelCrop() {
  document.getElementById('cropModal').style.display='none';
  if(cropper){cropper.destroy();cropper=null;}
}
function saveCrop() {
  if(!cropper) return;
  var w = (cropTarget==='rest') ? 900 : (cropTarget==='gallery' ? 700 : 600);
  var h = (cropTarget==='rest') ? 506 : (cropTarget==='gallery' ? 525 : 600);
  var canvas = cropper.getCroppedCanvas({width:w, height:h});
  var status = cropTarget==='rest' ? 'restImgStatus' : 'itemImgStatus';
  document.getElementById(status).className='upload-status uploading';
  document.getElementById(status).textContent='Uploading to Cloudinary…';

  canvas.toBlob(function(blob){
    var fd = new FormData();
    fd.append('file', blob);
    fd.append('upload_preset', PRESET);
    var xhr = new XMLHttpRequest();
    xhr.open('POST','https://api.cloudinary.com/v1_1/'+CLOUD+'/image/upload',true);
    xhr.onload = function(){
      try{
        var d = JSON.parse(xhr.responseText);
        if(d.secure_url){
          if(cropTarget==='rest'){
            setRestImg(d.secure_url);
            document.getElementById('restImgStatus').className='upload-status done';
            document.getElementById('restImgStatus').textContent='✅ Uploaded!';
          } else if(cropTarget==='item'){
            setItemImg(d.secure_url);
            document.getElementById('itemImgStatus').className='upload-status done';
            document.getElementById('itemImgStatus').textContent='✅ Uploaded!';
          } else if(cropTarget==='gallery'){
            addGalleryImg(d.secure_url);
          }
          cancelCrop();
        }
      }catch(e){ alert('Upload failed'); }
    };
    xhr.onerror = function(){ alert('Upload failed. Check internet connection.'); };
    xhr.send(fd);
  }, 'image/jpeg', 0.87);
}

/* ════ GALLERY MANAGEMENT ════ */
function addGalleryImg(url) {
  galleryUrls.push(url);
  renderGallery();
}
function removeGalleryImg(idx) {
  galleryUrls.splice(idx,1);
  renderGallery();
}
function renderGallery() {
  var grid = document.getElementById('galleryGrid');
  var inp  = document.getElementById('galleryInputs');
  var html = '';
  galleryUrls.forEach(function(url,i){
    html += '<div class="gallery-thumb">'+
      '<img src="'+url+'" alt="">'+
      '<button type="button" onclick="removeGalleryImg('+i+')" title="Remove">&#x2715;</button>'+
    '</div>';
  });
  html += '<div class="add-gallery-btn" onclick="document.getElementById(\'galleryImgFile\').click()" title="Add photo">+</div>';
  grid.innerHTML = html;
  /* Hidden inputs */
  var iHtml = '';
  galleryUrls.forEach(function(url){
    iHtml += '<input type="hidden" name="item_extra_images[]" value="'+url+'">';
  });
  inp.innerHTML = iHtml;
}

/* ════ ITEM MODAL ════ */
function openItemModal(item) {
  currentItemData = item;
  galleryUrls = [];
  var modal = document.getElementById('itemModal');
  var form  = document.getElementById('itemForm');
  form.reset();
  document.getElementById('itemImgPreview').classList.remove('show');
  document.getElementById('itemImgArea').classList.remove('has-img');
  document.getElementById('itemImgStatus').textContent='';
  renderGallery();

  if(item) {
    document.getElementById('modalTitle').textContent = '✏️ Edit: '+(item.title||'');
    document.getElementById('itemId').value      = item.id||'';
    document.getElementById('itemTitle').value   = item.title||'';
    document.getElementById('itemPrice').value   = item.price||'';
    document.getElementById('itemDesc').value    = item.description||'';
    document.getElementById('itemCategory').value= item.sub_category||'';
    document.getElementById('itemPrep').value    = item.prep_time||'';
    document.getElementById('itemBadge').value   = item.badge||'';
    document.getElementById('itemFeatured').checked = item.is_featured==1;
    document.getElementById('itemActive').checked   = item.is_active==1;
    /* Image */
    if(item.image_url){
      setItemImg(item.image_url);
      document.getElementById('itemImgStatus').className='upload-status done';
      document.getElementById('itemImgStatus').textContent='✅ Photo loaded';
    }
    /* Gallery */
    if(item.gallery){
      galleryUrls = item.gallery.split('||').filter(function(u){return u;});
      renderGallery();
    }
  } else {
    document.getElementById('modalTitle').textContent = '➕ Add Menu Item';
    document.getElementById('itemId').value = '';
    document.getElementById('itemFeatured').checked = true;
    document.getElementById('itemActive').checked   = true;
    renderGallery();
  }
  modal.classList.add('open');
  document.body.style.overflow='hidden';
}
function closeItemModal() {
  document.getElementById('itemModal').classList.remove('open');
  document.body.style.overflow='';
}
function closeItemModalIfBg(e) {
  if(e.target===document.getElementById('itemModal')) closeItemModal();
}
</script>
</body>
</html>