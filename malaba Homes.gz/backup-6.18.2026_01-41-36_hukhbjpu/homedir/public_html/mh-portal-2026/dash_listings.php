<?php
require_once 'auth.php';
require_once 'db.php';
requirePerm('listings'); 

$db  = getDB();
$msg = '';

// Quick toggle active/hidden
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_id'])) {
    $db->prepare("UPDATE listings SET is_active = 1 - is_active WHERE id = ?")
       ->execute(array($_POST['toggle_id']));
    if (isset($_POST['ajax'])) {
        header('Content-Type: application/json');
        $newState = (int)$db->query("SELECT is_active FROM listings WHERE id='".addslashes($_POST['toggle_id'])."'")->fetchColumn();
        echo json_encode(array('success'=>true,'is_active'=>$newState));
        exit;
    }
}

// Stats
$stats = $db->query("
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN is_active=1 THEN 1 ELSE 0 END) AS active,
        SUM(CASE WHEN is_active=0 THEN 1 ELSE 0 END) AS hidden,
        SUM(CASE WHEN category_id=1 THEN 1 ELSE 0 END) AS homes,
        SUM(CASE WHEN category_id=2 THEN 1 ELSE 0 END) AS food,
        SUM(CASE WHEN category_id=3 THEN 1 ELSE 0 END) AS shop
    FROM listings
")->fetch(PDO::FETCH_ASSOC);

// Filters
$catF  = isset($_GET['cat']) ? $_GET['cat'] : '';
$q     = trim(isset($_GET['q'])  ? $_GET['q']  : '');
$where = array('1=1');
$params= array();
if ($catF) { $where[] = 'c.slug = ?'; $params[] = $catF; }
if ($q)    { $where[] = '(l.title LIKE ? OR l.location LIKE ?)'; $s="%$q%"; $params[]=$s; $params[]=$s; }
$whereSQL = implode(' AND ', $where);

$listings = $db->prepare("
    SELECT l.*, c.slug AS cat_slug, c.name AS cat_name, c.icon
    FROM listings l JOIN categories c ON c.id=l.category_id
    WHERE $whereSQL ORDER BY l.updated_at DESC LIMIT 80
");
$listings->execute($params);
$listings = $listings->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Listings Dashboard &mdash; Malaba</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<style>
:root{--bg:#0D0B08;--surface:#141210;--card:#1A1714;--border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);--text:#F2EDE6;--muted:#6E6560;--green:#52B788;--amber:#E8521A;--amber2:#FF7043;--blue:#4895EF;--red:#ef4444;--purple:#8b5cf6;}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;-webkit-font-smoothing:antialiased;}
a{color:inherit;text-decoration:none;}
button{cursor:pointer;font-family:inherit;border:none;background:none;}
.header{background:var(--surface);border-bottom:1px solid var(--border);padding:0 24px;height:60px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;}
.h-brand{display:flex;align-items:center;gap:10px;}
.h-mark{width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,var(--green),#40916C);display:flex;align-items:center;justify-content:center;font-size:16px;box-shadow:0 4px 16px rgba(82,183,136,.35);}
.h-title{font-family:'Syne',sans-serif;font-weight:800;font-size:16px;}
.h-role{font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:rgba(82,183,136,.15);color:var(--green);}
.h-right{display:flex;align-items:center;gap:10px;}
.h-name{font-size:13px;color:var(--muted);}
.h-add{display:flex;align-items:center;gap:6px;padding:8px 16px;background:var(--green);color:#fff;border-radius:10px;font-weight:700;font-size:13px;transition:all .2s;box-shadow:0 4px 14px rgba(82,183,136,.35);}
.h-add:hover{transform:translateY(-1px);}
.h-logout{font-size:12px;font-weight:600;padding:6px 12px;border-radius:8px;background:rgba(255,255,255,.05);border:1px solid var(--border2);color:var(--muted);}
.h-logout:hover{color:var(--red);}

.page{max-width:1200px;margin:0 auto;padding:24px;}

/* Stats */
.stats{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:24px;}
@media(max-width:900px){.stats{grid-template-columns:repeat(3,1fr);}}
@media(max-width:540px){.stats{grid-template-columns:repeat(2,1fr);}}
.sc{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:16px 12px;text-align:center;cursor:pointer;transition:all .2s;display:block;}
.sc:hover{border-color:var(--border2);transform:translateY(-2px);}
.sc.active{border-color:var(--green);background:rgba(82,183,136,.08);}
.sc-val{font-family:'Syne',sans-serif;font-weight:800;font-size:26px;color:var(--text);line-height:1;margin-bottom:4px;}
.sc-lbl{font-size:10px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;}

/* Filter */
.filter-row{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;align-items:center;}
.filter-row input,.filter-row select{padding:9px 13px;background:var(--surface);border:1.5px solid var(--border2);border-radius:10px;color:var(--text);font-family:inherit;font-size:13px;outline:none;transition:border-color .2s;}
.filter-row input:focus,.filter-row select:focus{border-color:var(--green);}
.cat-tabs{display:flex;gap:6px;}
.ct{padding:8px 14px;border-radius:20px;font-size:12px;font-weight:700;border:1px solid var(--border2);color:var(--muted);cursor:pointer;transition:all .15s;text-decoration:none;display:inline-block;}
.ct:hover{border-color:var(--border2);color:var(--text);}
.ct.active{background:var(--green);border-color:var(--green);color:#fff;}

/* Listings grid */
.listings-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;}
@media(max-width:640px){.listings-grid{grid-template-columns:1fr;}}

.lcard{background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden;transition:all .2s;}
.lcard:hover{border-color:var(--border2);transform:translateY(-3px);box-shadow:0 12px 32px rgba(0,0,0,.4);}
.lcard.hidden-listing{opacity:.55;}
.lc-img{position:relative;height:160px;overflow:hidden;}
.lc-img img{width:100%;height:100%;object-fit:cover;transition:transform .4s;}
.lcard:hover .lc-img img{transform:scale(1.04);}
.lc-img-ph{width:100%;height:160px;background:var(--surface);display:flex;align-items:center;justify-content:center;font-size:40px;}
.lc-badge{position:absolute;top:8px;left:8px;font-size:10px;font-weight:700;padding:3px 8px;border-radius:10px;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);color:#fff;}
.lc-status{position:absolute;top:8px;right:8px;font-size:10px;font-weight:700;padding:3px 8px;border-radius:10px;}
.lcs-active{background:rgba(82,183,136,.85);color:#fff;}
.lcs-hidden{background:rgba(100,100,100,.75);color:#fff;}
.lc-video{position:absolute;bottom:8px;right:8px;background:rgba(139,92,246,.85);color:#fff;font-size:10px;font-weight:700;padding:3px 8px;border-radius:8px;}
.lc-body{padding:12px 14px;}
.lc-cat{font-size:10px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:4px;}
.lc-title{font-family:'Syne',sans-serif;font-weight:700;font-size:14px;color:var(--text);margin-bottom:4px;line-height:1.3;}
.lc-price{font-size:14px;font-weight:800;color:var(--green);margin-bottom:4px;}
.lc-loc{font-size:11px;color:var(--muted);}
.lc-foot{display:flex;gap:6px;padding:8px 14px 12px;}
.lf-btn{flex:1;padding:8px;border-radius:9px;font-size:12px;font-weight:700;text-align:center;transition:all .15s;cursor:pointer;font-family:inherit;}
.lf-edit{background:rgba(82,183,136,.12);color:var(--green);border:1px solid rgba(82,183,136,.2);text-decoration:none;}
.lf-edit:hover{background:var(--green);color:#fff;}
.lf-toggle{background:rgba(255,255,255,.05);border:1px solid var(--border2);color:var(--muted);border:none;}
.lf-toggle.is-active{color:var(--green);}
.lf-toggle.is-hidden{color:var(--muted);}
.lf-del{background:rgba(239,68,68,.1);color:#fca5a5;border:none;width:36px;flex:0;display:flex;align-items:center;justify-content:center;font-size:14px;border-radius:9px;}
.lf-del:hover{background:var(--red);color:#fff;}

/* Empty */
.empty{grid-column:1/-1;text-align:center;padding:60px 20px;color:var(--muted);}
.empty-icon{font-size:48px;margin-bottom:14px;}
.empty-title{font-family:'Syne',sans-serif;font-weight:800;font-size:18px;color:var(--text);margin-bottom:8px;}

.toast{position:fixed;bottom:20px;left:50%;transform:translateX(-50%) translateY(10px);background:var(--text);color:var(--bg);padding:10px 20px;border-radius:20px;font-size:13px;font-weight:600;z-index:999;opacity:0;pointer-events:none;transition:all .25s;white-space:nowrap;}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
</style>
</head>
<body>

<header class="header">
  <div class="h-brand">
    <div class="h-mark">&#x1F4CB;</div>
    <span class="h-title">Listings</span>
    <span class="h-role">&#x1F4CB; Content Manager</span>
  </div>
  <div class="h-right">
    <a href="listing_form.php" class="h-add">&#x2795; Add Listing</a>
    <span class="h-name">&#x1F44B; <?php echo htmlspecialchars($CURRENT_NAME); ?></span>
    <a href="logout.php" class="h-logout">Logout</a>
  </div>
</header>

<div class="page">

  <!-- Stats -->
  <div class="stats">
    <a href="?" class="sc <?php echo (!$catF?'active':''); ?>">
      <div class="sc-val"><?php echo (int)(isset($stats['total'])?$stats['total']:0); ?></div>
      <div class="sc-lbl">Total</div>
    </a>
    <a href="?cat=" class="sc">
      <div class="sc-val" style="color:var(--green);"><?php echo (int)(isset($stats['active'])?$stats['active']:0); ?></div>
      <div class="sc-lbl">Active</div>
    </a>
    <a href="?" class="sc">
      <div class="sc-val" style="color:var(--muted);"><?php echo (int)(isset($stats['hidden'])?$stats['hidden']:0); ?></div>
      <div class="sc-lbl">Hidden</div>
    </a>
    <a href="?cat=houses" class="sc <?php echo ($catF==='houses'?'active':''); ?>">
      <div class="sc-val" style="color:var(--green);"><?php echo (int)(isset($stats['homes'])?$stats['homes']:0); ?></div>
      <div class="sc-lbl">&#x1F3E0; Homes</div>
    </a>
    <a href="?cat=food" class="sc <?php echo ($catF==='food'?'active':''); ?>">
      <div class="sc-val" style="color:#FF7043;"><?php echo (int)(isset($stats['food'])?$stats['food']:0); ?></div>
      <div class="sc-lbl">&#x1F354; Food</div>
    </a>
    <a href="?cat=items" class="sc <?php echo ($catF==='items'?'active':''); ?>">
      <div class="sc-val" style="color:var(--blue);"><?php echo (int)(isset($stats['shop'])?$stats['shop']:0); ?></div>
      <div class="sc-lbl">&#x1F6CB; Shop</div>
    </a>
  </div>

  <!-- Filter -->
  <div class="filter-row">
    <input type="text" id="searchInput" placeholder="&#x1F50D; Search listings..." value="<?php echo htmlspecialchars($q); ?>" oninput="filterCards(this.value)">
    <div class="cat-tabs">
      <a href="?" class="ct <?php echo (!$catF?'active':''); ?>">All</a>
      <a href="?cat=houses" class="ct <?php echo ($catF==='houses'?'active':''); ?>">&#x1F3E0;</a>
      <a href="?cat=food"   class="ct <?php echo ($catF==='food'  ?'active':''); ?>">&#x1F354;</a>
      <a href="?cat=items"  class="ct <?php echo ($catF==='items' ?'active':''); ?>">&#x1F6CB;</a>
    </div>
    <span style="font-size:13px;color:var(--muted);margin-left:auto;" id="listCount"><?php echo count($listings); ?> listings</span>
  </div>

  <!-- Grid -->
  <div class="listings-grid" id="listingsGrid">
  <?php if (empty($listings)): ?>
    <div class="empty">
      <div class="empty-icon">&#x1F4CB;</div>
      <div class="empty-title">No listings yet</div>
      <p>Click "+ Add Listing" to get started.</p>
    </div>
  <?php endif; ?>
  <?php foreach ($listings as $l):
    $hasVideo = !empty($l['video_url']);
    $isActive = (int)$l['is_active'];
    $imgSrc   = isset($l['image_url']) ? $l['image_url'] : '';
    $slug     = isset($l['cat_slug']) ? $l['cat_slug'] : '';
    $icon     = isset($l['icon'])     ? $l['icon']     : '';
    $catName  = isset($l['cat_name']) ? $l['cat_name'] : '';
  ?>
  <div class="lcard <?php echo $isActive?'':'hidden-listing'; ?>" data-title="<?php echo htmlspecialchars(strtolower($l['title'])); ?>" data-loc="<?php echo htmlspecialchars(strtolower(isset($l['location'])?$l['location']:'')); ?>">
    <div class="lc-img">
      <?php if ($imgSrc): ?>
      <img src="<?php echo htmlspecialchars($imgSrc); ?>" alt="" loading="lazy" onerror="this.parentElement.innerHTML='<div class=\'lc-img-ph\'><?php echo $icon; ?></div>'">
      <?php else: ?>
      <div class="lc-img-ph"><?php echo $icon; ?></div>
      <?php endif; ?>
      <?php if (isset($l['badge']) && $l['badge']): ?>
      <div class="lc-badge"><?php echo htmlspecialchars($l['badge']); ?></div>
      <?php endif; ?>
      <div class="lc-status <?php echo $isActive?'lcs-active':'lcs-hidden'; ?>"><?php echo $isActive?'&#x2705; Active':'&#x26D4; Hidden'; ?></div>
      <?php if ($hasVideo): ?><div class="lc-video">&#x25B6; Video</div><?php endif; ?>
    </div>
    <div class="lc-body">
      <div class="lc-cat"><?php echo $icon; ?> <?php echo htmlspecialchars($catName); ?></div>
      <div class="lc-title"><?php echo htmlspecialchars($l['title']); ?></div>
      <div class="lc-price"><?php echo htmlspecialchars($l['price']); ?></div>
      <div class="lc-loc">&#x1F4CD; <?php echo htmlspecialchars(isset($l['location'])?$l['location']:''); ?></div>
    </div>
    <div class="lc-foot">
      <a href="listing_form.php?id=<?php echo $l['id']; ?>" class="lf-btn lf-edit">&#x270F; Edit</a>
      <button class="lf-btn lf-toggle <?php echo $isActive?'is-active':'is-hidden'; ?>"
              id="toggle-<?php echo $l['id']; ?>"
              onclick="toggleListing('<?php echo $l['id']; ?>',this)">
        <?php echo $isActive?'&#x1F441; Hide':'&#x1F7E2; Show'; ?>
      </button>
      <button class="lf-btn lf-del"
              onclick="if(confirm('Delete &quot;<?php echo addslashes($l['title']); ?>&quot;?'))location.href='listing_delete.php?id=<?php echo $l['id']; ?>'">
        &#x1F5D1;
      </button>
    </div>
  </div>
  <?php endforeach; ?>
  </div>

</div>

<div class="toast" id="toast"></div>

<script>
var BASE = <?php echo json_encode(rtrim(dirname($_SERVER['PHP_SELF']),'/')); ?>;

function toggleListing(id, btn) {
  var card = btn.closest('.lcard');
  var xhr  = new XMLHttpRequest();
  xhr.open('POST', BASE + '/dash_listings.php', true);
  xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
  xhr.onload = function() {
    try {
      var d = JSON.parse(xhr.responseText);
      if (d.success) {
        var active = d.is_active;
        btn.className   = 'lf-btn lf-toggle ' + (active ? 'is-active' : 'is-hidden');
        btn.innerHTML   = active ? '&#x1F441; Hide' : '&#x1F7E2; Show';
        if (card) { card.classList.toggle('hidden-listing', !active); }
        // Update status badge
        var sb = card ? card.querySelector('.lc-status') : null;
        if (sb) { sb.className = 'lc-status '+(active?'lcs-active':'lcs-hidden'); sb.innerHTML = active ? '&#x2705; Active' : '&#x26D4; Hidden'; }
        showToast(active ? '&#x1F7E2; Listing is now live' : '&#x26D4; Listing hidden');
      }
    } catch(e) { location.reload(); }
  };
  xhr.send('toggle_id='+encodeURIComponent(id)+'&ajax=1');
}

function filterCards(q) {
  q = q.toLowerCase();
  var cards = document.querySelectorAll('.lcard');
  var shown = 0;
  cards.forEach(function(c) {
    var t = (c.dataset.title||'') + ' ' + (c.dataset.loc||'');
    var m = !q || t.includes(q);
    c.style.display = m ? '' : 'none';
    if (m) shown++;
  });
  var ct = document.getElementById('listCount');
  if (ct) ct.textContent = shown + ' listings';
}

function showToast(msg) {
  var t = document.getElementById('toast');
  t.innerHTML = msg; t.classList.add('show');
  setTimeout(function(){ t.classList.remove('show'); }, 2000);
}
</script>
</body>
</html>
