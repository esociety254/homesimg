<?php
require_once 'auth.php';
require_once 'db.php';
requirePerm('analytics');

$db = getDB();

// Stats for social manager
$kpi = $db->query("
    SELECT
        (SELECT COUNT(*) FROM listings WHERE is_active=1) AS active_listings,
        (SELECT COUNT(*) FROM listings WHERE video_url IS NOT NULL AND video_url <> '') AS with_video,
        (SELECT COUNT(*) FROM orders WHERE DATE(created_at)=CURDATE()) AS orders_today,
        (SELECT IFNULL(SUM(CASE WHEN payment_status='received' THEN total_amount ELSE 0 END),0) FROM orders WHERE DATE(created_at)=CURDATE()) AS revenue_today,
        (SELECT COUNT(*) FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) AS orders_week,
        (SELECT IFNULL(SUM(views),0) FROM listings) AS total_views
")->fetch(PDO::FETCH_ASSOC);

// Top viewed listings
$topViewed = $db->query("
    SELECT l.id, l.title, l.price, l.image_url, IFNULL(l.views,0) AS views,
           IFNULL(l.video_url,'') AS video_url, c.icon, c.slug
    FROM listings l JOIN categories c ON c.id=l.category_id
    WHERE l.is_active=1
    ORDER BY IFNULL(l.views,0) DESC LIMIT 6
")->fetchAll(PDO::FETCH_ASSOC);

// Listings without videos
$noVideo = $db->query("
    SELECT l.id, l.title, l.price, l.image_url, c.icon, c.slug
    FROM listings l JOIN categories c ON c.id=l.category_id
    WHERE l.is_active=1 AND (l.video_url IS NULL OR l.video_url='')
    ORDER BY IFNULL(l.views,0) DESC LIMIT 12
")->fetchAll(PDO::FETCH_ASSOC);

// Daily orders for sparkline (last 7 days)
$daily = $db->query("
    SELECT DATE(created_at) AS day, COUNT(*) AS n
    FROM orders
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(created_at)
    ORDER BY day ASC
")->fetchAll(PDO::FETCH_ASSOC);
$dailyLabels = array(); $dailyData = array();
foreach ($daily as $d) { $dailyLabels[] = date('D', strtotime($d['day'])); $dailyData[] = (int)$d['n']; }

// Recent inquiries
$inquiries = $db->query("
    SELECT i.user_name, i.user_phone, i.message, i.created_at, l.title AS listing_title
    FROM inquiries i LEFT JOIN listings l ON l.id=i.listing_id
    ORDER BY i.created_at DESC LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Social Dashboard &mdash; Malaba</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
:root{--bg:#0D0B08;--surface:#141210;--card:#1A1714;--border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);--text:#F2EDE6;--muted:#6E6560;--green:#52B788;--amber:#E8521A;--amber2:#FF7043;--blue:#4895EF;--purple:#8b5cf6;--gold:#f59e0b;}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;-webkit-font-smoothing:antialiased;}
a{color:inherit;text-decoration:none;}
button{cursor:pointer;font-family:inherit;border:none;background:none;}
.header{background:var(--surface);border-bottom:1px solid var(--border);padding:0 24px;height:60px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;}
.h-brand{display:flex;align-items:center;gap:10px;}
.h-mark{width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,var(--blue),#3278cc);display:flex;align-items:center;justify-content:center;font-size:16px;box-shadow:0 4px 16px rgba(72,149,239,.35);}
.h-title{font-family:'Syne',sans-serif;font-weight:800;font-size:16px;}
.h-role{font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:rgba(72,149,239,.15);color:var(--blue);}
.h-right{display:flex;align-items:center;gap:10px;}
.h-name{font-size:13px;color:var(--muted);}
.h-logout{font-size:12px;font-weight:600;padding:6px 12px;border-radius:8px;background:rgba(255,255,255,.05);border:1px solid var(--border2);color:var(--muted);}
.h-logout:hover{color:#ef4444;}

.page{max-width:1200px;margin:0 auto;padding:24px;}
.section-title{font-family:'Syne',sans-serif;font-weight:800;font-size:16px;margin-bottom:14px;display:flex;align-items:center;gap:8px;}
.section-title span{font-size:11px;font-weight:600;color:var(--muted);}

/* KPI Cards */
.kpi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:28px;}
@media(max-width:700px){.kpi-grid{grid-template-columns:repeat(2,1fr);}}
.kpi{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:20px;position:relative;overflow:hidden;}
.kpi::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;}
.kpi.blue::before{background:var(--blue);}
.kpi.green::before{background:var(--green);}
.kpi.amber::before{background:var(--amber);}
.kpi.purple::before{background:var(--purple);}
.kpi.gold::before{background:var(--gold);}
.kpi.teal::before{background:#0d9488;}
.kpi-icon{font-size:22px;margin-bottom:10px;}
.kpi-val{font-family:'Syne',sans-serif;font-weight:800;font-size:30px;color:var(--text);line-height:1;margin-bottom:4px;letter-spacing:-1px;}
.kpi-lbl{font-size:12px;color:var(--muted);font-weight:600;}

/* Chart card */
.chart-card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:20px;margin-bottom:28px;}
.chart-wrap{height:160px;position:relative;}

/* Two cols */
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:28px;}
@media(max-width:800px){.two-col{grid-template-columns:1fr;}}

/* Product cards (top viewed) */
.prod-list{display:flex;flex-direction:column;gap:8px;}
.pc{display:flex;align-items:center;gap:10px;padding:10px;background:var(--surface);border:1px solid var(--border);border-radius:12px;transition:all .2s;}
.pc:hover{border-color:var(--border2);}
.pc-img{width:44px;height:44px;border-radius:9px;object-fit:cover;flex-shrink:0;background:rgba(255,255,255,.05);}
.pc-img-ph{width:44px;height:44px;border-radius:9px;background:rgba(255,255,255,.05);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;}
.pc-info{flex:1;min-width:0;}
.pc-title{font-size:13px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.pc-price{font-size:11px;color:var(--amber2);font-weight:700;}
.pc-views{font-size:11px;color:var(--muted);}
.pc-vid{font-size:10px;font-weight:700;padding:2px 7px;border-radius:8px;background:rgba(139,92,246,.15);color:var(--purple);}
.pc-add-vid{font-size:10px;font-weight:700;padding:3px 8px;border-radius:8px;background:rgba(72,149,239,.1);color:var(--blue);border:1px solid rgba(72,149,239,.2);text-decoration:none;white-space:nowrap;}
.pc-add-vid:hover{background:var(--blue);color:#fff;}

/* Social checklist */
.checklist{display:flex;flex-direction:column;gap:8px;}
.cl-item{display:flex;align-items:flex-start;gap:10px;padding:12px 14px;background:var(--surface);border:1px solid var(--border);border-radius:12px;}
.cl-box{width:20px;height:20px;border-radius:5px;border:2px solid var(--border2);flex-shrink:0;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .15s;margin-top:1px;}
.cl-box.done{background:var(--green);border-color:var(--green);color:#fff;font-size:11px;}
.cl-text{flex:1;}
.cl-title{font-size:13px;font-weight:600;color:var(--text);}
.cl-sub{font-size:11px;color:var(--muted);}
.cl-time{font-size:10px;color:var(--muted);flex-shrink:0;align-self:center;}

/* Recent inquiries */
.inq-list{display:flex;flex-direction:column;gap:8px;}
.inq-item{padding:12px;background:var(--surface);border-radius:12px;border:1px solid var(--border);}
.inq-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;}
.inq-name{font-size:13px;font-weight:700;}
.inq-time{font-size:11px;color:var(--muted);}
.inq-listing{font-size:11px;color:var(--blue);margin-bottom:4px;}
.inq-msg{font-size:12px;color:var(--muted);line-height:1.4;}
.inq-wa{display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:700;color:#25D366;margin-top:6px;}

.toast{position:fixed;bottom:20px;left:50%;transform:translateX(-50%) translateY(10px);background:var(--text);color:var(--bg);padding:10px 20px;border-radius:20px;font-size:13px;font-weight:600;z-index:999;opacity:0;pointer-events:none;transition:all .25s;}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
</style>
</head>
<body>

<header class="header">
  <div class="h-brand">
    <div class="h-mark">&#x1F4F1;</div>
    <span class="h-title">Growth</span>
    <span class="h-role">&#x1F4F1; Social Manager</span>
  </div>
  <div class="h-right">
    <span class="h-name">&#x1F44B; <?php echo htmlspecialchars($CURRENT_NAME); ?></span>
    <a href="logout.php" class="h-logout">Logout</a>
  </div>
</header>

<div class="page">

  <!-- KPIs -->
  <div class="kpi-grid">
    <div class="kpi blue">
      <div class="kpi-icon">&#x1F4C8;</div>
      <div class="kpi-val"><?php echo (int)(isset($kpi['orders_week'])?$kpi['orders_week']:0); ?></div>
      <div class="kpi-lbl">Orders this week</div>
    </div>
    <div class="kpi amber">
      <div class="kpi-icon">&#x1F4E6;</div>
      <div class="kpi-val"><?php echo (int)(isset($kpi['orders_today'])?$kpi['orders_today']:0); ?></div>
      <div class="kpi-lbl">Orders today</div>
    </div>
    <div class="kpi green">
      <div class="kpi-icon">&#x1F4B0;</div>
      <div class="kpi-val">KSH <?php echo number_format((float)(isset($kpi['revenue_today'])?$kpi['revenue_today']:0),0); ?></div>
      <div class="kpi-lbl">Revenue today</div>
    </div>
    <div class="kpi teal">
      <div class="kpi-icon">&#x1F4CB;</div>
      <div class="kpi-val"><?php echo (int)(isset($kpi['active_listings'])?$kpi['active_listings']:0); ?></div>
      <div class="kpi-lbl">Live listings</div>
    </div>
    <div class="kpi purple">
      <div class="kpi-icon">&#x25B6;</div>
      <div class="kpi-val"><?php echo (int)(isset($kpi['with_video'])?$kpi['with_video']:0); ?></div>
      <div class="kpi-lbl">Have videos</div>
    </div>
    <div class="kpi gold">
      <div class="kpi-icon">&#x1F440;</div>
      <div class="kpi-val"><?php echo number_format((int)(isset($kpi['total_views'])?$kpi['total_views']:0)); ?></div>
      <div class="kpi-lbl">Total views</div>
    </div>
  </div>

  <!-- 7-day orders chart -->
  <div class="chart-card">
    <div class="section-title">&#x1F4C8; Orders — Last 7 Days</div>
    <div class="chart-wrap">
      <canvas id="ordersChart"></canvas>
    </div>
  </div>

  <div class="two-col">

    <!-- Left: Top viewed + video status -->
    <div>
      <div class="section-title">&#x1F525; Top Viewed <span>click Edit to add a video</span></div>
      <div class="prod-list">
      <?php foreach ($topViewed as $tv):
        $imgSrc = isset($tv['image_url']) ? $tv['image_url'] : '';
        $hasVid = !empty($tv['video_url']);
      ?>
        <div class="pc">
          <?php if ($imgSrc): ?>
          <img src="<?php echo htmlspecialchars($imgSrc); ?>" class="pc-img" loading="lazy" onerror="this.style.display='none'">
          <?php else: ?>
          <div class="pc-img-ph"><?php echo isset($tv['icon'])?$tv['icon']:''; ?></div>
          <?php endif; ?>
          <div class="pc-info">
            <div class="pc-title"><?php echo htmlspecialchars($tv['title']); ?></div>
            <div style="display:flex;align-items:center;gap:6px;margin-top:2px;">
              <span class="pc-price"><?php echo htmlspecialchars($tv['price']); ?></span>
              <span class="pc-views">&#x1F440; <?php echo number_format((int)$tv['views']); ?></span>
            </div>
          </div>
          <?php if ($hasVid): ?>
          <span class="pc-vid">&#x25B6; Video</span>
          <?php else: ?>
          <a href="listing_form.php?id=<?php echo $tv['id']; ?>" class="pc-add-vid">+ Add Video</a>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
      <?php if (empty($topViewed)): ?>
        <p style="color:var(--muted);font-size:13px;padding:20px 0;">No listings yet.</p>
      <?php endif; ?>
      </div>
    </div>

    <!-- Right: Daily social checklist -->
    <div>
      <div class="section-title">&#x2705; Today's Checklist</div>
      <div class="checklist" id="checklist">
        <div class="cl-item">
          <div class="cl-box" onclick="toggleCheck(this)"></div>
          <div class="cl-text">
            <div class="cl-title">Morning post (8 AM)</div>
            <div class="cl-sub">Post 1 shop item with price on WhatsApp status + Facebook</div>
          </div>
          <div class="cl-time">08:00</div>
        </div>
        <div class="cl-item">
          <div class="cl-box" onclick="toggleCheck(this)"></div>
          <div class="cl-text">
            <div class="cl-title">Home listing post (10 AM)</div>
            <div class="cl-sub">Share a home with price + location. Caption: "Looking for a house in Malaba?"</div>
          </div>
          <div class="cl-time">10:00</div>
        </div>
        <div class="cl-item">
          <div class="cl-box" onclick="toggleCheck(this)"></div>
          <div class="cl-text">
            <div class="cl-title">Lunchtime food post (12 PM)</div>
            <div class="cl-sub">Post a food item. Include delivery time and "Order now" with the link</div>
          </div>
          <div class="cl-time">12:00</div>
        </div>
        <div class="cl-item">
          <div class="cl-box" onclick="toggleCheck(this)"></div>
          <div class="cl-text">
            <div class="cl-title">Film 1 product video</div>
            <div class="cl-sub">15-30 sec. Upload to YouTube, paste link in listing form</div>
          </div>
          <div class="cl-time">2:00</div>
        </div>
        <div class="cl-item">
          <div class="cl-box" onclick="toggleCheck(this)"></div>
          <div class="cl-text">
            <div class="cl-title">Evening engagement (6 PM)</div>
            <div class="cl-sub">Reply to all comments & DMs. Share a testimonial or delivered order</div>
          </div>
          <div class="cl-time">18:00</div>
        </div>
        <div class="cl-item">
          <div class="cl-box" onclick="toggleCheck(this)"></div>
          <div class="cl-text">
            <div class="cl-title">Weekly report (Friday only)</div>
            <div class="cl-sub">Screenshot analytics numbers and send to manager on WhatsApp</div>
          </div>
          <div class="cl-time">Fri</div>
        </div>
      </div>
    </div>

  </div>

  <!-- Products needing videos -->
  <?php if (!empty($noVideo)): ?>
  <div style="margin-bottom:28px;">
    <div class="section-title">&#x1F3A5; Needs a Video <span><?php echo count($noVideo); ?> items</span></div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px;">
    <?php foreach ($noVideo as $nv): ?>
      <a href="listing_form.php?id=<?php echo $nv['id']; ?>" style="display:flex;align-items:center;gap:8px;padding:10px;background:var(--card);border:1px solid var(--border);border-radius:12px;transition:all .2s;color:var(--text);" onmouseover="this.style.borderColor='rgba(72,149,239,.4)'" onmouseout="this.style.borderColor='var(--border)'">
        <?php if (isset($nv['image_url']) && $nv['image_url']): ?>
        <img src="<?php echo htmlspecialchars($nv['image_url']); ?>" style="width:38px;height:38px;border-radius:8px;object-fit:cover;flex-shrink:0;" loading="lazy" onerror="this.style.display='none'">
        <?php else: ?>
        <div style="width:38px;height:38px;border-radius:8px;background:rgba(255,255,255,.05);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;"><?php echo isset($nv['icon'])?$nv['icon']:''; ?></div>
        <?php endif; ?>
        <div style="min-width:0;">
          <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?php echo htmlspecialchars($nv['title']); ?></div>
          <div style="font-size:11px;color:var(--blue);">+ Add video &#x2192;</div>
        </div>
      </a>
    <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Recent inquiries -->
  <div>
    <div class="section-title">&#x1F4AC; Recent Inquiries</div>
    <div class="inq-list">
    <?php if (empty($inquiries)): ?>
      <p style="color:var(--muted);font-size:13px;padding:16px 0;">No inquiries yet today.</p>
    <?php endif; ?>
    <?php foreach ($inquiries as $inq):
      $phone   = isset($inq['user_phone']) ? $inq['user_phone'] : '';
      $waNum   = preg_replace('/\D/','',$phone);
      if (strlen($waNum)===10&&$waNum[0]==='0') $waNum='254'.substr($waNum,1);
      elseif (strlen($waNum)===9) $waNum='254'.$waNum;
      $name    = isset($inq['user_name'])     ? $inq['user_name']     : 'Customer';
      $listing = isset($inq['listing_title']) ? $inq['listing_title'] : '';
      $msg     = mb_strimwidth(isset($inq['message'])?$inq['message']:'',0,80,'...');
      $time    = date('d M H:i', strtotime(isset($inq['created_at'])?$inq['created_at']:'now'));
    ?>
      <div class="inq-item">
        <div class="inq-top">
          <span class="inq-name">&#x1F464; <?php echo htmlspecialchars($name); ?></span>
          <span class="inq-time"><?php echo $time; ?></span>
        </div>
        <?php if ($listing): ?>
        <div class="inq-listing">&#x1F4CB; <?php echo htmlspecialchars($listing); ?></div>
        <?php endif; ?>
        <div class="inq-msg"><?php echo htmlspecialchars($msg); ?></div>
        <?php if ($waNum): ?>
        <a href="https://wa.me/<?php echo $waNum; ?>" target="_blank" class="inq-wa">&#x1F4AC; Reply on WhatsApp</a>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
    </div>
  </div>

</div>

<div class="toast" id="toast"></div>

<script>
// Orders chart
var ctx = document.getElementById('ordersChart');
if (ctx) {
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: <?php echo json_encode($dailyLabels ?: array('Mon','Tue','Wed','Thu','Fri','Sat','Sun')); ?>,
      datasets: [{
        label: 'Orders',
        data: <?php echo json_encode($dailyData ?: array(0,0,0,0,0,0,0)); ?>,
        backgroundColor: 'rgba(232,82,26,0.7)',
        borderRadius: 6,
        borderSkipped: false,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: 'rgba(255,255,255,.04)' }, ticks: { color: '#6E6560', font: { size: 11 } } },
        y: { grid: { color: 'rgba(255,255,255,.04)' }, ticks: { color: '#6E6560', font: { size: 11 }, stepSize: 1 }, beginAtZero: true }
      }
    }
  });
}

// Checklist persistence
var STORAGE_KEY = 'malaba_checklist_' + new Date().toDateString();
var saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
var boxes = document.querySelectorAll('.cl-box');
boxes.forEach(function(b, i) {
  if (saved[i]) { b.classList.add('done'); b.innerHTML = '&#x2713;'; }
});

function toggleCheck(box) {
  var done = box.classList.toggle('done');
  box.innerHTML = done ? '&#x2713;' : '';
  var state = [];
  document.querySelectorAll('.cl-box').forEach(function(b){ state.push(b.classList.contains('done')); });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  showToast(done ? '&#x2705; Done!' : 'Unmarked');
}

function showToast(msg) {
  var t = document.getElementById('toast');
  t.innerHTML = msg; t.classList.add('show');
  setTimeout(function(){ t.classList.remove('show'); }, 1800);
}
</script>
</body>
</html>
