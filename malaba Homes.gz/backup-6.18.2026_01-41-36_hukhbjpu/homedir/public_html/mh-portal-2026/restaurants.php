<?php
/**
 * admin/restaurants.php
 * List all restaurants in the admin panel
 */
require_once 'auth.php';
require_once 'db.php';
requirePerm('listings');

$db = getDB();

/* ── Stats ── */
$totalRests = 0;
$totalItems = 0;
$totalOrders= 0;
$restaurants= array();

try {
    $totalRests = (int)$db->query("SELECT COUNT(*) FROM restaurants WHERE is_active=1")->fetchColumn();
    $totalItems = (int)$db->query("SELECT COUNT(*) FROM listings WHERE category_id=2 AND is_active=1")->fetchColumn();
    $totalOrders= (int)$db->query("SELECT COUNT(*) FROM orders WHERE category='food'")->fetchColumn();

    $stmt = $db->query(
        "SELECT r.*,
            COUNT(DISTINCT l.id) AS item_count,
            COUNT(DISTINCT o.id) AS order_count
         FROM restaurants r
         LEFT JOIN listings l ON l.restaurant_id = r.id AND l.is_active = 1
         LEFT JOIN orders o ON o.listing_id = l.id
         GROUP BY r.id
         ORDER BY r.is_featured DESC, r.total_orders DESC, r.created_at DESC"
    );
    $restaurants = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Restaurants — Malaba Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<style>
<?php include 'admin.css.php'; ?>
.stat-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px;}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px;}
.stat-num{font-family:'Syne',sans-serif;font-size:26px;font-weight:800;color:var(--text);}
.stat-lbl{font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-top:3px;}
.rest-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;}
.rcard{background:var(--surface);border:1px solid var(--border);border-radius:16px;overflow:hidden;transition:border-color .2s;}
.rcard:hover{border-color:var(--border2);}
.rcard-img{height:120px;object-fit:cover;width:100%;background:var(--bg);}
.rcard-body{padding:12px 14px;}
.rcard-name{font-family:'Syne',sans-serif;font-weight:800;font-size:14px;color:var(--text);margin-bottom:3px;}
.rcard-meta{font-size:11px;color:var(--muted);margin-bottom:8px;}
.rcard-stats{display:flex;gap:12px;margin-bottom:10px;}
.rcs{text-align:center;flex:1;background:rgba(255,255,255,.03);border-radius:8px;padding:6px;}
.rcs-n{font-family:'Syne',sans-serif;font-size:15px;font-weight:800;color:var(--text);}
.rcs-l{font-size:9px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;}
.rcard-actions{display:flex;gap:7px;}
.btn-edit{flex:1;padding:8px;background:rgba(139,92,246,.15);border:1px solid rgba(139,92,246,.2);
  color:#c4b5fd;border-radius:9px;font-size:12px;font-weight:700;cursor:pointer;
  font-family:inherit;text-align:center;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:4px;transition:all .2s;}
.btn-edit:hover{background:rgba(139,92,246,.25);}
.status-pill{font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;}
.sp-open{background:rgba(34,197,94,.15);color:#4ade80;}
.sp-closed{background:rgba(100,100,100,.15);color:var(--muted);}
.sp-featured{background:rgba(245,158,11,.15);color:#fcd34d;}
.btn-add{display:inline-flex;align-items:center;gap:7px;padding:11px 20px;
  background:linear-gradient(135deg,#E8521A,#FF7043);color:#fff;border:none;
  border-radius:12px;font-family:'Syne',sans-serif;font-weight:800;font-size:14px;
  cursor:pointer;box-shadow:0 4px 14px rgba(232,82,26,.3);text-decoration:none;transition:all .2s;}
.btn-add:hover{transform:translateY(-1px);}
.empty{text-align:center;padding:48px 20px;color:var(--muted);}
.empty-ico{font-size:48px;margin-bottom:14px;}
@media(max-width:480px){.stat-grid{grid-template-columns:1fr 1fr;}
  .stat-grid .stat-card:last-child{grid-column:1/-1;}}
</style>
</head>
<body>
<?php include 'nav.php'; ?>
<main class="main">

  <div class="page-header">
    <div>
      <h1 class="page-title">&#x1F3E9; Restaurants</h1>
      <p class="page-sub">Manage your food partners and their menus</p>
    </div>
    <a href="restaurant_form.php" class="btn-add">&#x2795; Add Restaurant</a>
  </div>

  <!-- Stats -->
  <div class="stat-grid">
    <div class="stat-card">
      <div class="stat-num"><?php echo $totalRests; ?></div>
      <div class="stat-lbl">Restaurants</div>
    </div>
    <div class="stat-card">
      <div class="stat-num"><?php echo $totalItems; ?></div>
      <div class="stat-lbl">Menu Items</div>
    </div>
    <div class="stat-card">
      <div class="stat-num"><?php echo $totalOrders; ?></div>
      <div class="stat-lbl">Food Orders</div>
    </div>
  </div>

  <?php if (empty($restaurants)): ?>
  <div class="empty">
    <div class="empty-ico">&#x1F37D;</div>
    <div style="font-family:'Syne',sans-serif;font-size:20px;font-weight:800;margin-bottom:8px;">No restaurants yet</div>
    <div style="margin-bottom:20px;">Add your first restaurant to start taking food orders</div>
    <a href="restaurant_form.php" class="btn-add">&#x2795; Add First Restaurant</a>
  </div>
  <?php else: ?>

  <div class="rest-grid">
    <?php foreach ($restaurants as $r): ?>
    <div class="rcard">
      <?php if ($r['image_url']): ?>
      <img class="rcard-img" src="<?php echo htmlspecialchars($r['image_url']); ?>"
           alt="<?php echo htmlspecialchars($r['name']); ?>">
      <?php else: ?>
      <div class="rcard-img" style="display:flex;align-items:center;justify-content:center;font-size:40px;">&#x1F3E9;</div>
      <?php endif; ?>

      <div class="rcard-body">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;">
          <div class="rcard-name"><?php echo htmlspecialchars($r['name']); ?></div>
          <?php if ($r['is_featured']): ?>
          <span class="status-pill sp-featured">&#x2B50; Featured</span>
          <?php endif; ?>
        </div>
        <div class="rcard-meta">
          <?php if ($r['cuisine']): ?>&#x1F374; <?php echo htmlspecialchars($r['cuisine']); ?> &bull; <?php endif; ?>
          <?php if ($r['location']): ?>&#x1F4CD; <?php echo htmlspecialchars(explode(',', $r['location'])[0]); ?><?php endif; ?>
          <?php if ($r['delivery_time']): ?> &bull; &#x23F1; <?php echo htmlspecialchars($r['delivery_time']); ?><?php endif; ?>
        </div>

        <div class="rcard-stats">
          <div class="rcs">
            <div class="rcs-n"><?php echo (int)$r['item_count']; ?></div>
            <div class="rcs-l">Items</div>
          </div>
          <div class="rcs">
            <div class="rcs-n"><?php echo (int)$r['order_count']; ?></div>
            <div class="rcs-l">Orders</div>
          </div>
          <div class="rcs">
            <div class="rcs-n"><?php echo number_format((float)($r['rating']??4.5),1); ?></div>
            <div class="rcs-l">Rating</div>
          </div>
        </div>

        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
          <span class="status-pill <?php echo $r['is_open'] ? 'sp-open' : 'sp-closed'; ?>">
            <?php echo $r['is_open'] ? '&#x1F7E2; Open' : '&#x1F534; Closed'; ?>
          </span>
          <span class="status-pill <?php echo $r['is_active'] ? 'sp-open' : 'sp-closed'; ?>">
            <?php echo $r['is_active'] ? 'Active' : 'Hidden'; ?>
          </span>
          <?php if ($r['contact_phone']): ?>
          <a href="https://wa.me/<?php echo htmlspecialchars($r['contact_phone']); ?>"
             target="_blank"
             style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;
                    background:#25D366;color:#fff;text-decoration:none;">
            &#x1F4AC; WA
          </a>
          <?php endif; ?>
        </div>

        <div class="rcard-actions">
          <a href="restaurant_form.php?id=<?php echo urlencode($r['id']); ?>" class="btn-edit">
            &#x270F; Edit &amp; Menu
          </a>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <?php endif; ?>
</main>
</body>
</html>