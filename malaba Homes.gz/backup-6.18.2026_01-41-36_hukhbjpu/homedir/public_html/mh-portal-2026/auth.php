<?php
// admin/auth.php -- Role-based auth, PHP 5.6 compatible
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }

// Role constants
define('ROLE_SUPER',    'superadmin');
define('ROLE_ADMIN',    'admin');
define('ROLE_LISTINGS', 'listings_manager');
define('ROLE_ORDERS',   'orders_manager');
define('ROLE_SOCIAL',   'social_manager');

$CURRENT_ROLE = isset($_SESSION['admin_role']) ? $_SESSION['admin_role'] : ROLE_ADMIN;
$CURRENT_NAME = isset($_SESSION['admin_name']) ? $_SESSION['admin_name'] : 'Staff';
$CURRENT_ID   = isset($_SESSION['admin_id'])   ? $_SESSION['admin_id']   : 0;

// Permission check helper
function can($permission) {
    global $CURRENT_ROLE;
    $perms = array(
        // full access
        ROLE_SUPER    => array('all','view_analytics', 'send_notifications'),
        ROLE_ADMIN    => array('all',  'view_analytics', 'send_notifications'),
        // listings girl: only listings + media
        ROLE_LISTINGS => array('listings','listing_form','listing_delete','upload'),
        // orders girl: only orders + inquiries
        ROLE_ORDERS   => array('orders','inquiries'),
        // social girl: read listings, analytics, upload
        ROLE_SOCIAL   => array('listings_read','analytics','upload','listing_form'),
    );
    $allowed = isset($perms[$CURRENT_ROLE]) ? $perms[$CURRENT_ROLE] : array();
    if (in_array('all', $allowed)) return true;
    return in_array($permission, $allowed);
}

// Page-level guard: call requirePerm('orders') at top of orders.php
function requirePerm($permission) {
    if (!can($permission)) {
        header('Location: denied.php'); exit;
    }
}

// Redirect each role to their home dashboard
function roleDashboard() {
    global $CURRENT_ROLE;
    $map = array(
        ROLE_LISTINGS => 'dash_listings.php',
        ROLE_ORDERS   => 'dash_orders.php',
        ROLE_SOCIAL   => 'dash_social.php',
    );
    return isset($map[$CURRENT_ROLE]) ? $map[$CURRENT_ROLE] : 'index.php';
}

// Role display info
function roleInfo() {
    global $CURRENT_ROLE;
    $info = array(
        ROLE_SUPER    => array('label'=>'Super Admin', 'color'=>'#8b5cf6', 'icon'=>'&#x1F451;'),
        ROLE_ADMIN    => array('label'=>'Admin',       'color'=>'#6C5CE7', 'icon'=>'&#x2699;&#xFE0F;'),
        ROLE_LISTINGS => array('label'=>'Listings',    'color'=>'#52B788', 'icon'=>'&#x1F4CB;'),
        ROLE_ORDERS   => array('label'=>'Orders',      'color'=>'#E8521A', 'icon'=>'&#x1F4E6;'),
        ROLE_SOCIAL   => array('label'=>'Social',      'color'=>'#4895EF', 'icon'=>'&#x1F4F1;'),
    );
    return isset($info[$CURRENT_ROLE]) ? $info[$CURRENT_ROLE] : $info[ROLE_ADMIN];
}
