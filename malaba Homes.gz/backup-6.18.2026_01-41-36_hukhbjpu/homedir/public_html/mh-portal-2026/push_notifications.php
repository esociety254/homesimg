<?php
/**
 * admin/push_notifications.php
 * Upload to: public_html/admin/push_notifications.php
 * The admin panel page to compose and send push notifications.
 */
require_once 'auth.php';
require_once 'db.php';
requirePerm('send_notifications');

$db = getDB();

/* ── Recent notifications ── */
$recent = array();
try {
    $s = $db->query(
        "SELECT * FROM push_notifications ORDER BY created_at DESC LIMIT 20"
    );
    $recent = $s->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {}

/* ── Subscriber counts ── */
$counts = array('all'=>0,'food'=>0,'shop'=>0,'homes'=>0,'orders'=>0);
try {
    $s = $db->query(
        "SELECT segment, COUNT(*) as n FROM push_subscribers
         WHERE is_active=1 GROUP BY segment"
    );
    while ($row = $s->fetch(PDO::FETCH_ASSOC)) {
        $counts[$row['segment']] = (int)$row['n'];
    }
    /* Total = all active */
    $tot = $db->query("SELECT COUNT(*) FROM push_subscribers WHERE is_active=1");
    $counts['total'] = (int)$tot->fetchColumn();
} catch (Exception $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Push Notifications — Malaba Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<style>
<?php include 'admin.css.php'; ?>

/* Push-specific styles */
.push-wrap { max-width: 720px; }

/* Subscriber stats */
.sub-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  margin-bottom: 20px;
}
@media(min-width:640px){ .sub-stats { grid-template-columns: repeat(6,1fr); } }
.sub-stat {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 14px 12px;
  text-align: center;
}
.sub-stat-num {
  font-family: 'Syne', sans-serif;
  font-size: 22px; font-weight: 800;
  color: var(--text); margin-bottom: 3px;
}
.sub-stat-lbl {
  font-size: 10px; font-weight: 700;
  color: var(--muted);
  text-transform: uppercase; letter-spacing: .5px;
}

/* Composer */
.composer {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 18px;
  padding: 24px;
  margin-bottom: 20px;
}
.composer-title {
  font-family: 'Syne', sans-serif;
  font-size: 14px; font-weight: 800;
  text-transform: uppercase; letter-spacing: .5px;
  color: var(--muted);
  margin-bottom: 18px;
  padding-bottom: 12px;
  border-bottom: 1px solid var(--border);
}
.field { margin-bottom: 16px; }
.field label {
  display: block;
  font-size: 11px; font-weight: 700;
  text-transform: uppercase; letter-spacing: .5px;
  color: var(--muted); margin-bottom: 6px;
}
.field input, .field textarea, .field select {
  width: 100%; padding: 10px 13px;
  background: var(--bg);
  border: 1.5px solid var(--border2);
  border-radius: 10px;
  color: var(--text);
  font-family: inherit; font-size: 14px;
  outline: none;
  transition: border-color .2s;
}
.field input:focus, .field textarea:focus, .field select:focus {
  border-color: var(--purple);
}
.field textarea { resize: vertical; min-height: 80px; }
.field .hint { font-size: 11px; color: var(--muted); margin-top: 4px; }

/* Segment selector */
.segment-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 8px;
  margin-top: 6px;
}
@media(min-width:500px){ .segment-grid { grid-template-columns: repeat(3,1fr); } }
.seg-opt {
  display: flex; align-items: center; gap: 9px;
  padding: 10px 12px;
  background: var(--bg);
  border: 2px solid var(--border2);
  border-radius: 11px;
  cursor: pointer;
  transition: all .18s;
}
.seg-opt.sel {
  border-color: var(--purple);
  background: rgba(139,92,246,.08);
}
.seg-opt:active { transform: scale(.98); }
.seg-opt input[type=radio] { display: none; }
.seg-ico { font-size: 18px; }
.seg-info {}
.seg-name { font-size: 12px; font-weight: 700; color: var(--text); }
.seg-count { font-size: 10px; color: var(--muted); }

/* Preview */
.notif-preview {
  background: linear-gradient(135deg, #1a1a2e, #16213e);
  border: 1px solid rgba(139,92,246,.2);
  border-radius: 16px;
  padding: 16px;
  margin-bottom: 16px;
}
.np-title {
  font-size: 11px; font-weight: 700;
  color: rgba(255,255,255,.4);
  text-transform: uppercase; letter-spacing: .5px;
  margin-bottom: 10px;
}
.np-card {
  background: rgba(255,255,255,.06);
  border-radius: 12px;
  padding: 12px 14px;
  display: flex; align-items: flex-start; gap: 12px;
}
.np-icon {
  width: 38px; height: 38px; border-radius: 10px;
  background: linear-gradient(135deg,#E8521A,#F5A623);
  display: flex; align-items: center; justify-content: center;
  font-size: 20px; flex-shrink: 0;
}
.np-body { flex: 1; min-width: 0; }
.np-notif-title {
  font-size: 14px; font-weight: 700; color: #fff;
  margin-bottom: 2px;
}
.np-notif-body {
  font-size: 12px; color: rgba(255,255,255,.55);
  line-height: 1.4;
  display: -webkit-box; -webkit-line-clamp: 2;
  -webkit-box-orient: vertical; overflow: hidden;
}
.np-time { font-size: 10px; color: rgba(255,255,255,.3); margin-top: 3px; }
.np-img {
  width: 52px; height: 52px; border-radius: 9px;
  object-fit: cover; flex-shrink: 0;
  display: none;
}
.np-img.show { display: block; }

/* Quick templates */
.templates {
  display: flex; gap: 6px;
  flex-wrap: wrap; margin-bottom: 14px;
}
.tpl-btn {
  padding: 5px 11px;
  background: rgba(139,92,246,.1);
  border: 1px solid rgba(139,92,246,.2);
  color: #c4b5fd;
  border-radius: 20px;
  font-size: 11px; font-weight: 700;
  cursor: pointer;
  transition: all .15s;
  font-family: inherit;
}
.tpl-btn:hover { background: rgba(139,92,246,.2); }
.tpl-btn:active { transform: scale(.95); }

/* Send button */
.send-btn {
  width: 100%; padding: 14px;
  background: linear-gradient(135deg, #7c3aed, #6366f1);
  color: #fff; border: none; border-radius: 13px;
  font-family: 'Syne', sans-serif;
  font-size: 17px; font-weight: 800;
  cursor: pointer;
  box-shadow: 0 4px 18px rgba(124,58,237,.35);
  transition: all .2s;
  display: flex; align-items: center; justify-content: center; gap: 8px;
}
.send-btn:hover { transform: translateY(-1px); box-shadow: 0 7px 24px rgba(124,58,237,.45); }
.send-btn:active { transform: scale(.98); }
.send-btn:disabled { opacity: .5; cursor: not-allowed; transform: none; }

/* Save draft */
.draft-btn {
  width: 100%; padding: 11px; margin-top: 8px;
  background: var(--bg);
  border: 1px solid var(--border2);
  color: var(--muted);
  border-radius: 13px;
  font-family: inherit; font-size: 13px; font-weight: 600;
  cursor: pointer; transition: all .18s;
}
.draft-btn:hover { border-color: var(--purple); color: var(--text); }

/* History table */
.history-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 18px;
  overflow: hidden;
}
.history-head {
  padding: 16px 20px;
  font-family: 'Syne', sans-serif;
  font-size: 13px; font-weight: 800;
  text-transform: uppercase; letter-spacing: .5px;
  color: var(--muted);
  border-bottom: 1px solid var(--border);
}
.history-row {
  display: grid;
  grid-template-columns: 1fr auto auto auto;
  gap: 12px;
  align-items: center;
  padding: 13px 20px;
  border-bottom: 1px solid var(--border);
  transition: background .13s;
}
.history-row:last-child { border-bottom: none; }
.history-row:hover { background: rgba(255,255,255,.02); }
.hr-title { font-size: 13px; font-weight: 600; color: var(--text); margin-bottom: 2px; }
.hr-body  { font-size: 11px; color: var(--muted);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 240px; }
.hr-badge {
  font-size: 10px; font-weight: 700; padding: 3px 9px;
  border-radius: 20px; white-space: nowrap;
}
.hr-sent  { background: rgba(34,197,94,.1);  color: #4ade80; }
.hr-draft { background: rgba(245,158,11,.1); color: #fcd34d; }
.hr-fail  { background: rgba(239,68,68,.1);  color: #fca5a5; }
.hr-num { font-size: 12px; color: var(--muted); white-space: nowrap; }
.hr-actions { display: flex; gap: 6px; }
.hr-resend {
  padding: 5px 10px; background: rgba(139,92,246,.1);
  border: 1px solid rgba(139,92,246,.2); color: #c4b5fd;
  border-radius: 8px; font-size: 11px; font-weight: 700;
  cursor: pointer; font-family: inherit;
}

/* Send result */
.send-result {
  padding: 14px 16px; border-radius: 12px;
  margin-bottom: 14px; font-size: 14px;
  display: none;
}
.sr-ok   { background: rgba(34,197,94,.1);  border: 1px solid rgba(34,197,94,.2);  color: #4ade80; }
.sr-fail { background: rgba(239,68,68,.1);  border: 1px solid rgba(239,68,68,.2);  color: #fca5a5; }

/* Char count */
.char-count { font-size: 10px; color: var(--muted); text-align: right; margin-top: 3px; }
.char-count.warn { color: #fcd34d; }
.char-count.over { color: #fca5a5; }
</style>
</head>
<body>
<?php include 'nav.php'; ?>

<main class="main">
<div class="push-wrap">

  <div class="page-header">
    <div>
      <h1 class="page-title">&#x1F514; Push Notifications</h1>
      <p class="page-sub">Send instant notifications to all your customers</p>
    </div>
  </div>

  <!-- SUBSCRIBER STATS -->
  <div class="sub-stats">
    <div class="sub-stat">
      <div class="sub-stat-num"><?php echo number_format($counts['total']); ?></div>
      <div class="sub-stat-lbl">Total</div>
    </div>
    <div class="sub-stat">
      <div class="sub-stat-num"><?php echo number_format($counts['food']); ?></div>
      <div class="sub-stat-lbl">Food</div>
    </div>
    <div class="sub-stat">
      <div class="sub-stat-num"><?php echo number_format($counts['shop']); ?></div>
      <div class="sub-stat-lbl">Shop</div>
    </div>
    <div class="sub-stat">
      <div class="sub-stat-num"><?php echo number_format($counts['homes']); ?></div>
      <div class="sub-stat-lbl">Homes</div>
    </div>
    <div class="sub-stat">
      <div class="sub-stat-num"><?php echo number_format($counts['orders']); ?></div>
      <div class="sub-stat-lbl">Orders</div>
    </div>
    <div class="sub-stat">
      <div class="sub-stat-num"><?php echo number_format($counts['all']); ?></div>
      <div class="sub-stat-lbl">General</div>
    </div>
  </div>

  <!-- SEND RESULT (hidden, shown after send) -->
  <div class="send-result sr-ok"  id="sendOk"></div>
  <div class="send-result sr-fail" id="sendFail"></div>

  <!-- COMPOSER -->
  <div class="composer">
    <div class="composer-title">&#x270F;&#xFE0F; Compose Notification</div>

    <!-- Quick templates -->
    <div class="field">
      <label>Quick Templates</label>
      <div class="templates">
        <button class="tpl-btn" onclick="fillTemplate('new_listing')">&#x1F3E0; New Listing</button>
        <button class="tpl-btn" onclick="fillTemplate('food_promo')">&#x1F354; Food Promo</button>
        <button class="tpl-btn" onclick="fillTemplate('shop_deal')">&#x1F6D2; Shop Deal</button>
        <button class="tpl-btn" onclick="fillTemplate('pizza_bogo')">&#x1F355; Pizza BOGO</button>
        <button class="tpl-btn" onclick="fillTemplate('lipa_promo')">&#x1F4B0; Lipa Mdogo</button>
        <button class="tpl-btn" onclick="fillTemplate('reengagement')">&#x1F44B; Re-engage</button>
      </div>
    </div>

    <!-- Title -->
    <div class="field">
      <label>Notification Title * <span id="titleCount" class="char-count">0/65</span></label>
      <input type="text" id="pnTitle" placeholder="e.g. New 2-Bed Apartment in Malaba CBD!"
             maxlength="65" oninput="updatePreview();updateCount('pnTitle','titleCount',65)">
    </div>

    <!-- Body -->
    <div class="field">
      <label>Message * <span id="bodyCount" class="char-count">0/240</span></label>
      <textarea id="pnBody" placeholder="e.g. Just listed — KSH 12,000/month. 2 bedrooms, fully furnished. Tap to view details →"
                maxlength="240" oninput="updatePreview();updateCount('pnBody','bodyCount',240)"></textarea>
    </div>

    <!-- Image URL (optional) -->
    <div class="field">
      <label>Image URL (optional)</label>
      <input type="url" id="pnImage" placeholder="https://... (Cloudinary image URL)"
             oninput="updatePreview()">
      <div class="hint">Shown as a large image in the notification. Use a Cloudinary URL for best results.</div>
    </div>

    <!-- Click URL -->
    <div class="field">
      <label>Opens This Page When Tapped</label>
      <select id="pnUrl" onchange="updatePreview()">
        <option value="/index.php">🏡 Home</option>
        <option value="/homes_listing.php">🏠 Homes Listing</option>
        <option value="/food_listing.php">🍔 Food Listing</option>
        <option value="/shop_listing.php">🛒 Shop Listing</option>
        <option value="/video_feed.php">▶ Watch &amp; Shop</option>
        <option value="/track_order.php">📦 Track Order</option>
        <option value="custom">✏️ Custom URL...</option>
      </select>
    </div>
    <div class="field" id="customUrlField" style="display:none;">
      <label>Custom URL</label>
      <input type="url" id="pnCustomUrl" placeholder="https://yoursite.com/page.php">
    </div>

    <!-- Segment -->
    <div class="field">
      <label>Send To</label>
      <div class="segment-grid">
        <label class="seg-opt sel" id="seg-all">
          <input type="radio" name="segment" value="all" checked>
          <span class="seg-ico">&#x1F310;</span>
          <span class="seg-info">
            <span class="seg-name">Everyone</span>
            <span class="seg-count"><?php echo $counts['total']; ?> devices</span>
          </span>
        </label>
        <label class="seg-opt" id="seg-food">
          <input type="radio" name="segment" value="food">
          <span class="seg-ico">&#x1F354;</span>
          <span class="seg-info">
            <span class="seg-name">Food Fans</span>
            <span class="seg-count"><?php echo $counts['food']; ?> devices</span>
          </span>
        </label>
        <label class="seg-opt" id="seg-shop">
          <input type="radio" name="segment" value="shop">
          <span class="seg-ico">&#x1F6D2;</span>
          <span class="seg-info">
            <span class="seg-name">Shoppers</span>
            <span class="seg-count"><?php echo $counts['shop']; ?> devices</span>
          </span>
        </label>
        <label class="seg-opt" id="seg-homes">
          <input type="radio" name="segment" value="homes">
          <span class="seg-ico">&#x1F3E0;</span>
          <span class="seg-info">
            <span class="seg-name">Home Seekers</span>
            <span class="seg-count"><?php echo $counts['homes']; ?> devices</span>
          </span>
        </label>
        <label class="seg-opt" id="seg-orders">
          <input type="radio" name="segment" value="orders">
          <span class="seg-ico">&#x1F4E6;</span>
          <span class="seg-info">
            <span class="seg-name">Customers</span>
            <span class="seg-count"><?php echo $counts['orders']; ?> devices</span>
          </span>
        </label>
      </div>
    </div>

    <!-- Live Preview -->
    <div class="notif-preview">
      <div class="np-title">&#x1F4F1; Preview — how it looks on phone</div>
      <div class="np-card">
        <div class="np-icon">&#x1F3E1;</div>
        <div class="np-body">
          <div class="np-notif-title" id="previewTitle">Your notification title</div>
          <div class="np-notif-body" id="previewBody">Your message will appear here…</div>
          <div class="np-time">Now &bull; Malaba Homes</div>
        </div>
        <img class="np-img" id="previewImg" src="" alt="">
      </div>
    </div>

    <!-- Save to log before sending -->
    <input type="hidden" id="currentNotifId" value="0">

    <!-- Send -->
    <button class="send-btn" id="sendBtn" onclick="confirmSend()">
      &#x1F514; Send Notification
    </button>
    <button class="draft-btn" onclick="saveDraft()">&#x1F4BE; Save as Draft</button>
  </div>

  <!-- HISTORY -->
  <?php if (!empty($recent)): ?>
  <div class="history-card">
    <div class="history-head">&#x1F4CB; Recent Notifications</div>
    <?php foreach ($recent as $n): ?>
    <div class="history-row">
      <div>
        <div class="hr-title"><?php echo htmlspecialchars($n['title']); ?></div>
        <div class="hr-body"><?php echo htmlspecialchars($n['body']); ?></div>
      </div>
      <div class="hr-num">
        &#x2705; <?php echo number_format((int)$n['sent_count']); ?> sent
      </div>
      <div>
        <span class="hr-badge <?php echo 'hr-'.$n['status']; ?>">
          <?php echo ucfirst($n['status']); ?>
        </span>
      </div>
      <div class="hr-actions">
        <button class="hr-resend"
          onclick="resendNotification(<?php echo (int)$n['id']; ?>,
            '<?php echo addslashes(htmlspecialchars($n['title'])); ?>',
            '<?php echo addslashes(htmlspecialchars($n['body'])); ?>',
            '<?php echo addslashes($n['click_url']); ?>')">
          Resend
        </button>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

</div>
</main>

<script>
/* ── TEMPLATES ── */
var TEMPLATES = {
  new_listing: {
    title: '🏠 New Home Just Listed!',
    body:  'A fresh listing just went live in Malaba. Affordable rent, great location. Tap to view →',
    url:   '/homes_listing.php'
  },
  food_promo: {
    title: '🍔 Hot Deals on Food Today!',
    body:  'Order now and get your food delivered fast. Special offers available today only →',
    url:   '/food_listing.php'
  },
  shop_deal: {
    title: '🛒 New Products in the Shop!',
    body:  'Fresh arrivals you\'ll love. Pay with Lipa Mdogo Mdogo — daily, weekly or twice a week →',
    url:   '/shop_listing.php'
  },
  pizza_bogo: {
    title: '🍕 PIZZA BOGO DAY is HERE!',
    body:  'Buy one pizza, get one FREE today only. Wednesday & Saturday special — order now! →',
    url:   '/food_listing.php'
  },
  lipa_promo: {
    title: '💰 Pay Small, Get Big!',
    body:  'Shop anything in Malaba Homes and pay in small instalments. Daily, weekly or twice a week →',
    url:   '/shop_listing.php'
  },
  reengagement: {
    title: '👋 We Miss You at Malaba Homes!',
    body:  'New homes, food deals and products have been added since your last visit. Come see what\'s new →',
    url:   '/index.php'
  }
};

function fillTemplate(key) {
  var tpl = TEMPLATES[key];
  if (!tpl) return;
  document.getElementById('pnTitle').value = tpl.title;
  document.getElementById('pnBody').value  = tpl.body;
  /* Set URL dropdown */
  var sel = document.getElementById('pnUrl');
  for (var i=0; i<sel.options.length; i++) {
    if (sel.options[i].value === tpl.url) { sel.selectedIndex=i; break; }
  }
  updatePreview();
  updateCount('pnTitle','titleCount',65);
  updateCount('pnBody','bodyCount',240);
}

/* ── URL dropdown ── */
document.getElementById('pnUrl').addEventListener('change', function() {
  document.getElementById('customUrlField').style.display =
    this.value === 'custom' ? 'block' : 'none';
  updatePreview();
});

/* ── Segment selection ── */
document.querySelectorAll('.seg-opt input[type=radio]').forEach(function(radio) {
  radio.addEventListener('change', function() {
    document.querySelectorAll('.seg-opt').forEach(function(o){ o.classList.remove('sel'); });
    this.closest('.seg-opt').classList.add('sel');
  });
});

/* ── Live preview ── */
function updatePreview() {
  var title = document.getElementById('pnTitle').value || 'Your notification title';
  var body  = document.getElementById('pnBody').value  || 'Your message will appear here…';
  var img   = document.getElementById('pnImage').value;
  document.getElementById('previewTitle').textContent = title;
  document.getElementById('previewBody').textContent  = body;
  var imgEl = document.getElementById('previewImg');
  if (img) { imgEl.src=img; imgEl.classList.add('show'); }
  else      { imgEl.classList.remove('show'); }
}

/* ── Char counter ── */
function updateCount(inputId, countId, max) {
  var val = document.getElementById(inputId).value.length;
  var el  = document.getElementById(countId);
  el.textContent = val + '/' + max;
  el.className   = 'char-count' + (val>max*0.9?' warn':'') + (val>=max?' over':'');
}

/* ── Get URL to send ── */
function getClickUrl() {
  var sel = document.getElementById('pnUrl').value;
  if (sel === 'custom') return document.getElementById('pnCustomUrl').value || '/index.php';
  return sel;
}

/* ── Confirm before sending ── */
function confirmSend() {
  var title   = document.getElementById('pnTitle').value.trim();
  var body    = document.getElementById('pnBody').value.trim();
  var segment = document.querySelector('.seg-opt input:checked').value;

  if (!title) { alert('Please enter a notification title'); return; }
  if (!body)  { alert('Please enter a message'); return; }

  /* Get device count for selected segment */
  var segCounts = <?php echo json_encode($counts); ?>;
  var count = segment === 'all' ? segCounts.total : (segCounts[segment] || 0);

  if (count === 0) {
    alert('No subscribers in this segment yet. Users need to allow notifications first.');
    return;
  }

  var ok = confirm(
    'Send this notification to ' + count + ' device' + (count!==1?'s':'') + '?\n\n' +
    'Title: ' + title + '\n' +
    'Message: ' + body.substring(0,80) + (body.length>80?'...':'') + '\n\n' +
    'Segment: ' + segment
  );
  if (ok) doSend(false);
}

/* ── Save draft ── */
function saveDraft() {
  var title   = document.getElementById('pnTitle').value.trim();
  var body    = document.getElementById('pnBody').value.trim();
  if (!title || !body) { alert('Enter a title and message first'); return; }
  doSaveLog('draft', function(id) {
    document.getElementById('currentNotifId').value = id;
    showResult(true, '💾 Draft saved (ID: '+id+')');
  });
}

/* ── Save to log ── */
function doSaveLog(status, cb) {
  var xhr = new XMLHttpRequest();
  xhr.open('POST', '/api/push_log.php', true);
  xhr.setRequestHeader('Content-Type','application/json');
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.onload = function() {
    try { var d=JSON.parse(xhr.responseText); if(d.id && cb) cb(d.id); } catch(e){}
  };
  xhr.send(JSON.stringify({
    title:   document.getElementById('pnTitle').value.trim(),
    body:    document.getElementById('pnBody').value.trim(),
    image:   document.getElementById('pnImage').value.trim(),
    url:     getClickUrl(),
    segment: document.querySelector('.seg-opt input:checked').value,
    status:  status
  }));
}

/* ── Do send ── */
function doSend(isDraft) {
  var btn = document.getElementById('sendBtn');
  btn.disabled = true;
  btn.innerHTML = '&#x23F3; Sending…';

  var notifId = parseInt(document.getElementById('currentNotifId').value) || 0;

  var xhr = new XMLHttpRequest();
  xhr.open('POST', '/api/push_send.php', true);
  xhr.setRequestHeader('Content-Type','application/json');
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout = 60000; /* 60s — sending to many devices takes time */
  xhr.onload = function() {
    btn.disabled = false;
    btn.innerHTML = '&#x1F514; Send Notification';
    try {
      var d = JSON.parse(xhr.responseText);
      if (d.success) {
        showResult(true,
          '✅ Sent to ' + d.sent + ' device' + (d.sent!==1?'s':'') +
          (d.failed?' · '+d.failed+' failed':'') +
          (d.deactivated?' · '+d.deactivated+' removed (uninstalled)':'')
        );
        /* Clear form */
        document.getElementById('pnTitle').value = '';
        document.getElementById('pnBody').value  = '';
        document.getElementById('pnImage').value = '';
        updatePreview();
        /* Reload history */
        setTimeout(function(){ location.reload(); }, 2000);
      } else {
        showResult(false, '❌ Error: ' + (d.error||'Unknown error'));
      }
    } catch(e) {
      showResult(false, '❌ Unexpected server response');
    }
  };
  xhr.onerror = xhr.ontimeout = function() {
    btn.disabled = false;
    btn.innerHTML = '&#x1F514; Send Notification';
    showResult(false, '❌ Network error or timeout. Check your Firebase config.');
  };
  xhr.send(JSON.stringify({
    title:    document.getElementById('pnTitle').value.trim(),
    body:     document.getElementById('pnBody').value.trim(),
    image:    document.getElementById('pnImage').value.trim(),
    url:      getClickUrl(),
    segment:  document.querySelector('.seg-opt input:checked').value,
    notif_id: notifId
  }));
}

/* ── Resend ── */
function resendNotification(id, title, body, url) {
  document.getElementById('pnTitle').value = title;
  document.getElementById('pnBody').value  = body;
  document.getElementById('currentNotifId').value = id;
  /* Scroll to composer */
  document.querySelector('.composer').scrollIntoView({behavior:'smooth'});
  updatePreview();
}

/* ── Show result ── */
function showResult(ok, msg) {
  var el = document.getElementById(ok ? 'sendOk' : 'sendFail');
  var ot = document.getElementById(ok ? 'sendFail' : 'sendOk');
  ot.style.display = 'none';
  el.textContent   = msg;
  el.style.display = 'block';
  el.scrollIntoView({behavior:'smooth', block:'center'});
  setTimeout(function(){ el.style.display='none'; }, 6000);
}
</script>
</body>
</html>