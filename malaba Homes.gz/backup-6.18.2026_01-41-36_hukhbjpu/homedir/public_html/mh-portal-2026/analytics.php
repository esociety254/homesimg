<?php
require_once 'auth.php';
require_once 'db.php';

$db = getDB();

// ── Date range ─────────────────────────────────────────────
$range  = $_GET['range'] ?? '30';   // 7 | 30 | 90 | 365 | all
$catF   = $_GET['cat']   ?? '';

$dateWhere = match($range) {
  '7'   => "AND o.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)",
  '30'  => "AND o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)",
  '90'  => "AND o.created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)",
  '365' => "AND o.created_at >= DATE_SUB(NOW(), INTERVAL 365 DAY)",
  default => "",
};
$catWhere = $catF ? "AND o.category = '$catF'" : "";

// ── KPI Cards ──────────────────────────────────────────────
$kpi = $db->query("
  SELECT
    COUNT(*)                                                  AS total_orders,
    SUM(CASE WHEN status='delivered' THEN 1 ELSE 0 END)       AS delivered,
    SUM(CASE WHEN status='cancelled' THEN 1 ELSE 0 END)       AS cancelled,
    SUM(CASE WHEN status NOT IN ('cancelled','pending') THEN 1 ELSE 0 END) AS confirmed,
    SUM(CASE WHEN payment_status='received' THEN total_amount ELSE 0 END) AS revenue,
    SUM(total_amount)                                         AS gmv,
    AVG(CASE WHEN payment_status='received' THEN total_amount ELSE NULL END) AS avg_order,
    SUM(CASE WHEN DATE(created_at)=CURDATE() THEN 1 ELSE 0 END) AS today_orders,
    SUM(CASE WHEN DATE(created_at)=CURDATE() AND payment_status='received' THEN total_amount ELSE 0 END) AS today_revenue
  FROM orders o
  WHERE 1=1 $dateWhere $catWhere
")->fetch();

// ── Revenue by category ────────────────────────────────────
$byCat = $db->query("
  SELECT
    o.category,
    COUNT(*)                                                  AS orders,
    SUM(CASE WHEN status='delivered' THEN 1 ELSE 0 END)       AS delivered,
    SUM(CASE WHEN payment_status='received' THEN total_amount ELSE 0 END) AS revenue,
    SUM(total_amount)                                         AS gmv,
    ROUND(AVG(CASE WHEN payment_status='received' THEN total_amount ELSE NULL END),0) AS avg_val,
    c.icon, c.name AS cat_name
  FROM orders o
  LEFT JOIN categories c ON c.slug = o.category
  WHERE 1=1 $dateWhere
  GROUP BY o.category
")->fetchAll();

// ── Daily revenue trend (last N days) ─────────────────────
$trendDays = min((int)$range ?: 30, 90);
$trend = $db->query("
  SELECT
    DATE(created_at)  AS day,
    COUNT(*)          AS orders,
    SUM(CASE WHEN payment_status='received' THEN total_amount ELSE 0 END) AS revenue
  FROM orders o
  WHERE created_at >= DATE_SUB(NOW(), INTERVAL $trendDays DAY) $catWhere
  GROUP BY DATE(created_at)
  ORDER BY day ASC
")->fetchAll();

// ── Status funnel ──────────────────────────────────────────
$funnel = $db->query("
  SELECT status, COUNT(*) AS n
  FROM orders o WHERE 1=1 $dateWhere $catWhere
  GROUP BY status
  ORDER BY FIELD(status,'pending','confirmed','processing','dispatched','delivered','cancelled')
")->fetchAll(PDO::FETCH_KEY_PAIR);

// ── Payment method breakdown ──────────────────────────────
$payMethods = $db->query("
  SELECT payment_method, COUNT(*) AS n,
    SUM(CASE WHEN payment_status='received' THEN total_amount ELSE 0 END) AS revenue
  FROM orders o WHERE 1=1 $dateWhere $catWhere
  GROUP BY payment_method
")->fetchAll();

// ── Top selling listings ──────────────────────────────────
$topListings = $db->query("
  SELECT
    o.listing_title, o.category,
    COUNT(*) AS orders,
    SUM(CASE WHEN payment_status='received' THEN total_amount ELSE 0 END) AS revenue,
    c.icon
  FROM orders o
  LEFT JOIN categories c ON c.slug = o.category
  WHERE o.listing_title IS NOT NULL $dateWhere $catWhere
  GROUP BY o.listing_title, o.category
  ORDER BY orders DESC
  LIMIT 10
")->fetchAll();

// ── Recent 5 orders ────────────────────────────────────────
$recentOrders = $db->query("
  SELECT o.order_ref, o.customer_name, o.category, o.status,
         o.payment_status, o.total_amount, o.created_at, c.icon
  FROM orders o
  LEFT JOIN categories c ON c.slug = o.category
  ORDER BY o.created_at DESC LIMIT 5
")->fetchAll();

// ── Monthly comparison ────────────────────────────────────
$monthly = $db->query("
  SELECT
    DATE_FORMAT(created_at,'%Y-%m') AS month,
    COUNT(*) AS orders,
    SUM(CASE WHEN payment_status='received' THEN total_amount ELSE 0 END) AS revenue
  FROM orders
  GROUP BY DATE_FORMAT(created_at,'%Y-%m')
  ORDER BY month DESC LIMIT 6
")->fetchAll();
$monthly = array_reverse($monthly);

// ── Customer stats ─────────────────────────────────────────
$customerStats = ['total'=>0,'with_orders'=>0,'repeat'=>0];
try {
    $cs = $db->query("SELECT COUNT(*) AS total FROM customers")->fetchColumn();
    $customerStats['total'] = (int)$cs;
    // Repeat customers: phone appears in orders more than once
    $rep = $db->query("SELECT COUNT(*) FROM (SELECT customer_phone, COUNT(*) AS n FROM orders GROUP BY customer_phone HAVING n > 1) t")->fetchColumn();
    $customerStats['repeat'] = (int)$rep;
} catch (Throwable $_) {}

// ── New customers this period ──────────────────────────────
$newCustomers = 0;
try {
    $ncQ = "SELECT COUNT(*) FROM orders WHERE 1=1 $dateWhere";
    // Unique phones that only appear in this date range
    $newCustomers = (int)$db->query($ncQ)->fetchColumn();
} catch (Throwable $_) {}

// ── Conversion rate ────────────────────────────────────────
$totalOrds  = (int)($kpi['total_orders'] ?? 0);
$delivered  = (int)($kpi['delivered'] ?? 0);
$convRate   = $totalOrds > 0 ? round(($delivered/$totalOrds)*100,1) : 0;
$cancelRate = $totalOrds > 0 ? round(((int)($kpi['cancelled']??0)/$totalOrds)*100,1) : 0;

function fmt($n): string { return 'KSH '.number_format((float)$n,0); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Analytics — Malaba Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
<?php include 'admin.css.php'; ?>

:root {
  --homes-c:#52B788; --food-c:#FF7043; --shop-c:#4895EF;
  --amber:#f59e0b;
}

/* KPI Grid */
.kpi-grid {
  display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
  gap:14px;margin-bottom:32px;
}
.kpi-card {
  background:var(--surface);border:1px solid var(--border);
  border-radius:16px;padding:20px 18px;position:relative;overflow:hidden;
}
.kpi-card::before {
  content:'';position:absolute;top:0;left:0;right:0;height:3px;
}
.kpi-card.amber::before {background:var(--amber);}
.kpi-card.green::before {background:var(--green);}
.kpi-card.blue::before  {background:var(--blue);}
.kpi-card.purple::before{background:var(--purple);}
.kpi-card.pink::before  {background:var(--pink);}
.kpi-card.teal::before  {background:#0d9488;}
.kpi-label {font-size:11px;font-weight:700;color:var(--muted);letter-spacing:.8px;text-transform:uppercase;margin-bottom:8px;}
.kpi-val   {font-size:28px;font-weight:800;color:#fff;letter-spacing:-1px;line-height:1;}
.kpi-sub   {font-size:12px;color:var(--muted);margin-top:6px;}
.kpi-change{font-size:12px;font-weight:600;margin-top:4px;}
.kpi-change.up  {color:var(--green);}
.kpi-change.down{color:#ff7675;}

/* Charts */
.charts-row {
  display:grid;grid-template-columns:2fr 1fr;gap:16px;margin-bottom:24px;
}
@media(max-width:900px){.charts-row{grid-template-columns:1fr;}}
.chart-card {
  background:var(--surface);border:1px solid var(--border);
  border-radius:16px;padding:24px;
}
.chart-title {
  font-size:15px;font-weight:700;color:#fff;margin-bottom:4px;
}
.chart-sub {font-size:12px;color:var(--muted);margin-bottom:20px;}
.chart-wrap {position:relative;height:220px;}

/* Category breakdown */
.cat-cards {
  display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:24px;
}
@media(max-width:700px){.cat-cards{grid-template-columns:1fr;}}
.cat-perf {
  background:var(--surface);border:1px solid var(--border);
  border-radius:16px;padding:22px;
}
.cat-perf-head {display:flex;align-items:center;gap:10px;margin-bottom:16px;}
.cat-emoji {font-size:24px;}
.cat-perf-name {font-size:14px;font-weight:700;color:#fff;}
.cat-perf-val  {font-size:22px;font-weight:800;color:#fff;margin-bottom:4px;}
.cat-bar-wrap  {height:6px;background:var(--border);border-radius:3px;margin:10px 0 6px;}
.cat-bar       {height:100%;border-radius:3px;transition:width .8s;}
.cat-meta      {display:flex;justify-content:space-between;font-size:11px;color:var(--muted);}

/* Progress bar for funnel */
.funnel {display:flex;flex-direction:column;gap:10px;}
.funnel-row {display:flex;align-items:center;gap:12px;}
.funnel-label {width:90px;font-size:12px;font-weight:600;color:var(--muted);text-align:right;}
.funnel-bar-wrap{flex:1;height:22px;background:var(--border);border-radius:6px;overflow:hidden;}
.funnel-bar    {height:100%;border-radius:6px;display:flex;align-items:center;padding:0 8px;font-size:11px;font-weight:700;color:#fff;white-space:nowrap;}
.funnel-count  {width:40px;font-size:13px;font-weight:700;color:#fff;}

/* Table styles */
.analytics-table {width:100%;border-collapse:collapse;font-size:13px;}
.analytics-table th {text-align:left;padding:10px 14px;font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.7px;border-bottom:1px solid var(--border);}
.analytics-table td {padding:12px 14px;border-bottom:1px solid var(--border);}
.analytics-table tr:last-child td{border-bottom:none;}
.analytics-table tr:hover td{background:rgba(255,255,255,.02);}

/* Range pills */
.range-pills{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:28px;align-items:center;}
.range-pill{
  padding:7px 16px;border-radius:30px;font-size:12px;font-weight:600;
  border:1px solid var(--border);background:var(--surface);color:var(--muted);
  text-decoration:none;transition:all .15s;
}
.range-pill.active,.range-pill:hover{background:var(--purple);border-color:var(--purple);color:#fff;}
.range-sep{color:var(--muted);font-size:12px;}

/* Stat inline */
.stat-inline{display:flex;align-items:center;gap:6px;font-size:13px;}
.dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;}
</style>
</head>
<body>
<?php include 'nav.php'; ?>

<main class="main">

  <!-- Header -->
  <div class="page-header">
    <div>
      <h1 class="page-title">📈 Analytics</h1>
      <p class="page-sub">Business performance dashboard</p>
    </div>
    <a href="orders.php" class="btn btn-secondary">← All Orders</a>
  </div>

  <!-- Range filters -->
  <div class="range-pills">
    <span class="range-sep">Period:</span>
    <?php foreach (['7'=>'7 Days','30'=>'30 Days','90'=>'90 Days','365'=>'1 Year','all'=>'All Time'] as $v=>$l): ?>
    <a href="?range=<?= $v ?><?= $catF?"&cat=$catF":'' ?>" class="range-pill <?= $range===$v?'active':'' ?>"><?= $l ?></a>
    <?php endforeach; ?>
    <span class="range-sep" style="margin-left:8px;">Category:</span>
    <a href="?range=<?= $range ?>" class="range-pill <?= !$catF?'active':'' ?>">All</a>
    <a href="?range=<?= $range ?>&cat=houses" class="range-pill <?= $catF==='houses'?'active':'' ?>">🏠 Homes</a>
    <a href="?range=<?= $range ?>&cat=food"   class="range-pill <?= $catF==='food'  ?'active':'' ?>">🍔 Food</a>
    <a href="?range=<?= $range ?>&cat=items"  class="range-pill <?= $catF==='items' ?'active':'' ?>">🛋️ Shop</a>
  </div>

  <!-- KPIs -->
  <div class="kpi-grid">
    <div class="kpi-card amber">
      <div class="kpi-label">Total Revenue</div>
      <div class="kpi-val"><?= fmt($kpi['revenue'] ?? 0) ?></div>
      <div class="kpi-sub">Payments received</div>
    </div>
    <div class="kpi-card green">
      <div class="kpi-label">Total GMV</div>
      <div class="kpi-val"><?= fmt($kpi['gmv'] ?? 0) ?></div>
      <div class="kpi-sub">Gross merchandise value</div>
    </div>
    <div class="kpi-card blue">
      <div class="kpi-label">Total Orders</div>
      <div class="kpi-val"><?= number_format((int)($kpi['total_orders']??0)) ?></div>
      <div class="kpi-sub"><?= $kpi['today_orders'] ?? 0 ?> today</div>
    </div>
    <div class="kpi-card green">
      <div class="kpi-label">Delivered</div>
      <div class="kpi-val"><?= number_format($delivered) ?></div>
      <div class="kpi-sub kpi-change up">↑ <?= $convRate ?>% conv. rate</div>
    </div>
    <div class="kpi-card purple">
      <div class="kpi-label">Avg Order Value</div>
      <div class="kpi-val"><?= fmt($kpi['avg_order'] ?? 0) ?></div>
      <div class="kpi-sub">Per paid order</div>
    </div>
    <div class="kpi-card pink">
      <div class="kpi-label">Today Revenue</div>
      <div class="kpi-val"><?= fmt($kpi['today_revenue'] ?? 0) ?></div>
      <div class="kpi-sub"><?= $kpi['today_orders'] ?? 0 ?> orders today</div>
    </div>
    <div class="kpi-card teal">
      <div class="kpi-label">Cancellation Rate</div>
      <div class="kpi-val"><?= $cancelRate ?>%</div>
      <div class="kpi-sub kpi-change <?= $cancelRate > 15 ? 'down' : 'up' ?>"><?= $cancelRate > 15 ? '↑ High' : '✓ Healthy' ?></div>
    </div>
    <div class="kpi-card blue">
      <div class="kpi-label">Confirmed</div>
      <div class="kpi-val"><?= number_format((int)($kpi['confirmed']??0)) ?></div>
      <div class="kpi-sub">Active orders</div>
    </div>
    <div class="kpi-card purple">
      <div class="kpi-label">Saved Customers</div>
      <div class="kpi-val"><?= number_format($customerStats['total']) ?></div>
      <div class="kpi-sub"><?= $customerStats['repeat'] ?> repeat buyers</div>
    </div>
  </div>

  <!-- Revenue Trend + Order Funnel -->
  <div class="charts-row">
    <div class="chart-card">
      <div class="chart-title">Revenue Trend</div>
      <div class="chart-sub">Daily revenue and order volume — last <?= $trendDays ?> days</div>
      <div class="chart-wrap"><canvas id="trendChart"></canvas></div>
    </div>
    <div class="chart-card">
      <div class="chart-title">Order Funnel</div>
      <div class="chart-sub">Orders by current status</div>
      <?php
      $funnelOrder = ['pending','confirmed','processing','dispatched','delivered','cancelled'];
      $funnelColors = ['#f59e0b','#0984e3','#8b5cf6','#0d9488','#00B894','#d63031'];
      $maxF = max(array_values($funnel) ?: [1]);
      ?>
      <div class="funnel" style="margin-top:8px;">
        <?php foreach ($funnelOrder as $i=>$s): $n=$funnel[$s]??0; $pct=round(($n/max($maxF,1))*100); ?>
        <div class="funnel-row">
          <div class="funnel-label"><?= ucfirst($s) ?></div>
          <div class="funnel-bar-wrap">
            <div class="funnel-bar" style="width:<?= max($pct,4) ?>%;background:<?= $funnelColors[$i] ?>;"><?= $n > 0 ? $n : '' ?></div>
          </div>
          <div class="funnel-count"><?= $n ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Category Performance -->
  <h2 style="font-size:16px;font-weight:700;color:#fff;margin-bottom:16px;">Category Performance</h2>
  <?php
  $catColors = ['houses'=>'var(--homes-c)','food'=>'var(--food-c)','items'=>'var(--shop-c)'];
  $maxRev = max(array_column($byCat,'revenue') ?: [1]);
  ?>
  <div class="cat-cards">
    <?php foreach ($byCat as $c):
      $col = $catColors[$c['category']] ?? 'var(--muted)';
      $pct = $maxRev > 0 ? round(($c['revenue']/$maxRev)*100) : 0;
    ?>
    <div class="cat-perf">
      <div class="cat-perf-head">
        <span class="cat-emoji"><?= $c['icon'] ?? '' ?></span>
        <div>
          <div class="cat-perf-name"><?= htmlspecialchars($c['cat_name'] ?? ucfirst($c['category'])) ?></div>
          <div style="font-size:11px;color:var(--muted);"><?= $c['orders'] ?> orders</div>
        </div>
      </div>
      <div class="kpi-label">Revenue Collected</div>
      <div class="cat-perf-val"><?= fmt($c['revenue']) ?></div>
      <div class="cat-bar-wrap">
        <div class="cat-bar" style="width:<?= $pct ?>%;background:<?= $col ?>;"></div>
      </div>
      <div class="cat-meta">
        <span>GMV: <?= fmt($c['gmv']) ?></span>
        <span>Avg: <?= fmt($c['avg_val'] ?? 0) ?></span>
      </div>
      <div style="margin-top:12px;display:flex;gap:12px;flex-wrap:wrap;">
        <div class="stat-inline"><div class="dot" style="background:var(--green);"></div><span><?= $c['delivered'] ?> delivered</span></div>
        <div class="stat-inline"><div class="dot" style="background:var(--blue);"></div><span><?= $c['orders'] - $c['delivered'] ?> in progress</span></div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (empty($byCat)): ?>
    <div class="cat-perf" style="grid-column:1/-1;text-align:center;color:var(--muted);padding:40px;">No order data yet.</div>
    <?php endif; ?>
  </div>

  <!-- Monthly + Payment method side by side -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px;">
    <!-- Monthly trend -->
    <div class="chart-card">
      <div class="chart-title">Monthly Revenue</div>
      <div class="chart-sub">Revenue vs GMV per month</div>
      <div class="chart-wrap"><canvas id="monthlyChart"></canvas></div>
    </div>

    <!-- Payment method donut -->
    <div class="chart-card">
      <div class="chart-title">Payment Methods</div>
      <div class="chart-sub">How customers are paying</div>
      <div class="chart-wrap" style="height:180px;margin:0 auto;max-width:200px;"><canvas id="payChart"></canvas></div>
      <div style="margin-top:16px;display:flex;flex-direction:column;gap:8px;">
        <?php
        $payColors = ['cash'=>'#f59e0b','mpesa'=>'#52B788','cash_on_delivery'=>'#4895EF','mpesa_on_delivery'=>'#8b5cf6'];
        foreach ($payMethods as $pm):
          $col = $payColors[$pm['payment_method']] ?? 'var(--muted)';
        ?>
        <div class="stat-inline">
          <div class="dot" style="background:<?= $col ?>;"></div>
          <span style="flex:1;"><?= ucwords(str_replace('_',' ',$pm['payment_method'])) ?></span>
          <strong><?= $pm['n'] ?> orders</strong>
          <span style="color:var(--muted);font-size:11px;"><?= fmt($pm['revenue']) ?></span>
        </div>
        <?php endforeach; ?>
        <?php if (empty($payMethods)): ?>
        <div style="color:var(--muted);font-size:13px;text-align:center;padding:12px;">No data yet</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Top Performing Listings -->
  <div class="chart-card" style="margin-bottom:24px;">
    <div class="chart-title">🏆 Top Performing Listings</div>
    <div class="chart-sub">Most ordered items by volume</div>
    <table class="analytics-table" style="margin-top:8px;">
      <thead>
        <tr>
          <th>#</th>
          <th>Listing</th>
          <th>Category</th>
          <th>Orders</th>
          <th>Revenue</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$topListings): ?>
        <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:30px;">No data yet — orders will appear here once placed.</td></tr>
        <?php endif; ?>
        <?php foreach ($topListings as $i=>$t): ?>
        <tr>
          <td style="color:var(--muted);font-weight:700;"><?= $i+1 ?></td>
          <td style="font-weight:600;color:#fff;"><?= htmlspecialchars($t['listing_title']) ?></td>
          <td><span class="badge <?= match($t['category']){ 'houses'=>'purple','food'=>'pink',default=>'green' } ?>"><?= $t['icon'] ?? '' ?> <?= ucfirst($t['category']) ?></span></td>
          <td style="font-weight:700;"><?= $t['orders'] ?></td>
          <td style="font-weight:700;color:var(--green);"><?= fmt($t['revenue']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Recent Orders -->
  <div class="chart-card">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
      <div>
        <div class="chart-title">Recent Orders</div>
        <div class="chart-sub">Last 5 orders placed</div>
      </div>
      <a href="orders.php" class="btn btn-secondary" style="font-size:12px;">View All →</a>
    </div>
    <table class="analytics-table">
      <thead>
        <tr><th>Ref</th><th>Customer</th><th>Category</th><th>Amount</th><th>Status</th><th>Date</th></tr>
      </thead>
      <tbody>
        <?php if (!$recentOrders): ?>
        <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:30px;">No orders yet.</td></tr>
        <?php endif; ?>
        <?php foreach ($recentOrders as $r): ?>
        <tr>
          <td style="font-size:11px;color:var(--muted);font-weight:700;"><?= $r['order_ref'] ?></td>
          <td style="font-weight:600;"><?= htmlspecialchars($r['customer_name']) ?></td>
          <td><span class="badge <?= match($r['category']){ 'houses'=>'purple','food'=>'pink',default=>'green' } ?>"><?= $r['icon']??'' ?> <?= ucfirst($r['category']) ?></span></td>
          <td style="color:var(--green);font-weight:700;"><?= $r['total_amount'] > 0 ? fmt($r['total_amount']) : '—' ?></td>
          <td><span class="status-badge sb-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
          <td style="color:var(--muted);font-size:12px;"><?= date('d M H:i',strtotime($r['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

</main>

<style>
/* inline fix for the 2-col grid */
@media(max-width:700px){
  div[style*="grid-template-columns:1fr 1fr"]{grid-template-columns:1fr!important;}
}
.status-badge{display:inline-flex;align-items:center;gap:5px;padding:4px 10px;border-radius:20px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;}
.sb-pending{background:rgba(245,158,11,.15);color:#f59e0b;}
.sb-confirmed{background:rgba(9,132,227,.15);color:#74b9ff;}
.sb-processing{background:rgba(139,92,246,.15);color:#a78bfa;}
.sb-dispatched{background:rgba(13,148,136,.15);color:#2dd4bf;}
.sb-delivered{background:rgba(0,184,148,.15);color:var(--green);}
.sb-cancelled{background:rgba(214,48,49,.15);color:#ff7675;}
</style>

<script>
const CHART_DEFAULTS = {
  color: '#888',
  borderColor: 'rgba(255,255,255,0.06)',
  plugins: { legend:{ labels:{ color:'#888', font:{ size:11 } } } },
  scales: {
    x: { grid:{ color:'rgba(255,255,255,0.05)' }, ticks:{ color:'#888', font:{size:11} } },
    y: { grid:{ color:'rgba(255,255,255,0.05)' }, ticks:{ color:'#888', font:{size:11} } },
  }
};

/* ── Revenue Trend Chart ── */
<?php
$trendLabels  = array_column($trend,'day');
$trendRevenue = array_column($trend,'revenue');
$trendOrders  = array_column($trend,'orders');
// Fill any gaps with 0 (optional — Chart.js handles sparse data fine)
?>
new Chart(document.getElementById('trendChart'), {
  type: 'bar',
  data: {
    labels: <?= json_encode(array_map(fn($d) => date('d M', strtotime($d)), $trendLabels)) ?>,
    datasets: [
      {
        label: 'Revenue (KSH)',
        data: <?= json_encode(array_map('floatval', $trendRevenue)) ?>,
        backgroundColor: 'rgba(232,82,26,0.7)',
        borderRadius: 4,
        yAxisID: 'y',
      },
      {
        label: 'Orders',
        data: <?= json_encode(array_map('intval', $trendOrders)) ?>,
        type: 'line',
        borderColor: '#4895EF',
        backgroundColor: 'rgba(72,149,239,0.1)',
        fill: true,
        tension: 0.4,
        pointRadius: 3,
        yAxisID: 'y1',
      }
    ]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend:{ labels:{ color:'#888', font:{size:11} } } },
    scales: {
      x:  { grid:{ color:'rgba(255,255,255,0.05)' }, ticks:{ color:'#888', font:{size:10}, maxTicksLimit:10 } },
      y:  { grid:{ color:'rgba(255,255,255,0.05)' }, ticks:{ color:'#888', font:{size:10}, callback: v => 'KSH '+v.toLocaleString() }, position:'left' },
      y1: { display:true, position:'right', grid:{ drawOnChartArea:false }, ticks:{ color:'#888', font:{size:10} } }
    }
  }
});

/* ── Monthly Chart ── */
<?php
$mLabels  = array_map(fn($m) => date('M y', strtotime($m['month'].'-01')), $monthly);
$mRevenue = array_column($monthly,'revenue');
$mGmv     = array_column($monthly,'gmv');
$mOrders  = array_column($monthly,'orders');
?>
new Chart(document.getElementById('monthlyChart'), {
  type: 'bar',
  data: {
    labels: <?= json_encode($mLabels) ?>,
    datasets: [
      {
        label: 'Revenue',
        data: <?= json_encode(array_map('floatval',$mRevenue)) ?>,
        backgroundColor: 'rgba(82,183,136,0.75)',
        borderRadius: 5,
      },
      {
        label: 'GMV',
        data: <?= json_encode(array_map('floatval',$mGmv)) ?>,
        backgroundColor: 'rgba(72,149,239,0.4)',
        borderRadius: 5,
      }
    ]
  },
  options: {
    responsive:true, maintainAspectRatio:false,
    plugins:{ legend:{ labels:{ color:'#888', font:{size:11} } } },
    scales:{
      x:{ grid:{color:'rgba(255,255,255,.05)'}, ticks:{color:'#888',font:{size:10}} },
      y:{ grid:{color:'rgba(255,255,255,.05)'}, ticks:{color:'#888',font:{size:10}, callback: v=>'KSH '+v.toLocaleString()} }
    }
  }
});

/* ── Payment method donut ── */
<?php
$pmLabels = array_map(fn($p) => ucwords(str_replace('_',' ',$p['payment_method'])), $payMethods);
$pmData   = array_column($payMethods,'n');
$pmColors = ['#f59e0b','#52B788','#4895EF','#8b5cf6','#0d9488'];
?>
<?php if ($payMethods): ?>
new Chart(document.getElementById('payChart'), {
  type: 'doughnut',
  data: {
    labels: <?= json_encode($pmLabels) ?>,
    datasets: [{
      data: <?= json_encode($pmData) ?>,
      backgroundColor: <?= json_encode(array_slice($pmColors, 0, count($payMethods))) ?>,
      borderWidth: 0, hoverOffset: 8,
    }]
  },
  options: {
    responsive:true, maintainAspectRatio:false, cutout:'70%',
    plugins:{ legend:{ display:false } }
  }
});
<?php else: ?>
document.getElementById('payChart').parentElement.innerHTML = '<p style="color:var(--muted);font-size:13px;text-align:center;padding:40px 0;">No payment data yet</p>';
<?php endif; ?>

/* ── Animate category bars on load ── */
document.querySelectorAll('.cat-bar').forEach(b => {
  const w = b.style.width; b.style.width='0';
  setTimeout(()=>{ b.style.width=w; },300);
});
</script>
</body>
</html>
