<?php
// admin/login.php -- PHP 5.6 compatible, role-aware
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// Already logged in -- go to dashboard
if (!empty($_SESSION['admin_id'])) {
    $roleMap = array(
        'listings_manager' => 'dash_listings.php',
        'orders_manager'   => 'dash_orders.php',
        'social_manager'   => 'dash_social.php',
    );
    $role = isset($_SESSION['admin_role']) ? $_SESSION['admin_role'] : '';
    $dest = isset($roleMap[$role]) ? $roleMap[$role] : 'index.php';
    header('Location: ' . $dest); exit;
}

require_once 'db.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim(isset($_POST['username']) ? $_POST['username'] : '');
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if ($username === '' || $password === '') {
        $error = 'Please enter both username and password.';
    } else {
        try {
            $db   = getDB();
            $stmt = $db->prepare("SELECT id, name, password_hash, role FROM admins WHERE username = ? LIMIT 1");
            $stmt->execute(array($username));
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($admin && password_verify($password, $admin['password_hash'])) {
                // Successful login
                session_regenerate_id(true);
                $_SESSION['admin_id']   = $admin['id'];
                $_SESSION['admin_name'] = $admin['name'];
                $_SESSION['admin_role'] = isset($admin['role']) ? $admin['role'] : 'admin';

                // Update last_login if column exists
                try {
                    $db->prepare("UPDATE admins SET last_login = NOW() WHERE id = ?")
                       ->execute(array($admin['id']));
                } catch (Exception $e) {}

                // Route by role
                $roleMap = array(
                    'listings_manager' => 'dash_listings.php',
                    'orders_manager'   => 'dash_orders.php',
                    'social_manager'   => 'dash_social.php',
                );
                $dest = isset($roleMap[$admin['role']]) ? $roleMap[$admin['role']] : 'index.php';
                header('Location: ' . $dest); exit;

            } elseif ($admin && !password_verify($password, $admin['password_hash'])) {
                $error = 'Wrong password. Please try again.';
            } else {
                $error = 'Username not found. Check spelling.';
            }
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff Login &mdash; Malaba Homes</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'DM Sans',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#080604;padding:20px;background-image:radial-gradient(ellipse 70% 50% at 50% -5%,rgba(232,82,26,.15) 0%,transparent 70%);}
.wrap{width:100%;max-width:420px;}
.brand{text-align:center;margin-bottom:28px;}
.brand-mark{width:52px;height:52px;border-radius:14px;background:linear-gradient(135deg,#E8521A,#FF7043);display:flex;align-items:center;justify-content:center;font-size:24px;margin:0 auto 10px;box-shadow:0 8px 24px rgba(232,82,26,.4);}
.brand-name{font-family:'Syne',sans-serif;font-weight:800;font-size:20px;color:#F2EDE6;letter-spacing:-.4px;}
.brand-sub{font-size:13px;color:#6E6560;margin-top:3px;}
.role-hint{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:24px;}
.rh{padding:11px 8px;border-radius:12px;text-align:center;border:1px solid;}
.rh-l{background:rgba(82,183,136,.07);border-color:rgba(82,183,136,.2);}
.rh-o{background:rgba(232,82,26,.07);border-color:rgba(232,82,26,.2);}
.rh-s{background:rgba(72,149,239,.07);border-color:rgba(72,149,239,.2);}
.rh-icon{font-size:20px;margin-bottom:4px;}
.rh-name{font-size:10px;font-weight:700;letter-spacing:.3px;text-transform:uppercase;}
.rh-l .rh-name{color:#52B788;}
.rh-o .rh-name{color:#FF7043;}
.rh-s .rh-name{color:#4895EF;}
.card{background:#141210;border:1px solid rgba(255,255,255,.08);border-radius:22px;padding:32px;}
.error{background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.2);color:#fca5a5;border-radius:11px;padding:12px 16px;font-size:13px;margin-bottom:18px;display:flex;align-items:center;gap:8px;line-height:1.4;}
.field{margin-bottom:16px;}
.field label{display:block;font-size:11px;font-weight:700;color:#6E6560;letter-spacing:.6px;text-transform:uppercase;margin-bottom:7px;}
.input-wrap{display:flex;align-items:center;background:#0D0B08;border:1.5px solid rgba(255,255,255,.08);border-radius:11px;overflow:hidden;transition:border-color .2s;}
.input-wrap:focus-within{border-color:#E8521A;}
.input-wrap svg{margin:0 12px;color:#6E6560;flex-shrink:0;width:15px;height:15px;}
.input-wrap input{flex:1;padding:13px 14px 13px 0;background:transparent;border:none;outline:none;font-family:inherit;font-size:15px;color:#F2EDE6;}
.input-wrap input::placeholder{color:#4a4540;}
.submit-btn{width:100%;padding:14px;margin-top:6px;background:linear-gradient(135deg,#E8521A,#FF7043);border:none;border-radius:11px;color:#fff;font-size:15px;font-weight:700;font-family:inherit;cursor:pointer;transition:all .2s;box-shadow:0 4px 20px rgba(232,82,26,.3);}
.submit-btn:hover{transform:translateY(-1px);box-shadow:0 8px 28px rgba(232,82,26,.4);}
.submit-btn:active{transform:scale(.98);}
.back-link{text-align:center;margin-top:18px;font-size:13px;color:#6E6560;}
.back-link a{color:#E8521A;text-decoration:none;}
</style>
</head>
<body>
<div class="wrap">
  <div class="brand">
    <div class="brand-mark">&#x1F3E1;</div>
    <div class="brand-name">Malaba Admin</div>
    <div class="brand-sub">Staff Portal &mdash; Sign in to your dashboard</div>
  </div>

  <div class="role-hint">
    <div class="rh rh-l"><div class="rh-icon">&#x1F4CB;</div><div class="rh-name">Listings</div></div>
    <div class="rh rh-o"><div class="rh-icon">&#x1F4E6;</div><div class="rh-name">Orders</div></div>
    <div class="rh rh-s"><div class="rh-icon">&#x1F4F1;</div><div class="rh-name">Social</div></div>
  </div>

  <div class="card">
    <?php if ($error !== ''): ?>
    <div class="error">&#x26A0;&#xFE0F; <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    <form method="POST" autocomplete="on">
      <div class="field">
        <label>Username</label>
        <div class="input-wrap">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          <input type="text" name="username" placeholder="Your username"
                 value="<?php echo htmlspecialchars(isset($_POST['username'])?$_POST['username']:''); ?>"
                 required autofocus autocomplete="username">
        </div>
      </div>
      <div class="field">
        <label>Password</label>
        <div class="input-wrap">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          <input type="password" name="password" placeholder="Your password"
                 required autocomplete="current-password">
        </div>
      </div>
      <button type="submit" class="submit-btn">Sign In &#x2192;</button>
    </form>
  </div>
  <div class="back-link"><a href="../index.php">&#x2190; Back to website</a></div>
</div>
</body>
</html>