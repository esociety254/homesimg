/**
 * push_register.js — Malaba Homes Push Notification Registration
 * Upload to: public_html/push_register.js
 *
 * FIXES:
 * - No delay, no scroll requirement — asks on first visit
 * - Persistent: re-asks users who dismissed (every 3 days)
 * - Custom permission UI before native prompt (better UX)
 * - Works on Oppo, Samsung, all Android Chrome browsers
 * - Silent token refresh when token expires
 */
(function() {
  'use strict';

  /* ── Skip if browser doesn't support push ── */
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;
  if (typeof FIREBASE_CONFIG === 'undefined' || typeof VAPID_KEY === 'undefined') return;

  /* ── Already installed as PWA standalone ── */
  var isStandalone = window.matchMedia('(display-mode: standalone)').matches
                     || window.navigator.standalone === true;

  /* ── Storage helpers ── */
  function store(k, v) { try { localStorage.setItem(k, v); } catch(e){} }
  function read(k)      { try { return localStorage.getItem(k); } catch(e){ return null; } }

  /* ── Should we show our custom prompt? ── */
  function shouldPrompt() {
    /* Already granted — just get/refresh token silently */
    if (Notification.permission === 'granted') return false;
    /* User permanently denied in browser settings — can't do anything */
    if (Notification.permission === 'denied')  return false;
    /* User dismissed our custom UI — wait 3 days then try again */
    var snoozed = parseInt(read('mh_push_snooze') || '0');
    if (snoozed && Date.now() < snoozed) return false;
    return true;
  }

  /* ── Inject custom permission card ── */
  function showPermissionCard() {
    /* Don't show twice */
    if (document.getElementById('mhPushCard')) return;

    var card = document.createElement('div');
    card.id = 'mhPushCard';
    card.innerHTML =
      '<div id="mhPushOverlay" style="' +
        'position:fixed;bottom:0;left:0;right:0;z-index:99999;' +
        'padding:12px 14px calc(12px + env(safe-area-inset-bottom,0px));' +
        'background:#0f0800;' +
        'border-top:2px solid #E8521A;' +
        'border-radius:22px 22px 0 0;' +
        'box-shadow:0 -8px 40px rgba(0,0,0,.75);' +
        'transform:translateY(100%);' +
        'transition:transform .4s cubic-bezier(.32,1,.68,1);' +
        'font-family:\'Outfit\',system-ui,sans-serif;">' +
        /* Handle bar */
        '<div style="display:flex;justify-content:center;padding-bottom:10px;">' +
          '<div style="width:38px;height:4px;border-radius:2px;background:rgba(255,255,255,.15);"></div>' +
        '</div>' +
        /* Content row */
        '<div style="display:flex;align-items:center;gap:13px;margin-bottom:13px;">' +
          '<div style="width:50px;height:50px;border-radius:14px;flex-shrink:0;' +
            'background:linear-gradient(135deg,#E8521A,#F5A623);' +
            'display:flex;align-items:center;justify-content:center;' +
            'font-size:26px;box-shadow:0 4px 16px rgba(232,82,26,.45);">&#x1F3E1;</div>' +
          '<div style="flex:1;">' +
            '<div style="font-size:16px;font-weight:800;color:#fff;margin-bottom:3px;' +
              'font-family:\'Bebas Neue\',\'Outfit\',system-ui,sans-serif;letter-spacing:.5px;">' +
              'Stay Updated with Malaba Homes</div>' +
            '<div style="font-size:12px;color:rgba(255,255,255,.5);line-height:1.4;">' +
              'Get notified about new homes, food deals, BOGO pizza days &amp; shop offers</div>' +
          '</div>' +
        '</div>' +
        /* Buttons */
        '<div style="display:flex;gap:9px;">' +
          '<button id="mhPushAllow" style="' +
            'flex:1;padding:13px;background:linear-gradient(135deg,#E8521A,#FF7043);' +
            'color:#fff;border:none;border-radius:13px;' +
            'font-family:\'Bebas Neue\',\'Outfit\',system-ui,sans-serif;' +
            'font-size:17px;letter-spacing:.5px;cursor:pointer;' +
            'box-shadow:0 4px 16px rgba(232,82,26,.4);">' +
            '&#x1F514; Allow Notifications</button>' +
          '<button id="mhPushLater" style="' +
            'padding:13px 16px;' +
            'background:rgba(255,255,255,.07);' +
            'border:1px solid rgba(255,255,255,.12);' +
            'border-radius:13px;color:rgba(255,255,255,.5);' +
            'font-family:system-ui,sans-serif;font-size:13px;font-weight:600;' +
            'cursor:pointer;">Later</button>' +
        '</div>' +
      '</div>';

    document.body.appendChild(card);

    /* Animate in after paint */
    requestAnimationFrame(function() {
      requestAnimationFrame(function() {
        var overlay = document.getElementById('mhPushOverlay');
        if (overlay) overlay.style.transform = 'translateY(0)';
      });
    });

    /* Allow button */
    document.getElementById('mhPushAllow').addEventListener('click', function() {
      dismissCard();
      requestNativePermission();
    });

    /* Later button — snooze 3 days */
    document.getElementById('mhPushLater').addEventListener('click', function() {
      dismissCard();
      store('mh_push_snooze', String(Date.now() + 3 * 24 * 60 * 60 * 1000));
    });

    /* Swipe down to dismiss */
    var startY = 0;
    var overlay2 = card.querySelector('#mhPushOverlay');
    overlay2.addEventListener('touchstart', function(e) {
      startY = e.touches[0].clientY;
    }, {passive:true});
    overlay2.addEventListener('touchend', function(e) {
      if (e.changedTouches[0].clientY - startY > 60) {
        dismissCard();
        store('mh_push_snooze', String(Date.now() + 3 * 24 * 60 * 60 * 1000));
      }
    }, {passive:true});
  }

  function dismissCard() {
    var card = document.getElementById('mhPushCard');
    if (!card) return;
    var overlay = document.getElementById('mhPushOverlay');
    if (overlay) {
      overlay.style.transform = 'translateY(100%)';
      setTimeout(function() {
        if (card.parentNode) card.parentNode.removeChild(card);
      }, 420);
    } else {
      if (card.parentNode) card.parentNode.removeChild(card);
    }
  }

  /* ── Request native browser permission ── */
  function requestNativePermission() {
    Notification.requestPermission().then(function(permission) {
      if (permission === 'granted') {
        initFirebaseAndGetToken();
      } else if (permission === 'denied') {
        /* Show a helper message — they need to unblock in browser settings */
        showUnblockHelper();
      }
    }).catch(function(e) {
      /* Old-style callback API (some older Android) */
      Notification.requestPermission(function(permission) {
        if (permission === 'granted') initFirebaseAndGetToken();
      });
    });
  }

  /* ── Show unblock instructions ── */
  function showUnblockHelper() {
    var t = document.createElement('div');
    t.style.cssText =
      'position:fixed;top:16px;left:14px;right:14px;z-index:99999;' +
      'background:#1a1000;border:1px solid rgba(232,82,26,.3);' +
      'border-radius:14px;padding:14px 16px;' +
      'font-family:system-ui,sans-serif;font-size:13px;' +
      'color:rgba(255,255,255,.75);line-height:1.5;' +
      'box-shadow:0 8px 24px rgba(0,0,0,.5);';
    t.innerHTML =
      '<div style="font-weight:700;color:#FF7043;margin-bottom:6px;">&#x1F512; Notifications blocked</div>' +
      'To enable: tap the <strong style="color:#fff;">lock icon &#x1F512;</strong> in your browser address bar ' +
      '→ tap <strong style="color:#fff;">Notifications</strong> → select <strong style="color:#fff;">Allow</strong>' +
      '<button onclick="this.parentNode.remove()" style="display:block;margin-top:10px;' +
        'background:rgba(255,255,255,.08);border:none;border-radius:8px;' +
        'padding:6px 14px;color:rgba(255,255,255,.5);font-size:12px;cursor:pointer;' +
        'font-family:inherit;">Got it</button>';
    document.body.appendChild(t);
    setTimeout(function(){ if(t.parentNode) t.parentNode.removeChild(t); }, 8000);
  }

  /* ── Load Firebase + get token ── */
  function initFirebaseAndGetToken() {
    loadScript('https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js', function() {
      loadScript('https://www.gstatic.com/firebasejs/9.23.0/firebase-messaging-compat.js', function() {
        try {
          if (!firebase.apps.length) firebase.initializeApp(FIREBASE_CONFIG);
          var messaging = firebase.messaging();
          getToken(messaging);
          /* Refresh token when it expires */
          messaging.onTokenRefresh(function() { getToken(messaging); });
        } catch(e) {
          console.warn('Push init error:', e);
        }
      });
    });
  }

  /* ── Get FCM token ── */
  function getToken(messaging) {
    navigator.serviceWorker.register('/firebase-messaging-sw.js')
      .then(function(swReg) {
        return messaging.getToken({
          vapidKey: VAPID_KEY,
          serviceWorkerRegistration: swReg
        });
      })
      .then(function(token) {
        if (token) {
          /* Only save if token changed */
          if (read('mh_push_token') !== token) {
            saveToken(token);
          }
        }
      })
      .catch(function(e) {
        console.warn('Push token error:', e);
      });
  }

  /* ── Save token to your server ── */
  function saveToken(token) {
    var path = window.location.pathname;
    var segment = 'all';
    if (path.indexOf('food')  !== -1) segment = 'food';
    else if (path.indexOf('shop')  !== -1) segment = 'shop';
    else if (path.indexOf('homes') !== -1) segment = 'homes';
    else if (path.indexOf('track') !== -1) segment = 'orders';
    else if (path.indexOf('my_orders') !== -1) segment = 'orders';

    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/push_subscribe.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.timeout = 10000;
    xhr.onload = function() {
      try {
        var d = JSON.parse(xhr.responseText);
        if (d && d.success) {
          store('mh_push_token', token);
          store('mh_push_snooze', ''); /* Clear snooze */
        }
      } catch(e) {}
    };
    xhr.send(JSON.stringify({
      token:      token,
      segment:    segment,
      platform:   /android/i.test(navigator.userAgent) ? 'android'
                  : (/iphone|ipad|ipod/i.test(navigator.userAgent) ? 'ios' : 'web'),
      user_agent: navigator.userAgent.substring(0, 255)
    }));
  }

  /* ── Script loader ── */
  function loadScript(src, cb) {
    var existing = document.querySelector('script[src="'+src+'"]');
    if (existing) { if(cb) cb(); return; }
    var s = document.createElement('script');
    s.src = src; s.async = true;
    s.onload = cb || function(){};
    s.onerror = function(){ console.warn('Could not load:', src); };
    document.head.appendChild(s);
  }

  /* ════════════════════════════════════════
     MAIN ENTRY POINT
  ════════════════════════════════════════ */
  function init() {
    /* Already granted — silently get/refresh token */
    if (Notification.permission === 'granted') {
      initFirebaseAndGetToken();
      return;
    }

    /* Show our custom card if conditions are met */
    if (shouldPrompt()) {
      /* On index.php — show after 1.5 seconds */
      /* On other pages — show after 3 seconds */
      var delay = (window.location.pathname === '/' ||
                   window.location.pathname.indexOf('index') !== -1) ? 1500 : 3000;
      setTimeout(function() {
        if (shouldPrompt()) showPermissionCard();
      }, delay);
    }
  }

  /* Run after DOM is ready */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();