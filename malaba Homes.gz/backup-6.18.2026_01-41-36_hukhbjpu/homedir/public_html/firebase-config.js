// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCFWhRA2Ca7NQgcuMMLtw7U_w9VjT9SDlM",
  authDomain: "malaba-homes.firebaseapp.com",
  projectId: "malaba-homes",
  storageBucket: "malaba-homes.firebasestorage.app",
  messagingSenderId: "123484577811",
  appId: "1:123484577811:web:f6e1b85dae424050421fe6",
  measurementId: "G-0THFJFY7WY"
  
};

var VAPID_KEY = "BH-wYrXwKSz0fBTrVNbNLeph-L6YSxk65bV8UZlERu4IIALwbjdSv3KGH-UeqrXsn7Ap_qL6I4cT5o-hcicSrb8";