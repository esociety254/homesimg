/**
 * sw.js — Malaba Homes Service Worker v2
 * MUST be at the root: public_html/sw.js
 */
var CACHE = 'mh-v2';
var OFFLINE_URL = '/offline.html';

var PRECACHE = [
  '/',
  '/index.php',
  '/offline.html',
  '/manifest.json'
];

/* INSTALL */
self.addEventListener('install', function(e) {
  e.waitUntil(
    caches.open(CACHE).then(function(cache) {
      return cache.addAll(PRECACHE).catch(function(){});
    }).then(function() {
      return self.skipWaiting();
    })
  );
});

/* ACTIVATE */
self.addEventListener('activate', function(e) {
  e.waitUntil(
    caches.keys().then(function(keys) {
      return Promise.all(keys.filter(function(k){ return k !== CACHE; }).map(function(k){ return caches.delete(k); }));
    }).then(function(){ return self.clients.claim(); })
  );
});

/* FETCH — network first, cache fallback */
self.addEventListener('fetch', function(e) {
  if (e.request.method !== 'GET') return;
  var url = new URL(e.request.url);
  if (url.pathname.indexOf('/admin') === 0) return;
  if (url.pathname.indexOf('/api/') !== -1) {
    e.respondWith(
      fetch(e.request).catch(function() {
        return caches.match(e.request).then(function(r){
          return r || new Response('{"success":false,"data":[],"meta":{"total":0,"pages":1}}',{headers:{'Content-Type':'application/json'}});
        });
      })
    );
    return;
  }
  e.respondWith(
    fetch(e.request).then(function(response) {
      if (response.ok) {
        var clone = response.clone();
        caches.open(CACHE).then(function(c){ c.put(e.request, clone); });
      }
      return response;
    }).catch(function() {
      return caches.match(e.request).then(function(r){ return r || caches.match(OFFLINE_URL); });
    })
  );
});