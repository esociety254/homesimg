<?php
$apiBase = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/api';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1">
<meta name="theme-color" content="#080400">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="description" content="Shop local products in Malaba. Pay with Lipa Mdogo Mdogo.">
<title>Shop — Malaba Homes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="dns-prefetch" href="<?php echo htmlspecialchars($apiBase, ENT_QUOTES); ?>">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<?php include 'pwa_head.php'; ?>
<link rel="stylesheet" href="perf_styles.css">
<style>
/* ── TOKENS ── */
:root{
  --ink:#080400;--ink2:#100a00;--surface:#161210;--card:#1c1812;
  --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);
  --text:#F5F0EB;--muted:#8a8078;--dim:#5a534c;
  --amber:#E8521A;--amber2:#FF7043;--gold:#F5A623;
  --green:#22C55E;--blue:#4895EF;--purple:#7c3aed;
  --sb:env(safe-area-inset-bottom,0px);
  --st:env(safe-area-inset-top,0px);
  --r:12px;--rl:18px;--nav:56px;--bnav:62px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
html{overflow-x:hidden;}
body{
  font-family:'Outfit',sans-serif;background:var(--ink);color:var(--text);
  min-height:100dvh;overflow-x:hidden;-webkit-font-smoothing:antialiased;
  /* Space for: bnav + checkout bar + safe area */
  padding-bottom:calc(var(--bnav) + var(--sb) + 80px);
}
a{color:inherit;text-decoration:none;}
button{cursor:pointer;font-family:inherit;border:none;background:none;}
img{display:block;max-width:100%;}
::-webkit-scrollbar{width:3px;height:3px;}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px;}

/* ── HEADER — FIXED, always on top no matter where user scrolls ── */
.hdr{
  position:fixed;
  top:0;left:0;right:0;
  z-index:200;
  background:rgba(8,4,0,.97);
  backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);
  border-bottom:1px solid var(--border);
  padding:var(--st) 0 0;
  box-shadow:0 2px 20px rgba(0,0,0,.45);
}
/* Page body must be pushed down by the header height.
   We calculate it in JS after the header renders, but set
   a safe fallback here: nav(56) + search(52) + cats(48) + safeTop */
#pageWrap{
  padding-top:170px; /* fallback; JS sets exact value */
}

/* Top row: back btn + brand + actions */
.hdr-row{
  height:var(--nav);
  display:flex;align-items:center;gap:10px;
  padding:0 14px;
}
.back-btn{
  width:36px;height:36px;border-radius:50%;
  background:var(--surface);border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;transition:transform .15s;
}
.back-btn:active{transform:scale(.9);}
.back-btn svg{width:17px;height:17px;color:var(--text);}
.hdr-brand{
  flex:1;font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:2px;
  overflow:hidden;white-space:nowrap;
}
.hdr-brand span{color:var(--amber2);}
.hdr-acts{display:flex;gap:7px;flex-shrink:0;}
.ico-btn{
  width:36px;height:36px;border-radius:50%;
  background:var(--surface);border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;
  font-size:15px;position:relative;transition:transform .15s;
}
.ico-btn:active{transform:scale(.9);}
.hbadge{
  position:absolute;top:-3px;right:-3px;width:17px;height:17px;border-radius:50%;
  background:var(--amber);color:#fff;font-size:9px;font-weight:800;
  display:none;align-items:center;justify-content:center;border:2px solid var(--ink);
}
.hbadge.on{display:flex;}

/* ── SEARCH ROW — always visible, never collapses ── */
.srch-row{
  padding:0 14px 10px;
}
.srch-box{
  display:flex;align-items:center;gap:9px;
  background:var(--surface);border:1.5px solid var(--border2);
  border-radius:30px;padding:0 15px;height:42px;
  transition:border-color .2s,box-shadow .2s;
  cursor:text;
}
.srch-box:focus-within{
  border-color:var(--amber);
  box-shadow:0 0 0 3px rgba(232,82,26,.12);
}
.srch-box svg{color:var(--muted);flex-shrink:0;width:14px;height:14px;}
.srch-box input{
  flex:1;padding:0;height:100%;background:transparent;
  border:none;outline:none;font-family:inherit;
  font-size:14px;color:var(--text);
}
.srch-box input::placeholder{color:var(--muted);}
/* Clear × button inside search */
.srch-clear{
  width:20px;height:20px;border-radius:50%;
  background:rgba(255,255,255,.12);color:rgba(255,255,255,.6);
  font-size:11px;display:none;align-items:center;justify-content:center;
  flex-shrink:0;cursor:pointer;transition:background .15s;
}
.srch-clear.show{display:flex;}
.srch-clear:active{background:rgba(255,255,255,.25);}

/* ── CATS ROW — always visible ── */
.cats-row{
  display:flex;gap:7px;padding:0 14px 10px;
  overflow-x:auto;scrollbar-width:none;
  -webkit-overflow-scrolling:touch;
}
.cats-row::-webkit-scrollbar{display:none;}
.cat-tab{
  display:inline-flex;align-items:center;gap:5px;
  padding:6px 13px;border-radius:30px;
  border:1px solid var(--border2);background:var(--surface);
  font-size:12px;font-weight:500;color:var(--muted);
  white-space:nowrap;flex-shrink:0;transition:all .2s;
}
.cat-tab.on{background:var(--amber);border-color:var(--amber);color:#fff;font-weight:700;}
.cat-tab:active{transform:scale(.95);}

/* ── Legacy compact classes — neutralised, kept so old JS won't error ── */
.hdr.compact .srch-row{ /* nothing — search always shows */ }
.hdr.compact .cats-row{ /* nothing — cats always show  */ }
.hdr.compact .hdr-brand{ /* nothing — brand always shows */ }

/* ── Inline compact search element — hidden, kept for compat ── */
.hdr-srch-inline{display:none!important;}
.hdr-srch-clear{display:none!important;}

/* ── FAB — hidden, kept for JS compat ── */
.srch-fab{display:none!important;}

/* ── SEARCH MODAL (full-screen, opened from any search input) ── */
.srch-modal{
  position:fixed;inset:0;z-index:600;
  background:rgba(8,4,0,.98);backdrop-filter:blur(24px);
  display:flex;flex-direction:column;
  padding-top:calc(var(--st) + 0px);
  opacity:0;pointer-events:none;
  transition:opacity .18s;
  /* Covers the fixed header completely when open */
}
.srch-modal.open{opacity:1;pointer-events:all;}
.sm-bar{
  display:flex;align-items:center;gap:10px;
  padding:12px 14px;
  border-bottom:1px solid var(--border);
}
.sm-input-wrap{
  flex:1;display:flex;align-items:center;gap:8px;
  background:rgba(255,255,255,.07);border:1.5px solid var(--amber);
  border-radius:30px;padding:0 14px;height:44px;
}
.sm-input-wrap svg{color:var(--amber);flex-shrink:0;width:15px;height:15px;}
.sm-input{
  flex:1;padding:0;background:transparent;border:none;
  outline:none;font-family:inherit;font-size:15px;color:var(--text);
}
.sm-input::placeholder{color:var(--muted);}
.sm-cancel{
  font-size:13px;font-weight:700;color:rgba(255,255,255,.5);
  white-space:nowrap;padding:4px 2px;
  transition:color .15s;
}
.sm-cancel:hover,.sm-cancel:active{color:#fff;}

/* Search results in modal */
.sm-results{flex:1;overflow-y:auto;padding:8px 0;}
.sm-res-empty{text-align:center;padding:40px 20px;font-size:14px;color:var(--muted);}
.sm-res-item{
  display:flex;align-items:center;gap:12px;
  padding:10px 14px;cursor:pointer;
  transition:background .13s;
}
.sm-res-item:active{background:rgba(255,255,255,.05);}
.sm-res-thumb{
  width:52px;height:52px;border-radius:10px;object-fit:cover;
  flex-shrink:0;background:var(--surface);
  min-width:52px;min-height:52px;
}
.sm-res-info{flex:1;min-width:0;}
.sm-res-title{font-size:14px;font-weight:600;color:var(--text);margin-bottom:2px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.sm-res-meta{font-size:11px;color:var(--muted);}
.sm-res-price{font-family:'Bebas Neue',sans-serif;font-size:14px;color:var(--amber2);flex-shrink:0;}
.sm-res-lipa{font-size:9px;font-weight:800;padding:2px 6px;border-radius:8px;
  background:rgba(245,166,35,.15);color:var(--gold);margin-left:auto;}
.hl{color:var(--amber);font-weight:700;}
.sm-sec{padding:10px 14px 6px;font-size:10px;font-weight:700;
  color:rgba(255,255,255,.3);letter-spacing:.7px;text-transform:uppercase;}
.sm-recent-wrap{display:flex;flex-wrap:wrap;gap:6px;padding:4px 14px 10px;}
.sm-recent-chip{
  display:inline-flex;align-items:center;gap:5px;
  padding:5px 11px;border-radius:20px;
  background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.09);
  font-size:12px;color:rgba(255,255,255,.55);cursor:pointer;transition:all .13s;
}
.sm-recent-chip:hover{background:rgba(255,255,255,.11);color:#fff;}
.sm-spinner{display:none;justify-content:center;padding:28px;}
.sm-spinner.show{display:flex;}
.sm-spin{width:22px;height:22px;border-radius:50%;border:2px solid var(--border2);
  border-top-color:var(--amber);animation:spin .65s linear infinite;}

/* ── SECTION HEAD ── */
.sec-head{display:flex;align-items:center;justify-content:space-between;padding:8px 14px;}
.sec-head h2{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.5px;}
.sec-head h2 span{color:var(--amber2);}
.sort-btn{
  display:flex;align-items:center;gap:5px;padding:6px 12px;border-radius:9px;
  background:var(--surface);border:1px solid var(--border2);
  font-size:11px;font-weight:600;color:var(--muted);transition:all .2s;
}
.sort-btn:active{border-color:var(--amber);color:var(--amber);}
.res-count{font-size:11px;color:var(--dim);padding:0 14px 8px;}

/* ── GRID ── */
.shop-grid{
  display:grid;gap:10px;
  grid-template-columns:repeat(2,1fr);
  padding:0 10px;
  /* performance: isolate paint */
  isolation:isolate;contain:layout style;
}
@media(min-width:480px){.shop-grid{gap:12px;padding:0 14px;}}
@media(min-width:640px){.shop-grid{grid-template-columns:repeat(3,1fr);}}
@media(min-width:900px){.shop-grid{grid-template-columns:repeat(4,1fr);padding:0 20px;}}

/* Skeletons (inline so they match perf even if perf_styles.css is slow) */
.skel{background:rgba(255,255,255,.06);position:relative;overflow:hidden;}
.skel::after{content:'';position:absolute;inset:0;transform:translateX(-100%);background:linear-gradient(90deg,transparent,rgba(255,255,255,.12),transparent);animation:skelSh 1.15s ease-in-out infinite;}
@keyframes skelSh{to{transform:translateX(100%);}}
.skel-card{background:var(--card);border-radius:var(--rl);overflow:hidden;border:1px solid var(--border);}
.skel-sq{width:100%;height:180px;background:rgba(255,255,255,.06);}
.skel-ln{height:12px;border-radius:4px;background:rgba(255,255,255,.06);}

.pcard{
  background:var(--card);border-radius:var(--rl);
  border:1px solid var(--border);overflow:hidden;
  display:flex;flex-direction:column;cursor:pointer;
  transition:transform .2s,box-shadow .2s,border-color .2s;
  position:relative;
  /* isolate each card's paint — browser only repaints this card, not the page */
  contain:layout style;
  /* Cards start visible by default — JS adds animation only to first 8 */
  opacity:1;transform:none;
}
/* Only animate first batch — JS toggles this class */
.pcard.animate-in{
  animation:fadeUp .38s cubic-bezier(.25,.46,.45,.94) both;
}
@keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
.pcard:active{transform:scale(.97);}
@media(hover:hover){.pcard:hover{transform:translateY(-3px);box-shadow:0 12px 30px rgba(0,0,0,.5);border-color:var(--border2);}}

/* Card image — CRITICAL: fixed dimensions prevent ALL layout shift ──────────
   The wrapper reserves space before the image loads.
   The image fades in on load — no pop, no reflow, no stagger.
   Uses padding-top fallback for browsers that don't support aspect-ratio. */
.pcard-img{
  position:relative;
  width:100%;
  /* Modern browsers */
  aspect-ratio:1/1;
  overflow:hidden;
  /* Warm placeholder shown while image loads — no empty white box */
  background:linear-gradient(135deg,var(--surface),var(--card));
  border-radius:var(--rl) var(--rl) 0 0;
}
/* Fallback for aspect-ratio — old Android / iOS Safari < 15 */
@supports not (aspect-ratio: 1/1) {
  .pcard-img::before{
    content:'';display:block;padding-top:100%;
  }
  .pcard-img img{position:absolute;}
}
.pcard-img img{
  position:absolute;inset:0;
  width:100%;height:100%;object-fit:cover;
  /* Default: fully visible. JS sets opacity:0 ONLY before the first load event,
     so cached/fast images never stagger. The fade only fires once per image. */
  opacity:1;
  transition:none;
}
/* JS adds this class before registering the load listener — only on slow images */
.pcard-img img.await-load{
  opacity:0;
  transition:opacity .35s ease;
}
.pcard-img img.img-loaded{
  opacity:1;
}
/* Zoom on hover — compositing layer only created on hover, released after */
@media(hover:hover){
  .pcard:hover .pcard-img img{
    transform:scale(1.05);
    transition:opacity .4s ease, transform .55s cubic-bezier(.25,.46,.45,.94);
  }
}

.pbadge{
  position:absolute;top:7px;left:7px;
  background:rgba(8,4,0,.82);backdrop-filter:blur(6px);
  color:var(--text);font-size:9px;font-weight:700;
  padding:3px 8px;border-radius:12px;white-space:nowrap;z-index:2;
}
.plipa-badge{
  position:absolute;bottom:7px;left:7px;z-index:2;
  background:linear-gradient(135deg,rgba(245,166,35,.92),rgba(232,82,26,.92));
  backdrop-filter:blur(4px);color:#fff;font-size:8px;font-weight:800;
  padding:3px 7px;border-radius:10px;white-space:nowrap;letter-spacing:.3px;
}
.wish{
  position:absolute;top:6px;right:6px;z-index:2;
  width:28px;height:28px;border-radius:50%;
  background:rgba(8,4,0,.7);backdrop-filter:blur(6px);
  display:flex;align-items:center;justify-content:center;font-size:13px;
  transition:all .2s;
}
.wish:active{transform:scale(.85);}
.wish.liked{background:rgba(232,82,26,.25);}

.pcard-body{padding:9px 9px 2px;flex:1;}
.ptitle{
  font-weight:700;font-size:12px;color:var(--text);line-height:1.3;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;
  overflow:hidden;margin-bottom:3px;
}
/* rating + location removed from cards per design update */
.prating{display:none;}
.ploc{display:none;}
.pprice{font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;color:var(--amber2);padding:4px 9px 2px;}

/* Card footer — two buttons only: Add to Cart + Buy Now */
.pcard-foot{display:flex;gap:6px;padding:6px 8px 9px;}
.btn-cart{
  flex:1;padding:9px 6px;border-radius:var(--r);
  background:rgba(255,255,255,.07);border:1px solid var(--border2);
  color:var(--text);
  font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:.3px;
  transition:all .18s;display:flex;align-items:center;justify-content:center;gap:3px;
}
.btn-cart:active{transform:scale(.95);}
.btn-cart.added{background:rgba(34,197,94,.15);border-color:var(--green);color:var(--green);}
.btn-buy{
  flex:1;padding:9px 6px;border-radius:var(--r);
  background:var(--amber);color:#fff;
  font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:.3px;
  transition:all .18s;display:flex;align-items:center;justify-content:center;gap:3px;
}
.btn-buy:active{transform:scale(.95);background:var(--amber2);}

/* Keep these hidden — referenced by old code but no longer rendered */
.btn-order{display:none;}
.btn-lipa{display:none;}
.btn-qv{display:none;}

/* ── LOAD MORE ── */
.load-wrap{display:flex;align-items:center;justify-content:center;height:64px;padding:8px 0;}
.spin{width:24px;height:24px;border:3px solid var(--border2);border-top-color:var(--amber);border-radius:50%;animation:spin .65s linear infinite;}
@keyframes spin{to{transform:rotate(360deg)}}
.load-end-msg{font-size:12px;color:var(--dim);text-align:center;}

/* Empty state */
.empty-state{grid-column:1/-1;text-align:center;padding:48px 20px;}
.empty-ico{font-size:48px;margin-bottom:12px;}
.empty-state h3{font-family:'Bebas Neue',sans-serif;font-size:22px;margin-bottom:6px;}
.empty-state p{color:var(--muted);font-size:13px;}

/* ── OVERLAY + SHEETS ── */
.overlay{
  position:fixed;inset:0;z-index:500;
  background:rgba(0,0,0,.82);backdrop-filter:blur(6px);
  opacity:0;pointer-events:none;transition:opacity .25s;
  display:flex;align-items:flex-end;
}
.overlay.open{opacity:1;pointer-events:all;}
.sheet{
  width:100%;background:var(--ink2);
  border-radius:24px 24px 0 0;border:1px solid rgba(255,255,255,.08);
  transform:translateY(100%);
  transition:transform .38s cubic-bezier(.32,1,.68,1);
  max-height:94dvh;overflow-y:auto;
  padding-bottom:calc(20px + var(--sb));
}
.overlay.open .sheet{transform:translateY(0);}
.sh-top{display:flex;align-items:center;justify-content:space-between;padding:13px 16px 0;}
.sh-handle{width:38px;height:4px;border-radius:2px;background:rgba(255,255,255,.1);}
.sh-close{
  width:28px;height:28px;border-radius:50%;
  background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
  display:flex;align-items:center;justify-content:center;
  color:rgba(255,255,255,.5);font-size:14px;
}
.sh-close:active{transform:scale(.9);}

/* Quick View */
/* ── DETAIL SHEET (replaces simple QV) ── */

/* Gallery */
.det-gallery{position:relative;overflow:hidden;background:var(--ink);border-radius:0;}
.det-track{
  display:flex;
  transition:transform .42s cubic-bezier(.25,.46,.45,.94);
  will-change:transform;
}
.det-slide{min-width:100%;flex-shrink:0;position:relative;}
.det-slide img{
  width:100%;height:260px;object-fit:cover;
  opacity:0;transition:opacity .4s ease;display:block;
}
@media(min-width:480px){.det-slide img{height:320px;}}
.det-slide img.img-loaded{opacity:1;}
/* Gallery controls */
.det-prev,.det-next{
  position:absolute;top:50%;transform:translateY(-50%);z-index:5;
  width:36px;height:36px;border-radius:50%;
  background:rgba(8,4,0,.7);backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.15);
  display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:17px;transition:all .18s;cursor:pointer;
}
.det-prev{left:10px;} .det-next{right:10px;}
.det-prev:active,.det-next:active{transform:translateY(-50%) scale(.9);}
/* Image count badge */
.det-count{
  position:absolute;bottom:10px;right:10px;z-index:5;
  background:rgba(0,0,0,.65);backdrop-filter:blur(6px);
  color:#fff;font-size:10px;font-weight:700;
  padding:3px 9px;border-radius:20px;
  border:1px solid rgba(255,255,255,.12);
}
/* Dot indicators */
.det-dots{
  position:absolute;bottom:10px;left:50%;
  transform:translateX(-50%);z-index:5;
  display:flex;gap:5px;pointer-events:none;
}
.det-dot{
  width:6px;height:6px;border-radius:50%;
  background:rgba(255,255,255,.35);transition:all .25s;
}
.det-dot.on{background:#fff;width:16px;border-radius:3px;}
/* Thumbnail strip */
.det-thumbs{
  display:flex;gap:6px;padding:9px 14px 4px;
  overflow-x:auto;scrollbar-width:none;
  background:rgba(255,255,255,.02);border-bottom:1px solid var(--border);
  -webkit-overflow-scrolling:touch;
}
.det-thumbs::-webkit-scrollbar{display:none;}
.det-thumb{
  width:54px;height:44px;border-radius:8px;object-fit:cover;
  flex-shrink:0;cursor:pointer;
  border:2px solid transparent;
  opacity:.55;transition:all .2s;
  background:var(--surface);
}
.det-thumb.on{border-color:var(--amber);opacity:1;}
.det-thumb:active{transform:scale(.94);}

/* Video button — prominent */
.det-video-btn{
  display:flex;align-items:center;gap:9px;
  margin:0 16px 12px;padding:12px 16px;
  background:linear-gradient(135deg,rgba(109,40,217,.25),rgba(99,102,241,.15));
  border:1px solid rgba(124,58,237,.35);border-radius:var(--rl);
  cursor:pointer;transition:all .2s;
}
.det-video-btn:active{transform:scale(.98);}
.dvb-icon{
  width:38px;height:38px;border-radius:50%;
  background:linear-gradient(135deg,#7c3aed,#6366f1);
  display:flex;align-items:center;justify-content:center;
  font-size:16px;flex-shrink:0;
  box-shadow:0 3px 12px rgba(124,58,237,.4);
}
.dvb-text{}
.dvb-title{font-size:14px;font-weight:700;color:#fff;margin-bottom:1px;}
.dvb-sub{font-size:11px;color:rgba(196,181,253,.7);}
.dvb-arr{font-size:18px;color:rgba(124,58,237,.6);margin-left:auto;}

/* Detail body */
.det-body{padding:14px 16px 0;}
.det-badge{display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:700;padding:3px 10px;border-radius:12px;background:rgba(232,82,26,.12);color:var(--amber2);margin-bottom:8px;}
.det-title{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:.5px;margin-bottom:3px;line-height:1.1;}
.det-price{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:.5px;color:var(--amber2);margin-bottom:6px;}
.det-meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:11px;color:var(--muted);margin-bottom:10px;}
.det-rating{color:var(--gold);font-size:12px;}
.det-desc{font-size:13px;color:var(--muted);line-height:1.65;margin-bottom:14px;}
.det-feats{display:grid;grid-template-columns:1fr 1fr;gap:7px;background:rgba(255,255,255,.03);border-radius:var(--r);padding:12px;margin-bottom:14px;border:1px solid var(--border);}
.df{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--muted);}

/* Keep qv-feats / qf as aliases */
.qv-feats{display:grid;grid-template-columns:1fr 1fr;gap:7px;background:rgba(255,255,255,.03);border-radius:var(--r);padding:12px;margin-bottom:14px;border:1px solid var(--border);}
.qf{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--muted);}

/* Buy options */
.buy-options{display:flex;flex-direction:column;gap:8px;margin-bottom:14px;}
.buy-opt{
  display:flex;align-items:center;gap:12px;padding:14px;border-radius:var(--rl);
  border:2px solid var(--border2);cursor:pointer;transition:all .2s;
  background:rgba(255,255,255,.02);
}
.buy-opt:active{transform:scale(.99);}
.opt-full:hover,.opt-full:active{border-color:var(--amber);background:rgba(232,82,26,.07);}
.opt-lipa:hover,.opt-lipa:active{border-color:var(--gold);background:rgba(245,166,35,.07);}
.opt-watch:hover,.opt-watch:active{border-color:var(--purple);background:rgba(124,58,237,.07);}
.bo-icon{width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;}
.boi-full{background:rgba(232,82,26,.15);}
.boi-lipa{background:rgba(245,166,35,.15);}
.boi-watch{background:rgba(124,58,237,.15);}
.bo-info{flex:1;}
.bo-title{font-size:14px;font-weight:700;color:var(--text);margin-bottom:2px;}
.bo-sub{font-size:11px;color:var(--muted);}
.bo-arrow{font-size:16px;color:var(--muted);}

/* Form fields */
.field{margin-bottom:11px;}
.field label{display:block;font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:5px;}
.field input{
  width:100%;padding:11px 13px;border-radius:var(--r);
  background:rgba(255,255,255,.05);border:1.5px solid var(--border2);
  color:var(--text);font-family:inherit;font-size:14px;outline:none;transition:border-color .2s;
}
.field input:focus{border-color:var(--amber);}
.field input::placeholder{color:rgba(255,255,255,.22);}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}

/* Pay options */
.pay-opts{display:flex;flex-direction:column;gap:7px;margin-bottom:12px;}
.po{display:flex;align-items:center;gap:11px;padding:11px 12px;border-radius:var(--r);border:2px solid var(--border2);cursor:pointer;transition:all .18s;}
.po.sel{border-color:var(--amber);background:rgba(232,82,26,.07);}
.po:active{transform:scale(.99);}
.po-ico{font-size:18px;}
.po-txt strong{display:block;font-size:13px;font-weight:600;}
.po-txt span{font-size:11px;color:var(--muted);}
.po-dot{width:17px;height:17px;border-radius:50%;border:2px solid var(--dim);margin-left:auto;flex-shrink:0;display:flex;align-items:center;justify-content:center;}
.po.sel .po-dot{border-color:var(--amber);background:var(--amber);}
.po.sel .po-dot::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}

/* Order summary */
.order-sum{background:rgba(255,255,255,.03);border-radius:var(--r);padding:11px;margin-bottom:12px;border:1px solid var(--border);}
.os-row{display:flex;justify-content:space-between;font-size:13px;color:var(--muted);padding:3px 0;}
.os-row.tot{font-size:14px;font-weight:700;color:var(--text);padding-top:8px;border-top:1px solid var(--border);margin-top:4px;}

/* Submit buttons */
.sbtn{
  width:100%;padding:14px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;border-radius:var(--rl);
  font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.5px;
  transition:all .2s;box-shadow:0 4px 18px rgba(232,82,26,.35);
  display:flex;align-items:center;justify-content:center;gap:7px;
}
.sbtn:active{transform:scale(.98);}

/* Lipa sheet */
.lipa-header{
  padding:16px 16px 0;
  background:linear-gradient(135deg,rgba(245,166,35,.08),rgba(232,82,26,.05));
  border-bottom:1px solid rgba(245,166,35,.12);margin-bottom:14px;
}
.lipa-product-row{display:flex;gap:12px;padding:0 0 14px;}
.lipa-pimg{
  width:58px;height:58px;border-radius:12px;object-fit:cover;flex-shrink:0;
  opacity:0;transition:opacity .3s;
}
.lipa-pimg.img-loaded{opacity:1;}
.lipa-pimg-ph{width:58px;height:58px;border-radius:12px;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0;}
.lipa-pname{font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.3px;margin-bottom:2px;}
.lipa-pwas{font-size:11px;color:var(--dim);text-decoration:line-through;}
.lipa-ptag{font-size:10px;color:var(--gold);font-weight:700;margin-top:2px;}

/* Step dots */
.lipa-steps{display:flex;align-items:center;padding:0 16px 14px;}
.lstep{display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;}
.lstep:last-child{flex:0;flex-shrink:0;}
.ls-dot{width:26px;height:26px;border-radius:50%;border:2px solid var(--border2);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:var(--muted);transition:all .3s;}
.ls-dot.done{background:var(--green);border-color:var(--green);color:#000;}
.ls-dot.active{background:var(--amber);border-color:var(--amber);color:#fff;box-shadow:0 0 0 4px rgba(232,82,26,.18);}
.ls-lbl{font-size:9px;font-weight:600;color:var(--muted);letter-spacing:.2px;text-align:center;}
.ls-lbl.active{color:var(--amber);}
.ls-lbl.done{color:var(--green);}
.ls-line{flex:1;height:2px;background:var(--border2);margin:0 4px;margin-bottom:14px;transition:background .3s;}
.ls-line.done{background:var(--green);}

/* Lipa panels */
.lipa-panel{display:none;padding:0 16px;}
.lipa-panel.active{display:block;animation:panelIn .22s ease;}
@keyframes panelIn{from{opacity:0;transform:translateX(10px)}to{opacity:1;transform:translateX(0)}}
.lipa-sec-title{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.3px;margin-bottom:4px;}
.lipa-sec-sub{font-size:12px;color:var(--muted);margin-bottom:14px;line-height:1.5;}

/* Frequency cards */
.lipa-freqs{display:flex;flex-direction:column;gap:7px;margin-bottom:14px;}
.lipa-freq{display:flex;align-items:center;gap:10px;padding:13px;border-radius:var(--rl);border:2px solid var(--border2);background:rgba(255,255,255,.02);cursor:pointer;transition:all .18s;}
.lipa-freq.sel{border-color:rgba(245,166,35,.55);background:rgba(245,166,35,.07);}
.lipa-freq:active{transform:scale(.99);}
.lf-radio{width:17px;height:17px;border-radius:50%;border:2px solid var(--dim);flex-shrink:0;display:flex;align-items:center;justify-content:center;transition:all .18s;}
.lipa-freq.sel .lf-radio{background:var(--gold);border-color:var(--gold);}
.lipa-freq.sel .lf-radio::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}
.lf-info{flex:1;}
.lf-name{font-size:13px;font-weight:700;color:var(--text);margin-bottom:1px;}
.lf-desc{font-size:11px;color:var(--muted);}
.lf-right{text-align:right;flex-shrink:0;}
.lf-amount{font-family:'Bebas Neue',sans-serif;font-size:16px;color:var(--gold);letter-spacing:.3px;}
.lf-per{font-size:9px;color:var(--muted);margin-top:1px;}

/* Duration grid */
.lipa-durs{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;}
.lipa-dur{padding:13px 11px;border-radius:var(--rl);border:2px solid var(--border2);background:rgba(255,255,255,.02);cursor:pointer;transition:all .18s;text-align:center;}
.lipa-dur.sel{border-color:rgba(245,166,35,.55);background:rgba(245,166,35,.07);}
.lipa-dur:active{transform:scale(.97);}
.ld-weeks{font-family:'Bebas Neue',sans-serif;font-size:22px;color:var(--text);letter-spacing:.3px;}
.ld-label{font-size:10px;color:var(--muted);margin-bottom:4px;}
.ld-per{font-size:12px;font-weight:700;color:var(--gold);}
.ld-total{font-size:10px;color:var(--dim);margin-top:2px;}

/* Summary box */
.lipa-summary{background:rgba(245,166,35,.07);border:1px solid rgba(245,166,35,.18);border-radius:var(--r);padding:12px 13px;margin-bottom:12px;display:none;}
.ls-row{display:flex;justify-content:space-between;font-size:12px;padding:3px 0;}
.ls-row .lbl{color:var(--muted);}
.ls-row .val{font-weight:700;color:var(--text);}
.ls-row .val.hi{color:var(--gold);}

/* Rule box */
.lipa-rule{background:rgba(232,82,26,.07);border:1px solid rgba(232,82,26,.15);border-radius:var(--r);padding:10px 12px;margin-bottom:12px;font-size:11px;color:rgba(255,190,120,.85);line-height:1.6;}
.lipa-rule strong{color:var(--amber2);}

/* Lipa pay mode */
.lipa-pay .po.sel{border-color:var(--gold);background:rgba(245,166,35,.07);}
.lipa-pay .po.sel .po-dot{border-color:var(--gold);background:var(--gold);}

/* Lipa nav */
.lipa-nav{display:flex;gap:8px;padding-bottom:2px;}
.lipa-back{padding:12px 16px;background:rgba(255,255,255,.06);border:1px solid var(--border2);border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;color:var(--muted);cursor:pointer;transition:all .18s;}
.lipa-next{flex:1;padding:13px;background:linear-gradient(135deg,var(--gold),var(--amber));color:#fff;border:none;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.3px;cursor:pointer;transition:all .18s;box-shadow:0 4px 16px rgba(245,166,35,.3);}
.lipa-next:active{transform:scale(.98);}

/* Cart summary */
.cart-sum{background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:var(--r);padding:11px;margin-bottom:12px;}
.csr{display:flex;justify-content:space-between;font-size:13px;color:var(--muted);padding:4px 0;}
.csr.tot{font-size:14px;font-weight:700;color:var(--text);padding-top:8px;border-top:1px solid var(--border);margin-top:4px;}

/* Sort options */
.sort-opt{padding:14px 18px;font-size:15px;color:var(--text);cursor:pointer;transition:background .13s;}
.sort-opt:active,.sort-opt:hover{background:rgba(255,255,255,.04);}
.sort-opt.sel{color:var(--amber);}

/* ── CATEGORY BROWSER SHEET ── */
.cb-header{padding:4px 16px 12px;}
.cb-title{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:.5px;margin-bottom:2px;}
.cb-subtitle{font-size:12px;color:var(--muted);line-height:1.5;}

/* Search bar inside sheet */
.cb-search{
  display:flex;align-items:center;gap:8px;
  background:rgba(255,255,255,.06);border:1.5px solid var(--border2);
  border-radius:30px;padding:0 14px;height:40px;
  margin:0 16px 14px;transition:border-color .2s;
}
.cb-search:focus-within{border-color:var(--amber);}
.cb-search svg{color:var(--muted);flex-shrink:0;width:13px;height:13px;}
.cb-search input{
  flex:1;padding:0;background:transparent;border:none;
  outline:none;font-family:inherit;font-size:14px;color:var(--text);
}
.cb-search input::placeholder{color:var(--muted);}

/* "All items" hero chip */
.cb-all-btn{
  display:flex;align-items:center;gap:10px;
  margin:0 16px 16px;padding:13px 16px;
  border-radius:var(--rl);
  background:linear-gradient(135deg,rgba(232,82,26,.18),rgba(255,112,67,.1));
  border:1.5px solid rgba(232,82,26,.35);
  cursor:pointer;transition:all .2s;
}
.cb-all-btn.active-cat{background:linear-gradient(135deg,var(--amber),var(--amber2));border-color:var(--amber);}
.cb-all-btn:active{transform:scale(.98);}
.cb-all-icon{font-size:24px;flex-shrink:0;}
.cb-all-info{flex:1;}
.cb-all-name{font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;color:var(--text);}
.cb-all-count{font-size:11px;color:var(--muted);}
.cb-all-btn.active-cat .cb-all-count{color:rgba(255,255,255,.7);}
.cb-all-check{
  width:22px;height:22px;border-radius:50%;
  background:rgba(255,255,255,.12);border:2px solid rgba(255,255,255,.2);
  display:flex;align-items:center;justify-content:center;
  font-size:11px;color:#fff;flex-shrink:0;
}
.cb-all-btn.active-cat .cb-all-check{background:rgba(255,255,255,.3);border-color:rgba(255,255,255,.5);}

/* Section label */
.cb-sec-label{
  padding:0 16px 8px;
  font-size:10px;font-weight:700;color:var(--muted);
  letter-spacing:.8px;text-transform:uppercase;
}

/* Grid of category tiles */
.cb-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:8px;
  padding:0 16px 4px;
}
@media(min-width:400px){.cb-grid{grid-template-columns:repeat(4,1fr);}}

.cb-tile{
  display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:5px;
  padding:12px 6px 10px;
  border-radius:14px;
  background:var(--card);border:1.5px solid var(--border);
  cursor:pointer;transition:all .2s;
  position:relative;text-align:center;
}
.cb-tile:active{transform:scale(.94);}
.cb-tile.active-cat{
  border-color:var(--amber);
  background:rgba(232,82,26,.1);
  box-shadow:0 0 0 1px rgba(232,82,26,.2);
}
.cb-tile-icon{
  font-size:26px;line-height:1;
}
.cb-tile-label{
  font-size:10px;font-weight:700;color:var(--muted);
  letter-spacing:.2px;line-height:1.2;
}
.cb-tile.active-cat .cb-tile-label{color:var(--amber);}
.cb-tile-count{
  font-size:9px;color:var(--dim);margin-top:-2px;
}
.cb-tile.active-cat .cb-tile-count{color:rgba(232,82,26,.6);}
/* Active check badge */
.cb-tile-check{
  position:absolute;top:6px;right:6px;
  width:16px;height:16px;border-radius:50%;
  background:var(--amber);
  display:none;align-items:center;justify-content:center;
  font-size:8px;color:#fff;font-weight:800;
}
.cb-tile.active-cat .cb-tile-check{display:flex;}

/* Empty state when no cats match search */
.cb-empty{
  grid-column:1/-1;text-align:center;
  padding:28px 20px;font-size:13px;color:var(--muted);
}

/* Sort section at bottom of sheet */
.cb-sort-section{
  margin:16px 16px 0;
  padding:14px;
  background:rgba(255,255,255,.03);
  border:1px solid var(--border);
  border-radius:var(--rl);
}
.cb-sort-label{
  font-size:10px;font-weight:700;color:var(--muted);
  letter-spacing:.8px;text-transform:uppercase;margin-bottom:10px;
}
.cb-sort-pills{
  display:flex;flex-wrap:wrap;gap:6px;
}
.cb-sort-pill{
  padding:6px 13px;border-radius:20px;
  background:var(--surface);border:1.5px solid var(--border2);
  font-size:12px;font-weight:600;color:var(--muted);
  cursor:pointer;transition:all .2s;white-space:nowrap;
}
.cb-sort-pill:active{transform:scale(.95);}
.cb-sort-pill.sel{
  background:rgba(232,82,26,.15);
  border-color:var(--amber);
  color:var(--amber);
}

/* Apply button */
.cb-apply-btn{
  display:flex;align-items:center;justify-content:center;gap:7px;
  width:100%;margin:16px 0 4px;padding:14px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;border:none;border-radius:var(--rl);
  font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.5px;
  cursor:pointer;transition:all .2s;
  box-shadow:0 4px 18px rgba(232,82,26,.35);
}
.cb-apply-btn:active{transform:scale(.98);}
.cb-apply-btn-wrap{padding:0 16px;}

/* Success */
.suc-wrap{text-align:center;padding:24px 16px 10px;}
.suc-ico{font-size:52px;margin-bottom:12px;}
.suc-title{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:.5px;margin-bottom:6px;}
.suc-sub{font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:12px;}
.suc-ref{font-size:12px;color:var(--amber);font-weight:700;margin-bottom:16px;}
.wa-btn{width:100%;padding:13px;background:#25D366;color:#fff;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;display:flex;align-items:center;justify-content:center;gap:7px;transition:all .2s;margin-bottom:8px;}
.done-btn{width:100%;padding:12px;background:rgba(255,255,255,.05);color:var(--muted);border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;border:1px solid var(--border2);transition:all .2s;}

/* ── BOTTOM NAV — matches index.php exactly ── */
.bnav{
  position:fixed;bottom:0;left:0;right:0;z-index:200;
  height:calc(var(--bnav) + var(--sb));padding-bottom:var(--sb);
  background:rgba(8,4,0,.95);backdrop-filter:blur(28px);-webkit-backdrop-filter:blur(28px);
  border-top:1px solid rgba(255,255,255,.07);
  display:flex;align-items:stretch;
}
.bni{
  flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;
  gap:3px;padding:0 4px;-webkit-tap-highlight-color:transparent;
  transition:all .2s;position:relative;
}
.bni-ico{font-size:20px;color:rgba(255,255,255,.38);transition:all .22s;line-height:1.15;}
.bni-lbl{font-size:9px;font-weight:700;color:rgba(255,255,255,.3);letter-spacing:.5px;text-transform:uppercase;transition:all .22s;}
.bni.active .bni-ico,.bni.active .bni-lbl{color:var(--amber);}
.bni.active::before{content:'';position:absolute;bottom:2px;width:20px;height:2px;border-radius:1px;background:var(--amber);animation:indIn .3s ease;}
@keyframes indIn{from{width:0;opacity:0;}to{width:20px;opacity:1;}}
.bni-center{
  flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;
  gap:4px;-webkit-tap-highlight-color:transparent;cursor:pointer;position:relative;text-decoration:none;
}
.bni-center-btn{
  width:48px;height:48px;border-radius:50%;
  background:linear-gradient(135deg,#7c3aed,#6366f1);
  display:flex;align-items:center;justify-content:center;font-size:18px;
  box-shadow:0 -2px 16px rgba(124,58,237,.5);margin-top:-16px;
  border:3px solid rgba(8,4,0,.95);transition:all .22s;
}
.bni-center:active .bni-center-btn{transform:scale(.92);}
.bni-center-lbl{font-size:9px;font-weight:700;color:rgba(139,92,246,.75);letter-spacing:.5px;text-transform:uppercase;}

/* ── TOAST ── */
.toast{
  position:fixed;bottom:calc(var(--bnav) + var(--sb) + 14px);left:50%;
  transform:translateX(-50%) translateY(8px);
  background:var(--text);color:var(--ink);
  padding:10px 20px;border-radius:30px;font-size:13px;font-weight:600;
  z-index:999;opacity:0;pointer-events:none;transition:all .22s;
  white-space:nowrap;box-shadow:0 8px 24px rgba(0,0,0,.4);
}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
/* ══════════════════════════════════════════════════════
   AD BANNER CAROUSEL
══════════════════════════════════════════════════════ */
.ad-section{
  padding:10px 0 4px;
  /* Visually separated from the header and grid */
}

/* Track that slides */
.ad-carousel{
  position:relative;
  overflow:hidden;
  border-radius:0;          /* full-bleed on mobile */
  margin:0 14px;
  border-radius:var(--rl);
}
@media(min-width:480px){.ad-carousel{margin:0 14px;}}

.ad-track{
  display:flex;
  transition:transform .5s cubic-bezier(.25,.46,.45,.94);
  will-change:transform;
}

/* Individual slide */
.ad-slide{
  min-width:100%;flex-shrink:0;
  position:relative;
  border-radius:var(--rl);
  overflow:hidden;
  cursor:pointer;
  /* Fixed height prevents any layout shift */
  height:160px;
}
@media(min-width:480px){.ad-slide{height:185px;}}
@media(min-width:768px){.ad-slide{height:220px;}}

.ad-slide:active{opacity:.93;}

/* Background image layer */
.ad-bg{
  position:absolute;inset:0;
  background-size:cover;background-position:center;
  transition:transform .55s ease;
}
.ad-slide:hover .ad-bg{transform:scale(1.03);}

/* Dark gradient overlay for legibility */
.ad-overlay{
  position:absolute;inset:0;
  background:linear-gradient(
    105deg,
    rgba(8,4,0,.82) 0%,
    rgba(8,4,0,.5)  55%,
    rgba(8,4,0,.08) 100%
  );
}

/* Content */
.ad-content{
  position:absolute;inset:0;
  display:flex;flex-direction:column;justify-content:center;
  padding:18px 20px;
  z-index:2;
}
.ad-eyebrow{
  font-size:9px;font-weight:800;letter-spacing:1.5px;
  text-transform:uppercase;margin-bottom:5px;
  opacity:.75;
}
.ad-title{
  font-family:'Bebas Neue',sans-serif;
  font-size:24px;letter-spacing:.5px;line-height:1.05;
  color:#fff;margin-bottom:6px;
  max-width:220px;
}
@media(min-width:480px){.ad-title{font-size:28px;}}
.ad-sub{
  font-size:11px;color:rgba(255,255,255,.72);
  margin-bottom:12px;max-width:200px;line-height:1.45;
}
.ad-cta{
  display:inline-flex;align-items:center;gap:6px;
  padding:8px 16px;border-radius:30px;
  font-family:'Bebas Neue',sans-serif;font-size:14px;letter-spacing:.5px;
  color:#fff;align-self:flex-start;
  transition:transform .18s,box-shadow .18s;
  box-shadow:0 4px 14px rgba(0,0,0,.35);
}
.ad-cta:active{transform:scale(.95);}

/* Price tag on slide */
.ad-price-tag{
  position:absolute;top:14px;right:14px;z-index:3;
  background:rgba(8,4,0,.78);backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.15);
  border-radius:12px;padding:5px 10px;
  font-family:'Bebas Neue',sans-serif;font-size:16px;
  color:var(--amber2);letter-spacing:.3px;
}

/* Dot indicators */
.ad-dots{
  display:flex;align-items:center;justify-content:center;
  gap:5px;padding:8px 0 4px;
}
.ad-dot{
  width:5px;height:5px;border-radius:50%;
  background:rgba(255,255,255,.2);
  transition:all .3s;
  cursor:pointer;
}
.ad-dot.on{
  background:var(--amber);
  width:18px;border-radius:3px;
}

/* Progress bar auto-advance indicator */
.ad-progress{
  position:absolute;bottom:0;left:0;right:0;height:2px;z-index:4;
  background:rgba(255,255,255,.12);overflow:hidden;
  border-radius:0 0 var(--rl) var(--rl);
}
.ad-progress-bar{
  height:100%;
  background:linear-gradient(90deg,var(--amber),var(--gold));
  width:0%;
  transition:width linear;
}

/* "Sponsored" label */
.ad-sponsored{
  position:absolute;top:10px;right:14px;z-index:3;
  font-size:8px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;
  color:rgba(255,255,255,.4);
  background:rgba(255,255,255,.07);
  padding:2px 7px;border-radius:8px;
  border:1px solid rgba(255,255,255,.1);
  pointer-events:none;
}

/* Second ad unit — "Featured Deals" horizontal strip */
.deals-section{
  margin:16px 0 4px;
  padding:0;
}
.deals-head{
  display:flex;align-items:center;justify-content:space-between;
  padding:0 14px 8px;
}
.deals-head h3{
  font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.5px;
}
.deals-head h3 span{color:var(--gold);}
.deals-head a{font-size:11px;font-weight:600;color:var(--amber);white-space:nowrap;}

.deals-strip{
  display:flex;gap:9px;
  padding:0 14px 4px;
  overflow-x:auto;scrollbar-width:none;
  -webkit-overflow-scrolling:touch;
}
.deals-strip::-webkit-scrollbar{display:none;}

/* Deal card */
.deal-card{
  min-width:140px;width:140px;flex-shrink:0;
  background:var(--card);border:1px solid var(--border);
  border-radius:16px;overflow:hidden;
  cursor:pointer;position:relative;
  transition:transform .2s,box-shadow .2s,border-color .2s;
}
@media(min-width:480px){.deal-card{min-width:155px;width:155px;}}
.deal-card:active{transform:scale(.97);}
@media(hover:hover){.deal-card:hover{transform:translateY(-3px);box-shadow:0 10px 28px rgba(0,0,0,.5);border-color:var(--border2);}}

.deal-img-wrap{
  position:relative;width:100%;height:110px;overflow:hidden;
  background:linear-gradient(135deg,var(--surface),var(--card));
}
.deal-img-wrap img{
  width:100%;height:100%;object-fit:cover;
  /* Same stagger-free strategy as grid cards */
  opacity:1;transition:none;
}
.deal-img-wrap img.await-load{opacity:0;transition:opacity .3s ease;}
.deal-img-wrap img.img-loaded{opacity:1;}
@media(hover:hover){.deal-card:hover .deal-img-wrap img{transform:scale(1.04);transition:transform .5s ease;}}

/* Discount badge */
.deal-disc{
  position:absolute;top:7px;left:7px;z-index:2;
  background:linear-gradient(135deg,#ef4444,#dc2626);
  color:#fff;font-size:9px;font-weight:800;
  padding:3px 7px;border-radius:10px;letter-spacing:.3px;
}
.deal-lipa-badge{
  position:absolute;bottom:6px;left:6px;z-index:2;
  background:linear-gradient(135deg,rgba(245,166,35,.9),rgba(232,82,26,.9));
  color:#fff;font-size:8px;font-weight:800;
  padding:2px 6px;border-radius:8px;white-space:nowrap;
}

.deal-body{padding:8px 9px 10px;}
.deal-title{
  font-size:11px;font-weight:700;color:var(--text);
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;
  line-height:1.3;margin-bottom:5px;
}
.deal-prices{display:flex;align-items:baseline;gap:5px;margin-bottom:7px;}
.deal-price{
  font-family:'Bebas Neue',sans-serif;font-size:16px;
  letter-spacing:.3px;color:var(--amber2);
}
.deal-was{
  font-size:10px;color:var(--dim);text-decoration:line-through;
}
.deal-buy{display:none;} /* removed per design — tap card to view */

/* ── CHECKOUT FLOAT BAR ── */
.checkout-bar{
  position:fixed;
  bottom:calc(var(--bnav) + var(--sb) + 8px);
  left:14px;right:14px;
  z-index:190;
  display:flex;align-items:center;gap:10px;
  background:linear-gradient(135deg,#1a0e00,#2a1500);
  border:1px solid rgba(232,82,26,.35);
  border-radius:20px;
  padding:10px 14px 10px 16px;
  box-shadow:0 8px 32px rgba(0,0,0,.6), 0 0 0 1px rgba(232,82,26,.12);
  /* hidden until items in cart */
  transform:translateY(calc(100% + 24px));
  opacity:0;
  transition:transform .38s cubic-bezier(.32,1,.68,1), opacity .28s;
  pointer-events:none;
}
.checkout-bar.show{
  transform:translateY(0);
  opacity:1;
  pointer-events:all;
}
.chk-info{flex:1;min-width:0;}
.chk-items{
  font-size:11px;color:var(--muted);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
  margin-bottom:1px;
}
.chk-total{
  font-family:'Bebas Neue',sans-serif;font-size:20px;
  letter-spacing:.3px;color:var(--amber2);line-height:1;
}
.chk-btn{
  display:flex;align-items:center;gap:7px;
  padding:11px 20px;border-radius:14px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;font-family:'Bebas Neue',sans-serif;
  font-size:17px;letter-spacing:.5px;
  box-shadow:0 4px 16px rgba(232,82,26,.4);
  transition:transform .18s,box-shadow .18s;
  white-space:nowrap;flex-shrink:0;
}
.chk-btn:active{transform:scale(.97);box-shadow:0 2px 8px rgba(232,82,26,.3);}
.chk-count{
  width:22px;height:22px;border-radius:50%;
  background:rgba(255,255,255,.2);
  font-size:11px;font-weight:800;
  display:flex;align-items:center;justify-content:center;
}

/* ── PROGRESSIVE CHECKOUT STEPS ── */
.co-steps{
  display:flex;align-items:center;
  padding:14px 16px 0;
  margin-bottom:4px;
}
.co-step{
  display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;
}
.co-step:last-child{flex:0;flex-shrink:0;}
.co-dot{
  width:28px;height:28px;border-radius:50%;
  border:2px solid var(--border2);
  display:flex;align-items:center;justify-content:center;
  font-size:11px;font-weight:800;color:var(--muted);
  transition:all .3s;
}
.co-dot.done{background:var(--green);border-color:var(--green);color:#000;}
.co-dot.active{background:var(--amber);border-color:var(--amber);color:#fff;
  box-shadow:0 0 0 4px rgba(232,82,26,.18);}
.co-lbl{font-size:9px;font-weight:700;color:var(--muted);letter-spacing:.3px;text-align:center;}
.co-lbl.active{color:var(--amber);}
.co-lbl.done{color:var(--green);}
.co-line{flex:1;height:2px;background:var(--border2);margin:0 4px;margin-bottom:14px;transition:background .3s;}
.co-line.done{background:var(--green);}

/* Step panels */
.co-panel{display:none;padding:0 16px;}
.co-panel.active{display:block;animation:coIn .22s ease;}
@keyframes coIn{from{opacity:0;transform:translateX(14px)}to{opacity:1;transform:translateX(0)}}

/* Cart items in checkout */
.co-item{
  display:flex;align-items:center;gap:10px;
  background:rgba(255,255,255,.03);border-radius:var(--r);
  padding:10px 11px;border:1px solid var(--border);margin-bottom:7px;
}
.co-item-img{
  width:46px;height:46px;border-radius:10px;object-fit:cover;
  flex-shrink:0;background:var(--surface);
  opacity:0;transition:opacity .3s;
}
.co-item-img.img-loaded{opacity:1;}
.co-item-info{flex:1;min-width:0;}
.co-item-title{font-size:13px;font-weight:600;color:var(--text);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:2px;}
.co-item-shop{font-size:10px;color:var(--muted);}
.co-item-qty{display:flex;align-items:center;gap:6px;margin-top:5px;}
.qty-btn{
  width:24px;height:24px;border-radius:50%;
  background:var(--surface);border:1px solid var(--border2);
  color:var(--text);font-size:13px;font-weight:700;
  display:flex;align-items:center;justify-content:center;
  transition:border-color .15s;
}
.qty-btn:active{border-color:var(--amber);}
.qty-val{font-family:'Bebas Neue',sans-serif;font-size:15px;min-width:16px;text-align:center;}
.co-item-price{
  font-family:'Bebas Neue',sans-serif;font-size:14px;
  color:var(--amber2);flex-shrink:0;
}
.co-item-del{color:var(--dim);font-size:15px;padding:3px 4px;flex-shrink:0;}
.co-item-del:active{color:#ef4444;}

/* Order summary box */
.co-summary{
  background:rgba(255,255,255,.03);border-radius:var(--r);
  padding:11px 13px;border:1px solid var(--border);margin-bottom:14px;
}
.co-sum-row{display:flex;justify-content:space-between;font-size:13px;
  color:var(--muted);padding:3px 0;}
.co-sum-row.tot{font-size:15px;font-weight:700;color:var(--text);
  padding-top:9px;border-top:1px solid var(--border);margin-top:5px;}
.co-sum-row .free{color:var(--green);font-weight:700;}

/* Step nav buttons */
.co-nav{display:flex;gap:8px;padding:12px 0 4px;}
.co-back{
  padding:12px 18px;background:rgba(255,255,255,.06);
  border:1px solid var(--border2);border-radius:var(--rl);
  font-family:inherit;font-weight:600;font-size:13px;color:var(--muted);
  transition:all .18s;
}
.co-back:active{background:rgba(255,255,255,.1);}
.co-next{
  flex:1;padding:13px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;border-radius:var(--rl);
  font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.4px;
  box-shadow:0 4px 16px rgba(232,82,26,.35);
  transition:all .18s;
}
.co-next:active{transform:scale(.98);}
.co-next:disabled{opacity:.6;transform:none;}

/* ══════════════════════════════════════════════════════
   MID-GRID DISCOVERY SECTIONS
   These sit between the first 6 grid items and the
   infinite scroll continuation.
══════════════════════════════════════════════════════ */

/* Shared strip header */
.disc-section{ margin:20px 0 4px; }
.disc-head{
  display:flex;align-items:center;justify-content:space-between;
  padding:0 14px 10px;
}
.disc-head h3{
  font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.5px;
  display:flex;align-items:center;gap:6px;
}
.disc-head h3 .dh-icon{font-size:20px;}
.disc-head h3 span{color:var(--amber2);}
.disc-head a{font-size:11px;font-weight:700;color:var(--amber);white-space:nowrap;}

/* Horizontal scroll strip — same width cards as deals */
.disc-strip{
  display:flex;gap:10px;
  padding:0 14px 4px;
  overflow-x:auto;scrollbar-width:none;
  -webkit-overflow-scrolling:touch;
}
.disc-strip::-webkit-scrollbar{display:none;}

/* Card inside a disc-strip — slightly wider than deal cards */
.disc-card{
  min-width:152px;width:152px;flex-shrink:0;
  background:var(--card);border:1px solid var(--border);
  border-radius:16px;overflow:hidden;cursor:pointer;
  position:relative;
  transition:transform .2s,box-shadow .2s,border-color .2s;
}
@media(min-width:480px){.disc-card{min-width:165px;width:165px;}}
.disc-card:active{transform:scale(.97);}
@media(hover:hover){
  .disc-card:hover{transform:translateY(-3px);box-shadow:0 10px 28px rgba(0,0,0,.5);border-color:var(--border2);}
}

.disc-img-wrap{
  position:relative;width:100%;height:108px;overflow:hidden;
  background:linear-gradient(135deg,var(--surface),var(--card));
}
.disc-img-wrap img{
  width:100%;height:100%;object-fit:cover;
  opacity:1;transition:none;
}
.disc-img-wrap img.await-load{opacity:0;transition:opacity .3s ease;}
.disc-img-wrap img.img-loaded{opacity:1;}
@media(hover:hover){
  .disc-card:hover .disc-img-wrap img{
    transform:scale(1.05);transition:transform .5s ease;
  }
}

/* Category pill on image */
.disc-cat-pill{
  position:absolute;bottom:6px;left:7px;z-index:2;
  font-size:8px;font-weight:800;letter-spacing:.4px;text-transform:uppercase;
  padding:3px 8px;border-radius:10px;
  color:#fff;backdrop-filter:blur(6px);
}

.disc-body{padding:8px 9px 10px;}
.disc-title{
  font-size:11px;font-weight:700;color:var(--text);
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;
  overflow:hidden;line-height:1.3;margin-bottom:5px;
}
.disc-footer{display:flex;align-items:center;justify-content:space-between;gap:4px;}
.disc-price{
  font-family:'Bebas Neue',sans-serif;font-size:15px;
  letter-spacing:.3px;color:var(--amber2);
}
.disc-cart{
  width:28px;height:28px;border-radius:9px;
  display:flex;align-items:center;justify-content:center;
  font-size:13px;flex-shrink:0;
  transition:all .18s;
}
.disc-cart.btn-add{ background:rgba(232,82,26,.15);color:var(--amber); }
.disc-cart.btn-add:active{ background:var(--amber);color:#fff; }
.disc-cart.btn-added{ background:rgba(34,197,94,.15);color:var(--green); }

/* Divider between sections */
.grid-divider{
  margin:20px 14px 0;
  height:1px;background:var(--border);
}

/* "Continue browsing" heading above infinite scroll */
.continue-head{
  padding:18px 14px 6px;
  font-family:'Bebas Neue',sans-serif;font-size:17px;
  letter-spacing:.5px;color:var(--muted);
}

</style>
</head>
<body>

<!-- HEADER — sticky, search always visible -->
<header class="hdr" id="mainHdr">
  <div class="hdr-row">
    <a href="index.php" class="back-btn">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
        <path d="M19 12H5M5 12l7-7M5 12l7 7"/>
      </svg>
    </a>
    <div class="hdr-brand">Malaba <span>Shop</span></div>
    <!-- Inline compact search kept in DOM for JS compat, hidden via CSS -->
    <div class="hdr-srch-inline" id="hdrSrchInline">
      <input type="search" id="srchInlineInput" placeholder="Search...">
      <span class="hdr-srch-clear" id="srchInlineClear">&#x2715;</span>
    </div>
    <div class="hdr-acts">
      <button class="ico-btn" onclick="openCategoryBrowser()" title="Browse Categories" id="catBrowserBtn">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
          <rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>
        </svg>
      </button>
      <button class="ico-btn" onclick="openCart()" title="Cart">
        &#x1F6D2;<span class="hbadge" id="hBadge">0</span>
      </button>
    </div>
  </div>

  <!-- Search bar — always visible at every scroll position -->
  <div class="srch-row">
    <div class="srch-box">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
        <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
      </svg>
      <input type="search" id="srchInput" placeholder="Search products, categories..."
             autocomplete="off" enterkeyhint="search">
      <span class="srch-clear" id="srchClear" onclick="clearSearch()" title="Clear search">&#x2715;</span>
    </div>
  </div>

  <!-- Category chips — populated dynamically from /api/subcategories.php -->
  <div class="cats-row" id="catsRow">
    <button class="cat-tab on" data-sub="">&#x2728; All</button>
    <!-- Real subcategories injected by loadSubcategories() on DOMContentLoaded -->
  </div>
</header>

<!-- FAB kept for JS compat, hidden via CSS -->
<button class="srch-fab" id="srchFab" onclick="openSearchModal()"></button>

<!-- ══ PAGE CONTENT WRAPPER — pushed down by fixed header (height set by JS) ══ -->
<div id="pageWrap">

<!-- FLOATING SEARCH MODAL -->
<div class="srch-modal" id="srchModal">
  <div class="sm-bar">
    <div class="sm-input-wrap">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
        <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
      </svg>
      <input class="sm-input" id="smInput" type="search"
             placeholder="Search products..." autocomplete="off" spellcheck="false">
    </div>
    <button class="sm-cancel" onclick="closeSearchModal()">Cancel</button>
  </div>
  <div class="sm-results" id="smResults">
    <div class="sm-sec">Recent searches</div>
    <div class="sm-recent-wrap" id="smRecentWrap"></div>
  </div>
</div>


<!-- ══════════════════════════════════════════════════════
     AD BANNER CAROUSEL
══════════════════════════════════════════════════════ -->
<div class="ad-section" id="adSection">
  <div class="ad-carousel">
    <div class="ad-track" id="adTrack">
      <!-- Slides rendered by JS — adSlides array below -->
    </div>
    <div class="ad-progress"><div class="ad-progress-bar" id="adProgressBar"></div></div>
  </div>
  <div class="ad-dots" id="adDots"></div>
</div>

<!-- ══════════════════════════════════════════════════════
     FEATURED DEALS STRIP
══════════════════════════════════════════════════════ -->
<div class="deals-section" id="dealsSection" style="display:none;">
  <div class="deals-head">
    <h3>🔥 <span>Hot Deals</span></h3>
    <a href="category.php" onclick="filterDeals();return false;">See all ›</a>
  </div>
  <div class="deals-strip" id="dealsStrip"></div>
</div>

<div class="sec-head">
  <h2>&#x2728; <span id="gridTitle">For You</span></h2>
  <button class="sort-btn" onclick="openSortSheet()">
    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <line x1="3" y1="6" x2="21" y2="6"/>
      <line x1="3" y1="12" x2="15" y2="12"/>
      <line x1="3" y1="18" x2="9" y2="18"/>
    </svg>
    <span id="sortLbl">Smart</span>
  </button>
</div>
<div class="res-count" id="resCount"></div>

<!-- GRID -->
<div class="shop-grid" id="shopGrid">
  <!-- Skeletons -->
  <div class="skel-card"><div class="skel-sq skel"></div>
    <div style="padding:9px;"><div class="skel-ln skel" style="width:75%;height:10px;border-radius:3px;margin-bottom:6px;"></div>
    <div class="skel-ln skel" style="width:50%;height:10px;border-radius:3px;"></div></div>
  </div>
  <div class="skel-card"><div class="skel-sq skel"></div>
    <div style="padding:9px;"><div class="skel-ln skel" style="width:70%;height:10px;border-radius:3px;margin-bottom:6px;"></div>
    <div class="skel-ln skel" style="width:45%;height:10px;border-radius:3px;"></div></div>
  </div>
  <div class="skel-card"><div class="skel-sq skel"></div>
    <div style="padding:9px;"><div class="skel-ln skel" style="width:80%;height:10px;border-radius:3px;margin-bottom:6px;"></div>
    <div class="skel-ln skel" style="width:55%;height:10px;border-radius:3px;"></div></div>
  </div>
  <div class="skel-card"><div class="skel-sq skel"></div>
    <div style="padding:9px;"><div class="skel-ln skel" style="width:65%;height:10px;border-radius:3px;margin-bottom:6px;"></div>
    <div class="skel-ln skel" style="width:42%;height:10px;border-radius:3px;"></div></div>
  </div>
</div>

<!-- Mid-grid discovery sections (Trending, Under Budget, etc.) — filled by JS -->
<div id="midSections"></div>

<!-- "Continue browsing" heading — shown once infinite scroll items exist -->
<div class="continue-head" id="continueHead" style="display:none;">&#x267B; Continue Browsing</div>

<!-- Second grid — infinite scroll appends here, not into shopGrid -->
<div class="shop-grid" id="gridContinue"></div>

<!-- Infinite scroll sentinel -->
<div class="load-wrap" id="loadWrap">
  <div class="spin" id="loadSpin" style="display:none;"></div>
  <div class="load-end-msg" id="loadEnd" style="display:none;">&#x1F389; You've seen everything!</div>
</div>

</div><!-- /pageWrap -->

<!-- CHECKOUT FLOAT BAR — slides up when cart has items -->
<div class="checkout-bar" id="checkoutBar">
  <div class="chk-info">
    <div class="chk-items" id="chkItems">0 items</div>
    <div class="chk-total" id="chkTotal">KSH 0</div>
  </div>
  <button class="chk-btn" onclick="openCheckout()">
    Checkout <div class="chk-count" id="chkCount">0</div>
  </button>
</div>

<!-- BOTTOM NAV -->
<nav class="bnav">
  <a href="index.php" class="bni">
    <div class="bni-ico">&#x1F3E1;</div>
    <div class="bni-lbl">Home</div>
  </a>
  <div class="bni active" onclick="openCart()">
    <div class="bni-ico">&#x1F6D2;</div>
    <div class="bni-lbl">Shop</div>
  </div>
  <a href="video_feed.php" class="bni-center">
    <div class="bni-center-btn">&#x25B6;</div>
    <div class="bni-center-lbl">Watch</div>
  </a>
  <a href="food_listing.php" class="bni">
    <div class="bni-ico">&#x1F354;</div>
    <div class="bni-lbl">Food</div>
  </a>
  <a href="homes_listing.php" class="bni">
    <div class="bni-ico">&#127976;</div>
    <div class="bni-lbl">Rentals</div>
  </a>
</nav>

<!-- OVERLAY -->
<div class="overlay" id="overlay" onclick="handleOvClick(event)">
  <div class="sheet" id="activeSheet">
    <div id="sheetContent"></div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script src="data.js"></script>
<script src="mh_user.js"></script>
<script src="img_perf_1.js"></script>
<script src="perf_patch_1.js"></script>
<script>
/* ═══════════════════════════════════════════════════════
   AD BANNER DATA 
═══════════════════════════════════════════════════════ */
var AD_SLIDES = [
  {
    bg: 'url(https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=900&q=75&auto=format&fit=crop)',
    eyebrow: '✨ New Arrivals',
    title: 'Modern Living,\nMalaba Price',
    sub: 'Premium furniture delivered to your door. Pay daily with Lipa Mdogo.',
    cta: '🛋 Shop Furniture',
    ctaColor: 'linear-gradient(135deg,#E8521A,#FF7043)',
    sub_filter: 'furniture',
    price: null,
  },
  {
    // bg: 'url(https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=900&q=75&auto=format&fit=crop)',
    bg: 'url(https://imgs.search.brave.com/Ufrcr1XIL6eaenTr6cvd7ZhPmAtD7tZf7NPTY1Elux0/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly90aHVt/YnMuZHJlYW1zdGlt/ZS5jb20vYi9jb25m/dXNlZC1ibGFjay1j/b3VwbGUtY29va2lu/Zy1wYXN0cnktcmVj/aXBlLWxhcHRvcC1s/b2Z0LWtpdGNoZW4t/aG9tZS1jb25mdXNl/ZC1ibGFjay1jb3Vw/bGUtY29va2luZy1w/YXN0cnktMTE5Nzg1/OTQyLmpwZw)',
    eyebrow: '🍳 Kitchen Essentials',
    title: 'Cook Better,\nSpend Less',
    sub: 'Quality kitchen tools & appliances at prices that make sense.',
    cta: '🔪 Shop Kitchen',
    ctaColor: 'linear-gradient(135deg,#F5A623,#E8521A)',
    sub_filter: 'kitchen',
    price: null,
  },
  {
    bg: 'url(https://images.unsplash.com/photo-1513694203232-719a280e022f?w=900&q=75&auto=format&fit=crop)',
    eyebrow: '💡 Limited Offer',
    title: 'Light Up\nYour Space',
    sub: 'Statement lighting from KSH 450. Transform any room instantly.',
    cta: '💡 Shop Lighting',
    ctaColor: 'linear-gradient(135deg,#7c3aed,#6366f1)',
    sub_filter: 'lighting',
    price: 'From KSH 450',
  },
  {
    bg: 'url(https://images.unsplash.com/photo-1565538810643-b5bdb714032a?w=900&q=75&auto=format&fit=crop)',
    eyebrow: '🏠 Home Decor',
    title: 'Style That\nTells Your Story',
    sub: 'Unique pieces curated for Malaba & Busia homes. Free delivery over KSH 2,000.',
    cta: '🖼 Shop Decor',
    ctaColor: 'linear-gradient(135deg,#059669,#10b981)',
    sub_filter: 'decor',
    price: null,
  },
  {
    // bg: 'linear-gradient(135deg,#1a0a00 0%,#2d1200 40%,#3d1a00 100%)',
    bg: 'url(./lipamdogo.png)',
    eyebrow: '💰 Lipa Mdogo Mdogo',
    title: 'Pay In Small\nInstalments',
    sub: 'Daily, weekly or bi-weekly plans. Own what you need today.',
    cta: '💰 Learn More',
    ctaColor: 'linear-gradient(135deg,#F5A623,#d97706)',
    sub_filter: '',
    price: null,
    isLipa: true,
  },
];

/* ═══════════════════════════════════════════════════════
   AD CAROUSEL ENGINE
═══════════════════════════════════════════════════════ */
var adIdx        = 0;
var adTimer      = null;
var adInterval   = 4800; // ms per slide
var adAnimFrame  = null;
var adProgressStart = 0;

function initAdCarousel() {
  var track = document.getElementById('adTrack');
  var dots  = document.getElementById('adDots');
  if (!track || !dots) return;

  /* Shuffle slide order each session so ads feel fresh */
  var slides = AD_SLIDES.slice();
  (function shuffleAds(arr){
    for(var i=arr.length-1;i>0;i--){
      var j=Math.floor(Math.random()*(i+1));
      var t=arr[i];arr[i]=arr[j];arr[j]=t;
    }
  })(slides);
  AD_SLIDES.length=0; slides.forEach(function(s){AD_SLIDES.push(s);});

  /* Build slides */
  track.innerHTML = AD_SLIDES.map(function(s, i) {
    var bgStyle = s.bg.indexOf('url(')===0
      ? 'background-image:'+s.bg+';'
      : 'background:'+s.bg+';';
    var titleLines = s.title.replace(/\n/g,'<br>');
    return (
      '<div class="ad-slide" onclick="adClicked('+i+')">' +
        '<div class="ad-bg" style="'+bgStyle+'"></div>' +
        '<div class="ad-overlay"></div>' +
        '<div class="ad-sponsored">Promoted</div>' +
        (s.price?'<div class="ad-price-tag">'+esc(s.price)+'</div>':'')+
        '<div class="ad-content">' +
          '<div class="ad-eyebrow" style="color:'+(s.isLipa?'var(--gold)':'var(--amber2)')+';">'+(s.eyebrow||'')+'</div>'+
          '<div class="ad-title">'+titleLines+'</div>'+
          '<div class="ad-sub">'+esc(s.sub||'')+'</div>'+
          '<div class="ad-cta" style="background:'+s.ctaColor+';">'+s.cta+'</div>'+
        '</div>'+
      '</div>'
    );
  }).join('');

  /* Build dots */
  dots.innerHTML = AD_SLIDES.map(function(_, i) {
    return '<div class="ad-dot'+(i===0?' on':'')+'" onclick="adGoTo('+i+')"></div>';
  }).join('');

  /* Touch swipe */
  var tsX=0, tsY=0;
  track.addEventListener('touchstart',function(e){ tsX=e.touches[0].clientX; tsY=e.touches[0].clientY; },{passive:true});
  track.addEventListener('touchend',function(e){
    var dx=e.changedTouches[0].clientX-tsX;
    var dy=e.changedTouches[0].clientY-tsY;
    if(Math.abs(dx)>36&&Math.abs(dx)>Math.abs(dy)*1.2){
      adGoTo((adIdx+(dx<0?1:-1)+AD_SLIDES.length)%AD_SLIDES.length);
    }
  },{passive:true});

  adGoTo(0);
  startAdProgress();
}

function adGoTo(idx) {
  adIdx = idx;
  var track = document.getElementById('adTrack');
  if (track) track.style.transform = 'translateX(-'+(idx*100)+'%)';
  var allDots = document.querySelectorAll('.ad-dot');
  allDots.forEach(function(d,i){ d.classList.toggle('on',i===idx); });
  /* Reset progress bar */
  clearAdProgress();
  startAdProgress();
}

function startAdProgress() {
  clearAdProgress();
  var bar = document.getElementById('adProgressBar');
  if (!bar) return;
  bar.style.transition = 'none';
  bar.style.width = '0%';
  adProgressStart = performance.now();
  /* rAF-based smooth progress */
  function step(now) {
    var elapsed = now - adProgressStart;
    var pct = Math.min(100, (elapsed / adInterval) * 100);
    bar.style.transition = 'none';
    bar.style.width = pct + '%';
    if (pct < 100) {
      adAnimFrame = requestAnimationFrame(step);
    } else {
      /* Advance to next slide */
      adGoTo((adIdx + 1) % AD_SLIDES.length);
    }
  }
  adAnimFrame = requestAnimationFrame(step);
}

function clearAdProgress() {
  if (adAnimFrame) { cancelAnimationFrame(adAnimFrame); adAnimFrame = null; }
}

function adClicked(i) {
  var s = AD_SLIDES[i];
  if (!s) return;
  if (s.isLipa) { /* scroll to grid and do nothing else */ return; }
  /* Filter the grid to that subcategory */
  if (s.sub_filter) {
    var tabs = document.querySelectorAll('.cat-tab');
    tabs.forEach(function(t){ t.classList.remove('on'); if(t.dataset.sub===s.sub_filter) t.classList.add('on'); });
    ST.sub = s.sub_filter;
    var el = document.getElementById('gridTitle');
    if (el) el.textContent = s.sub_filter.charAt(0).toUpperCase()+s.sub_filter.slice(1);
    loadItems(true);
    /* Smooth scroll to grid */
    var grid = document.getElementById('shopGrid');
    if (grid) grid.scrollIntoView({behavior:'smooth', block:'start'});
  }
}

/* ═══════════════════════════════════════════════════════
   DEALS STRIP — populated from loaded items
   Shows the top discount/featured items in a horizontal
   scroll strip below the carousel.
═══════════════════════════════════════════════════════ */
function renderDeals(items) {
  /* Score using REAL DB flags: is_featured > is_premium > views > price range */
  var scored = items
    .filter(function(it){ return it.is_active !== 0; })
    .map(function(it) {
      var score = 0;
      /* Real DB flags — these come directly from the listings table columns */
      if (it.is_featured)  score += 40;
      if (it.is_premium)   score += 25;
      if (it.badge)        score += 10;
      if (it.has_video || it.video_url) score += 10;
      var raw = parseFloat(String(it.price||'').replace(/[^0-9.]/g,''))||0;
      /* Prefer mid-range items as "deals" */
      if (raw >= 200 && raw <= 3000) score += 15;
      if (it.views && it.views > 0)  score += Math.min(15, it.views * 0.05);
      return { item: it, score: score };
    })
    .sort(function(a, b){ return b.score - a.score; })
    .slice(0, 30);

  /* Random pick of up to 10 from the top-scored pool */
  var deals = dPick(scored.map(function(x){ return x.item; }), 10);
  if (!deals.length) return;

  var strip = document.getElementById('dealsStrip');
  var sec   = document.getElementById('dealsSection');
  if (!strip || !sec) return;

  strip.innerHTML = deals.map(function(it) {
    var raw    = parseFloat(String(it.price||'').replace(/[^0-9.]/g,''))||0;
    var hasLipa= raw >= 200;
    /* Synthetic was-price — only shown when item has some scoring signal */
    var showDisc = it.is_featured || it.is_premium || it.badge;
    var pct  = showDisc ? 0.15 + dRand() * 0.12 : 0;
    var was  = (pct > 0 && raw > 0) ? Math.round(raw * (1 + pct) / 10) * 10 : 0;
    var disc = pct > 0 ? Math.round(pct * 100) : 0;
    var rawImg = it.image || it.image_url || '';
    var img    = rawImg;
    if (img.indexOf('unsplash.com')  !== -1) img = img.split('?')[0] + '?w=320&h=220&q=70&auto=format&fit=crop';
    if (img.indexOf('cloudinary.com')!== -1) img = img.replace('/upload/', '/upload/w_320,h_220,c_fill,f_auto,q_70/');
    if (!img) img = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=320&q=65';

    /* Premium badge overlay */
    var overlayBadge = it.is_premium ? '<div style="position:absolute;top:7px;right:7px;z-index:2;background:linear-gradient(135deg,#7c3aed,#6366f1);color:#fff;font-size:8px;font-weight:800;padding:3px 7px;border-radius:10px;">&#x1F451; Premium</div>' : '';

    return (
      '<div class="deal-card" onclick="goToItem(\'' + esc(it.id) + '\')">' +
        '<div class="deal-img-wrap">' +
          '<img src="' + esc(img) + '" alt="' + esc(it.title) + '" loading="lazy" decoding="async" width="320" height="220"' +
            ' onerror="this.onerror=null;this.src=\'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=320&q=60\'">' +
          (disc > 0 ? '<div class="deal-disc">-' + disc + '%</div>' : '') +
          (hasLipa  ? '<div class="deal-lipa-badge">&#x1F4B0; Lipa</div>' : '') +
          overlayBadge +
        '</div>' +
        '<div class="deal-body">' +
          '<div class="deal-title">' + esc(it.title) + '</div>' +
          '<div class="deal-prices">' +
            '<div class="deal-price">' + esc(it.price) + '</div>' +
            (was > 0 ? '<div class="deal-was">KSH ' + was.toLocaleString() + '</div>' : '') +
          '</div>' +
          '<div style="font-size:10px;color:var(--muted);margin-top:2px;">Tap to view ›</div>' +
        '</div>' +
      '</div>'
    );
  }).join('');

  /* Stagger-free image init */
  strip.querySelectorAll('.deal-img-wrap img').forEach(function(img) {
    if (img.complete && img.naturalWidth > 0) { img.classList.add('img-loaded'); return; }
    img.classList.add('await-load');
    img.addEventListener('load',  function(){ img.classList.remove('await-load'); img.classList.add('img-loaded'); }, {once:true});
    img.addEventListener('error', function(){
      img.src = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=320&q=60';
      img.classList.remove('await-load'); img.classList.add('img-loaded');
    }, {once:true});
  });

  sec.style.display = 'block';
}

function dealQuickBuy(ev, id) {
  ev.stopPropagation();
  var item = ST.items.find(function(i){ return i.id===id; });
  if (!item) return;
  currentItem = item;
  var btn = document.getElementById('dbtn-'+id);
  var ex  = cart.findIndex(function(c){ return c.id===id; });

  if (ex !== -1) {
    /* Remove */
    cart.splice(ex, 1);
    saveCart(); renderBadges();
    if (btn) { btn.innerHTML='🛒 Buy'; btn.classList.remove('added'); }
    showToast('Removed from cart');
  } else {
    /* Add */
    cart.push({id:id, title:item.title, price:item.price, qty:1,
      shop:item.location||'',
      phone:(item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'')});
    saveCart(); renderBadges();
    if (btn) { btn.innerHTML='✓ Added'; btn.classList.add('added'); }
    showToast('&#x2713; Added to cart');
  }
}

function filterDeals() {
  window.location.href = 'category.php?sort=popular';
}

/* ═══════════════════════════════════════════════════════
   DISCOVERY SECTIONS
   Five thematic strips shown between the first 6 grid
   cards and the infinite scroll continuation.
   Each uses a different scoring algorithm and a fresh
   random shuffle every page load so the selection
   changes every time.
═══════════════════════════════════════════════════════ */

/* Re-usable per-session rand — separate from shuffleItems seed so
   discovery sections get independent variation */
var _dSeed = 0;
function dRand() {
  if (!_dSeed) {
    try { _dSeed = parseInt(sessionStorage.getItem('mh_disc_seed')||'0',10); } catch(e){}
    if (!_dSeed) {
      _dSeed = (Date.now() ^ (Math.random()*0xFFFFFF|0)) >>> 0;
      try { sessionStorage.setItem('mh_disc_seed', String(_dSeed)); } catch(e){}
    }
  }
  _dSeed = (_dSeed + 0x9E3779B9) >>> 0;
  var z = _dSeed ^ (_dSeed >>> 16);
  z = Math.imul(z, 0x85EBCA6B) >>> 0;
  z = z ^ (z >>> 13);
  z = Math.imul(z, 0xC2B2AE35) >>> 0;
  return ((z ^ (z >>> 16)) >>> 0) / 4294967296;
}
function dShuffle(arr) {
  var out = arr.slice();
  for (var i=out.length-1;i>0;i--) {
    var j=Math.floor(dRand()*(i+1));
    var t=out[i];out[i]=out[j];out[j]=t;
  }
  return out;
}
function dPick(arr, n) { return dShuffle(arr).slice(0,n); }

function renderDiscoverySections(allItems) {
  var mid = document.getElementById('midSections');
  if (!mid) return;
  mid.innerHTML = '';

  var active = allItems.filter(function(it){ return it.is_active !== 0; });
  if (active.length < 2) return;

  /* ── disc-card builder ── */
  function discCard(it, pillLabel, pillColor) {
    var rawImg = it.image||it.image_url||'';
    var img = rawImg;
    if(img.indexOf('unsplash.com')!==-1) img=img.split('?')[0]+'?w=330&h=220&q=70&auto=format&fit=crop';
    if(img.indexOf('cloudinary.com')!==-1) img=img.replace('/upload/','/upload/w_330,h_220,c_fill,f_auto,q_70/');
    if(!img) img='https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=330&q=65';
    var inCart = cart.find(function(c){ return c.id===it.id; });
    return (
      '<div class="disc-card" onclick="goToItem(\''+esc(it.id)+'\')">' +
        '<div class="disc-img-wrap">' +
          '<img src="'+esc(img)+'" alt="'+esc(it.title)+'" loading="lazy" decoding="async" width="330" height="220"' +
            ' onerror="this.src=\'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=330&q=60\'">' +
          '<div class="disc-cat-pill" style="background:'+pillColor+';">'+esc(pillLabel)+'</div>' +
        '</div>'+
        '<div class="disc-body">'+
          '<div class="disc-title">'+esc(it.title)+'</div>'+
          '<div class="disc-footer">'+
            '<div class="disc-price">'+esc(it.price)+'</div>'+
            '<button class="disc-cart '+(inCart?'btn-added':'btn-add')+'" id="dc-'+esc(it.id)+'"' +
              ' onclick="discCartToggle(event,\''+esc(it.id)+'\')" title="'+(inCart?'Remove':'Add to cart')+'">'+
              (inCart?'&#x2713;':'+')+
            '</button>'+
          '</div>'+
        '</div>'+
      '</div>'
    );
  }

  /* ── image init helper ── */
  function initDiscImgs(el) {
    el.querySelectorAll('.disc-img-wrap img').forEach(function(img) {
      if(img.complete&&img.naturalWidth>0){ img.classList.add('img-loaded'); return; }
      img.classList.add('await-load');
      img.addEventListener('load',  function(){ img.classList.remove('await-load'); img.classList.add('img-loaded'); },{once:true});
      img.addEventListener('error', function(){
        img.src='https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=330&q=60';
        img.classList.remove('await-load'); img.classList.add('img-loaded');
      },{once:true});
    });
  }

  /* ── section builder — only renders if items.length >= MIN ── */
  var MIN = 2;
  function buildSection(icon, heading, items, pillLabel, pillColor, filterSub) {
    if (!items || items.length < MIN) return;
    var el = document.createElement('div');
    el.className = 'disc-section';
    el.innerHTML =
      '<div class="disc-head">'+
        '<h3><span class="dh-icon">'+icon+'</span> <span>'+heading+'</span></h3>'+
        (filterSub
          ? '<a href="category.php?sub='+encodeURIComponent(filterSub)+'">See all ›</a>'
          : '<a href="category.php">See all ›</a>')+
      '</div>'+
      '<div class="disc-strip">'+
        items.map(function(it){ return discCard(it, pillLabel, pillColor); }).join('')+
      '</div>';
    mid.appendChild(el);
    initDiscImgs(el);
    var div = document.createElement('div');
    div.className = 'grid-divider';
    mid.appendChild(div);
  }

  /* ════════════════════════════════════════════════════════
     STEP 1 — Index items by their ACTUAL subcategory
     (uses whatever subcategory string the DB/seed returns,
      no assumptions about what categories exist)
  ════════════════════════════════════════════════════════ */
  var bySub = {};   /* { 'kitchen': [...], 'decor': [...], ... } */
  active.forEach(function(it) {
    var sub = (it.sub_category || it.subCategory || '').toLowerCase().trim();
    if (!sub) return;
    if (!bySub[sub]) bySub[sub] = [];
    bySub[sub].push(it);
  });

  /* Sort subcategories by item count descending — most-stocked first */
  var subKeys = Object.keys(bySub).sort(function(a,b){ return bySub[b].length - bySub[a].length; });

  /* ════════════════════════════════════════════════════════
     STEP 2 — Price-range buckets derived from REAL data
     Dynamically calculate the 33rd and 66th percentile of
     prices in the dataset, then label accordingly.
  ════════════════════════════════════════════════════════ */
  var allPrices = active.map(function(it){
    return parseFloat(String(it.price||'').replace(/[^0-9.]/g,''))||0;
  }).filter(function(p){ return p > 0; }).sort(function(a,b){ return a-b; });

  var budgetCeil  = 0; /* top of "affordable" bucket */
  var premiumFloor= 0; /* bottom of "premium" bucket */
  if (allPrices.length >= 3) {
    budgetCeil   = allPrices[Math.floor(allPrices.length * 0.33)];
    premiumFloor = allPrices[Math.floor(allPrices.length * 0.66)];
  } else if (allPrices.length > 0) {
    budgetCeil   = allPrices[0] * 1.2;
    premiumFloor = allPrices[allPrices.length-1] * 0.8;
  }

  var budgetItems  = budgetCeil  > 0 ? active.filter(function(it){
    var p = parseFloat(String(it.price||'').replace(/[^0-9.]/g,''))||0;
    return p > 0 && p <= budgetCeil;
  }) : [];

  var premiumItems = premiumFloor > 0 ? active.filter(function(it){
    var p = parseFloat(String(it.price||'').replace(/[^0-9.]/g,''))||0;
    return p >= premiumFloor;
  }) : [];

  /* Budget label — e.g. "Under KSH 1,500" using real threshold */
  var budgetLabel = budgetCeil > 0
    ? 'Under KSH ' + Math.ceil(budgetCeil/100)*100 + ''
    : 'Great Value';

  /* ════════════════════════════════════════════════════════
     STEP 3 — Cross-category sections (always have items)
  ════════════════════════════════════════════════════════ */

  /* 3a. Trending Now — views + is_featured (real DB field), pick 8 from top 20 */
  var trending = active
    .slice()
    .sort(function(a,b){
      /* is_featured=true from DB gets the heaviest boost */
      var fa = (a.is_featured ? 60 : 0) + (a.is_premium ? 30 : 0) + (a.views||0);
      var fb = (b.is_featured ? 60 : 0) + (b.is_premium ? 30 : 0) + (b.views||0);
      return fb - fa;
    })
    .slice(0, 20);
  buildSection(
    '&#x1F525;', 'Trending Now',
    dPick(trending, 8),
    'Trending', 'rgba(239,68,68,.85)', ''
  );

  /* ════════════════════════════════════════════════════════
     STEP 4 — Subcategory spotlights
     Show the top 3 most-stocked subcategories as sections.
     Each shows 8 randomly-picked items from THAT category.
     Subcategory label and icon are inferred from the name.
  ════════════════════════════════════════════════════════ */

  /* Icon + display-name map — covers common slugs; unknown ones get a fallback */
  var subMeta = {
    kitchen:    { icon:'&#x1F373;', label:'Kitchen Essentials',  color:'rgba(245,158,11,.85)' },
    decor:      { icon:'&#x1F5BC;', label:'Home Décor',          color:'rgba(168,85,247,.85)' },
    appliances: { icon:'&#x26A1;',  label:'Appliances',          color:'rgba(59,130,246,.85)' },
    storage:    { icon:'&#x1F9FA;', label:'Storage & Organising',color:'rgba(16,185,129,.85)' },
    furniture:  { icon:'&#x1F6CB;', label:'Furniture',           color:'rgba(245,158,11,.85)' },
    cleaning:   { icon:'&#x1F9F9;', label:'Cleaning',            color:'rgba(34,197,94,.85)'  },
    lighting:   { icon:'&#x1F4A1;', label:'Lighting',            color:'rgba(253,224,71,.9)'  },
    bedding:    { icon:'&#x1F6CF;', label:'Bedding & Linen',     color:'rgba(99,102,241,.85)' },
    bathroom:   { icon:'&#x1F6BF;', label:'Bathroom',            color:'rgba(56,189,248,.85)' },
    garden:     { icon:'&#x1F331;', label:'Garden & Outdoor',    color:'rgba(74,222,128,.85)' },
    electronics:{ icon:'&#x1F4BB;', label:'Electronics',         color:'rgba(59,130,246,.85)' },
    toys:       { icon:'&#x1F9F8;', label:'Toys & Kids',         color:'rgba(249,115,22,.85)' },
    fashion:    { icon:'&#x1F457;', label:'Fashion & Clothing',  color:'rgba(236,72,153,.85)' },
    beauty:     { icon:'&#x1F48B;', label:'Beauty & Personal',   color:'rgba(244,114,182,.85)'},
    food:       { icon:'&#x1F96A;', label:'Food & Snacks',       color:'rgba(239,68,68,.85)'  },
    sports:     { icon:'&#x26BD;',  label:'Sports & Fitness',    color:'rgba(16,185,129,.85)' },
    tools:      { icon:'&#x1F527;', label:'Tools & Hardware',    color:'rgba(107,114,128,.85)'},
    stationery: { icon:'&#x1F4DA;', label:'Stationery & Office', color:'rgba(99,102,241,.85)' },
    health:     { icon:'&#x1F48A;', label:'Health & Wellness',   color:'rgba(239,68,68,.85)'  },
    baby:       { icon:'&#x1F476;', label:'Baby & Maternity',    color:'rgba(251,191,36,.85)' },
  };

  function subIcon(sub)  { return (subMeta[sub]&&subMeta[sub].icon)  || '&#x1F6CD;'; }
  function subLabel(sub) { return (subMeta[sub]&&subMeta[sub].label) || (sub.charAt(0).toUpperCase()+sub.slice(1)); }
  function subColor(sub) { return (subMeta[sub]&&subMeta[sub].color) || 'rgba(107,114,128,.85)'; }

  /* Render up to 3 subcategory sections */
  var sectionsShown = 0;
  subKeys.forEach(function(sub) {
    if (sectionsShown >= 3) return;
    var pool = bySub[sub];
    if (pool.length < MIN) return;
    buildSection(
      subIcon(sub),
      subLabel(sub),
      dPick(pool, 8),
      sub.charAt(0).toUpperCase()+sub.slice(1),
      subColor(sub),
      sub
    );
    sectionsShown++;
  });

  /* ════════════════════════════════════════════════════════
     STEP 5 — Price-range sections (only if real items exist)
  ════════════════════════════════════════════════════════ */
  buildSection(
    '&#x1F4B0;', budgetLabel,
    dPick(budgetItems, 8),
    'Value', 'rgba(34,197,94,.85)', ''
  );

  buildSection(
    '&#x1F451;', 'Premium Selection',
    dPick(premiumItems, 8),
    'Premium', 'rgba(245,158,11,.85)', ''
  );

  /* ════════════════════════════════════════════════════════
     STEP 6 — Editorial sections (cross-category, always work)
  ════════════════════════════════════════════════════════ */

  /* Just Arrived — most recent 20, random pick of 8 */
  var recent = active.slice().sort(function(a,b){
    var da = a.created_at ? new Date(a.created_at).getTime() : 0;
    var db = b.created_at ? new Date(b.created_at).getTime() : 0;
    return db - da;
  }).slice(0, 20);
  buildSection(
    '&#x2728;', 'Just Arrived',
    dPick(recent, 8),
    'New', 'rgba(99,102,241,.85)', ''
  );

  /* Staff Picks — items where is_featured=1 OR is_premium=1 (real DB columns).
     Falls back to highest-viewed items if neither flag is set in the dataset. */
  var picked = active.filter(function(it){ return it.is_featured || it.is_premium; });
  if (picked.length < MIN) {
    /* Fallback: top-viewed items not already in trending */
    var trendingIds = trending.map(function(t){ return t.id; });
    picked = active
      .filter(function(it){ return trendingIds.indexOf(it.id) === -1; })
      .sort(function(a,b){ return (b.views||0)-(a.views||0); });
  }
  buildSection(
    '&#x1F3C6;', 'Staff Picks',
    dPick(picked, 8),
    'Staff Pick', 'rgba(168,85,247,.85)', ''
  );
}


/* Cart toggle for disc-card buttons */
function discCartToggle(ev, id) {
  ev.stopPropagation();
  var item = ST.items.find(function(i){ return i.id===id; });
  if (!item) return;
  var btn = document.getElementById('dc-'+id);
  var ex  = cart.findIndex(function(c){ return c.id===id; });
  if (ex !== -1) {
    cart.splice(ex, 1);
    saveCart(); renderBadges();
    if (btn) { btn.innerHTML='+'; btn.className='disc-cart btn-add'; btn.title='Add to cart'; }
    showToast('Removed from cart');
  } else {
    cart.push({id:id, title:item.title, price:item.price, qty:1,
      shop:item.location||'',
      phone:(item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'')});
    saveCart(); renderBadges();
    if (btn) { btn.innerHTML='&#x2713;'; btn.className='disc-cart btn-added'; btn.title='Remove from cart'; }
    showToast('&#x2713; Added to cart');
  }
}

/* Navigate to dedicated category page when "See all" is tapped */
function discFilter(sub) {
  window.location.href = 'category.php' + (sub ? '?sub=' + encodeURIComponent(sub) : '');
}

/* ═══════════════════════════════════════════════════════
   STATE
═══════════════════════════════════════════════════════ */
var ST = {
  items:[], page:1, limit:20, total:0,
  loading:false, done:false,
  sub:'', sort:'smart', search:''
};
var cart         = [];
var wishlist     = [];
var currentItem  = null;
var payMode      = 'cash';
var lipaFreq     = null;
var lipaDur      = null;
var lipaPayMode  = 'mpesa';
var lipaFreqOpts = [];
var lipaDurOpts  = [];
var recentSearches = [];

try { cart            = JSON.parse(localStorage.getItem('mh_shop_cart') || '[]'); } catch(e){}
try { wishlist        = JSON.parse(localStorage.getItem('mh_shop_wish') || '[]'); } catch(e){}
try { recentSearches  = JSON.parse(localStorage.getItem('mh_shop_srch') || '[]'); } catch(e){}

var API_BASE = (function(){
  var scripts = document.querySelectorAll('script[src]');
  for (var i=0; i<scripts.length; i++) {
    if (scripts[i].src && scripts[i].src.indexOf('data.js') !== -1) {
      return scripts[i].src.replace(/\/data\.js[^\/]*$/, '/api');
    }
  }
  return '<?php echo htmlspecialchars($apiBase, ENT_QUOTES); ?>';
})();

/* ═══════════════════════════════════════════════════════
   SCROLL — header is always fully visible; we only add
   a stronger shadow once the user has scrolled past the
   hero area so the header reads as floating.
═══════════════════════════════════════════════════════ */
var hdr        = document.getElementById('mainHdr');
var srchFab    = document.getElementById('srchFab'); /* hidden, kept for compat */
var _compact   = false; /* kept so any legacy references don't error */
var _scrollRaf = false;

window.addEventListener('scroll', function() {
  if (_scrollRaf) return;
  _scrollRaf = true;
  requestAnimationFrame(function() {
    _scrollRaf = false;
    hdr.classList.toggle('scrolled', window.scrollY > 10);
  });
}, {passive: true});

/* ═══════════════════════════════════════════════════════
   SEARCH — inline bar is always visible; also opens the
   full-screen modal for live results while typing.
═══════════════════════════════════════════════════════ */
var smTimer = null;

function clearSearch() {
  ST.search = '';
  var si = document.getElementById('srchInput');
  if (si) si.value = '';
  var cl = document.getElementById('srchClear');
  if (cl) cl.classList.remove('show');
  var gt = document.getElementById('gridTitle');
  if (gt) gt.textContent = 'All Products';
  loadItems(true);
}

/* compat stubs — referenced by other parts of the page */
function clearInlineSearch(ev) { if (ev) ev.stopPropagation(); clearSearch(); }
function openSearchModal() {
  var modal = document.getElementById('srchModal');
  if (!modal) return;
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
  renderRecent();
  var smInput = document.getElementById('smInput');
  if (smInput) {
    smInput.value = ST.search || '';
    setTimeout(function() { smInput.focus(); smInput.select(); }, 60);
  }
}
function closeSearchModal() {
  var modal = document.getElementById('srchModal');
  if (modal) modal.classList.remove('open');
  document.body.style.overflow = '';
  var sm = document.getElementById('smInput');
  if (sm) sm.value = '';
}

document.addEventListener('DOMContentLoaded', function() {
  var srchInput = document.getElementById('srchInput');
  var smInput   = document.getElementById('smInput');
  var srchClear = document.getElementById('srchClear');

  /* ── Inline header search ── */
  srchInput.addEventListener('input', function() {
    var q = this.value.trim();
    /* Show / hide clear button */
    if (srchClear) srchClear.classList.toggle('show', q.length > 0);
    clearTimeout(smTimer);
    /* Open modal for live results after a short pause */
    smTimer = setTimeout(function() {
      if (q.length > 0) {
        openSearchModal();
        var sm = document.getElementById('smInput');
        if (sm) {
          sm.value = q;
          doModalSearch(q);
        }
      } else {
        /* Cleared — reset grid */
        closeSearchModal();
        ST.search = '';
        loadItems(true);
      }
    }, 220);
  });

  srchInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && this.value.trim()) {
      applySearch(this.value.trim());
    }
    if (e.key === 'Escape') { clearSearch(); this.blur(); }
  });

  /* Tapping the search bar opens modal right away for instant results UX */
  srchInput.addEventListener('focus', function() {
    if (this.value.trim()) {
      openSearchModal();
      var sm = document.getElementById('smInput');
      if (sm) { sm.value = this.value; doModalSearch(this.value.trim()); }
    } else {
      openSearchModal(); /* shows recent searches */
    }
  });

  /* ── Modal search input ── */
  if (smInput) {
    smInput.addEventListener('input', function() {
      var q = this.value.trim();
      /* Mirror back to header input */
      if (srchInput) srchInput.value = this.value;
      if (srchClear) srchClear.classList.toggle('show', q.length > 0);
      clearTimeout(smTimer);
      if (!q) { renderRecent(); return; }
      document.getElementById('smResults').innerHTML =
        '<div class="sm-spinner show"><div class="sm-spin"></div></div>';
      smTimer = setTimeout(function() { doModalSearch(q); }, 220);
    });

    smInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' && this.value.trim()) applySearch(this.value.trim());
      if (e.key === 'Escape') closeSearchModal();
    });
  }
});

function applySearch(q) {
  ST.search = q;
  var si = document.getElementById('srchInput');  if (si) si.value = q;
  var cl = document.getElementById('srchClear');  if (cl) cl.classList.toggle('show', !!q);
  closeSearchModal();
  var gt = document.getElementById('gridTitle');  if (gt) gt.textContent = '"' + q + '"';
  loadItems(true);
  /* Scroll grid into view after a tick */
  setTimeout(function() {
    var grid = document.getElementById('shopGrid');
    if (grid) grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, 120);
}




function doModalSearch(q) {
  // First search locally (instant)
  var local = localSearch(q);
  renderSearchResults(local, q);
  // Then try API
  var xhr = new XMLHttpRequest();
  xhr.open('GET', API_BASE+'/search.php?q='+encodeURIComponent(q)+'&type=items&limit=25', true);
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout = 5000;
  xhr.onload = function() {
    try {
      var d = JSON.parse(xhr.responseText);
      if (d && d.success && d.data && d.data.length) {
        renderSearchResults(d.data, q);
      }
    } catch(e) {}
  };
  xhr.send();
}

function localSearch(q) {
  q = q.toLowerCase();
  return ST.items.filter(function(item) {
    return ((item.title||'')+(item.description||'')+
            (item.location||'')).toLowerCase().indexOf(q) !== -1;
  }).slice(0, 20);
}

function renderSearchResults(data, q) {
  var wrap = document.getElementById('smResults');
  if (!data || !data.length) {
    wrap.innerHTML = '<div class="sm-res-empty">&#x1F50D; No results for "'+esc(q)+'"</div>';
    return;
  }
  saveRecent(q);
  var html = '';
  data.forEach(function(item) {
    var img = item.image || item.image_url || '';
    var raw = parseFloat(String(item.price||'').replace(/[^0-9.]/g,'')) || 0;
    var hl  = hlText(esc(item.title||''), q);
    html +=
      '<div class="sm-res-item" onclick="pickSearchResult(\''+esc(item.id)+'\')">' +
      (img
        ? '<img class="sm-res-thumb" src="'+cdnThumb(img)+'" loading="lazy" width="52" height="52" onerror="this.style.display=\'none\'">'
        : '<div class="sm-res-thumb" style="background:var(--surface);border-radius:10px;"></div>') +
      '<div class="sm-res-info">' +
        '<div class="sm-res-title">'+hl+'</div>' +
        '<div class="sm-res-meta">'+esc((item.location||'').split(',')[0])+'</div>' +
      '</div>' +
      '<div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;">' +
        '<div class="sm-res-price">'+esc(item.price||'')+'</div>' +
        (raw>=200?'<div class="sm-res-lipa">&#x1F4B0; Lipa</div>':'') +
      '</div>' +
      '</div>';
  });
  wrap.innerHTML = html;
}

function pickSearchResult(id) {
  closeSearchModal();
  window.location.href = 'item_detail.php?id=' + encodeURIComponent(id);
}


function hlText(text, q) {
  if (!q) return text;
  var re = new RegExp('('+q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','gi');
  return text.replace(re, '<span class="hl">$1</span>');
}

function saveRecent(q) {
  recentSearches = recentSearches.filter(function(r){ return r!==q; });
  recentSearches.unshift(q);
  recentSearches = recentSearches.slice(0,8);
  try { localStorage.setItem('mh_shop_srch', JSON.stringify(recentSearches)); } catch(e){}
}
function renderRecent() {
  var wrap = document.getElementById('smResults');
  if (!recentSearches.length) {
    wrap.innerHTML = '<div class="sm-res-empty" style="padding-top:28px;">&#x1F50D; Search for products</div>';
    return;
  }
  var chips = recentSearches.map(function(q) {
    return '<span class="sm-recent-chip" onclick="quickSearchModal(\''+esc(q)+'\')">&#x1F550; '+esc(q)+'</span>';
  }).join('');
  wrap.innerHTML = '<div class="sm-sec">Recent searches</div><div class="sm-recent-wrap">'+chips+'</div>';
}
function quickSearchModal(q) {
  document.getElementById('smInput').value = q;
  doModalSearch(q);
}

/* CDN thumb helper (inline — works even if img_perf.js hasn't loaded yet) */
function cdnThumb(url) {
  if (!url) return '';
  if (url.indexOf('cloudinary.com') !== -1) {
    return url.replace('/upload/', '/upload/w_120,h_120,c_fill,f_auto,q_60/');
  }
  if (url.indexOf('unsplash.com') !== -1) {
    return url.split('?')[0] + '?w=120&h=120&q=60&auto=format&fit=crop';
  }
  return url;
}

/* ═══════════════════════════════════════════════════════
   LIPA PLAN CALCULATOR
═══════════════════════════════════════════════════════ */
function calcFrequencies(raw) {
  if (!raw || raw < 200) return [];
  var ksh = function(n){ return 'KSH '+Math.round(n).toLocaleString('en-KE'); };
  return [
    {id:'daily',  label:'Daily',        per:'day',  factor:1.0,  desc:'No extra charge — best value',
     amount:function(total,weeks){ return total/(weeks*7); }},
    {id:'3xweek', label:'3× per week',  per:'week', factor:1.02, desc:'+2% total — great flexibility',
     amount:function(total,weeks){ return total/(weeks*3); }},
    {id:'2xweek', label:'Twice a week', per:'week', factor:1.04, desc:'+4% total — comfortable pace',
     amount:function(total,weeks){ return total/(weeks*2); }},
    {id:'weekly', label:'Weekly',       per:'week', factor:1.07, desc:'+7% total — once a week',
     amount:function(total,weeks){ return total/weeks; }},
  ];
}
function calcDurations(raw, freq) {
  if (!freq) return [];
  var ksh   = function(n){ return 'KSH '+Math.round(n).toLocaleString('en-KE'); };
  var total = raw * freq.factor;
  return [
    {weeks:2,  label:'2 Weeks',  deposit:raw*.25, total:total},
    {weeks:4,  label:'4 Weeks',  deposit:raw*.2,  total:total},
    {weeks:8,  label:'8 Weeks',  deposit:raw*.15, total:total*1.03},
    {weeks:12, label:'12 Weeks', deposit:raw*.1,  total:total*1.06},
  ].map(function(d){
    var perPay = freq.amount(d.total, d.weeks);
    return {weeks:d.weeks,label:d.label,depositAmt:d.deposit,
            deposit:ksh(d.deposit),total:d.total,totalStr:ksh(d.total),
            perPay:perPay,perPayStr:ksh(perPay)};
  });
}

/* ═══════════════════════════════════════════════════════
   INIT
═══════════════════════════════════════════════════════ */

/* Hoisted so loadSubcategories / renderCatTabs can call it
   after the chips strip is rebuilt and the header height changes. */
function setPageOffset() {
  var hdr  = document.getElementById('mainHdr');
  var wrap = document.getElementById('pageWrap');
  if (hdr && wrap) wrap.style.paddingTop = hdr.offsetHeight + 'px';
}

window.addEventListener('DOMContentLoaded', function() {
  setPageOffset();
  /* Re-measure if fonts / images cause layout reflow */
  window.addEventListener('resize', setPageOffset, {passive:true});
  /* Also re-measure after a short delay for web-font load */
  setTimeout(setPageOffset, 400);

  renderBadges();
  initAdCarousel();
  loadItems(true);
  initInfiniteScroll();
  initCats();   /* fetches real subcategories from /api/subcategories.php */
  // Swipe-down to close sheet
  var sheet = document.getElementById('activeSheet');
  var tsY   = 0;
  sheet.addEventListener('touchstart', function(e){ tsY=e.touches[0].clientY; },{passive:true});
  sheet.addEventListener('touchend', function(e){
    if (e.changedTouches[0].clientY-tsY > 80 && sheet.scrollTop===0) closeOverlay();
  },{passive:true});
});

/* ═══════════════════════════════════════════════════════
   SHUFFLE — Fisher-Yates with a session seed so the order
   changes on every page load / refresh but is stable while
   the user scrolls (seed stored in sessionStorage, not
   localStorage, so it resets on tab close).
═══════════════════════════════════════════════════════ */
function shuffleItems(arr) {
  /* Generate a per-session seed so the order is different every time
     the page is opened or refreshed, but consistent within a session. */
  var seed = 0;
  try {
    seed = parseInt(sessionStorage.getItem('mh_shuffle_seed') || '0', 10);
    if (!seed) {
      seed = Date.now() % 999983; // large prime keeps distribution even
      sessionStorage.setItem('mh_shuffle_seed', String(seed));
    }
  } catch(e) { seed = Date.now(); }

  /* Seeded pseudo-random (mulberry32) — deterministic for a given seed */
  function rand() {
    seed = (seed + 0x6D2B79F5) >>> 0;
    var t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) >>> 0;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  var out = arr.slice(); // don't mutate original
  for (var i = out.length - 1; i > 0; i--) {
    var j = Math.floor(rand() * (i + 1));
    var tmp = out[i]; out[i] = out[j]; out[j] = tmp;
  }
  return out;
}

/* ═══════════════════════════════════════════════════════
   LOAD ITEMS
═══════════════════════════════════════════════════════ */
function loadItems(reset) {
  if (ST.loading || (ST.done && !reset)) return;
  ST.loading = true;
  if (reset) { ST.page=1; ST.items=[]; ST.done=false; }
  showSpin(true);

  /* Always use listings.php — recommended.php is optional and may not exist.
     sub_category is passed as &filter= which the API maps to exact sub_category match. */
  var url = API_BASE + '/listings.php?type=items'
    + '&page='   + ST.page
    + '&limit='  + ST.limit
    + '&sort='   + encodeURIComponent(ST.sort)
    + '&search=' + encodeURIComponent(ST.search)
    + (ST.sub ? '&filter=' + encodeURIComponent(ST.sub) : '');

  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout = 9000;
  xhr.onload = function() {
    var newItems = [];
    try {
      var d = JSON.parse(xhr.responseText);
      if (d && d.success) {
        newItems = d.data || [];
        if (d.meta) { ST.total=d.meta.total; if(ST.page>=d.meta.pages) ST.done=true; }
      }
    } catch(e) {}
    finish(newItems);
  };
  xhr.onerror = xhr.ontimeout = function() { finish([]); };
  xhr.send();

  function finish(newItems) {
    if (!newItems.length) {
      var seed = (window.MalabaAPI && MalabaAPI._seed && MalabaAPI._seed.items) || [];
      if (ST.sub) seed=seed.filter(function(i){return i.subCategory===ST.sub;});
      if (ST.search) { var q=ST.search.toLowerCase(); seed=seed.filter(function(i){return ((i.title||'')+(i.description||'')).toLowerCase().indexOf(q)!==-1;}); }
      newItems=seed; ST.done=true;
    }
    if (reset) {
      ST.items = shuffleItems(newItems);
      renderGrid(true);
      if (newItems.length) {
        renderDeals(newItems);
        renderDiscoverySections(newItems);
      }
    }
    else { newItems.forEach(function(i){ ST.items.push(i); }); appendCards(newItems); }
    ST.page++; ST.loading=false; showSpin(false);
    var rc = document.getElementById('resCount');
    if (rc) rc.textContent = ST.items.length+(ST.done?'':'+')+ ' product'+(ST.items.length!==1?'s':'');
    if (ST.done) { var le=document.getElementById('loadEnd'); if(le)le.style.display='block'; }
    // Tell perf_patch to apply optimisations to new images
    if (window.MhPerfPatch) MhPerfPatch.run();
  }
}

/* ═══════════════════════════════════════════════════════
   RENDER / APPEND CARDS
   Layout contract:
     • #shopGrid     — first 6 items only (above-fold preview)
     • #midSections  — discovery strips (injected after first load)
     • #gridContinue — all subsequent items via infinite scroll
═══════════════════════════════════════════════════════ */
var ABOVE_FOLD_CAP = 6; /* items shown before mid-sections */

function renderGrid(reset) {
  var grid     = document.getElementById('shopGrid');
  var gridCont = document.getElementById('gridContinue');
  var midSec   = document.getElementById('midSections');
  var contHead = document.getElementById('continueHead');

  if (reset) {
    grid.innerHTML     = '';
    gridCont.innerHTML = '';
    if (midSec)   midSec.innerHTML   = '';
    if (contHead) contHead.style.display = 'none';
  }

  if (!ST.items.length && reset) {
    grid.innerHTML =
      '<div class="empty-state"><div class="empty-ico">&#x1F50D;</div>' +
      '<h3>Nothing Found</h3><p>Try a different search or category</p></div>';
    return;
  }

  if (window.MhImgPerf && reset) MhImgPerf.preloadFirst(ST.items, 3);

  /* First 6 → shopGrid, rest → gridContinue */
  var above = ST.items.slice(0, ABOVE_FOLD_CAP);
  var below = ST.items.slice(ABOVE_FOLD_CAP);

  appendCardsTo(grid, above, 0);

  if (below.length) {
    if (contHead) contHead.style.display = 'block';
    appendCardsTo(gridCont, below, ABOVE_FOLD_CAP);
  }
}

function appendCards(items) {
  /* Called by infinite scroll for subsequent pages — always goes to gridContinue */
  var gridCont = document.getElementById('gridContinue');
  var contHead = document.getElementById('continueHead');
  if (contHead) contHead.style.display = 'block';
  var existingCount = gridCont.querySelectorAll('.pcard').length +
                      ABOVE_FOLD_CAP; /* offset for animation index */
  appendCardsTo(gridCont, items, existingCount);
}

function appendCardsTo(grid, items, startIdx) {
  var frag = document.createDocumentFragment();

  items.forEach(function(item, i) {
    var el = document.createElement('div');
    el.className = 'pcard';
    el.setAttribute('data-id', item.id || '');

    var totalIdx = startIdx + i;
    if (totalIdx < 8) {
      el.classList.add('animate-in');
      el.style.animationDelay = '0s';
      el.addEventListener('animationend', function() {
        el.style.willChange = 'auto';
        el.style.animationDelay = '';
      }, {once: true});
    }

    el.innerHTML = cardHTML(item);
    frag.appendChild(el);
  });

  grid.appendChild(frag);

  /* Stagger-free image init */
  var newCards = grid.querySelectorAll('.pcard:not([data-img-init])');
  newCards.forEach(function(card) {
    card.setAttribute('data-img-init', '1');
    var img = card.querySelector('.pcard-img img');
    if (!img) return;
    if (img.complete && img.naturalWidth > 0) {
      img.classList.add('img-loaded');
    } else {
      img.classList.add('await-load');
      img.addEventListener('load', function() {
        img.classList.remove('await-load');
        img.classList.add('img-loaded');
      }, {once: true});
      img.addEventListener('error', function() {
        img.src = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=600&q=60';
        img.classList.remove('await-load');
        img.classList.add('img-loaded');
      }, {once: true});
    }
  });
}

/* ═══════════════════════════════════════════════════════
   CARD HTML — with CDN optimised images
═══════════════════════════════════════════════════════ */
function cardHTML(item) {
  // Avoid stagger/animation dependency: always render with fast card-size images.

  var liked  = wishlist.indexOf(item.id) !== -1;
  var inCart = cart.find(function(c){ return c.id===item.id; });
  var raw    = parseFloat(String(item.price||'').replace(/[^0-9.]/g,'')) || 0;
  var hasLipa= raw >= 200;
  var hasVid = !!(item.video_url || item.has_video);
  var rating = item.rating ? parseFloat(item.rating).toFixed(1) : (3.9+Math.random()*.9).toFixed(1);

  // CDN optimised image — exact card size, no wasted bytes
  var rawImg = item.image || item.image_url || '';
  var img    = window.MhImgPerf ? MhImgPerf.imgCard(rawImg) : rawImg;

  // Fallback: enforce card-size images even if MhImgPerf hasn't loaded yet.
  if (img && (img.indexOf('cloudinary.com') !== -1 || img.indexOf('unsplash.com') !== -1)) {
    if (img.indexOf('cloudinary.com') !== -1) {
      img = img.replace('/upload/', '/upload/w_360,h_360,c_fill,f_auto,q_70/');
    } else if (img.indexOf('unsplash.com') !== -1) {
      img = img.split('?')[0] + '?w=360&h=360&q=70&auto=format&fit=crop';
    }
  }

  if (!img) img = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=360&h=360&q=70&auto=format&fit=crop';

  return (
    '<div class="pcard-img" onclick="goToItem(\''+esc(item.id)+'\')">' +
      '<img src="'+esc(img)+'" alt="'+esc(item.title)+'"'+
        ' loading="lazy" decoding="async" width="600" height="600"'+
        ' onerror="this.src=\'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=600&q=60\'">' +
      (item.badge?'<div class="pbadge">'+esc(item.badge)+'</div>':'') +
      (hasLipa?'<div class="plipa-badge">&#x1F4B0; Lipa</div>':'') +
      '<button class="wish'+(liked?' liked':'')+'" onclick="toggleWish(event,\''+esc(item.id)+'\',this)">'+
        (liked?'&#x2665;':'&#x2661;')+'</button>' +
    '</div>' +
    '<div class="pcard-body" onclick="goToItem(\''+esc(item.id)+'\')">' +
      '<div class="ptitle">'+esc(item.title)+'</div>' +
    '</div>' +
    '<div class="pprice" onclick="goToItem(\''+esc(item.id)+'\')">' +esc(item.price)+'</div>' +
    '<div class="pcard-foot">' +
      '<button class="btn-cart'+(inCart?' added':'')+'" id="btn-'+esc(item.id)+
        '" onclick="addToCart(event,\''+esc(item.id)+'\')">' +
        (inCart?'&#x2713; Added':'+ Cart') +
      '</button>' +
      '<button class="btn-buy" onclick="buyNow(event,\''+esc(item.id)+'\')">' +
        '&#x1F6D2; Buy' +
      '</button>' +
    '</div>'
  );
}

/* ═══════════════════════════════════════════════════════
   CARD ACTIONS — Toggle Cart / Buy Now
═══════════════════════════════════════════════════════ */
function addToCart(ev, id) {
  ev.stopPropagation();
  var item = ST.items.find(function(i){ return i.id===id; });
  if (!item) return;
  currentItem = item;

  var btn = document.getElementById('btn-'+id);
  var ex  = cart.findIndex(function(c){ return c.id===id; });

  if (ex !== -1) {
    /* Already in cart — REMOVE it */
    cart.splice(ex, 1);
    saveCart(); renderBadges();
    if (btn) { btn.innerHTML='+ Cart'; btn.classList.remove('added'); }
    showToast('Removed from cart');
  } else {
    /* Not in cart — ADD it */
    cart.push({id:id, title:item.title, price:item.price, qty:1,
      shop: item.location||'',
      phone:(item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'')});
    saveCart(); renderBadges();
    if (btn) { btn.innerHTML='&#x2713; Added'; btn.classList.add('added'); }
    showToast('&#x2713; Added to cart');
  }
}

function buyNow(ev, id) {
  ev.stopPropagation();
  var item = ST.items.find(function(i){ return i.id===id; });
  if (!item) return;
  currentItem = item;
  /* Add silently if not already in cart */
  var ex = cart.findIndex(function(c){ return c.id===id; });
  if (ex === -1) {
    cart.push({id:id, title:item.title, price:item.price, qty:1,
      shop: item.location||'',
      phone:(item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'')});
    saveCart(); renderBadges();
    var btn = document.getElementById('btn-'+id);
    if (btn) { btn.innerHTML='&#x2713; Added'; btn.classList.add('added'); }
  }
  /* Open progressive checkout and jump straight to details step */
  coStep = 1; coPayMode = 'cash';
  buildCheckoutSheet();
  openSheet();
  prefillSaved();
  /* Auto-advance to step 2 so user goes straight to details */
  setTimeout(function() { setCoStep(2); prefillSaved(); }, 60);
}

/* backward-compat alias */
function quickOrder(ev, id) { addToCart(ev, id); }


/* ═══════════════════════════════════════════════════════
   OPEN DETAIL SHEET — full gallery + video + buy options
═══════════════════════════════════════════════════════ */
var detGalIdx = 0; // current gallery slide index

function openQV(id) { goToItem(id); } /* alias — backward compat */
function goToItem(id) {
  window.location.href = 'item_detail.php?id=' + encodeURIComponent(id);
}
function openLipa(ev, id) {
  if (ev) ev.stopPropagation();
  var item = ST.items.find(function(i){ return i.id===id; });
  if (!item) return;
  currentItem = item;
  startLipaSheet();
}
function openLipaFromQV(id) { openLipa(null, id); }

function openDetail(id) {
  var item = ST.items.find(function(i){ return i.id===id; }) || currentItem;
  if (!item) return;
  currentItem  = item;
  detGalIdx    = 0;

  var raw     = parseFloat(String(item.price||'').replace(/[^0-9.]/g,'')) || 0;
  var hasLipa = raw >= 200;
  var hasVid  = !!(item.video_url || item.has_video);
  var inCart  = cart.find(function(c){ return c.id===id; });
  var rating  = item.rating ? parseFloat(item.rating).toFixed(1) : (3.9+Math.random()*.9).toFixed(1);

  /* Build image array — main image + any gallery images */
  var imgs = [];
  var mainRaw = item.image || item.image_url || '';
  if (mainRaw) imgs.push(mainRaw);
  if (item.images && item.images.length) {
    item.images.forEach(function(gi) {
      var u = gi.image_url || gi.url || gi || '';
      if (u && imgs.indexOf(u) === -1) imgs.push(u);
    });
  }
  if (!imgs.length) imgs.push('https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=800&q=75');

  var multi = imgs.length > 1;

  /* ── Gallery slides ── */
  var slidesHTML = imgs.map(function(rawSrc, si) {
    var src = window.MhImgPerf ? MhImgPerf.imgHero(rawSrc) : rawSrc;
    return '<div class="det-slide">' +
      '<img src="'+esc(src)+'" alt="'+esc(item.title)+' image '+(si+1)+'"' +
        ' loading="'+(si===0?'eager':'lazy')+'"' +
        ' width="800" height="260"' +
        ' onerror="this.src=\'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=800&q=70\'">' +
    '</div>';
  }).join('');

  /* ── Dot indicators ── */
  var dotsHTML = multi ? imgs.map(function(_, di) {
    return '<div class="det-dot'+(di===0?' on':'')+'"></div>';
  }).join('') : '';

  /* ── Thumbnail strip ── */
  var thumbsHTML = multi ? imgs.map(function(rawSrc, ti) {
    var src = window.MhImgPerf ? MhImgPerf.imgThumb(rawSrc) : rawSrc;
    return '<img src="'+esc(src)+'" class="det-thumb'+(ti===0?' on':'')+'"' +
      ' loading="lazy" width="54" height="44"' +
      ' onclick="detGalTo('+ti+')"' +
      ' onerror="this.style.display=\'none\'">';
  }).join('') : '';

  /* ── Features ── */
  var featsHTML = '';
  if (item.features && item.features.length) {
    featsHTML = '<div class="det-feats">'+
      item.features.map(function(f) {
        return '<div class="df"><span>'+(f.icon||'&#x2705;')+'</span><span>'+
          esc(f.text||f.feature_text||'')+'</span></div>';
      }).join('')+'</div>';
  }

  /* ── Build sheet HTML ── */
  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div>'+
    '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>'+

    /* Gallery */
    '<div class="det-gallery">'+
      '<div class="det-track" id="detTrack">'+slidesHTML+'</div>'+
      (multi?
        '<button class="det-prev" onclick="detGal(-1)">&#x2039;</button>'+
        '<button class="det-next" onclick="detGal(1)">&#x203A;</button>'+
        '<div class="det-count" id="detCount">1 / '+imgs.length+'</div>'+
        '<div class="det-dots" id="detDots">'+dotsHTML+'</div>'
      :'')+
    '</div>'+

    /* Thumbnail strip */
    (multi?'<div class="det-thumbs" id="detThumbs">'+thumbsHTML+'</div>':'')+

    /* Video button — only if listing has a video */
    (hasVid?
      '<div class="det-video-btn" onclick="openInVideoFeed(\''+esc(id)+'\')">'+
        '<div class="dvb-icon">&#x25B6;</div>'+
        '<div class="dvb-text">'+
          '<div class="dvb-title">Watch Product Video</div>'+
          '<div class="dvb-sub">See it in action on Watch &amp; Shop</div>'+
        '</div>'+
        '<div class="dvb-arr">&#x203A;</div>'+
      '</div>'
    :'')+

    /* Detail body */
    '<div class="det-body">'+
      (item.badge?'<div class="det-badge">'+esc(item.badge)+'</div>':'')+
      '<div class="det-title">'+esc(item.title)+'</div>'+
      '<div class="det-price">'+esc(item.price)+'</div>'+
      '<div class="det-meta">'+
        '<span class="det-rating">&#x2605; '+rating+'</span>'+
        (item.location?'<span>&#x1F4CD; '+esc((item.location||'').split(',')[0])+'</span>':'')+
        (item.prep_time?'<span>&#x23F1; '+esc(item.prep_time)+'</span>':'')+
      '</div>'+
      (item.description?'<div class="det-desc">'+esc(item.description)+'</div>':'')+
      featsHTML+

      /* Buy options */
      '<div class="buy-options">'+
        '<div class="buy-opt opt-full" onclick="openDirectOrder(\''+esc(id)+'\')">'+
          '<div class="bo-icon boi-full">&#x1F6D2;</div>'+
          '<div class="bo-info">'+
            '<div class="bo-title">Buy Now — '+esc(item.price)+'</div>'+
            '<div class="bo-sub">Pay cash or M-Pesa on delivery.</div>'+
          '</div>'+
          '<div class="bo-arrow">&#x203A;</div>'+
        '</div>'+
        (hasLipa?
          '<div class="buy-opt opt-lipa" onclick="openLipaFromQV(\''+esc(id)+'\')">'+
            '<div class="bo-icon boi-lipa">&#x1F4B0;</div>'+
            '<div class="bo-info">'+
              '<div class="bo-title">Lipa Mdogo Mdogo</div>'+
              '<div class="bo-sub">Daily, twice-weekly or weekly payments. Delivered after full payment.</div>'+
            '</div>'+
            '<div class="bo-arrow">&#x203A;</div>'+
          '</div>':'')+
      '</div>'+

      /* Cart status */
      (inCart?
        '<div style="text-align:center;font-size:13px;color:var(--green);padding:4px 0 8px;">'+
          '&#x2713; Already in your cart — '+
          '<button onclick="openCart()" style="color:var(--amber);font-weight:700;font-size:13px;cursor:pointer;">View Cart</button>'+
        '</div>':'')+
    '</div>';

  openSheet();

  /* ── Fade in each gallery image independently ── */
  var slides = document.querySelectorAll('.det-slide img');
  slides.forEach(function(img) {
    if (img.complete && img.naturalWidth > 0) {
      img.classList.add('img-loaded');
    } else {
      img.addEventListener('load',  function(){ img.classList.add('img-loaded'); }, {once:true});
      img.addEventListener('error', function(){
        img.src = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=800&q=60';
        img.classList.add('img-loaded');
      }, {once:true});
    }
  });

  /* ── Thumbnail fade-in ── */
  var thumbEls = document.querySelectorAll('.det-thumb');
  thumbEls.forEach(function(t) {
    if (t.complete && t.naturalWidth > 0) { t.style.opacity=t.classList.contains('on')?'1':'0.55'; }
    else {
      t.addEventListener('load', function(){
        t.style.opacity = t.classList.contains('on') ? '1' : '0.55';
      }, {once:true});
    }
  });

  /* ── Touch swipe on gallery ── */
  var track = document.getElementById('detTrack');
  if (track) {
    var tsX = 0, tsY = 0, swiping = false;
    track.addEventListener('touchstart', function(e) {
      tsX = e.touches[0].clientX;
      tsY = e.touches[0].clientY;
      swiping = true;
    }, {passive:true});
    track.addEventListener('touchend', function(e) {
      if (!swiping) return;
      swiping = false;
      var dx = e.changedTouches[0].clientX - tsX;
      var dy = e.changedTouches[0].clientY - tsY;
      /* Only trigger if horizontal swipe dominates */
      if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy) * 1.2) {
        detGal(dx < 0 ? 1 : -1);
      }
    }, {passive:true});
  }

  if (window.MalabaAPI) MalabaAPI.trackView(id);
}

/* Gallery navigation */
function detGal(dir) {
  var item = currentItem;
  if (!item) return;
  var imgs = [];
  if (item.image || item.image_url) imgs.push(item.image||item.image_url);
  if (item.images && item.images.length) {
    item.images.forEach(function(gi){
      var u=gi.image_url||gi.url||gi||'';
      if (u && imgs.indexOf(u)===-1) imgs.push(u);
    });
  }
  if (!imgs.length) return;
  detGalIdx = (detGalIdx + dir + imgs.length) % imgs.length;
  detGalTo(detGalIdx);
}

function detGalTo(idx) {
  detGalIdx = idx;
  var track  = document.getElementById('detTrack');
  var dots   = document.getElementById('detDots');
  var thumbs = document.getElementById('detThumbs');
  var count  = document.getElementById('detCount');

  if (track) track.style.transform = 'translateX(-'+( idx * 100 )+'%)';

  if (dots) {
    var dEls = dots.querySelectorAll('.det-dot');
    dEls.forEach(function(d, i){ d.classList.toggle('on', i===idx); });
  }
  if (thumbs) {
    var tEls = thumbs.querySelectorAll('.det-thumb');
    tEls.forEach(function(t, i){
      t.classList.toggle('on', i===idx);
      t.style.opacity = (i===idx) ? '1' : '0.55';
    });
    /* Scroll active thumb into view */
    var activeThumb = thumbs.querySelectorAll('.det-thumb')[idx];
    if (activeThumb) activeThumb.scrollIntoView({behavior:'smooth', block:'nearest', inline:'center'});
  }
  /* Update slides — load next one lazily */
  var slides = document.querySelectorAll('.det-slide img');
  if (slides[idx]) {
    var nextSrc = slides[idx].getAttribute('src');
    if (!nextSrc || nextSrc === '') {
      /* Hasn't been set yet — this handles lazy-loaded extras */
    }
  }
  if (count) {
    var total = document.querySelectorAll('.det-slide').length;
    count.textContent = (idx+1)+' / '+total;
  }
}

/* Open in video feed */
function openInVideoFeed(id) {
  window.location.href = 'video_feed.php?id='+encodeURIComponent(id)+'&cat=items';
}

/* ═══════════════════════════════════════════════════════
   DIRECT ORDER FORM
═══════════════════════════════════════════════════════ */
function openDirectOrder(id) {
  var item = id ? (ST.items.find(function(i){ return i.id===id; })||currentItem) : currentItem;
  if (!item) return;
  currentItem = item; payMode = 'cash';

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div>'+
    '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>'+
    '<div style="padding:14px 16px 0;">'+
      '<div style="display:flex;align-items:center;gap:10px;padding-bottom:14px;'+
        'border-bottom:1px solid var(--border);margin-bottom:16px;">'+
        '<div style="font-size:26px;">&#x1F6D2;</div>'+
        '<div><div style="font-family:\'Bebas Neue\',sans-serif;font-size:17px;letter-spacing:.3px;">'+esc(item.title)+'</div>'+
        '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:20px;color:var(--amber2);">'+esc(item.price)+'</div></div>'+
      '</div>'+
      '<div class="row2">'+
        '<div class="field"><label>Full Name *</label>'+
        '<input type="text" id="do_name" placeholder="Your name" autocomplete="name"></div>'+
        '<div class="field"><label>Phone *</label>'+
        '<input type="tel" id="do_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>'+
      '</div>'+
      '<div class="field"><label>Delivery Address *</label>'+
      '<input type="text" id="do_addr" placeholder="e.g. Near Malaba Market"></div>'+
      '<div style="font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:8px;">Payment Method</div>'+
      '<div class="pay-opts">'+
        '<div class="po sel" id="do_cash" onclick="setDirectPay(\'cash\',this)">'+
        '<div class="po-ico">&#x1F4B5;</div><div class="po-txt"><strong>Cash on Delivery</strong><span>Pay when item arrives</span></div>'+
        '<div class="po-dot"></div></div>'+
        '<div class="po" id="do_mpesa" onclick="setDirectPay(\'mpesa\',this)">'+
        '<div class="po-ico">&#x1F4F1;</div><div class="po-txt"><strong>M-Pesa on Delivery</strong><span>Send M-Pesa when delivered</span></div>'+
        '<div class="po-dot"></div></div>'+
      '</div>'+
      '<button class="sbtn" id="doSubmitBtn" onclick="submitDirectOrder()">'+
        '&#x1F6D2; Place Order — '+esc(item.price)+'</button>'+
    '</div>';

  openSheet(); prefillSaved();
}
function setDirectPay(mode, el) {
  payMode = mode;
  document.getElementById('do_cash').classList.toggle('sel', mode==='cash');
  document.getElementById('do_mpesa').classList.toggle('sel', mode==='mpesa');
}
function submitDirectOrder() {
  var name  = (document.getElementById('do_name').value||'').trim();
  var phone = (document.getElementById('do_phone').value||'').trim();
  var addr  = (document.getElementById('do_addr').value||'').trim();
  if (!name)  { showToast('Enter your full name'); return; }
  if (!phone || phone.replace(/\D/g,'').length < 9) { showToast('Enter a valid phone number'); return; }
  if (!addr)  { showToast('Enter your delivery address'); return; }
  var btn = document.getElementById('doSubmitBtn');
  if (btn) { btn.disabled=true; btn.textContent='Placing order...'; }
  saveMhUser(name, phone, addr);
  var item = currentItem;
  var waNum = normWA((item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||''));
  postOrder({
    category:'items',listing_id:item.id||'',
    listing_title:item.title||'',listing_price:item.price||'',
    name:name,phone:phone,address:addr,
    payment_method:payMode==='mpesa'?'mpesa_on_delivery':'cash_on_delivery',
    total_amount:item.price||'0',
    notes:'Direct buy — '+payMode,
  }, function(d) {
    var ref = d&&d.order_ref?d.order_ref:'';
    var msg = encodeURIComponent('Hi! I ordered *'+item.title+'* ('+item.price+')\nRef: '+(ref||'—')+'\nName: '+name+'\nPhone: '+phone+'\nAddress: '+addr+'\nPayment: '+payMode);
    showSuccess('Order Placed!','Pay '+item.price+(payMode==='cash'?' cash':' via M-Pesa')+' when your item arrives.',ref,
      function(){ window.open('https://wa.me/'+waNum+'?text='+msg,'_blank'); });
  }, function() {
    if (btn) { btn.disabled=false; btn.textContent='&#x1F6D2; Place Order — '+item.price; }
    showToast('Network error. Please try again.');
  });
}

/* ═══════════════════════════════════════════════════════
   LIPA MDOGO MDOGO
═══════════════════════════════════════════════════════ */
function startLipaSheet() {
  var item = currentItem;
  if (!item) return;
  lipaFreq=null; lipaDur=null;
  var raw = parseFloat(String(item.price||'').replace(/[^0-9.]/g,''))||0;
  lipaFreqOpts = calcFrequencies(raw);
  if (!lipaFreqOpts.length) { openDirectOrder(item.id); return; }
  var rawImg = item.image||item.image_url||'';
  var img    = window.MhImgPerf ? MhImgPerf.imgThumb(rawImg) : rawImg;

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div>'+
    '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>'+
    '<div class="lipa-header">'+
      '<div class="lipa-product-row">'+
        (img?'<img class="lipa-pimg" src="'+esc(img)+'" width="58" height="58" loading="lazy" onerror="this.style.display=\'none\'">':'<div class="lipa-pimg-ph">&#x1F4E6;</div>')+
        '<div><div class="lipa-pname">'+esc(item.title)+'</div>'+
        '<div class="lipa-pwas">'+esc(item.price)+' full price</div>'+
        '<div class="lipa-ptag">&#x1F4B0; Instalment plan available</div></div>'+
      '</div>'+
      '<div class="lipa-steps">'+
        '<div class="lstep"><div class="ls-dot active" id="lsd1">1</div><div class="ls-lbl active" id="lsl1">Frequency</div></div>'+
        '<div class="ls-line" id="lsl1l"></div>'+
        '<div class="lstep"><div class="ls-dot" id="lsd2">2</div><div class="ls-lbl" id="lsl2">Duration</div></div>'+
        '<div class="ls-line" id="lsl2l"></div>'+
        '<div class="lstep"><div class="ls-dot" id="lsd3">3</div><div class="ls-lbl" id="lsl3">Details</div></div>'+
      '</div>'+
    '</div>'+
    // Step 1
    '<div class="lipa-panel active" id="lp1">'+
      '<div class="lipa-sec-title">How often can you pay?</div>'+
      '<div class="lipa-sec-sub">Choose your payment frequency. Daily payments have zero markup.</div>'+
      buildFreqHTML()+
      '<div class="lipa-nav"><button class="lipa-next" onclick="lipaNext(1)">Next: Duration &#x2192;</button></div>'+
    '</div>'+
    // Step 2
    '<div class="lipa-panel" id="lp2">'+
      '<div class="lipa-sec-title">How long to pay?</div>'+
      '<div class="lipa-sec-sub">Shorter = bigger payments. Longer = smaller payments.</div>'+
      '<div class="lipa-durs" id="lipaDurGrid"></div>'+
      '<div class="lipa-summary" id="lipaSummary"></div>'+
      '<div class="lipa-nav">'+
        '<button class="lipa-back" onclick="lipaBack(2)">&#x2190; Back</button>'+
        '<button class="lipa-next" onclick="lipaNext(2)">Next: Your Details &#x2192;</button>'+
      '</div>'+
    '</div>'+
    // Step 3
    '<div class="lipa-panel" id="lp3">'+
      '<div class="lipa-sec-title">Your Details</div>'+
      '<div class="lipa-rule"><strong>&#x26A0; Important:</strong> Product delivered ONLY after all payments received. First payment secures your order.</div>'+
      '<div class="field"><label>Full Name *</label><input type="text" id="lp_name" placeholder="Your full name" autocomplete="name"></div>'+
      '<div class="field"><label>Phone *</label><input type="tel" id="lp_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>'+
      '<div class="field"><label>Delivery Address *</label><input type="text" id="lp_addr" placeholder="e.g. Near Malaba Market"></div>'+
      '<div style="font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:8px;">First payment method</div>'+
      '<div class="pay-opts lipa-pay">'+
        '<div class="po sel" id="lpo_mpesa" onclick="setLipaPay(\'mpesa\',this)"><div class="po-ico">&#x1F4F1;</div><div class="po-txt"><strong>M-Pesa</strong><span>First instalment via M-Pesa</span></div><div class="po-dot"></div></div>'+
        '<div class="po" id="lpo_cash"  onclick="setLipaPay(\'cash\',this)"><div class="po-ico">&#x1F4B5;</div><div class="po-txt"><strong>Cash</strong><span>First instalment in cash</span></div><div class="po-dot"></div></div>'+
      '</div>'+
      '<div class="lipa-nav">'+
        '<button class="lipa-back" onclick="lipaBack(3)">&#x2190; Back</button>'+
        '<button class="lipa-next" id="lipaSubmitBtn" onclick="submitLipa()">&#x1F4B0; Submit Plan Request</button>'+
      '</div>'+
    '</div>';

  openSheet(); prefillSaved();
  // Fade in lipa product image
  var lImg = document.querySelector('.lipa-pimg');
  if (lImg) {
    lImg.onload  = function(){ lImg.classList.add('img-loaded'); };
    lImg.onerror = function(){ lImg.classList.add('img-loaded'); };
    if (lImg.complete && lImg.naturalWidth>0) lImg.classList.add('img-loaded');
  }
}
function buildFreqHTML() {
  var raw = parseFloat(String(currentItem.price||'').replace(/[^0-9.]/g,''))||0;
  var html = '<div class="lipa-freqs">';
  lipaFreqOpts.forEach(function(f, i) {
    var pp = f.amount(raw*f.factor, 4);
    html +=
      '<div class="lipa-freq" id="lf-'+f.id+'" onclick="selFreq(\''+f.id+'\','+i+')">'+
        '<div class="lf-radio"></div>'+
        '<div class="lf-info"><div class="lf-name">'+f.label+'</div><div class="lf-desc">'+f.desc+'</div></div>'+
        '<div class="lf-right">'+
          '<div class="lf-amount">KSH '+Math.round(pp).toLocaleString('en-KE')+'</div>'+
          '<div class="lf-per">/'+f.per+' (est.)</div>'+
        '</div>'+
      '</div>';
  });
  return html+'</div>';
}
function selFreq(id, i) {
  lipaFreq = lipaFreqOpts[i];
  document.querySelectorAll('.lipa-freq').forEach(function(el){ el.classList.remove('sel'); });
  var el = document.getElementById('lf-'+id);
  if (el) el.classList.add('sel');
  var raw = parseFloat(String(currentItem.price||'').replace(/[^0-9.]/g,''))||0;
  lipaDurOpts = calcDurations(raw, lipaFreq);
  buildDurGrid();
}
function buildDurGrid() {
  var grid = document.getElementById('lipaDurGrid');
  if (!grid) return;
  lipaDur = null;
  grid.innerHTML = lipaDurOpts.map(function(d,i){
    return '<div class="lipa-dur" id="ld-'+i+'" onclick="selDur('+i+')">'+
      '<div class="ld-weeks">'+d.weeks+'</div>'+
      '<div class="ld-label">weeks</div>'+
      '<div class="ld-per">'+d.perPayStr+'</div>'+
      '<div class="ld-total">Total: '+d.totalStr+'</div>'+
    '</div>';
  }).join('');
  var s = document.getElementById('lipaSummary');
  if (s) s.style.display='none';
}
function selDur(i) {
  lipaDur = lipaDurOpts[i];
  document.querySelectorAll('.lipa-dur').forEach(function(el){ el.classList.remove('sel'); });
  var el = document.getElementById('ld-'+i);
  if (el) el.classList.add('sel');
  var s = document.getElementById('lipaSummary');
  if (s) {
    s.style.display='block';
    s.innerHTML =
      '<div class="ls-row"><span class="lbl">Frequency</span><span class="val">'+lipaFreq.label+'</span></div>'+
      '<div class="ls-row"><span class="lbl">Duration</span><span class="val">'+lipaDur.label+'</span></div>'+
      '<div class="ls-row"><span class="lbl">Per payment</span><span class="val hi">'+lipaDur.perPayStr+'</span></div>'+
      '<div class="ls-row"><span class="lbl">First deposit</span><span class="val">'+lipaDur.deposit+'</span></div>'+
      '<div class="ls-row"><span class="lbl">Grand total</span><span class="val">'+lipaDur.totalStr+'</span></div>';
  }
}
function lipaNext(step) {
  if (step===1) {
    if (!lipaFreq) { showToast('Select a payment frequency'); return; }
    if (!lipaDurOpts.length) {
      var raw = parseFloat(String(currentItem.price||'').replace(/[^0-9.]/g,''))||0;
      lipaDurOpts = calcDurations(raw, lipaFreq); buildDurGrid();
    }
  }
  if (step===2 && !lipaDur) { showToast('Select a duration'); return; }
  setLipaStep(step+1);
}
function lipaBack(step){ setLipaStep(step-1); }
function setLipaStep(s) {
  [1,2,3].forEach(function(n){
    var p=document.getElementById('lp'+n);
    if (p) p.className='lipa-panel'+(n===s?' active':'');
    var dot=document.getElementById('lsd'+n),lbl=document.getElementById('lsl'+n),ln=document.getElementById('lsl'+n+'l');
    if (!dot) return;
    if (n<s){ dot.className='ls-dot done';dot.innerHTML='&#x2713;';lbl.className='ls-lbl done';if(ln)ln.className='ls-line done'; }
    else if(n===s){ dot.className='ls-dot active';dot.innerHTML=n;lbl.className='ls-lbl active'; }
    else{ dot.className='ls-dot';dot.innerHTML=n;lbl.className='ls-lbl';if(ln)ln.className='ls-line'; }
  });
}
function setLipaPay(mode, el) {
  lipaPayMode = mode;
  ['lpo_mpesa','lpo_cash'].forEach(function(id){ var e=document.getElementById(id);if(e)e.classList.remove('sel'); });
  el.classList.add('sel');
}
function submitLipa() {
  if (!lipaFreq||!lipaDur) { showToast('Complete all steps first'); return; }
  var name  = (document.getElementById('lp_name').value||'').trim();
  var phone = (document.getElementById('lp_phone').value||'').trim();
  var addr  = (document.getElementById('lp_addr').value||'').trim();
  if (!name)  { showToast('Enter your full name'); return; }
  if (!phone||phone.replace(/\D/g,'').length<9) { showToast('Enter a valid phone number'); return; }
  if (!addr)  { showToast('Enter your delivery address'); return; }
  var btn = document.getElementById('lipaSubmitBtn');
  if (btn) { btn.disabled=true; btn.textContent='Sending...'; }
  saveMhUser(name,phone,addr);
  var item  = currentItem;
  var waNum = normWA((item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||''));
  var notes = 'LIPA MDOGO MDOGO | Freq:'+lipaFreq.label+' | '+lipaDur.label+' | Per:'+lipaDur.perPayStr+' | Deposit:'+lipaDur.deposit+' | Total:'+lipaDur.totalStr+' | Pay:'+lipaPayMode+' | DELIVER AFTER FULL PAYMENT ONLY';
  postOrder({
    category:'items',listing_id:item.id||'',
    listing_title:item.title||'',listing_price:item.price||'',
    name:name,phone:phone,address:addr,
    payment_method:lipaPayMode,total_amount:String(lipaDur.total||'0'),notes:notes,
  }, function(d) {
    var ref = d&&d.order_ref?d.order_ref:'';
    var msg = encodeURIComponent('Hi! Lipa Mdogo Mdogo:\n*'+item.title+'*\nFreq: '+lipaFreq.label+'\nDuration: '+lipaDur.label+'\nPer payment: '+lipaDur.perPayStr+'\nDeposit: '+lipaDur.deposit+'\nTotal: '+lipaDur.totalStr+'\nRef: '+(ref||'—')+'\nName: '+name+'\nPhone: '+phone+'\nAddress: '+addr+'\n\n⚠️ Delivered ONLY after all payments received.');
    showSuccess('Request Sent!','Your '+lipaFreq.label+' plan over '+lipaDur.label+' is confirmed. We\'ll call to confirm schedule.',ref,
      function(){ window.open('https://wa.me/'+waNum+'?text='+msg,'_blank'); });
  }, function() {
    if (btn) { btn.disabled=false; btn.textContent='&#x1F4B0; Submit Plan Request'; }
    showToast('Network error. Please try again.');
  });
}

/* ═══════════════════════════════════════════════════════
   CART
═══════════════════════════════════════════════════════ */
/* ═══════════════════════════════════════════════════════
   PROGRESSIVE CHECKOUT — 3 steps: Cart → Details → Payment
═══════════════════════════════════════════════════════ */
var coStep    = 1;  /* current step */
var coPayMode = 'cash';

/* Entry points */
function openCart()     { openCheckout(); }
function openCheckout() {
  var n = cart.reduce(function(s,c){ return s+c.qty; }, 0);
  if (!n) { showToast('Your cart is empty'); return; }
  coStep = 1; coPayMode = 'cash';
  buildCheckoutSheet();
  openSheet();
  prefillSaved();
}

/* ── Step stepper helper ── */
function setCoStep(s) {
  coStep = s;
  [1,2,3].forEach(function(n) {
    var dot = document.getElementById('cod'+n);
    var lbl = document.getElementById('col'+n);
    var ln  = document.getElementById('coline'+n);
    if (!dot) return;
    if (n < s) {
      dot.className='co-dot done'; dot.innerHTML='&#x2713;';
      if (lbl) lbl.className='co-lbl done';
      if (ln)  ln.className='co-line done';
    } else if (n === s) {
      dot.className='co-dot active'; dot.innerHTML=n;
      if (lbl) lbl.className='co-lbl active';
    } else {
      dot.className='co-dot'; dot.innerHTML=n;
      if (lbl) lbl.className='co-lbl';
      if (ln)  ln.className='co-line';
    }
    var panel = document.getElementById('cop'+n);
    if (panel) panel.className = 'co-panel' + (n === s ? ' active' : '');
  });
}

/* ── Render the whole sheet (steps header + all 3 panels) ── */
function buildCheckoutSheet() {
  var total = cart.reduce(function(s,c){ return s+px(c.price)*c.qty; }, 0);
  var dlv   = total >= 2000 ? 0 : 100;
  var grand = total + dlv;
  window._coGrand = grand;

  /* Step 1 — Cart items */
  var itemsHTML = cart.map(function(c) {
    var rawImg = c.image || '';
    var imgHTML = rawImg
      ? '<img class="co-item-img" src="'+esc(rawImg)+'" loading="lazy" width="46" height="46"' +
        ' onerror="this.style.display=\'none\'">'
      : '<div class="co-item-img" style="background:var(--surface);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;">&#x1F4E6;</div>';
    return (
      '<div class="co-item" id="coi-'+esc(c.id)+'">' +
        imgHTML +
        '<div class="co-item-info">' +
          '<div class="co-item-title">'+esc(c.title)+'</div>' +
          '<div class="co-item-shop">'+esc((c.shop||'').split(',')[0])+'</div>' +
          '<div class="co-item-qty">' +
            '<button class="qty-btn" onclick="coQty(\''+esc(c.id)+'\',-1)">&#x2212;</button>' +
            '<span class="qty-val" id="cqv-'+esc(c.id)+'">'+c.qty+'</span>' +
            '<button class="qty-btn" onclick="coQty(\''+esc(c.id)+'\',1)">+</button>' +
          '</div>' +
        '</div>' +
        '<div class="co-item-price" id="cip-'+esc(c.id)+'">KSH '+(px(c.price)*c.qty).toLocaleString('en-KE')+'</div>' +
        '<button class="co-item-del" onclick="coQty(\''+esc(c.id)+'\',0)" title="Remove">&#x2715;</button>' +
      '</div>'
    );
  }).join('');

  var summaryHTML =
    '<div class="co-summary">'+
      '<div class="co-sum-row"><span>Subtotal</span><span>KSH '+total.toLocaleString('en-KE')+'</span></div>'+
      '<div class="co-sum-row"><span>Delivery</span><span>'+
        (dlv === 0 ? '<span class="free">FREE &#x1F389;</span>' : 'KSH '+dlv)+
      '</span></div>'+
      '<div class="co-sum-row tot"><span>Total on Delivery</span><span>KSH '+grand.toLocaleString('en-KE')+'</span></div>'+
    '</div>';

  /* Step 2 — Details */
  var detailsHTML =
    '<div style="font-size:13px;color:var(--muted);margin-bottom:14px;">Where should we deliver your '+
      cart.length+' item'+(cart.length!==1?'s':'')+' to?</div>'+
    '<div class="row2">'+
      '<div class="field"><label>Full Name *</label>'+
      '<input type="text" id="co_name" placeholder="Your name" autocomplete="name"></div>'+
      '<div class="field"><label>Phone *</label>'+
      '<input type="tel" id="co_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>'+
    '</div>'+
    '<div class="field"><label>Delivery Address *</label>'+
    '<input type="text" id="co_addr" placeholder="e.g. Near Malaba Market, Malaba Town"></div>'+
    '<div class="field"><label>Note to Seller (optional)</label>'+
    '<input type="text" id="co_note" placeholder="e.g. Call before delivery"></div>';

  /* Step 3 — Payment */
  var payHTML =
    '<div class="co-summary" style="margin-bottom:14px;">'+
      '<div class="co-sum-row tot"><span>Total to pay on delivery</span><span>KSH '+grand.toLocaleString('en-KE')+'</span></div>'+
    '</div>'+
    '<div style="font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:9px;">Payment Method</div>'+
    '<div class="pay-opts" id="coPayOpts">'+
      '<div class="po sel" id="copo_cash" onclick="setCoPayMode(\'cash\',this)">'+
        '<div class="po-ico">&#x1F4B5;</div>'+
        '<div class="po-txt"><strong>Cash on Delivery</strong><span>Pay cash when item arrives</span></div>'+
        '<div class="po-dot"></div>'+
      '</div>'+
      '<div class="po" id="copo_mpesa" onclick="setCoPayMode(\'mpesa\',this)">'+
        '<div class="po-ico">&#x1F4F1;</div>'+
        '<div class="po-txt"><strong>M-Pesa on Delivery</strong><span>Send M-Pesa when delivered</span></div>'+
        '<div class="po-dot"></div>'+
      '</div>'+
    '</div>'+
    '<div style="font-size:11px;color:var(--muted);padding:8px 0 4px;line-height:1.6;">'+
      '&#x26A1; Fast delivery within Malaba & Busia. We\'ll call to confirm your order.'+
    '</div>';

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div>'+
    '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>'+

    /* Step indicator */
    '<div class="co-steps">'+
      '<div class="co-step">'+
        '<div class="co-dot active" id="cod1">1</div>'+
        '<div class="co-lbl active" id="col1">Cart</div>'+
      '</div>'+
      '<div class="co-line" id="coline1"></div>'+
      '<div class="co-step">'+
        '<div class="co-dot" id="cod2">2</div>'+
        '<div class="co-lbl" id="col2">Details</div>'+
      '</div>'+
      '<div class="co-line" id="coline2"></div>'+
      '<div class="co-step" style="flex:0;">'+
        '<div class="co-dot" id="cod3">3</div>'+
        '<div class="co-lbl" id="col3">Payment</div>'+
      '</div>'+
    '</div>'+

    /* Panel 1 — Cart */
    '<div class="co-panel active" id="cop1" style="overflow-y:auto;max-height:58dvh;">'+
      '<div style="padding:12px 16px 0;">'+
        itemsHTML +
        summaryHTML +
        '<div class="co-nav">'+
          '<button class="co-next" onclick="coNext(1)">Continue to Details &#x203A;</button>'+
        '</div>'+
      '</div>'+
    '</div>'+

    /* Panel 2 — Details */
    '<div class="co-panel" id="cop2">'+
      '<div style="padding:12px 16px 0;">'+
        detailsHTML +
        '<div class="co-nav">'+
          '<button class="co-back" onclick="setCoStep(1)">&#x2190; Cart</button>'+
          '<button class="co-next" onclick="coNext(2)">Review Payment &#x203A;</button>'+
        '</div>'+
      '</div>'+
    '</div>'+

    /* Panel 3 — Payment */
    '<div class="co-panel" id="cop3">'+
      '<div style="padding:12px 16px 0;">'+
        payHTML +
        '<div class="co-nav">'+
          '<button class="co-back" onclick="setCoStep(2)">&#x2190; Details</button>'+
          '<button class="co-next" id="coPlaceBtn" onclick="submitCheckout()">&#x2705; Place Order — KSH '+grand.toLocaleString('en-KE')+'</button>'+
        '</div>'+
      '</div>'+
    '</div>';

  /* Lazy-load cart item images */
  document.querySelectorAll('.co-item-img').forEach(function(img) {
    if (!img.src) return;
    if (img.complete && img.naturalWidth > 0) { img.classList.add('img-loaded'); return; }
    img.addEventListener('load',  function(){ img.classList.add('img-loaded'); },{once:true});
    img.addEventListener('error', function(){ img.style.display='none'; },{once:true});
  });
}

function coNext(step) {
  if (step === 1) {
    /* Validate cart still has items */
    var n = cart.reduce(function(s,c){ return s+c.qty; }, 0);
    if (!n) { closeOverlay(); showToast('Your cart is empty'); return; }
    setCoStep(2);
    prefillSaved();
  } else if (step === 2) {
    /* Validate details */
    var name  = (document.getElementById('co_name').value||'').trim();
    var phone = (document.getElementById('co_phone').value||'').trim();
    var addr  = (document.getElementById('co_addr').value||'').trim();
    if (!name)  { showToast('Enter your full name'); document.getElementById('co_name').focus(); return; }
    if (!phone || phone.replace(/\D/g,'').length < 9) { showToast('Enter a valid phone number'); document.getElementById('co_phone').focus(); return; }
    if (!addr)  { showToast('Enter your delivery address'); document.getElementById('co_addr').focus(); return; }
    setCoStep(3);
  }
}

function setCoPayMode(mode, el) {
  coPayMode = mode;
  ['copo_cash','copo_mpesa'].forEach(function(id){
    var e = document.getElementById(id); if (e) e.classList.remove('sel');
  });
  if (el) el.classList.add('sel');
}

function coQty(id, d) {
  var ex = cart.find(function(c){ return c.id===id; });
  if (!ex) return;
  if (d === 0) {
    cart = cart.filter(function(c){ return c.id !== id; });
  } else {
    ex.qty = Math.max(0, ex.qty + d);
    if (!ex.qty) cart = cart.filter(function(c){ return c.id !== id; });
  }
  saveCart(); renderBadges();
  /* Sync card button state */
  var btn = document.getElementById('btn-'+id);
  if (btn) { btn.innerHTML='+ Cart'; btn.classList.remove('added'); }
  if (!cart.length) { closeOverlay(); return; }
  /* Rebuild sheet in-place staying on step 1 */
  buildCheckoutSheet();
  prefillSaved();
}

/* backward-compat alias */
function cartQty(id, d) { coQty(id, d); }
function setCartPay(mode, el) { setCoPayMode(mode, el); }

function submitCheckout() {
  var name  = (document.getElementById('co_name').value||'').trim();
  var phone = (document.getElementById('co_phone').value||'').trim();
  var addr  = (document.getElementById('co_addr').value||'').trim();
  var note  = (document.getElementById('co_note') ? document.getElementById('co_note').value : '') || '';
  if (!name || !phone || !addr) { setCoStep(2); showToast('Please complete your details'); return; }

  var btn = document.getElementById('coPlaceBtn');
  if (btn) { btn.disabled=true; btn.textContent='Placing order...'; }
  saveMhUser(name, phone, addr);

  var grand = window._coGrand || 0;
  var items = cart.map(function(c){ return c.title; }).join(', ');
  var waNum = normWA(cart[0] && cart[0].phone ? cart[0].phone : '');
  var snap  = cart.slice();

  postOrder({
    category:'items',
    listing_id: snap[0] && snap[0].id ? snap[0].id : '',
    name:name, phone:phone, address:addr,
    payment_method: coPayMode==='mpesa' ? 'mpesa_on_delivery' : 'cash_on_delivery',
    total_amount: String(grand),
    notes: 'Cart: '+items+(note?' | Note: '+note:'')+' | '+coPayMode,
    cart_items: snap.map(function(c){ return {id:c.id,title:c.title,price:c.price,qty:c.qty}; }),
  }, function(d) {
    var ref = d && d.order_ref ? d.order_ref : '';
    var msg = encodeURIComponent(
      '🛒 *Order from '+name+'*\n'+
      'Phone: '+phone+'\n'+
      'Address: '+addr+'\n'+
      (note?'Note: '+note+'\n':'')+
      'Items: '+items+'\n'+
      'Total: KSH '+grand.toLocaleString('en-KE')+'\n'+
      'Payment: '+(coPayMode==='mpesa'?'M-Pesa on delivery':'Cash on delivery')+'\n'+
      'Ref: '+(ref||'—')
    );
    /* Reset card buttons */
    snap.forEach(function(c) {
      var b = document.getElementById('btn-'+c.id);
      if (b) { b.innerHTML='+ Cart'; b.classList.remove('added'); }
    });
    cart = []; saveCart(); renderBadges();
    showSuccess(
      'Order Placed! &#x2705;',
      (coPayMode==='cash'
        ? 'Pay KSH '+grand.toLocaleString('en-KE')+' cash when your items arrive.'
        : 'Send M-Pesa when your items are delivered.'),
      ref,
      function(){ window.open('https://wa.me/'+waNum+'?text='+msg, '_blank'); }
    );
  }, function() {
    if (btn) { btn.disabled=false; btn.textContent='&#x2705; Place Order — KSH '+grand.toLocaleString('en-KE'); }
    showToast('Network error — please try again');
  });
}


/* ═══════════════════════════════════════════════════════
   CATEGORY BROWSER SHEET
   Opens when user taps the grid icon in the header.
   Shows all real subcategories from the API as visual
   tiles, plus sort options, with a live filter search.
═══════════════════════════════════════════════════════ */

/* Cached subcategory list for the browser (populated by loadSubcategories) */
var _cbSubs = [];   /* [{slug, label, count}, ...] */
var _cbPendingSort = null; /* sort selection before Apply is tapped */

/* Called from loadSubcategories so the browser always has fresh data */
function _storeCbSubs(subs) {
  _cbSubs = subs || [];
}

function openCategoryBrowser() {
  /* If we have no subs cached yet, fetch then open */
  if (!_cbSubs.length) {
    _fetchAndOpenBrowser();
    return;
  }
  _buildAndOpenBrowser(_cbSubs);
}

function _fetchAndOpenBrowser() {
  /* Show a quick loading state in the sheet while fetching */
  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div>' +
    '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<div style="display:flex;align-items:center;justify-content:center;padding:48px;">' +
      '<div style="width:28px;height:28px;border-radius:50%;border:3px solid var(--border2);border-top-color:var(--amber);animation:spin .65s linear infinite;"></div>' +
    '</div>';
  openSheet();

  var xhr = new XMLHttpRequest();
  xhr.open('GET', API_BASE + '/subcategories.php?type=items', true);
  xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
  xhr.timeout = 8000;
  xhr.onload = function() {
    try {
      var d = JSON.parse(xhr.responseText);
      if (d && d.success && d.data && d.data.length) {
        _cbSubs = d.data;
        _buildAndOpenBrowser(_cbSubs);
        return;
      }
    } catch(e) {}
    _buildAndOpenBrowser([]);
  };
  xhr.onerror = xhr.ontimeout = function() { _buildAndOpenBrowser([]); };
  xhr.send();
}

function _buildAndOpenBrowser(subs) {
  _cbPendingSort = ST.sort; /* pre-select current sort */

  var totalItems = 0;
  subs.forEach(function(s){ totalItems += (parseInt(s.count)||0); });

  var sorts = [
    {v:'smart',   l:'✨ Smart'},
    {v:'popular', l:'🔥 Popular'},
    {v:'newest',  l:'🆕 Newest'},
    {v:'price_asc', l:'💰 Low → High'},
    {v:'price_desc',l:'💎 High → Low'},
  ];

  document.getElementById('sheetContent').innerHTML =
    /* ── Header ── */
    '<div class="sh-top"><div class="sh-handle"></div>' +
    '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +

    '<div class="cb-header">' +
      '<div class="cb-title">Browse Categories</div>' +
      '<div class="cb-subtitle">Tap a category to filter · ' + subs.length + ' categories available</div>' +
    '</div>' +

    /* ── Live search inside sheet ── */
    '<div class="cb-search">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">' +
        '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>' +
      '</svg>' +
      '<input type="search" id="cbSearchInput" placeholder="Find a category..." autocomplete="off" oninput="filterCbTiles(this.value)">' +
    '</div>' +

    /* ── All items button ── */
    '<div class="cb-all-btn' + (ST.sub === '' ? ' active-cat' : '') + '" onclick="cbSelectAll()">' +
      '<div class="cb-all-icon">✨</div>' +
      '<div class="cb-all-info">' +
        '<div class="cb-all-name">All Items</div>' +
        '<div class="cb-all-count">' + (totalItems > 0 ? totalItems.toLocaleString() + ' products' : 'Browse everything') + '</div>' +
      '</div>' +
      '<div class="cb-all-check">✓</div>' +
    '</div>' +

    /* ── Category grid ── */
    '<div class="cb-sec-label">Shop by Category</div>' +
    '<div class="cb-grid" id="cbGrid">' + _buildCbTiles(subs) + '</div>' +

    /* ── Sort section ── */
    '<div class="cb-sort-section">' +
      '<div class="cb-sort-label">Sort Results By</div>' +
      '<div class="cb-sort-pills">' +
        sorts.map(function(s) {
          return '<div class="cb-sort-pill' + (ST.sort === s.v ? ' sel' : '') + '"' +
            ' id="cbsp-' + s.v + '" onclick="cbSelectSort(\'' + s.v + '\')">' + s.l + '</div>';
        }).join('') +
      '</div>' +
    '</div>' +

    /* ── Apply button ── */
    '<div class="cb-apply-btn-wrap">' +
      '<button class="cb-apply-btn" id="cbApplyBtn" onclick="cbApply()">' +
        '&#x1F50D; Show Results' +
      '</button>' +
    '</div>';

  openSheet();

  /* Focus search after open animation */
  setTimeout(function() {
    var inp = document.getElementById('cbSearchInput');
    if (inp) inp.focus();
  }, 360);
}

/* Build all category tiles, optionally filtered by a search query */
function _buildCbTiles(subs, filterQ) {
  var q = (filterQ || '').toLowerCase().trim();
  var filtered = q
    ? subs.filter(function(s){ return (s.label || s.slug || '').toLowerCase().indexOf(q) !== -1; })
    : subs;

  if (!filtered.length) {
    return '<div class="cb-empty">No categories match "' + esc(filterQ) + '"</div>';
  }

  return filtered.map(function(s) {
    var slug  = (s.slug || s.name || '').toLowerCase().trim();
    var label = s.label || subLabel(slug);
    var icon  = subIcon(slug);
    var count = parseInt(s.count) || 0;
    var isActive = ST.sub === slug;
    return (
      '<div class="cb-tile' + (isActive ? ' active-cat' : '') + '"' +
        ' id="cbt-' + esc(slug) + '"' +
        ' onclick="cbSelectCat(\'' + esc(slug) + '\')">' +
        '<div class="cb-tile-check">✓</div>' +
        '<div class="cb-tile-icon">' + icon + '</div>' +
        '<div class="cb-tile-label">' + esc(label) + '</div>' +
        (count > 0 ? '<div class="cb-tile-count">' + count + '</div>' : '') +
      '</div>'
    );
  }).join('');
}

/* Live-filter tiles as user types in the sheet search box */
function filterCbTiles(q) {
  var grid = document.getElementById('cbGrid');
  if (!grid) return;
  grid.innerHTML = _buildCbTiles(_cbSubs, q);
}

/* Select a subcategory tile (toggle selection) */
function cbSelectCat(slug) {
  /* Deselect "All" */
  var allBtn = document.querySelector('.cb-all-btn');
  if (allBtn) allBtn.classList.remove('active-cat');

  /* If tapping the already-active tile, deselect it (go back to All) */
  if (ST.sub === slug) {
    ST.sub = '';
    if (allBtn) allBtn.classList.add('active-cat');
    document.querySelectorAll('.cb-tile').forEach(function(t){ t.classList.remove('active-cat'); });
    _updateCbApplyBtn();
    return;
  }

  /* Mark new selection */
  ST.sub = slug;
  document.querySelectorAll('.cb-tile').forEach(function(t){
    t.classList.toggle('active-cat', t.id === 'cbt-' + slug);
  });
  _updateCbApplyBtn();
}

/* Select "All Items" */
function cbSelectAll() {
  ST.sub = '';
  document.querySelectorAll('.cb-tile').forEach(function(t){ t.classList.remove('active-cat'); });
  var allBtn = document.querySelector('.cb-all-btn');
  if (allBtn) allBtn.classList.add('active-cat');
  _updateCbApplyBtn();
}

/* Select a sort pill */
function cbSelectSort(v) {
  _cbPendingSort = v;
  document.querySelectorAll('.cb-sort-pill').forEach(function(p){ p.classList.remove('sel'); });
  var pill = document.getElementById('cbsp-' + v);
  if (pill) pill.classList.add('sel');
  _updateCbApplyBtn();
}

/* Update the apply button label to reflect current selection */
function _updateCbApplyBtn() {
  var btn = document.getElementById('cbApplyBtn');
  if (!btn) return;
  var label = ST.sub ? subLabel(ST.sub) : 'All Items';
  btn.innerHTML = '🔍 Show ' + esc(label) + ' Results';
}

/* Apply — close sheet, update grid */
function cbApply() {
  /* Apply pending sort if changed */
  if (_cbPendingSort && _cbPendingSort !== ST.sort) {
    ST.sort = _cbPendingSort;
    var sl = document.getElementById('sortLbl');
    if (sl) sl.textContent = ST.sort.charAt(0).toUpperCase() + ST.sort.slice(1).replace(/_/g,' ');
  }

  closeOverlay();

  /* Update header chips to reflect selection */
  document.querySelectorAll('.cat-tab').forEach(function(c){
    c.classList.toggle('on', c.dataset.sub === ST.sub);
  });

  /* Update grid title */
  var gt = document.getElementById('gridTitle');
  if (gt) gt.textContent = ST.sub ? subLabel(ST.sub) : 'For You';

  loadItems(true);

  /* Scroll grid into view */
  setTimeout(function() {
    var grid = document.getElementById('shopGrid');
    if (grid) grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, 120);
}

/* Keep backward compat — openSortSheet now opens the category browser */
function openSortSheet() { openCategoryBrowser(); }

function applySort(v){
  ST.sort = v;
  _cbPendingSort = v;
  var el = document.getElementById('sortLbl');
  if (el) el.textContent = v.charAt(0).toUpperCase() + v.slice(1).replace(/_/g,' ');
  closeOverlay();
  loadItems(true);
}

/* ═══════════════════════════════════════════════════════
   SUCCESS
═══════════════════════════════════════════════════════ */
function showSuccess(title, sub, ref, waFn){
  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div><button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>'+
    '<div class="suc-wrap">'+
      '<div class="suc-ico">'+(title.indexOf('Request')!==-1?'&#x1F389;':'&#x2705;')+'</div>'+
      '<div class="suc-title">'+esc(title)+'</div>'+
      '<div class="suc-sub">'+esc(sub)+'</div>'+
      (ref?'<div class="suc-ref">Ref: '+esc(ref)+'</div>':'')+
      '<button class="wa-btn" id="sucWaBtn">&#x1F4AC; Confirm on WhatsApp</button>'+
      '<button class="done-btn" onclick="closeOverlay()">Continue Shopping</button>'+
    '</div>';
  var wb=document.getElementById('sucWaBtn');
  if(wb) wb.onclick=waFn;
}

/* ═══════════════════════════════════════════════════════
   CATS + FILTERS + INFINITE SCROLL
   Subcategories are fetched from /api/subcategories.php
   so they always reflect what is actually in the DB.
═══════════════════════════════════════════════════════ */

/* Icon + friendly-label map — keys are the DB slug values.
   Unknown slugs get a fallback icon and title-cased label. */
var SUB_META = {
  kitchen:    { icon: '🍳', label: 'Kitchen' },
  decor:      { icon: '🖼',  label: 'Décor' },
  appliances: { icon: '⚡',  label: 'Appliances' },
  storage:    { icon: '🧺',  label: 'Storage' },
  furniture:  { icon: '🛋',  label: 'Furniture' },
  cleaning:   { icon: '🧹',  label: 'Cleaning' },
  lighting:   { icon: '💡',  label: 'Lighting' },
  bedding:    { icon: '🛏',  label: 'Bedding' },
  bathroom:   { icon: '🚿',  label: 'Bathroom' },
  garden:     { icon: '🌱',  label: 'Garden' },
  electronics:{ icon: '📱',  label: 'Electronics' },
  toys:       { icon: '🧸',  label: 'Toys' },
  fashion:    { icon: '👗',  label: 'Fashion' },
  beauty:     { icon: '💄',  label: 'Beauty' },
  sports:     { icon: '⚽',  label: 'Sports' },
  tools:      { icon: '🔧',  label: 'Tools' },
  stationery: { icon: '📚',  label: 'Stationery' },
  health:     { icon: '💊',  label: 'Health' },
  baby:       { icon: '👶',  label: 'Baby & Kids' },
  food:       { icon: '🥗',  label: 'Food & Snacks' },
};

function subIcon(slug)  { return (SUB_META[slug] && SUB_META[slug].icon)  || '🛍'; }
function subLabel(slug) { return (SUB_META[slug] && SUB_META[slug].label) || (slug.charAt(0).toUpperCase() + slug.slice(1)); }

function loadSubcategories() {
  var xhr = new XMLHttpRequest();
  xhr.open('GET', API_BASE + '/subcategories.php?type=items', true);
  xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
  xhr.timeout = 8000;
  xhr.onload = function() {
    try {
      var d = JSON.parse(xhr.responseText);
      if (d && d.success && d.data && d.data.length) {
        renderCatTabs(d.data);
        return;
      }
    } catch(e) {}
    /* Fallback: render a minimal set from local knowledge so UI never looks broken */
    renderCatTabsFallback();
  };
  xhr.onerror = xhr.ontimeout = function() { renderCatTabsFallback(); };
  xhr.send();
}

function renderCatTabs(subs) {
  /* subs = [{slug, label, count}, ...] already sorted by item count DESC */
  /* Cache for the category browser sheet */
  _storeCbSubs(subs);

  var strip = document.getElementById('catsRow');
  if (!strip) return;

  /* Keep the "All" chip that was already there, then append the real subcategories */
  var html = '<button class="cat-tab on" data-sub="">✨ All</button>';
  subs.forEach(function(s) {
    var slug  = (s.slug  || s.name || '').toLowerCase().trim();
    var label = s.label  || subLabel(slug);
    var icon  = subIcon(slug);
    var count = s.count  || '';
    if (!slug) return;
    html += '<button class="cat-tab" data-sub="' + esc(slug) + '">' +
              icon + ' ' + esc(label) +
              (count ? ' <span style="font-size:9px;opacity:.6;">(' + count + ')</span>' : '') +
            '</button>';
  });

  strip.innerHTML = html;
  bindCatTabEvents();
  /* Re-measure header height because the chips may have wrapped */
  if (typeof setPageOffset === 'function') setTimeout(setPageOffset, 60);
}

function renderCatTabsFallback() {
  /* Use the same SUB_META keys as a static fallback so the bar is never empty */
  var fallbackOrder = ['kitchen','decor','appliances','storage','furniture','cleaning','lighting','fashion','electronics','beauty','sports','health','baby'];
  renderCatTabs(fallbackOrder.map(function(slug){
    return { slug: slug, label: subLabel(slug), count: 0 };
  }));
}

function bindCatTabEvents() {
  document.querySelectorAll('.cat-tab').forEach(function(c) {
    c.addEventListener('click', function() {
      var sub = c.dataset.sub;
      document.querySelectorAll('.cat-tab').forEach(function(x){ x.classList.remove('on'); });
      c.classList.add('on');

      if (sub) {
        /* Has a subcategory — filter the grid in-place (no page nav) */
        ST.sub = sub;
        var el = document.getElementById('gridTitle');
        if (el) el.textContent = subLabel(sub);
        loadItems(true);
        /* Scroll grid into view */
        var grid = document.getElementById('shopGrid');
        if (grid) grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
      } else {
        /* "All" tab — show everything */
        ST.sub = '';
        var el = document.getElementById('gridTitle');
        if (el) el.textContent = 'For You';
        loadItems(true);
      }
    });
  });
}

function initCats() {
  /* Bind the default "All" chip immediately so it works before subcategories load */
  bindCatTabEvents();
  /* Then fetch real subcategories from the backend */
  loadSubcategories();
}
function initInfiniteScroll(){
  var obs=new IntersectionObserver(function(entries){
    if(entries[0].isIntersecting&&!ST.done&&!ST.loading) loadItems(false);
  },{rootMargin:'300px'});
  obs.observe(document.getElementById('loadWrap'));
}

/* ═══════════════════════════════════════════════════════
   WISHLIST
═══════════════════════════════════════════════════════ */
function toggleWish(ev,id,btn){
  ev.stopPropagation();
  var i=wishlist.indexOf(id);
  if(i!==-1){ wishlist.splice(i,1);btn.innerHTML='&#x2661;';btn.classList.remove('liked');showToast('Removed from saved'); }
  else      { wishlist.unshift(id);btn.innerHTML='&#x2665;';btn.classList.add('liked');   showToast('&#x2665; Saved!'); }
  localStorage.setItem('mh_shop_wish',JSON.stringify(wishlist));
}

/* ═══════════════════════════════════════════════════════
   OVERLAY / SHEET HELPERS
═══════════════════════════════════════════════════════ */
function openSheet(){document.getElementById('overlay').classList.add('open');document.body.style.overflow='hidden';}
function closeOverlay(){document.getElementById('overlay').classList.remove('open');document.body.style.overflow='';}
function handleOvClick(e){if(e.target===e.currentTarget)closeOverlay();}

/* ═══════════════════════════════════════════════════════
   API + PERSISTENCE
═══════════════════════════════════════════════════════ */
function postOrder(data,onOk,onErr){
  var xhr=new XMLHttpRequest();
  xhr.open('POST',API_BASE+'/order.php',true);
  xhr.setRequestHeader('Content-Type','application/json');
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout=12000;
  xhr.onload=function(){try{var d=JSON.parse(xhr.responseText);if(typeof onOk==='function')onOk(d);}catch(e){if(typeof onOk==='function')onOk({});}};
  xhr.onerror=xhr.ontimeout=function(){if(typeof onErr==='function')onErr();};
  xhr.send(JSON.stringify(data));
}
function saveCart(){localStorage.setItem('mh_shop_cart',JSON.stringify(cart));}
function renderBadges() {
  var n     = cart.reduce(function(s,c){ return s+c.qty; }, 0);
  var total = cart.reduce(function(s,c){ return s+px(c.price)*c.qty; }, 0);
  var dlv   = total >= 2000 ? 0 : 100;
  var grand = total + dlv;

  /* Header badge */
  var el = document.getElementById('hBadge');
  if (el) { el.textContent = n; el.classList.toggle('on', n > 0); }

  /* Checkout float bar */
  var bar   = document.getElementById('checkoutBar');
  var items = document.getElementById('chkItems');
  var tot   = document.getElementById('chkTotal');
  var cnt   = document.getElementById('chkCount');
  if (bar) {
    bar.classList.toggle('show', n > 0);
    if (items) items.textContent = n + ' item' + (n !== 1 ? 's' : '') +
      (dlv === 0 ? ' · Free delivery' : ' · +KSH 100 delivery');
    if (tot)   tot.textContent   = 'KSH ' + grand.toLocaleString('en-KE');
    if (cnt)   cnt.textContent   = n;
  }
}
function saveMhUser(name,phone,addr){
  try{
    if(window.MhUser)MhUser.saveDetails({name:name,phone:phone,address:addr});
    else localStorage.setItem('mh_user_details',JSON.stringify({name:name,phone:phone,address:addr}));
  }catch(e){}
}
function prefillSaved(){
  var d=null;
  try{if(window.MhUser)d=MhUser.getDetails();else d=JSON.parse(localStorage.getItem('mh_user_details')||'null');}catch(e){}
  if(!d)return;
  /* All field IDs across every sheet form */
  var map={
    co_name:'name', co_phone:'phone', co_addr:'address',
    do_name:'name', do_phone:'phone', do_addr:'address',
    lp_name:'name', lp_phone:'phone', lp_addr:'address',
    cart_name:'name', cart_phone:'phone', cart_addr:'address'
  };
  Object.keys(map).forEach(function(fid){
    var el=document.getElementById(fid);
    if(el && d[map[fid]] && !el.value) el.value=d[map[fid]];
  });
}

/* ═══════════════════════════════════════════════════════
   UTILS
═══════════════════════════════════════════════════════ */
function px(str){var n=parseInt(String(str||'').replace(/[^0-9]/g,''));return isNaN(n)?0:n;}
function normWA(p){var d=(p||'').replace(/\D/g,'');if(d.length===9)return'254'+d;if(d.length===10&&d[0]==='0')return'254'+d.substring(1);if(d.length===12&&d.substring(0,3)==='254')return d;return d||'254700000000';}
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function showSpin(on){var el=document.getElementById('loadSpin');if(el)el.style.display=on?'block':'none';}
function showToast(msg){var t=document.getElementById('toast');t.innerHTML=msg;t.classList.add('show');setTimeout(function(){t.classList.remove('show');},2400);}
</script>
</body>
</html>