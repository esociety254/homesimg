/**
 *
 * What this does:
 * 1. Applies lazy loading & async decoding to all img tags
 * 2. Wraps bare images in aspect-ratio boxes to prevent layout shift
 * 3. Throttles card animation so only 8 animate at a time
 * 4. Smooth fade-in on image load
 *
 * NOTE: CDN re-optimisation has been intentionally removed.
 * img_perf.js already serves the correct high-quality URLs.
 * Re-applying cdnImg() here was downgrading quality back to q=75.
 */
(function() {
  'use strict';

  /* ── Fix every img tag on the page ─────────────────────── */
  function patchAllImages() {
    var imgs = document.querySelectorAll('img[src]:not([data-patched])');
    imgs.forEach(function(img) {
      img.setAttribute('data-patched', '1');

      // 1. Ensure lazy loading & async decoding
      if (!img.getAttribute('loading')) {
        img.setAttribute('loading', 'lazy');
      }
      if (!img.getAttribute('decoding')) {
        img.setAttribute('decoding', 'async');
      }

      // 2. Smooth fade-in while loading — do NOT touch img.src
      //    (img_perf.js already set the correct high-quality URL)
      if (!img.complete) {
        if (!img.style.opacity) {
          img.style.opacity = '0';
          img.style.transition = 'opacity .45s ease';
        }
        img.addEventListener('load', function() {
          img.style.opacity = '1';
          img.classList.add('img-loaded');
        }, { once: true });
        img.addEventListener('error', function() {
          img.style.opacity = '1';
          // High-quality fallback — do NOT use a low-q URL here
          if (!img.src || img.src.indexOf('unsplash') === -1) {
            img.src = 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=85';
          }
        }, { once: true });
      } else {
        // Already loaded
        img.style.opacity = '1';
        img.classList.add('img-loaded');
      }
    });
  }

  /* ── Prevent layout shift on dynamically added cards ─────── */
  function fixAspectRatios() {
    var selectors = [
      '.fcard-img',
      '.pcard-img',
      '.hcard-carousel',
      '.cat-card-bg',
    ];
    selectors.forEach(function(sel) {
      document.querySelectorAll(sel + ':not([data-ar-fixed])').forEach(function(el) {
        el.setAttribute('data-ar-fixed', '1');
        var cs = window.getComputedStyle(el);
        if (!el.style.aspectRatio && cs.height === 'auto') {
          el.style.overflow = 'hidden';
          el.style.position = 'relative';
        }
      });
    });
  }

  /* ── Throttle card fade-in animations ────────────────────── */
  function throttleAnimations() {
    var animated = document.querySelectorAll('.fcard,.pcard,.hcard,.cat-card');
    var inView = 0;
    animated.forEach(function(card) {
      if (!card.getAttribute('data-anim')) {
        card.setAttribute('data-anim', '1');
        inView++;
        if (inView > 8) {
          card.style.animation = 'none';
          card.style.opacity   = '1';
          card.style.transform = 'none';
        }
      }
    });
  }

  /* ── MutationObserver: patch images as they're added ─────── */
  if ('MutationObserver' in window) {
    var mo = new MutationObserver(function(mutations) {
      var needsPatch = false;
      mutations.forEach(function(m) {
        if (m.addedNodes.length) needsPatch = true;
      });
      if (needsPatch) {
        requestAnimationFrame(function() {
          patchAllImages();
          fixAspectRatios();
          throttleAnimations();
        });
      }
    });
    mo.observe(document.body, { childList: true, subtree: true });
  }

  /* ── Run on initial load ─────────────────────────────────── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      patchAllImages();
      fixAspectRatios();
      throttleAnimations();
    });
  } else {
    patchAllImages();
    fixAspectRatios();
    throttleAnimations();
  }

  /* ── Expose for manual calls after AJAX renders ─────────── */
  window.MhPerfPatch = {
    run: function() {
      patchAllImages();
      fixAspectRatios();
      throttleAnimations();
    }
  };

})();