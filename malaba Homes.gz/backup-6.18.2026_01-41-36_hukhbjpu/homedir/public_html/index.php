<?php
$apiBase = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/api';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1">

<meta name="theme-color" content="#080400">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<!--<meta name="description" content="Malaba Homes — Find homes, order food, shop local. Malaba's #1 marketplace.">-->


<meta name="description" content="Malaba Homes - Find houses for rent, order food & shop local in Malaba & Busia. Lipa Mdogo Mdogo available. Fast delivery.">
<meta name="keywords" content="houses for rent malaba, food delivery malaba, shop malaba, lipa mdogo mdogo malaba, busia homes">
<meta name="geo.region" content="KE-04"> 
<meta name="geo.placename" content="Malaba, Kenya">
<meta name="robots" content="index, follow">


<title>Malaba Homes | Houses for Rent, Food Delivery & Shop in Malaba & Busia</title>

<!-- Open Graph for WhatsApp & Social -->
<meta property="og:title" content="Malaba Homes - Homes, Food & Shop">
<meta property="og:description" content="Best marketplace in Malaba & Busia">
<meta property="og:image" content="https://malabahomes.com/logo.png">
<meta property="og:locale" content="en_KE">

<link rel="sitemap" type="application/xml" href="https://malabahomes.com/sitemap.php">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<?php include 'pwa_head.php'; ?>

  <script src="/firebase-config.js"></script>
  <script src="/push_register.js"></script>
<style>
/* ────────────────────────────────────────
   DESIGN TOKENS
──────────────────────────────────────── */
:root {
  --ink:    #080400;
  --ink2:   #0f0a02;
  --amber:  #E8521A;
  --amber2: #FF7043;
  --gold:   #F5A623;
  --paper:  #F5EFE0;
  --muted:  #7a6f5e;
  --green:  #2D6A4F;
  --red:    #C1440E;
  --blue:   #1B4F9E;
  --purple: #6d28d9;

  --st: env(safe-area-inset-top,0px);
  --sb: env(safe-area-inset-bottom,0px);
  --bnav: 62px;
}

/* ────────────────────────────────────────
   RESET & BASE
──────────────────────────────────────── */
*,*::before,*::after{
  margin:0;padding:0;box-sizing:border-box;
  -webkit-tap-highlight-color:transparent;
}
html{
  scroll-behavior:smooth;
  overflow-x:hidden;
  /* Momentum scrolling on iOS */
  -webkit-overflow-scrolling:touch;
}
body{
  font-family:'Outfit',sans-serif;
  background:var(--ink);
  color:var(--paper);
  -webkit-font-smoothing:antialiased;
  -moz-osx-font-smoothing:grayscale;
  overflow-x:hidden;
  /* Custom smooth scrolling via JS */
  overflow-y:auto;
}
a{color:inherit;text-decoration:none;}
button{cursor:pointer;font-family:inherit;border:none;background:none;}
img{display:block;max-width:100%;}

/* ────────────────────────────────────────
   CUSTOM SCROLLBAR (desktop)
──────────────────────────────────────── */
::-webkit-scrollbar{width:4px;}
::-webkit-scrollbar-track{background:var(--ink);}
::-webkit-scrollbar-thumb{background:rgba(232,82,26,.4);border-radius:2px;}

/* ────────────────────────────────────────
   SPLASH SCREEN
──────────────────────────────────────── */
#splash{
  position:fixed;inset:0;z-index:9999;
  background:var(--ink);
  display:flex;flex-direction:column;
  align-items:center;justify-content:center;
  overflow:hidden;
}
#splash.exit{
  animation:splashExit .8s cubic-bezier(.4,0,.2,1) forwards;
}
@keyframes splashExit{
  0%   {opacity:1;transform:scale(1);}
  60%  {opacity:1;transform:scale(1.04);}
  100% {opacity:0;transform:scale(1.08);pointer-events:none;}
}

/* Animated mesh background */
.sp-mesh{
  position:absolute;inset:0;z-index:0;
  background:
    radial-gradient(ellipse 80% 60% at 50% 120%, rgba(232,82,26,.18) 0%, transparent 70%),
    radial-gradient(ellipse 50% 40% at 20% 20%, rgba(245,166,35,.06) 0%, transparent 60%);
  animation:meshPulse 4s ease-in-out infinite;
}
@keyframes meshPulse{
  0%,100%{opacity:.7;}
  50%    {opacity:1;}
}

/* Grid lines */
.sp-grid{
  position:absolute;inset:0;z-index:0;
  background-image:
    linear-gradient(rgba(255,255,255,.025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,.025) 1px, transparent 1px);
  background-size:40px 40px;
  mask-image:radial-gradient(ellipse 80% 80% at 50% 50%, black 30%, transparent 100%);
}

/* Orbiting rings */
.sp-rings{position:absolute;inset:0;z-index:0;pointer-events:none;}
.sp-ring{
  position:absolute;border-radius:50%;border:1px solid rgba(232,82,26,.1);
  top:50%;left:50%;
  transform:translate(-50%,-50%) scale(0);
  animation:ringIn 1.8s cubic-bezier(.2,1,.3,1) forwards;
}
.sp-ring:nth-child(1){width:160px;height:160px;animation-delay:.05s;border-color:rgba(232,82,26,.18);}
.sp-ring:nth-child(2){width:280px;height:280px;animation-delay:.18s;}
.sp-ring:nth-child(3){width:420px;height:420px;animation-delay:.32s;}
.sp-ring:nth-child(4){width:580px;height:580px;animation-delay:.48s;border-color:rgba(232,82,26,.05);}
.sp-ring:nth-child(5){width:760px;height:760px;animation-delay:.65s;border-color:rgba(232,82,26,.03);}
@keyframes ringIn{
  from{transform:translate(-50%,-50%) scale(0);opacity:0;}
  to  {transform:translate(-50%,-50%) scale(1);opacity:1;}
}

/* Central glow */
.sp-glow{
  position:absolute;top:50%;left:50%;
  transform:translate(-50%,-54%);
  width:320px;height:320px;border-radius:50%;
  background:radial-gradient(circle,rgba(232,82,26,.22) 0%,transparent 70%);
  animation:glowPulse 3s ease-in-out infinite;
}
@keyframes glowPulse{
  0%,100%{transform:translate(-50%,-54%) scale(1);}
  50%    {transform:translate(-50%,-54%) scale(1.12);}
}

/* Logo */
.sp-logo{
  position:relative;z-index:1;
  display:flex;flex-direction:column;align-items:center;gap:0;
}
.sp-mark{
  width:88px;height:88px;border-radius:28px;
  background:linear-gradient(145deg,#E8521A,#FF7043,#F5A623);
  display:flex;align-items:center;justify-content:center;
  box-shadow:
    0 0 0 14px rgba(232,82,26,.07),
    0 0 0 28px rgba(232,82,26,.03),
    0 24px 64px rgba(232,82,26,.45);
  animation:markIn .9s cubic-bezier(.34,1.56,.64,1) .1s both;
  position:relative;margin-bottom:22px;
}
.sp-mark::before{
  content:'';position:absolute;inset:-2px;border-radius:30px;
  background:linear-gradient(145deg,rgba(255,255,255,.35),transparent 50%);
  pointer-events:none;
}
.sp-mark svg{width:44px;height:44px;color:#fff;filter:drop-shadow(0 2px 8px rgba(0,0,0,.3));}
@keyframes markIn{
  from{transform:scale(0) rotate(-15deg);opacity:0;}
  to  {transform:scale(1) rotate(0deg);opacity:1;}
}

.sp-name{
  font-family:'Bebas Neue',sans-serif;
  font-size:48px;letter-spacing:6px;color:#fff;
  line-height:1;margin-bottom:4px;
  animation:textIn .6s ease .55s both;
}
.sp-name span{color:var(--amber);}

.sp-tagline{
  font-size:11px;font-weight:500;
  color:rgba(255,255,255,.35);
  letter-spacing:4px;text-transform:uppercase;
  animation:textIn .5s ease .72s both;
  margin-bottom:28px;
}
@keyframes textIn{
  from{transform:translateY(16px);opacity:0;}
  to  {transform:translateY(0);opacity:1;}
}

/* Location badge */
.sp-location{
  display:inline-flex;align-items:center;gap:6px;
  background:rgba(255,255,255,.05);
  border:1px solid rgba(255,255,255,.1);
  border-radius:30px;padding:5px 14px;
  font-size:11px;font-weight:600;
  color:rgba(255,255,255,.4);
  animation:textIn .5s ease .88s both;
}
.sp-loc-dot{
  width:7px;height:7px;border-radius:50%;
  background:var(--amber);flex-shrink:0;
  animation:locPulse 2s ease infinite;
}
@keyframes locPulse{
  0%,100%{box-shadow:0 0 0 0 rgba(232,82,26,.5);}
  50%    {box-shadow:0 0 0 6px rgba(232,82,26,0);}
}

/* Progress */
.sp-progress{
  position:absolute;bottom:0;left:0;right:0;height:3px;
  background:rgba(255,255,255,.05);
}
.sp-fill{
  height:100%;width:0%;
  background:linear-gradient(90deg,var(--amber),var(--gold),var(--amber));
  background-size:200% 100%;
  animation:shimmer 1.5s linear infinite;
  transition:width .04s linear;
}
@keyframes shimmer{
  0%  {background-position:200% 0;}
  100%{background-position:-200% 0;}
}

/* ────────────────────────────────────────
   TOP NAV
──────────────────────────────────────── */
.nav{
  position:fixed;top:0;left:0;right:0;z-index:200;
  height:calc(56px + var(--st));
  padding:var(--st) 16px 0;
  display:flex;align-items:center;
  transition:background .4s,backdrop-filter .4s,border-color .4s;
  border-bottom:1px solid transparent;
}
.nav.solid{
  background:rgba(8,4,0,.93);
  backdrop-filter:blur(24px);
  -webkit-backdrop-filter:blur(24px);
  border-bottom-color:rgba(255,255,255,.07);
}
.nav-brand{
  display:flex;align-items:center;gap:9px;flex:1;
}
.nav-mark{
  width:32px;height:32px;border-radius:10px;
  background:linear-gradient(135deg,var(--amber),var(--gold));
  display:flex;align-items:center;justify-content:center;
  font-size:15px;flex-shrink:0;
  box-shadow:0 3px 12px rgba(232,82,26,.45);
  transition:transform .2s;
}
.nav-mark:hover{transform:scale(1.05);}
.nav-title{
  font-family:'Bebas Neue',sans-serif;
  font-size:19px;letter-spacing:2.5px;color:#fff;
}
.nav-right{display:flex;align-items:center;gap:7px;}
.nav-btn{
  display:flex;align-items:center;gap:5px;
  padding:6px 13px;border-radius:24px;
  font-size:12px;font-weight:700;
  transition:all .2s;
}
.nav-btn:active{transform:scale(.95);}
.nav-srch{
  background:rgba(255,255,255,.08);
  border:1px solid rgba(255,255,255,.1);
  color:rgba(255,255,255,.7);
}
.nav-srch:hover{background:rgba(255,255,255,.13);}
.nav-track{
  background:var(--amber);color:#fff;
  box-shadow:0 2px 10px rgba(232,82,26,.4);
}
.nav-track:hover{background:var(--amber2);}

/* ────────────────────────────────────────
   HERO
──────────────────────────────────────── */
.hero{
  position:relative;
  height:100dvh;min-height:640px;
  display:flex;flex-direction:column;
  align-items:center;justify-content:flex-end;
  overflow:hidden;
  padding-bottom:calc(var(--bnav) + var(--sb) + 32px);
}

/* Layered backgrounds */
.hero-media{position:absolute;inset:0;z-index:0;}
.hero-img{
  width:100%;height:100%;
  object-fit:cover;object-position:center 30%;
  filter:brightness(.55) saturate(1.15);
  transform:scale(1.08);
  animation:heroKen 14s ease-in-out infinite alternate;
  will-change:transform;
}


.hero-video-bg {
    position: absolute;
    top: 0; left: 0; width: 100vw; height: 100vh;
    object-fit: cover;
    z-index: 0;
    filter: brightness(0.7) blur(.6px);
}

@keyframes heroKen{
  from{transform:scale(1.08) translate(0,0);}
  to  {transform:scale(1.0)  translate(-1%,-.5%);}
}

/* Multi-layer gradient */
.hero-grad{
  position:absolute;inset:0;z-index:1;pointer-events:none;
  background:
    linear-gradient(to bottom,
      rgba(8,4,0,.65) 0%,
      rgba(8,4,0,.1)  22%,
      transparent     40%,
      rgba(8,4,0,.35) 60%,
      rgba(8,4,0,.92) 82%,
      rgba(8,4,0,1)   100%
    ),
    linear-gradient(to right,
      rgba(8,4,0,.4) 0%,
      transparent    50%
    );
}
/* Noise texture overlay */
.hero-noise{
  position:absolute;inset:0;z-index:1;pointer-events:none;
  opacity:.035;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
  background-size:150px;
}

/* Floating particles */
.hero-particles{
  position:absolute;inset:0;z-index:2;pointer-events:none;
  overflow:hidden;
}
.particle{
  position:absolute;
  width:2px;height:2px;border-radius:50%;
  background:rgba(232,82,26,.6);
  animation:particleFloat linear infinite;
}
@keyframes particleFloat{
  0%  {transform:translateY(100vh) scale(0);opacity:0;}
  10% {opacity:1;}
  90% {opacity:.8;}
  100%{transform:translateY(-20px) scale(1.5);opacity:0;}
}

/* Hero content */
.hero-content{
  position:relative;z-index:5;
  width:100%;max-width:640px;
  padding:0 0px 80px 0px;
  text-align:center;
}
.hero-badge{
  display:inline-flex;align-items:center;gap:7px;
  background:rgba(232,82,26,.16);
  border:1px solid rgba(232,82,26,.32);
  border-radius:30px;padding:5px 14px;
  font-size:11px;font-weight:700;
  color:var(--amber2);letter-spacing:.5px;
  text-transform:uppercase;margin-bottom:18px;
  animation:heroRise .7s ease .05s both;
  backdrop-filter:blur(8px);
}
.hb-dot{
  width:6px;height:6px;border-radius:50%;
  background:var(--amber);flex-shrink:0;
  animation:locPulse 2s ease infinite;
}

.hero-title{
  font-family:'Bebas Neue',sans-serif;
  font-size:clamp(58px,18vw,96px);
  line-height:.92;letter-spacing:2px;
  color:#fff;margin-bottom:16px;
  animation:heroRise .7s ease .12s both;
  text-shadow:0 4px 32px rgba(0,0,0,.4);
}
.hero-title .accent{color:var(--amber);}
.hero-title .stroke{
  -webkit-text-stroke:2px #fff;
  color:transparent;
}

.hero-sub{
  font-size:clamp(14px,3.8vw,17px);
  font-weight:400;color:rgba(255,255,255,.6);
  line-height:1.65;margin-bottom:28px;
  max-width:460px;margin-left:auto;margin-right:auto;
  animation:heroRise .7s ease .22s both;
}
@keyframes heroRise{
  from{transform:translateY(22px);opacity:0;}
  to  {transform:translateY(0);opacity:1;}
}

/* Pill row */
.hero-pills{
  display:flex;flex-wrap:wrap;gap:8px;
  justify-content:center;
  animation:heroRise .7s ease .32s both;
}
.pill{
  display:inline-flex;align-items:center;gap:7px;
  padding:11px 18px;border-radius:28px;
  font-size:13px;font-weight:700;
  transition:transform .18s,box-shadow .18s;
  flex-shrink:0;
  position:relative;overflow:hidden;
}
.pill::before{
  content:'';position:absolute;inset:0;
  background:rgba(255,255,255,.08);
  opacity:0;transition:opacity .18s;
}
.pill:active::before{opacity:1;}
.pill:active{transform:scale(.95)!important;}
.pill-homes{
  background:rgba(45,106,79,.85);color:#86efac;
  border:1px solid rgba(45,106,79,.5);
  box-shadow:0 4px 18px rgba(45,106,79,.25);
}
.pill-homes:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(45,106,79,.35);}
.pill-food{
  background:rgba(193,68,14,.85);color:#fca5a5;
  border:1px solid rgba(193,68,14,.5);
  box-shadow:0 4px 18px rgba(193,68,14,.25);
}
.pill-food:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(193,68,14,.35);}
.pill-shop{
  background:rgba(27,79,158,.85);color:#93c5fd;
  border:1px solid rgba(27,79,158,.5);
  box-shadow:0 4px 18px rgba(27,79,158,.25);
}
.pill-shop:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(27,79,158,.35);}
.pill-watch{
  background:rgba(109,40,217,.85);color:#c4b5fd;
  border:1px solid rgba(109,40,217,.5);
  box-shadow:0 4px 18px rgba(109,40,217,.25);
}
.pill-watch:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(109,40,217,.35);}

/* Scroll hint */
.scroll-hint{
  position:absolute;bottom:calc(var(--bnav) + var(--sb) + 90px);
  left:45%;transform:translateX(-45%);z-index:5;
  display:flex;flex-direction:column;align-items:center;gap:5px;
  animation:heroRise .7s ease .5s both;
  pointer-events:none;
}
.sh-mouse{
  width:22px;height:34px;border-radius:11px;
  border:2px solid rgba(255,255,255,.25);
  position:relative;display:flex;justify-content:center;
}
.sh-wheel{
  width:3px;height:6px;border-radius:2px;
  background:rgba(255,255,255,.5);
  margin-top:5px;
  animation:wheelScroll 2s ease-in-out infinite;
}
@keyframes wheelScroll{
  0%,100%{transform:translateY(0);opacity:1;}
  60%    {transform:translateY(10px);opacity:0;}
}
.sh-txt{font-size:9px;font-weight:700;letter-spacing:2.5px;text-transform:uppercase;color:rgba(255,255,255,.3);}

/* ────────────────────────────────────────
   STATS TICKER
──────────────────────────────────────── */
.stats-ticker{
  background:var(--amber);
  padding:0;overflow:hidden;
  position:relative;
}
.ticker-track{
  display:flex;align-items:center;
  animation:tickerScroll 18s linear infinite;
  white-space:nowrap;
}
@keyframes tickerScroll{
  from{transform:translateX(0);}
  to  {transform:translateX(-50%);}
}
.ticker-item{
  display:inline-flex;align-items:center;gap:8px;
  padding:12px 28px;
  font-family:'Bebas Neue',sans-serif;
  font-size:18px;letter-spacing:2px;color:#fff;
  flex-shrink:0;
}
.ticker-dot{width:5px;height:5px;border-radius:50%;background:rgba(255,255,255,.5);flex-shrink:0;}

/* ────────────────────────────────────────
   SECTION UTILITIES
──────────────────────────────────────── */
.wrap{max-width:600px;margin:0 auto;padding:0 16px;}
.eyebrow{
  font-size:10px;font-weight:700;letter-spacing:2.5px;
  text-transform:uppercase;color:var(--amber);
  margin-bottom:8px;
}
.sec-title{
  font-family:'Bebas Neue',sans-serif;
  font-size:clamp(34px,10vw,52px);
  letter-spacing:1.5px;color:#fff;line-height:.96;
  margin-bottom:24px;
}
.sec-title em{color:var(--amber);font-style:normal;}

/* Reveal system */
.rv{opacity:0;transform:translateY(32px);transition:opacity .72s cubic-bezier(.25,.46,.45,.94),transform .72s cubic-bezier(.25,.46,.45,.94);}
.rv.rv-left{transform:translateX(-28px) translateY(0);}
.rv.rv-right{transform:translateX(28px) translateY(0);}
.rv.rv-scale{transform:scale(.92);}
.rv.in{opacity:1;transform:none;}

/* ────────────────────────────────────────
   CATEGORY CARDS
──────────────────────────────────────── */
.cats-section{padding:52px 0 0;}
.cats-wrap{padding:0 16px 52px;max-width:600px;margin:0 auto;display:flex;flex-direction:column;gap:12px;}

.cat-card{
  position:relative;border-radius:22px;overflow:hidden;
  display:block;height:188px;cursor:pointer;
  -webkit-tap-highlight-color:transparent;
}
/* Animated border gradient */
.cat-card::before{
  content:'';position:absolute;inset:-2px;border-radius:24px;z-index:0;
  background:linear-gradient(135deg,rgba(255,255,255,.12),rgba(255,255,255,.04),rgba(255,255,255,.12));
  opacity:0;transition:opacity .35s;
}
.cat-card:active::before,.cat-card:focus::before{opacity:1;}
.cat-card:active{transform:scale(.985);}
.cat-card-inner{
  position:absolute;inset:0;border-radius:22px;overflow:hidden;z-index:1;
}
.cat-img{
  width:100%;height:100%;object-fit:cover;
  filter:brightness(.5) saturate(1.2);
  transition:transform .7s cubic-bezier(.25,.46,.45,.94),filter .5s;
  transform:scale(1.04);
  will-change:transform;
}
.cat-card:hover .cat-img,.cat-card:focus .cat-img{
  transform:scale(1.08);filter:brightness(.55) saturate(1.3);
}
.cat-grad{position:absolute;inset:0;}
.cc-homes .cat-grad{background:linear-gradient(145deg,rgba(45,106,79,.88) 0%,rgba(45,106,79,.15) 65%,transparent 100%);}
.cc-food  .cat-grad{background:linear-gradient(145deg,rgba(193,68,14,.88) 0%,rgba(193,68,14,.15) 65%,transparent 100%);}
.cc-shop  .cat-grad{background:linear-gradient(145deg,rgba(27,79,158,.88)  0%,rgba(27,79,158,.15)  65%,transparent 100%);}
/* Shine sweep on hover */
.cat-shine{
  position:absolute;inset:0;z-index:3;
  background:linear-gradient(105deg,transparent 40%,rgba(255,255,255,.07) 50%,transparent 60%);
  transform:translateX(-100%);
  transition:transform .55s ease;
}
.cat-card:hover .cat-shine{transform:translateX(100%);}

.cat-body{
  position:absolute;inset:0;z-index:4;
  padding:18px 18px;
  display:flex;flex-direction:column;justify-content:space-between;
}
.cat-top{display:flex;align-items:center;justify-content:space-between;}
.cat-icon-wrap{
  width:42px;height:42px;border-radius:13px;
  background:rgba(255,255,255,.14);backdrop-filter:blur(10px);
  border:1px solid rgba(255,255,255,.2);
  display:flex;align-items:center;justify-content:center;font-size:21px;
  transition:transform .2s;
}
.cat-card:hover .cat-icon-wrap{transform:scale(1.08) rotate(-3deg);}
.cat-live{
  display:flex;align-items:center;gap:5px;
  background:rgba(0,0,0,.45);backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.1);
  padding:4px 10px;border-radius:20px;
  font-size:10px;font-weight:600;color:rgba(255,255,255,.8);
}
.live-dot{width:5px;height:5px;border-radius:50%;background:#4ade80;animation:locPulse 2s ease infinite;}
.cat-bottom{}
.cat-label-txt{font-size:9px;font-weight:700;letter-spacing:1.8px;text-transform:uppercase;color:rgba(255,255,255,.55);margin-bottom:3px;}
.cat-name{
  font-family:'Bebas Neue',sans-serif;
  font-size:31px;letter-spacing:1px;color:#fff;
  line-height:1;margin-bottom:9px;
  text-shadow:0 2px 12px rgba(0,0,0,.4);
}
.cat-go{
  display:inline-flex;align-items:center;gap:6px;
  padding:6px 13px;border-radius:20px;
  font-size:11px;font-weight:700;
  backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.18);
  transition:all .22s;
}
.cc-homes .cat-go{background:rgba(45,106,79,.38);color:#86efac;border-color:rgba(134,239,172,.25);}
.cc-food  .cat-go{background:rgba(193,68,14,.38);color:#fca5a5;border-color:rgba(252,165,165,.25);}
.cc-shop  .cat-go{background:rgba(27,79,158,.38); color:#93c5fd;border-color:rgba(147,197,253,.25);}
.cat-card:hover .cat-go{padding-right:17px;}
.cat-go::after{content:'→';opacity:0;transform:translateX(-4px);transition:all .22s;display:inline-block;}
.cat-card:hover .cat-go::after{opacity:1;transform:translateX(0);}

/* ────────────────────────────────────────
   WATCH & SHOP
──────────────────────────────────────── */
.watch-section{
  margin:0 16px 52px;
  max-width:568px;
  margin-left:auto;margin-right:auto;
  border-radius:26px;overflow:hidden;
  background:linear-gradient(135deg,#12003d,#0a0025 50%,#050015);
  border:1px solid rgba(139,92,246,.18);
  position:relative;
}
.ws-aurora{
  position:absolute;inset:0;z-index:0;pointer-events:none;
  background:
    radial-gradient(ellipse 70% 50% at 80% 20%,rgba(139,92,246,.25) 0%,transparent 60%),
    radial-gradient(ellipse 50% 60% at 20% 80%,rgba(232,82,26,.12) 0%,transparent 60%);
  animation:auroraDrift 6s ease-in-out infinite alternate;
}
@keyframes auroraDrift{
  from{opacity:.7;transform:scale(1);}
  to  {opacity:1;transform:scale(1.06);}
}
.ws-content{position:relative;z-index:1;padding:26px 20px 20px;}
.ws-badge{
  display:inline-flex;align-items:center;gap:5px;
  background:rgba(139,92,246,.2);border:1px solid rgba(139,92,246,.28);
  color:#c4b5fd;border-radius:20px;padding:4px 11px;
  font-size:10px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;
  margin-bottom:14px;
}
.ws-title{
  font-family:'Bebas Neue',sans-serif;
  font-size:36px;letter-spacing:1px;color:#fff;
  line-height:1;margin-bottom:8px;
}
.ws-title em{color:#a78bfa;font-style:normal;}
.ws-sub{font-size:13px;color:rgba(255,255,255,.45);line-height:1.6;margin-bottom:20px;}
/* Phones mockup */
.ws-phones{
  display:flex;gap:12px;align-items:flex-end;
  margin-bottom:20px;
}
.ws-phone{
  border-radius:16px;overflow:hidden;
  border:2px solid rgba(255,255,255,.1);
  box-shadow:0 16px 40px rgba(0,0,0,.6);
  background:#0a0a0a;flex-shrink:0;
  transition:transform .4s ease;
}
.ws-phone:nth-child(1){width:72px;transform:rotate(-5deg) translateY(8px);}
.ws-phone:nth-child(2){width:84px;transform:rotate(0deg);}
.ws-phone:nth-child(3){width:72px;transform:rotate(5deg) translateY(8px);}
.ws-section:hover .ws-phone:nth-child(1){transform:rotate(-6deg) translateY(6px);}
.ws-section:hover .ws-phone:nth-child(3){transform:rotate(6deg) translateY(6px);}  
.ws-phone-screen{
  aspect-ratio:9/16;position:relative;
  display:flex;align-items:center;justify-content:center;
  overflow:hidden;
}
.ws-phone-img{
  position:absolute;inset:0;width:100%;height:100%;
  object-fit:cover;filter:brightness(.48);
}
.ws-phone-over{
  position:absolute;inset:0;z-index:1;
  background:linear-gradient(to top,rgba(0,0,0,.88) 0%,transparent 55%);
  display:flex;flex-direction:column;justify-content:flex-end;padding:7px;
}
.ws-ph-name{font-size:8px;font-weight:700;color:#fff;line-height:1.2;margin-bottom:2px;}
.ws-ph-price{font-size:10px;font-weight:800;color:var(--amber2);}
.ws-play{
  position:absolute;top:50%;left:50%;z-index:2;
  transform:translate(-50%,-50%);
  width:28px;height:28px;border-radius:50%;
  background:rgba(255,255,255,.18);backdrop-filter:blur(4px);
  display:flex;align-items:center;justify-content:center;
  font-size:11px;
}
.ws-cta{
  display:flex;align-items:center;justify-content:center;gap:8px;
  padding:14px;border-radius:15px;
  background:linear-gradient(135deg,#7c3aed,#6366f1);
  color:#fff;font-weight:800;font-size:14px;
  box-shadow:0 6px 24px rgba(124,58,237,.38);
  transition:all .22s;
}
.ws-cta:active{transform:scale(.97);}
.ws-cta:hover{box-shadow:0 10px 32px rgba(124,58,237,.5);}

/* ────────────────────────────────────────
   LIPA MDOGO MDOGO
──────────────────────────────────────── */
.lipa-section{
  margin:0 16px 52px;
  max-width:568px;margin-left:auto;margin-right:auto;
  border-radius:26px;overflow:hidden;
  background:linear-gradient(135deg,#1c0e00,#110800);
  border:1px solid rgba(245,166,35,.13);
  position:relative;
}
.lipa-glow{
  position:absolute;top:-30px;right:-30px;
  width:220px;height:220px;border-radius:50%;
  background:radial-gradient(circle,rgba(245,166,35,.14) 0%,transparent 70%);
  pointer-events:none;animation:auroraDrift 5s ease-in-out infinite alternate;
}
.lipa-inner{position:relative;z-index:1;}
.lipa-top{padding:24px 20px 0;display:flex;gap:14px;align-items:flex-start;}
.lipa-icon{
  width:50px;height:50px;border-radius:15px;
  background:linear-gradient(135deg,var(--gold),var(--amber));
  display:flex;align-items:center;justify-content:center;font-size:24px;
  box-shadow:0 6px 20px rgba(245,166,35,.38);flex-shrink:0;
}
.lipa-txt{}
.lipa-title{
  font-family:'Bebas Neue',sans-serif;
  font-size:28px;letter-spacing:1px;color:#fff;margin-bottom:3px;
}
.lipa-sub{font-size:12px;color:rgba(255,255,255,.42);line-height:1.6;}
/* Frequency chips */
.lipa-chips{
  display:flex;gap:7px;padding:16px 20px;
  overflow-x:auto;scrollbar-width:none;
  -webkit-overflow-scrolling:touch;
}
.lipa-chips::-webkit-scrollbar{display:none;}
.lipa-chip{
  flex-shrink:0;padding:10px 14px;border-radius:16px;
  background:rgba(245,166,35,.08);
  border:1px solid rgba(245,166,35,.18);
  text-align:center;cursor:pointer;
  transition:all .22s;
}
.lipa-chip:hover{background:rgba(245,166,35,.16);transform:translateY(-2px);}
.lipa-chip:active{transform:scale(.95);}
.lc-freq{font-family:'Bebas Neue',sans-serif;font-size:20px;color:var(--gold);letter-spacing:.5px;}
.lc-mark{font-size:9px;font-weight:600;color:rgba(255,255,255,.35);letter-spacing:.4px;margin-top:1px;}
.lipa-rule{
  margin:0 20px 14px;padding:10px 13px;
  background:rgba(232,82,26,.07);border:1px solid rgba(232,82,26,.15);
  border-radius:11px;font-size:11px;color:rgba(255,190,120,.8);line-height:1.6;
}
.lipa-rule strong{color:var(--amber2);}
.lipa-btn{
  margin:0 20px 20px;
  display:flex;align-items:center;justify-content:center;gap:8px;
  padding:14px;border-radius:15px;
  background:linear-gradient(135deg,var(--gold),var(--amber));
  color:#fff;font-weight:800;font-size:14px;
  box-shadow:0 6px 22px rgba(245,166,35,.3);
  transition:all .22s;
}
.lipa-btn:active{transform:scale(.97);}
.lipa-btn:hover{box-shadow:0 10px 30px rgba(245,166,35,.42);}

/* ────────────────────────────────────────
   TRACK ORDER
──────────────────────────────────────── */
.track-card{
  margin:0 16px 52px;
  max-width:568px;margin-left:auto;margin-right:auto;
  background:rgba(232,82,26,.07);
  border:1px solid rgba(232,82,26,.18);
  border-radius:22px;padding:22px 18px;
  display:flex;align-items:center;gap:15px;
  transition:all .22s;
}
.track-card:hover{
  background:rgba(232,82,26,.1);
  border-color:rgba(232,82,26,.3);
  transform:translateY(-2px);
  box-shadow:0 8px 32px rgba(232,82,26,.12);
}
.track-card:active{transform:scale(.98);}
.tc-icon{
  width:52px;height:52px;border-radius:15px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  display:flex;align-items:center;justify-content:center;font-size:24px;
  flex-shrink:0;box-shadow:0 4px 16px rgba(232,82,26,.38);
  animation:trackPulse 3s ease-in-out infinite;
}
@keyframes trackPulse{
  0%,100%{box-shadow:0 4px 16px rgba(232,82,26,.38);}
  50%    {box-shadow:0 4px 28px rgba(232,82,26,.55);}
}
.tc-body{flex:1;min-width:0;}
.tc-title{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:1px;color:#fff;margin-bottom:2px;}
.tc-sub{font-size:12px;color:rgba(255,255,255,.4);line-height:1.4;}
.tc-btn{
  flex-shrink:0;padding:9px 16px;
  background:var(--amber);color:#fff;border-radius:12px;
  font-size:12px;font-weight:800;white-space:nowrap;
  box-shadow:0 3px 12px rgba(232,82,26,.4);
  transition:all .2s;
}
.tc-btn:active{transform:scale(.93);}
.tc-btn:hover{background:var(--amber2);box-shadow:0 6px 20px rgba(232,82,26,.5);}

/* ────────────────────────────────────────
   HOW IT WORKS
──────────────────────────────────────── */
.hiw-wrap{padding:0 16px 52px;max-width:568px;margin:0 auto;}
.hiw-list{display:flex;flex-direction:column;}
.hiw-item{
  display:flex;gap:16px;align-items:flex-start;
  padding-bottom:30px;position:relative;
}
.hiw-item:last-child{padding-bottom:0;}
.hiw-item:not(:last-child)::after{
  content:'';position:absolute;left:20px;top:44px;bottom:0;width:2px;
  background:linear-gradient(to bottom,rgba(232,82,26,.25),rgba(232,82,26,.03));
}
.hiw-num{
  width:42px;height:42px;border-radius:14px;
  background:rgba(232,82,26,.1);border:1px solid rgba(232,82,26,.2);
  display:flex;align-items:center;justify-content:center;flex-shrink:0;
  font-family:'Bebas Neue',sans-serif;font-size:22px;color:var(--amber);
  transition:all .3s;
}
.hiw-item.in .hiw-num{
  background:var(--amber);color:#fff;
  box-shadow:0 4px 14px rgba(232,82,26,.4);
}
.hiw-text{}
.hiw-step-title{font-size:15px;font-weight:700;color:#fff;margin-bottom:3px;margin-top:8px;}
.hiw-step-desc{font-size:13px;color:rgba(255,255,255,.4);line-height:1.6;}

/* ────────────────────────────────────────
   BRAND STRIP
──────────────────────────────────────── */
.brand-strip{
  margin:0 16px 52px;
  max-width:568px;margin-left:auto;margin-right:auto;
  border-radius:26px;overflow:hidden;position:relative;
  background:linear-gradient(135deg,var(--amber) 0%,#b83d10 55%,#6e2000 100%);
  padding:28px 22px;
}
.bs-pattern{
  position:absolute;inset:0;pointer-events:none;
  background-image:
    repeating-linear-gradient(45deg,rgba(255,255,255,.04) 0px,rgba(255,255,255,.04) 1px,transparent 1px,transparent 16px),
    repeating-linear-gradient(-45deg,rgba(255,255,255,.04) 0px,rgba(255,255,255,.04) 1px,transparent 1px,transparent 16px);
}
.bs-shine{
  position:absolute;top:-50%;right:-20%;
  width:280px;height:280px;border-radius:50%;
  background:radial-gradient(circle,rgba(255,255,255,.1) 0%,transparent 65%);
  pointer-events:none;
}
.bs-content{position:relative;z-index:1;}
.bs-logo-row{display:flex;align-items:center;gap:10px;margin-bottom:12px;}
.bs-mark{
  width:42px;height:42px;border-radius:13px;
  background:rgba(255,255,255,.2);backdrop-filter:blur(8px);
  display:flex;align-items:center;justify-content:center;font-size:21px;
}
.bs-name{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:3px;color:#fff;}
.bs-desc{font-size:13px;color:rgba(255,255,255,.7);line-height:1.65;margin-bottom:20px;font-weight:400;}
.bs-links{display:flex;flex-wrap:wrap;gap:7px;}
.bs-link{
  display:inline-flex;align-items:center;gap:5px;
  padding:7px 13px;border-radius:20px;
  background:rgba(255,255,255,.14);backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.18);
  font-size:12px;font-weight:700;color:#fff;
  transition:all .2s;
}
.bs-link:hover{background:rgba(255,255,255,.24);transform:translateY(-1px);}
.bs-link:active{transform:scale(.95);}

/* ────────────────────────────────────────
   FOOTER
──────────────────────────────────────── */
.footer{
  padding:24px 20px calc(var(--bnav) + var(--sb) + 20px);
  text-align:center;border-top:1px solid rgba(255,255,255,.05);
  max-width:600px;margin:0 auto;
}
.footer-mark{display:flex;align-items:center;justify-content:center;gap:7px;margin-bottom:8px;}
.fm-ico{
  width:26px;height:26px;border-radius:8px;
  background:linear-gradient(135deg,var(--amber),var(--gold));
  display:flex;align-items:center;justify-content:center;font-size:12px;
}
.fm-name{font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:2px;color:rgba(255,255,255,.4);}
.footer-copy{font-size:11px;color:rgba(255,255,255,.18);}

/* ────────────────────────────────────────
   BOTTOM NAV
──────────────────────────────────────── */
.bnav{
  position:fixed;bottom:0;left:0;right:0;z-index:200;
  height:calc(var(--bnav) + var(--sb));
  padding-bottom:var(--sb);
  background:rgba(8,4,0,.95);
  backdrop-filter:blur(28px);
  -webkit-backdrop-filter:blur(28px);
  border-top:1px solid rgba(255,255,255,.07);
  display:flex;align-items:stretch;
  /* Raised center button */
  position:fixed;
}
.bni{
  flex:1;display:flex;flex-direction:column;
  align-items:center;justify-content:center;
  gap:3px;padding:0 4px;
  position:relative;transition:all .2s;
  cursor:pointer;-webkit-tap-highlight-color:transparent;
}
.bni-ico{font-size:20px;color:rgba(255,255,255,.38);transition:all .22s;line-height:1.15;}
.bni-lbl{font-size:9px;font-weight:700;color:rgba(255,255,255,.3);letter-spacing:.5px;text-transform:uppercase;transition:all .22s;}
.bni.active .bni-ico{color:var(--amber);}
.bni.active .bni-lbl{color:var(--amber);}
/* Active indicator dot */
.bni.active::before{
  content:'';position:absolute;bottom:2px;
  width:20px;height:2px;border-radius:1px;
  background:var(--amber);
  animation:indIn .3s ease;
}
@keyframes indIn{from{width:0;opacity:0;}to{width:20px;opacity:1;}}

/* Centre Watch button — floats above nav */
.bni-center{
  position:relative;display:flex;flex-direction:column;
  align-items:center;justify-content:center;gap:4px;
  flex:1;padding:0;cursor:pointer;
  -webkit-tap-highlight-color:transparent;
}
.bni-center-btn{
  width:50px;height:50px;border-radius:50%;
  background:linear-gradient(135deg,#7c3aed,#6366f1);
  display:flex;align-items:center;justify-content:center;
  font-size:18px;
  box-shadow:0 -2px 20px rgba(124,58,237,.55);
  margin-top:-18px;
  border:3px solid rgba(8,4,0,.95);
  transition:all .22s;
}
.bni-center:active .bni-center-btn{transform:scale(.92);}
.bni-center-btn:hover{box-shadow:0 -2px 28px rgba(124,58,237,.7);}
.bni-center-lbl{font-size:9px;font-weight:700;color:rgba(139,92,246,.75);letter-spacing:.5px;text-transform:uppercase;}

/* ────────────────────────────────────────
   FLOATING BACK-TO-TOP
──────────────────────────────────────── */
.fab{
  position:fixed;bottom:calc(var(--bnav) + var(--sb) + 14px);right:16px;z-index:150;
  width:42px;height:42px;border-radius:50%;
  background:rgba(232,82,26,.9);backdrop-filter:blur(8px);
  display:flex;align-items:center;justify-content:center;
  font-size:18px;color:#fff;
  box-shadow:0 4px 16px rgba(232,82,26,.4);
  opacity:0;pointer-events:none;
  transform:translateY(12px) scale(.8);
  transition:all .3s cubic-bezier(.34,1.56,.64,1);
}
.fab.show{opacity:1;pointer-events:all;transform:none;}
.fab:active{transform:scale(.9)!important;}

/* ────────────────────────────────────────
   SEARCH MODAL
──────────────────────────────────────── */
.search-modal{
  position:fixed;inset:0;z-index:600;
  background:rgba(8,4,0,.98);
  backdrop-filter:blur(24px);
  display:flex;flex-direction:column;
  padding-top:calc(var(--st) + 8px);
  opacity:0;pointer-events:none;
  transition:opacity .22s;
}
.search-modal.open{opacity:1;pointer-events:all;}
.sm-bar{
  display:flex;align-items:center;gap:10px;
  padding:10px 14px;border-bottom:1px solid rgba(255,255,255,.06);
}
.sm-input-wrap{
  flex:1;display:flex;align-items:center;gap:8px;
  background:rgba(255,255,255,.07);
  border:1.5px solid rgba(255,255,255,.1);
  border-radius:13px;padding:0 13px;
  transition:border-color .2s;
}
.sm-input-wrap:focus-within{border-color:var(--amber);}
.sm-ico{font-size:15px;opacity:.4;flex-shrink:0;}
.sm-inp{
  flex:1;background:transparent;border:none;
  padding:12px 0;color:#fff;font-size:15px;
  font-family:inherit;outline:none;
}
.sm-inp::placeholder{color:rgba(255,255,255,.2);}
.sm-cancel{font-size:13px;font-weight:700;color:rgba(255,255,255,.45);padding:4px;}
.sm-cancel:hover{color:#fff;}
.sm-results{flex:1;overflow-y:auto;}
.sm-sec{padding:13px 16px 6px;font-size:10px;font-weight:700;color:rgba(255,255,255,.28);letter-spacing:.8px;text-transform:uppercase;}
.sm-link{
  display:flex;align-items:center;gap:13px;
  padding:12px 16px;transition:background .13s;
}
.sm-link:active{background:rgba(255,255,255,.05);}
.sm-link-ico{
  width:44px;height:44px;border-radius:13px;
  display:flex;align-items:center;justify-content:center;font-size:21px;flex-shrink:0;
}
.sli-h{background:rgba(45,106,79,.2);}
.sli-f{background:rgba(193,68,14,.2);}
.sli-s{background:rgba(27,79,158,.2);}
.sli-w{background:rgba(109,40,217,.2);}
.sli-t{background:rgba(232,82,26,.2);}
.sm-link-txt{}
.sm-link-name{font-size:15px;font-weight:700;color:#fff;margin-bottom:1px;}
.sm-link-desc{font-size:11px;color:rgba(255,255,255,.33);}
.sm-divider{height:1px;background:rgba(255,255,255,.04);margin:4px 16px;}
</style>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Malaba Homes",
  "description": "Homes, Food Delivery & Shopping Marketplace in Malaba and Busia",
  "url": "https://malabahomes.com",
  "telephone": "+254747501436",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Malaba",
    "addressRegion": "Busia",
    "addressCountry": "KE"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 0.491,
    "longitude": 34.102
  },
  "openingHours": "Mo-Su 07:00-21:00",
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "Malaba Homes Services",
    "itemListElement": [
      {"@type":"Offer","itemOffered":{"@type":"Service","name":"House Rental"}},
      {"@type":"Offer","itemOffered":{"@type":"Service","name":"Food Delivery"}},
      {"@type":"Offer","itemOffered":{"@type":"Service","name":"Local Shopping"}}
    ]
  }
}
</script>
</head>
<body>

<!-- ═══════════════════════════════════════════
     SPLASH SCREEN
═══════════════════════════════════════════ -->
<div id="splash">
  <div class="sp-mesh"></div>
  <div class="sp-grid"></div>
  <div class="sp-rings">
    <div class="sp-ring"></div>
    <div class="sp-ring"></div>
    <div class="sp-ring"></div>
    <div class="sp-ring"></div>
    <div class="sp-ring"></div>
  </div>
  <div class="sp-glow"></div>

  <div class="sp-logo">
    <div class="sp-mark">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9.5L12 2L21 9.5V20C21 21.1 20.1 22 19 22H5C3.9 22 3 21.1 3 20V9.5Z" fill="rgba(255,255,255,.15)" stroke="white"/>
        <path d="M9 22V14H15V22" stroke="white"/>
        <circle cx="12" cy="10" r="1.5" fill="white" stroke="none"/>
      </svg>
    </div>
    <div class="sp-name">MALABA <span>HOMES</span></div>
    <div class="sp-tagline">Find &bull; Order &bull; Live</div>
    <div class="sp-location">
      <div class="sp-loc-dot"></div>
      Malaba, Kenya
    </div>
  </div>

  <div class="sp-progress">
    <div class="sp-fill" id="spFill"></div>
  </div>
</div>

<!-- ═══════════════════════════════════════════
     NAV
═══════════════════════════════════════════ -->
<nav class="nav" id="mainNav">
  <div class="nav-brand">
    <div class="nav-mark">&#x1F3E1;</div>
    <span class="nav-title">MALABA</span>
  </div>
  <div class="nav-right">
    <button class="nav-btn nav-srch" onclick="openSearch()">&#x1F50D; Search</button>
    <a href="track_order.php" class="nav-btn nav-track">&#x1F4E6; Track</a>
  </div>
</nav>

<!-- ═══════════════════════════════════════════
     HERO
═══════════════════════════════════════════ -->
<section class="hero">
  <div class="hero-media">
    <!--<img-->
    <!--  class="hero-img"-->
    <!--  src="https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=1400&q=80"-->
    <!--  alt="Malaba Homes"-->
    <!--  fetchpriority="high"-->
    <!-->
    
    <video class="hero-video-bg" src="homes_hero.webm" autoplay loop muted playsinline></video>
  </div>
  <div class="hero-grad"></div>
  <div class="hero-noise"></div>
  <div class="hero-particles" id="heroParticles"></div>

  <div class="hero-content" id="heroContent">
    <div class="hero-badge">
      <div class="hb-dot"></div>
      Malaba's #1 Marketplace
    </div>
    <h1 class="hero-title">
      FIND.<br>
      <span class="accent">ORDER.</span><br>
      <span class="stroke">LIVE.</span>
    </h1>
    <p class="hero-sub">
      Homes, hot food &amp; top local shops — all built for Malaba. Order in seconds, track in real time.
    </p>
    <div class="hero-pills">
      <a href="homes_listing.php" class="pill pill-homes">&#x1F3E0; Homes</a>
      <a href="food_listing.php"  class="pill pill-food">&#x1F354; Food</a>
      <a href="shop_listing.php"  class="pill pill-shop">&#x1F6D2; Shop</a>
      <!--<a href="video_feed.php"    class="pill pill-watch">&#x25B6; Watch</a>-->
    </div>
  </div>
    <br><br>
  <div class="scroll-hint">
    <div class="sh-mouse"><div class="sh-wheel"></div></div>
    <div class="sh-txt">Scroll</div>
  </div>
</section>

<!-- ═══════════════════════════════════════════
     STATS TICKER
═══════════════════════════════════════════ -->
<div class="stats-ticker" aria-hidden="true">
  <div class="ticker-track" id="tickerTrack">
    <!-- items injected by JS, duplicated for seamless loop -->
  </div>
</div>

<!-- ═══════════════════════════════════════════
     CATEGORIES
═══════════════════════════════════════════ -->
<section class="cats-section">
  <div class="wrap rv">
    <div class="eyebrow">What we offer</div>
    <div class="sec-title">THREE WAYS<br>TO <em>LIVE BETTER</em></div>
  </div>
  <div class="cats-wrap">

    <a href="homes_listing.php" class="cat-card cc-homes rv" style="--d:.08s">
      <div class="cat-card-inner">
        <img class="cat-img"
          src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900&q=75"
          alt="Homes" loading="lazy">
        <div class="cat-grad"></div>
        <div class="cat-shine"></div>
      </div>
      <div class="cat-body">
        <div class="cat-top">
          <div class="cat-icon-wrap">&#x1F3E0;</div>
          <div class="cat-live"><div class="live-dot"></div><span id="homesCount">Available</span></div>
        </div>
        <div class="cat-bottom">
          <div class="cat-label-txt">Homes &amp; Rentals</div>
          <div class="cat-name">FIND YOUR SPACE</div>
          <div class="cat-go">Browse Homes</div>
        </div>
      </div>
    </a>

    <a href="food_listing.php" class="cat-card cc-food rv" style="--d:.16s">
      <div class="cat-card-inner">
        <img class="cat-img"
          src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=900&q=75"
          alt="Food" loading="lazy">
        <div class="cat-grad"></div>
        <div class="cat-shine"></div>
      </div>
      <div class="cat-body">
        <div class="cat-top">
          <div class="cat-icon-wrap">&#x1F354;</div>
          <div class="cat-live"><div class="live-dot"></div><span id="foodCount">Order now</span></div>
        </div>
        <div class="cat-bottom">
          <div class="cat-label-txt">Food &amp; Drinks</div>
          <div class="cat-name">HOT FOOD FAST</div>
          <div class="cat-go">Order Food</div>
        </div>
      </div>
    </a>

    <a href="shop_listing.php" class="cat-card cc-shop rv" style="--d:.24s">
      <div class="cat-card-inner">
        <img class="cat-img"
          src="https://images.unsplash.com/photo-1601004890684-d8cbf643f5f2?w=900&q=75"
          alt="Shop" loading="lazy">
        <div class="cat-grad"></div>
        <div class="cat-shine"></div>
      </div>
      <div class="cat-body">
        <div class="cat-top">
          <div class="cat-icon-wrap">&#x1F6D2;</div>
          <div class="cat-live"><div class="live-dot"></div><span id="shopCount">Shop local</span></div>
        </div>
        <div class="cat-bottom">
          <div class="cat-label-txt">Home &amp; Shopping</div>
          <div class="cat-name">SHOP &amp; SAVE MORE</div>
          <div class="cat-go">Browse Shop</div>
        </div>
      </div>
    </a>

  </div>
</section>

<!-- ═══════════════════════════════════════════
     WATCH & SHOP
═══════════════════════════════════════════ -->
<div class="wrap rv" style="margin-bottom:16px;">
  <div class="eyebrow">New Feature</div>
  <div class="sec-title">WATCH &amp; <em>SHOP</em></div>
</div>
<div class="watch-section rv">
  <div class="ws-aurora"></div>
  <div class="ws-content">
    <div class="ws-badge">&#x2728; Live Now</div>
    <div class="ws-title">TikTok-style<br><em>Shopping</em> for Malaba</div>
    <div class="ws-sub">Swipe through product videos, order in one tap. Pay with Lipa Mdogo Mdogo — daily, twice-weekly, or weekly.</div>
    <div class="ws-phones">
      <div class="ws-phone">
        <div class="ws-phone-screen">
          <img class="ws-phone-img" src="https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=300&q=65" alt="" loading="lazy">
          <div class="ws-phone-over"><div class="ws-ph-name">Non-Stick Set</div><div class="ws-ph-price">KSH 3,500</div></div>
          <div class="ws-play">&#x25B6;</div>
        </div>
      </div>
      <div class="ws-phone">
        <div class="ws-phone-screen">
          <img class="ws-phone-img" src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300&q=65" alt="" loading="lazy">
          <div class="ws-phone-over"><div class="ws-ph-name">Burger Combo</div><div class="ws-ph-price">KSH 450</div></div>
          <div class="ws-play">&#x25B6;</div>
        </div>
      </div>
      <div class="ws-phone">
        <div class="ws-phone-screen">
          <img class="ws-phone-img" src="https://images.unsplash.com/photo-1563297007-0686b7003af7?w=300&q=65" alt="" loading="lazy">
          <div class="ws-phone-over"><div class="ws-ph-name">Electric Kettle</div><div class="ws-ph-price">KSH 1,200</div></div>
          <div class="ws-play">&#x25B6;</div>
        </div>
      </div>
    </div>
    <a href="video_feed.php" class="ws-cta">&#x25B6; Watch &amp; Shop Now</a>
  </div>
</div>

<!-- ═══════════════════════════════════════════
     LIPA MDOGO MDOGO
═══════════════════════════════════════════ -->
<div class="wrap rv" style="margin-bottom:16px;">
  <div class="eyebrow">Flexible Payments</div>
  <div class="sec-title">LIPA MDOGO <em>MDOGO</em></div>
</div>
<div class="lipa-section rv">
  <div class="lipa-glow"></div>
  <div class="lipa-inner">
    <div class="lipa-top">
      <div class="lipa-icon">&#x1F4B0;</div>
      <div class="lipa-txt">
        <div class="lipa-title">Pay Small, Get Big</div>
        <div class="lipa-sub">Order any shop item today. Pay at your own pace. Product delivered only after full payment is confirmed.</div>
      </div>
    </div>
    <div class="lipa-chips">
      <div class="lipa-chip"><div class="lc-freq">Daily</div><div class="lc-mark">No markup</div></div>
      <div class="lipa-chip"><div class="lc-freq">3&times;/week</div><div class="lc-mark">+2% only</div></div>
      <div class="lipa-chip"><div class="lc-freq">2&times;/week</div><div class="lc-mark">+4% only</div></div>
      <div class="lipa-chip"><div class="lc-freq">Weekly</div><div class="lc-mark">+7% only</div></div>
    </div>
    <div class="lipa-rule"><strong>&#x26A0; Important:</strong> Your product is only delivered after all payments are received. First payment secures your slot.</div>
    <a href="shop_listing.php" class="lipa-btn">&#x1F6D2; Shop with Lipa Mdogo Mdogo</a>
  </div>
</div>

<!-- ═══════════════════════════════════════════
     TRACK ORDER
═══════════════════════════════════════════ -->
<a href="track_order.php" class="track-card rv">
  <div class="tc-icon">&#x1F4E6;</div>
  <div class="tc-body">
    <div class="tc-title">TRACK YOUR ORDER</div>
    <div class="tc-sub">Real-time updates on your food, home booking, or shop order</div>
  </div>
  <div class="tc-btn">Track &#x2192;</div>
</a>

<!-- ═══════════════════════════════════════════
     HOW IT WORKS
═══════════════════════════════════════════ -->
<div class="wrap rv" style="margin-bottom:24px;">
  <div class="eyebrow">How it works</div>
  <div class="sec-title">EASY AS <em>1-2-3</em></div>
</div>
<div class="hiw-wrap">
  <div class="hiw-list">
    <div class="hiw-item rv rv-left" style="--d:.05s">
      <div class="hiw-num">1</div>
      <div class="hiw-text">
        <div class="hiw-step-title">Browse &amp; Choose</div>
        <div class="hiw-step-desc">Find homes, food items, or shop products. Search, filter, or explore the Watch &amp; Shop video feed.</div>
      </div>
    </div>
    <div class="hiw-item rv rv-left" style="--d:.12s">
      <div class="hiw-num">2</div>
      <div class="hiw-text">
        <div class="hiw-step-title">Order in Seconds</div>
        <div class="hiw-step-desc">Enter your name, phone, and address. Pay with cash, M-Pesa, or choose Lipa Mdogo Mdogo for shop items.</div>
      </div>
    </div>
    <div class="hiw-item rv rv-left" style="--d:.19s">
      <div class="hiw-num">3</div>
      <div class="hiw-text">
        <div class="hiw-step-title">Track &amp; Receive</div>
        <div class="hiw-step-desc">Follow your order status live. We send WhatsApp updates at every stage until it's in your hands.</div>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════════
     BRAND STRIP
═══════════════════════════════════════════ -->
<div class="brand-strip rv">
  <div class="bs-pattern"></div>
  <div class="bs-shine"></div>
  <div class="bs-content">
    <div class="bs-logo-row">
      <div class="bs-mark">&#x1F3E1;</div>
      <div class="bs-name">MALABA HOMES</div>
    </div>
    <div class="bs-desc">Your trusted local marketplace in Malaba, Kenya. Connecting buyers with the best homes, freshest food, and top local sellers — all in one place.</div>
    <div class="bs-links">
      <a href="homes_listing.php" class="bs-link">&#x1F3E0; Homes</a>
      <a href="food_listing.php"  class="bs-link">&#x1F354; Food</a>
      <a href="shop_listing.php"  class="bs-link">&#x1F6D2; Shop</a>
      <a href="video_feed.php"    class="bs-link">&#x25B6; Watch</a>
      <a href="track_order.php"   class="bs-link">&#x1F4E6; Track</a>
      <a href="my_orders.php"     class="bs-link">&#x1F4CB; My Orders</a>
    </div>
  </div>
</div>

<footer class="footer">
  <div class="footer-mark">
    <div class="fm-ico">&#x1F3E1;</div>
    <div class="fm-name">MALABA HOMES</div>
  </div>
  <div class="footer-copy">&copy; 2024 Malaba Homes &bull; Built for Malaba, Kenya</div>
</footer>

<!-- BOTTOM NAV -->
<nav class="bnav">
  <a href="index.php" class="bni active">
    <div class="bni-ico">&#x1F3E1;</div>
    <div class="bni-lbl">Home</div>
  </a>
  <a href="shop_listing.php" class="bni">
    <div class="bni-ico">&#x1F6D2;</div>
    <div class="bni-lbl">Shop</div>
  </a>
  <a href="video_feed.php" class="bni-center">
    <div class="bni-center-btn">&#x25B6;</div>
    <div class="bni-center-lbl">Watch</div>
  </a>
  <a href="food_listing.php" class="bni">
    <div class="bni-ico">&#x1F354;</div>
    <div class="bni-lbl">Food</div>
  </a>
    <a href="homes_listing.php" class="bni">
    <div class="bni-ico">&#127976;</div>
    <div class="bni-lbl">Rentals</div>
  </a>

</nav>

<!-- FAB -->
<button class="fab" id="fabTop" onclick="smoothScrollTop()" title="Back to top">&#x2191;</button>

<!-- SEARCH MODAL -->
<div class="search-modal" id="searchModal">
  <div class="sm-bar">
    <div class="sm-input-wrap">
      <span class="sm-ico">&#x1F50D;</span>
      <input class="sm-inp" id="smInp" type="search"
        placeholder="Search homes, food, shop items..."
        autocomplete="off" autocorrect="off" spellcheck="false">
    </div>
    <button class="sm-cancel" onclick="closeSearch()">Cancel</button>
  </div>
  <div class="sm-results">
    <div class="sm-sec">Browse</div>
    <a href="homes_listing.php" class="sm-link" onclick="closeSearch()">
      <div class="sm-link-ico sli-h">&#x1F3E0;</div>
      <div class="sm-link-txt"><div class="sm-link-name">Homes &amp; Rentals</div><div class="sm-link-desc">Apartments, studios &amp; family homes</div></div>
    </a>
    <div class="sm-divider"></div>
    <a href="food_listing.php" class="sm-link" onclick="closeSearch()">
      <div class="sm-link-ico sli-f">&#x1F354;</div>
      <div class="sm-link-txt"><div class="sm-link-name">Order Food</div><div class="sm-link-desc">Hot meals delivered to your door</div></div>
    </a>
    <div class="sm-divider"></div>
    <a href="shop_listing.php" class="sm-link" onclick="closeSearch()">
      <div class="sm-link-ico sli-s">&#x1F6D2;</div>
      <div class="sm-link-txt"><div class="sm-link-name">Shop Items</div><div class="sm-link-desc">Home goods &amp; local products</div></div>
    </a>
    <div class="sm-divider"></div>
    <a href="video_feed.php" class="sm-link" onclick="closeSearch()">
      <div class="sm-link-ico sli-w">&#x25B6;</div>
      <div class="sm-link-txt"><div class="sm-link-name">Watch &amp; Shop</div><div class="sm-link-desc">TikTok-style product videos</div></div>
    </a>
    <div class="sm-divider"></div>
    <a href="track_order.php" class="sm-link" onclick="closeSearch()">
      <div class="sm-link-ico sli-t">&#x1F4E6;</div>
      <div class="sm-link-txt"><div class="sm-link-name">Track My Order</div><div class="sm-link-desc">Real-time order status</div></div>
    </a>
  </div>
</div>

<script>
/* ═══════════════════════════════════════════════
   SPLASH
═══════════════════════════════════════════════ */
(function(){
  var fill   = document.getElementById('spFill');
  var splash = document.getElementById('splash');
  var pct = 0, start = Date.now();
  var dur = 2400;

  // Fast splash for returning users
  try {
    var today = new Date().toDateString();
    if (localStorage.getItem('mh_seen') === today) {
      dur = 700;
    } else {
      localStorage.setItem('mh_seen', today);
    }
  } catch(e){}

  var t = setInterval(function(){
    pct = Math.min(((Date.now()-start)/dur)*100, 100);
    // Easing: slow start, fast middle, slow end
    var eased = pct < 50
      ? 2 * pct * pct / 100
      : 100 - Math.pow(-2*pct/100+2, 2) / 2 * 100;
    fill.style.width = eased + '%';
    if (pct >= 100) {
      clearInterval(t);
      setTimeout(function(){
        splash.classList.add('exit');
        setTimeout(function(){ splash.style.display='none'; }, 850);
      }, 120);
    }
  }, 20);
})();

/* ═══════════════════════════════════════════════
   PARTICLES
═══════════════════════════════════════════════ */
(function(){
  var container = document.getElementById('heroParticles');
  var count = 18;
  for (var i = 0; i < count; i++) {
    var p = document.createElement('div');
    p.className = 'particle';
    var left  = 10 + Math.random() * 80;
    var delay = Math.random() * 12;
    var dur   = 8 + Math.random() * 10;
    var size  = 1 + Math.random() * 2.5;
    p.style.cssText =
      'left:'+left+'%;' +
      'animation-duration:'+dur+'s;' +
      'animation-delay:'+delay+'s;' +
      'width:'+size+'px;height:'+size+'px;' +
      'opacity:'+(0.3+Math.random()*0.5)+';';
    container.appendChild(p);
  }
})();

/* ═══════════════════════════════════════════════
   TICKER
═══════════════════════════════════════════════ */
(function(){
  var items = [
    '&#x1F3E0; Homes Available',
    '&#x1F354; Order Food Now',
    '&#x1F6D2; Shop Local',
    '&#x25B6; Watch &amp; Shop',
    '&#x1F4B0; Lipa Mdogo Mdogo',
    '&#x1F4E6; Track Your Order',
    '&#x1F4CD; Malaba, Kenya',
    '&#x23F0; Open 24/7',
  ];
  var track = document.getElementById('tickerTrack');
  // Duplicate for seamless loop
  var all = items.concat(items);
  var html = all.map(function(item){
    return '<div class="ticker-item"><div class="ticker-dot"></div>'+item+'</div>';
  }).join('');
  track.innerHTML = html;
})();

/* ═══════════════════════════════════════════════
   SMOOTH SCROLL
═══════════════════════════════════════════════ */
function smoothScrollTop(){
  var start    = window.scrollY;
  var startT   = Date.now();
  var dur      = Math.min(600, start * 0.5);
  var raf;
  function ease(t){ return t<.5?4*t*t*t:(t-1)*(2*t-2)*(2*t-2)+1; }
  function step(){
    var elapsed = Date.now() - startT;
    var progress = Math.min(elapsed/dur, 1);
    window.scrollTo(0, start*(1-ease(progress)));
    if (progress < 1) raf = requestAnimationFrame(step);
  }
  cancelAnimationFrame(raf);
  raf = requestAnimationFrame(step);
}

/* ═══════════════════════════════════════════════
   NAV & FAB on scroll
═══════════════════════════════════════════════ */
var nav  = document.getElementById('mainNav');
var fab  = document.getElementById('fabTop');
var lastY = 0;
window.addEventListener('scroll', function(){
  var y = window.scrollY;
  nav.classList.toggle('solid', y > 40);
  fab.classList.toggle('show', y > 400);
  lastY = y;
}, {passive:true});

/* ═══════════════════════════════════════════════
   REVEAL ON SCROLL — staggered per element
═══════════════════════════════════════════════ */
var rvEls = document.querySelectorAll('.rv');
// Set initial delay from CSS var --d
rvEls.forEach(function(el){
  var d = parseFloat(getComputedStyle(el).getPropertyValue('--d')||'0') || 0;
  el.style.transitionDelay = d + 's';
});

var rvObs = new IntersectionObserver(function(entries){
  entries.forEach(function(entry){
    if (entry.isIntersecting){
      entry.target.classList.add('in');
      // Animate HIW numbers to active state
      if (entry.target.classList.contains('hiw-item')){
        entry.target.classList.add('in');
      }
      rvObs.unobserve(entry.target);
    }
  });
}, {threshold:0.1, rootMargin:'0px 0px -40px 0px'});

rvEls.forEach(function(el){ rvObs.observe(el); });

/* ═══════════════════════════════════════════════
   COUNTER ANIMATION for stats
═══════════════════════════════════════════════ */
function animateCount(el, target, suffix){
  var start  = 0;
  var dur    = 1200;
  var startT = Date.now();
  function step(){
    var p = Math.min((Date.now()-startT)/dur, 1);
    var eased = 1-Math.pow(1-p, 3); // ease-out-cubic
    el.textContent = Math.round(eased*target) + suffix;
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

/* ═══════════════════════════════════════════════
   LOAD STATS
═══════════════════════════════════════════════ */
(function(){
  var apiBase = '<?php echo htmlspecialchars($apiBase, ENT_QUOTES); ?>';
  var map = [
    {cat:'houses', badge:'homesCount'},
    {cat:'food',   badge:'foodCount'},
    {cat:'items',  badge:'shopCount'},
  ];
  map.forEach(function(m){
    var xhr = new XMLHttpRequest();
    xhr.open('GET', apiBase+'/listings.php?type='+m.cat+'&limit=1', true);
    xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
    xhr.timeout = 5000;
    xhr.onload = function(){
      try {
        var d = JSON.parse(xhr.responseText);
        if (d && d.meta && d.meta.total > 0){
          var el = document.getElementById(m.badge);
          if (el) el.textContent = d.meta.total + '+ ' + (m.cat==='houses'?'homes':m.cat==='food'?'items':'products');
        }
      } catch(e){}
    };
    xhr.send();
  });
})();

/* ═══════════════════════════════════════════════
   SEARCH MODAL
═══════════════════════════════════════════════ */
function openSearch(){
  document.getElementById('searchModal').classList.add('open');
  setTimeout(function(){ document.getElementById('smInp').focus(); }, 180);
}
function closeSearch(){
  document.getElementById('searchModal').classList.remove('open');
}
document.addEventListener('DOMContentLoaded', function(){
  var inp = document.getElementById('smInp');
  if (!inp) return;
  inp.addEventListener('keydown', function(e){
    if (e.key==='Enter' && this.value.trim()){
      var q = encodeURIComponent(this.value.trim());
      window.location.href = 'shop_listing.php?q=' + q;
    }
    if (e.key==='Escape') closeSearch();
  });
});

/* ═══════════════════════════════════════════════
   HERO PARALLAX (subtle, mobile-safe)
═══════════════════════════════════════════════ */
var heroImg = document.querySelector('.hero-img');
window.addEventListener('scroll', function(){
  if (!heroImg) return;
  var y = window.scrollY;
  if (y < window.innerHeight){
    heroImg.style.transform = 'scale(1.06) translateY(' + (y * 0.22) + 'px)';
  }
}, {passive:true});

/* ═══════════════════════════════════════════════
   LIPA CHIPS — ripple on tap
═══════════════════════════════════════════════ */
document.querySelectorAll('.lipa-chip').forEach(function(chip){
  chip.addEventListener('click', function(){
    chip.style.transform = 'scale(.93)';
    setTimeout(function(){ chip.style.transform=''; }, 160);
    // Navigate to shop
    setTimeout(function(){ window.location.href='shop_listing.php'; }, 250);
  });
});
</script>
<?php include 'pwa_install_banner.php'; ?>

</body>
</html>