<?php
/**
 * pwa_head.php — Include inside <head> on every page
 * Usage: <?php include 'pwa_head.php'; ?>
 */
?>
<!-- ═══ PWA CORE ═══ -->
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#E8521A">
<meta name="mobile-web-app-capable" content="yes">

<!-- iOS Safari -->
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Malaba Homes">

<!-- iOS icons (Safari ignores manifest icons) -->
<link rel="apple-touch-icon" href="/icons/icon-192.png">
<link rel="apple-touch-icon" sizes="192x192" href="/icons/icon-192.png">
<link rel="apple-touch-icon" sizes="152x152" href="/icons/icon-152.png">
<link rel="apple-touch-icon" sizes="144x144" href="/icons/icon-144.png">

<!-- Favicon -->
<link rel="icon" type="image/png" sizes="192x192" href="/icons/icon-192.png">
<link rel="icon" type="image/png" sizes="96x96" href="/icons/icon-96.png">
<link rel="shortcut icon" href="/icons/icon-96.png">

<!-- Windows / Samsung -->
<meta name="msapplication-TileImage" content="/icons/icon-144.png">
<meta name="msapplication-TileColor" content="#080400">
<meta name="application-name" content="Malaba Homes">

<!-- Service Worker -->
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function() {
    navigator.serviceWorker.register('/sw.js', {scope:'/'})
      .then(function(reg){ reg.update(); })
      .catch(function(e){ console.warn('SW failed:', e); });
  });
}
</script>