<?php
/**
 * pwa_install_banner.php — Smart install prompt
 * Include before </body> on index.php ONLY
 * <?php include 'pwa_install_banner.php'; ?>
 */
?>
<style>
/* ── INSTALL BOTTOM SHEET ── */
.pwa-sheet{
  position:fixed;bottom:0;left:0;right:0;z-index:9999;
  background:#0f0800;
  border-top:2px solid #E8521A;
  border-radius:24px 24px 0 0;
  padding:0 0 calc(env(safe-area-inset-bottom,0px) + 8px);
  transform:translateY(105%);
  transition:transform .44s cubic-bezier(.32,1,.68,1);
  box-shadow:0 -12px 48px rgba(0,0,0,.7);
}
.pwa-sheet.visible{transform:translateY(0);}

.pwa-sheet-handle{
  display:flex;justify-content:center;padding:12px 0 0;
}
.pwa-sheet-bar{
  width:40px;height:4px;border-radius:2px;
  background:rgba(255,255,255,.15);
}
.pwa-sheet-body{
  padding:16px 20px 20px;
  display:flex;align-items:center;gap:15px;
}
.pwa-app-icon{
  width:56px;height:56px;border-radius:16px;flex-shrink:0;
  background:linear-gradient(145deg,#E8521A,#F5A623);
  display:flex;align-items:center;justify-content:center;
  font-size:28px;
  box-shadow:0 4px 18px rgba(232,82,26,.45);
  border:1px solid rgba(255,255,255,.1);
}
.pwa-app-info{flex:1;min-width:0;}
.pwa-app-name{
  font-family:'Bebas Neue',system-ui,sans-serif;
  font-size:19px;letter-spacing:.5px;color:#fff;margin-bottom:2px;
}
.pwa-app-desc{font-size:12px;color:rgba(255,255,255,.4);line-height:1.4;}
.pwa-app-meta{
  display:flex;align-items:center;gap:6px;margin-top:5px;
}
.pwa-free-badge{
  font-size:9px;font-weight:700;padding:2px 7px;border-radius:8px;
  background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.25);
  color:#4ade80;letter-spacing:.5px;text-transform:uppercase;
}
.pwa-size-badge{
  font-size:9px;font-weight:700;padding:2px 7px;border-radius:8px;
  background:rgba(255,255,255,.07);
  color:rgba(255,255,255,.4);
}

.pwa-sheet-actions{
  padding:0 20px 12px;
  display:flex;gap:10px;
}
.pwa-install-btn{
  flex:1;padding:14px;
  background:linear-gradient(135deg,#E8521A,#FF7043);
  color:#fff;border:none;border-radius:14px;
  font-family:'Bebas Neue',system-ui,sans-serif;
  font-size:18px;letter-spacing:.5px;
  cursor:pointer;
  box-shadow:0 4px 18px rgba(232,82,26,.4);
  transition:transform .15s;
  display:flex;align-items:center;justify-content:center;gap:8px;
}
.pwa-install-btn:active{transform:scale(.97);}
.pwa-later-btn{
  padding:14px 18px;
  background:rgba(255,255,255,.06);
  border:1px solid rgba(255,255,255,.1);
  border-radius:14px;color:rgba(255,255,255,.5);
  font-family:system-ui,sans-serif;font-size:14px;font-weight:600;
  cursor:pointer;
}
.pwa-later-btn:active{background:rgba(255,255,255,.1);}

/* ── iOS MODAL ── */
.pwa-ios-backdrop{
  position:fixed;inset:0;z-index:9998;
  background:rgba(0,0,0,.75);backdrop-filter:blur(6px);
  display:flex;align-items:flex-end;
  opacity:0;pointer-events:none;
  transition:opacity .25s;
}
.pwa-ios-backdrop.visible{opacity:1;pointer-events:all;}

.pwa-ios-card{
  width:100%;background:#1a1000;
  border-radius:24px 24px 0 0;
  border-top:2px solid rgba(232,82,26,.35);
  padding:20px 20px calc(env(safe-area-inset-bottom,0px)+20px);
}
.pwa-ios-title{
  font-family:'Bebas Neue',system-ui,sans-serif;
  font-size:22px;letter-spacing:.5px;color:#fff;
  text-align:center;margin-bottom:4px;
}
.pwa-ios-sub{font-size:13px;color:rgba(255,255,255,.4);text-align:center;margin-bottom:18px;}

.pwa-ios-step{
  display:flex;align-items:center;gap:14px;
  padding:13px 0;
  border-bottom:1px solid rgba(255,255,255,.06);
}
.pwa-ios-step:last-of-type{border-bottom:none;}
.pwa-ios-step-num{
  width:30px;height:30px;border-radius:50%;flex-shrink:0;
  background:rgba(232,82,26,.15);border:1px solid rgba(232,82,26,.25);
  color:#FF7043;font-weight:800;font-size:13px;
  display:flex;align-items:center;justify-content:center;
}
.pwa-ios-step-ico{font-size:22px;flex-shrink:0;}
.pwa-ios-step-txt{font-size:14px;color:rgba(255,255,255,.75);line-height:1.4;}
.pwa-ios-step-txt strong{color:#fff;}

/* Arrow pointing down for iOS */
.pwa-ios-arrow{
  display:flex;justify-content:center;margin-top:14px;margin-bottom:8px;
}
.pwa-ios-arrow-ico{
  font-size:28px;animation:bounceDown 1.2s ease-in-out infinite;
  color:rgba(232,82,26,.7);
}
@keyframes bounceDown{
  0%,100%{transform:translateY(0);}
  50%{transform:translateY(6px);}
}

.pwa-ios-close-btn{
  width:100%;padding:13px;margin-top:16px;
  background:rgba(255,255,255,.07);
  border:1px solid rgba(255,255,255,.1);border-radius:14px;
  color:rgba(255,255,255,.6);font-family:system-ui,sans-serif;
  font-size:15px;font-weight:600;cursor:pointer;
}
</style>

<!-- INSTALL BOTTOM SHEET -->
<div class="pwa-sheet" id="pwaSheet">
  <div class="pwa-sheet-handle"><div class="pwa-sheet-bar"></div></div>
  <div class="pwa-sheet-body">
    <div class="pwa-app-icon">🏡</div>
    <div class="pwa-app-info">
      <div class="pwa-app-name">Malaba Homes</div>
      <div class="pwa-app-desc">Find homes, order food, shop local</div>
      <div class="pwa-app-meta">
        <span class="pwa-free-badge">FREE</span>
        <span class="pwa-size-badge">No Play Store needed</span>
      </div>
    </div>
  </div>
  <div class="pwa-sheet-actions">
    <button class="pwa-install-btn" id="pwaInstallBtn">
      &#x2B07; Install App
    </button>
    <button class="pwa-later-btn" id="pwaLaterBtn">Later</button>
  </div>
</div>

<!-- iOS STEP-BY-STEP MODAL -->
<div class="pwa-ios-backdrop" id="pwaIosBackdrop">
  <div class="pwa-ios-card">
    <div class="pwa-ios-title">Install Malaba Homes</div>
    <div class="pwa-ios-sub">Follow these 3 quick steps in Safari</div>

    <div class="pwa-ios-step">
      <div class="pwa-ios-step-num">1</div>
      <div class="pwa-ios-step-ico">📤</div>
      <div class="pwa-ios-step-txt">
        Tap the <strong>Share button</strong> at the bottom of Safari
        <br><span style="font-size:11px;color:rgba(255,255,255,.3);">The box with an arrow pointing up</span>
      </div>
    </div>
    <div class="pwa-ios-step">
      <div class="pwa-ios-step-num">2</div>
      <div class="pwa-ios-step-ico">➕</div>
      <div class="pwa-ios-step-txt">
        Scroll down and tap <strong>"Add to Home Screen"</strong>
      </div>
    </div>
    <div class="pwa-ios-step">
      <div class="pwa-ios-step-num">3</div>
      <div class="pwa-ios-step-ico">✅</div>
      <div class="pwa-ios-step-txt">
        Tap <strong>"Add"</strong> in the top-right corner
      </div>
    </div>

    <div class="pwa-ios-arrow">
      <span class="pwa-ios-arrow-ico">&#x2193;</span>
    </div>
    <button class="pwa-ios-close-btn" onclick="closeIosModal()">Got it, I'll follow these steps</button>
  </div>
</div>

<script>
(function() {

  /* ──────────────────────────────────────────────────────
     HELPERS
  ────────────────────────────────────────────────────── */
  var sheet      = document.getElementById('pwaSheet');
  var installBtn = document.getElementById('pwaInstallBtn');
  var laterBtn   = document.getElementById('pwaLaterBtn');
  var iosBackdrop= document.getElementById('pwaIosBackdrop');

  var deferredPrompt = null;

  /* Detect device */
  var ua    = navigator.userAgent || '';
  var isIOS = (/iphone|ipad|ipod/i.test(ua)) && !window.MSStream;
  var isAndroid = /android/i.test(ua);

  /* Is it already installed as PWA? */
  function isInstalled() {
    return (
      window.matchMedia('(display-mode: standalone)').matches ||
      window.navigator.standalone === true ||
      document.referrer.indexOf('android-app://') === 0
    );
  }

  /* Should we show the prompt? */
  function canShow() {
    if (isInstalled()) return false;
    try {
      /* Permanently dismissed */
      if (localStorage.getItem('pwa_done') === '1') return false;
      /* Snoozed for 3 days */
      var snooze = parseInt(localStorage.getItem('pwa_snooze') || '0');
      if (snooze && Date.now() < snooze) return false;
    } catch(e) {}
    return true;
  }

  if (!canShow()) return;

  /* ──────────────────────────────────────────────────────
     ANDROID: capture beforeinstallprompt
     Chrome fires this when the site meets PWA criteria.
     We must call e.preventDefault() to stop the
     mini-infobar and show our own UI instead.
  ────────────────────────────────────────────────────── */
  window.addEventListener('beforeinstallprompt', function(e) {
    e.preventDefault();
    deferredPrompt = e;
    /* Show our sheet after 2.5 seconds */
    setTimeout(function() {
      if (canShow()) sheet.classList.add('visible');
    }, 2500);
  });

  /* ──────────────────────────────────────────────────────
     iOS: show after 3 seconds automatically
     Safari never fires beforeinstallprompt — we show
     the manual-steps modal immediately.
  ────────────────────────────────────────────────────── */
  if (isIOS) {
    setTimeout(function() {
      if (canShow()) sheet.classList.add('visible');
    }, 3000);
  }

  /* ──────────────────────────────────────────────────────
     INSTALL BUTTON TAPPED
  ────────────────────────────────────────────────────── */
  installBtn.addEventListener('click', function() {
    sheet.classList.remove('visible');

    if (isIOS) {
      /* iOS: show step-by-step guide */
      iosBackdrop.classList.add('visible');
      return;
    }

    if (deferredPrompt) {
      /* Android Chrome: trigger native install prompt */
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then(function(choice) {
        deferredPrompt = null;
        if (choice.outcome === 'accepted') {
          try { localStorage.setItem('pwa_done','1'); } catch(e) {}
          showInstalledToast();
        }
      });
      return;
    }

    /* Fallback for Oppo/Xiaomi/Samsung browsers */
    iosBackdrop.classList.add('visible');
  });

  /* ──────────────────────────────────────────────────────
     LATER BUTTON — snooze for 3 days
  ────────────────────────────────────────────────────── */
  laterBtn.addEventListener('click', function() {
    sheet.classList.remove('visible');
    try {
      localStorage.setItem('pwa_snooze', String(Date.now() + 3*24*60*60*1000));
    } catch(e) {}
  });

  /* ──────────────────────────────────────────────────────
     INSTALLED — fires after user completes install
  ────────────────────────────────────────────────────── */
  window.addEventListener('appinstalled', function() {
    sheet.classList.remove('visible');
    iosBackdrop.classList.remove('visible');
    try { localStorage.setItem('pwa_done','1'); } catch(e) {}
    showInstalledToast();
  });

  /* ──────────────────────────────────────────────────────
     TOAST — "App Installed!"
  ────────────────────────────────────────────────────── */
  function showInstalledToast() {
    var t = document.createElement('div');
    t.textContent = '🎉 Malaba Homes installed!';
    t.style.cssText =
      'position:fixed;bottom:calc(80px + env(safe-area-inset-bottom,0px));' +
      'left:50%;transform:translateX(-50%);' +
      'background:#22C55E;color:#fff;' +
      'padding:12px 22px;border-radius:30px;' +
      'font-size:14px;font-weight:700;font-family:system-ui,sans-serif;' +
      'z-index:99999;white-space:nowrap;' +
      'box-shadow:0 6px 20px rgba(34,197,94,.45);' +
      'transition:opacity .4s;';
    document.body.appendChild(t);
    setTimeout(function() { t.style.opacity='0'; }, 2800);
    setTimeout(function() { t.parentNode && t.parentNode.removeChild(t); }, 3300);
  }

  /* Close iOS modal when tapping backdrop */
  iosBackdrop.addEventListener('click', function(e) {
    if (e.target === iosBackdrop) closeIosModal();
  });

  /* Swipe down to dismiss sheet */
  var sheetTsY = 0;
  sheet.addEventListener('touchstart', function(e) {
    sheetTsY = e.touches[0].clientY;
  }, {passive:true});
  sheet.addEventListener('touchend', function(e) {
    if (e.changedTouches[0].clientY - sheetTsY > 60) {
      sheet.classList.remove('visible');
      try { localStorage.setItem('pwa_snooze', String(Date.now() + 3*24*60*60*1000)); } catch(e2) {}
    }
  }, {passive:true});

})();

function closeIosModal() {
  document.getElementById('pwaIosBackdrop').classList.remove('visible');
}
</script>