<?php
/**
 * DYNAMIC SITEMAP - Malaba Homes
 * Auto-generates sitemap from database + static pages
 * SEO Optimized for Google
 */

header('Content-Type: application/xml; charset=utf-8');
header('Cache-Control: public, max-age=3600');

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

require_once './mh-portal-2026/db.php';
$db = getDB();

$baseURL = 'https://malabahomes.com'; 
$today   = date('Y-m-d');

// ====================== STATIC PAGES ======================
$staticPages = [
    '/' => ['priority' => '1.0', 'freq' => 'daily'],
    '/homes_listing.php' => ['priority' => '0.9', 'freq' => 'daily'],
    '/food_listing.php' => ['priority' => '0.9', 'freq' => 'daily'],
    '/shop_listing.php' => ['priority' => '0.9', 'freq' => 'daily'],
    '/video_feed.php' => ['priority' => '0.85', 'freq' => 'daily'],
    '/track_order.php' => ['priority' => '0.7', 'freq' => 'weekly'],
    '/my_orders.php' => ['priority' => '0.6', 'freq' => 'weekly'],
];

foreach ($staticPages as $path => $data) {
    echo "  <url>\n";
    echo "    <loc>" . htmlspecialchars($baseURL . $path) . "</loc>\n";
    echo "    <lastmod>" . $today . "</lastmod>\n";
    echo "    <changefreq>" . $data['freq'] . "</changefreq>\n";
    echo "    <priority>" . $data['priority'] . "</priority>\n";
    echo "  </url>\n";
}

// ====================== DYNAMIC LISTINGS ======================
try {
    $stmt = $db->query("
        SELECT l.id, l.title, l.created_at, c.slug as category_slug 
        FROM listings l 
        JOIN categories c ON l.category_id = c.id 
        WHERE l.is_active = 1 
        ORDER BY l.created_at DESC
    ");

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $url = $baseURL;
        
        if ($row['category_slug'] === 'houses') {
            $url .= '/homes_listing.php?id=' . $row['id'];
        } elseif ($row['category_slug'] === 'food') {
            $url .= '/food_listing.php?id=' . $row['id'];
        } else {
            $url .= '/shop_listing.php?id=' . $row['id'];
        }

        $lastmod = date('Y-m-d', strtotime($row['created_at']));

        echo "  <url>\n";
        echo "    <loc>" . htmlspecialchars($url) . "</loc>\n";
        echo "    <lastmod>" . $lastmod . "</lastmod>\n";
        echo "    <changefreq>weekly</changefreq>\n";
        echo "    <priority>0.8</priority>\n";
        echo "  </url>\n";
    }
} catch (Exception $e) {
    // Silent fail - still show static pages
}

echo '</urlset>';
?>