<?php
$apiBase = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/api';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1">
<meta name="theme-color" content="#080400">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>Order Food — Malaba Homes</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
/* ════════════════════════════════════════
   TOKENS — match homes_listing exactly
════════════════════════════════════════ */
:root{
  --ink:#080400;--ink2:#0f0900;--surface:#151008;--card:#1c1610;
  --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);
  --text:#F5F0EB;--muted:#8a8070;--dim:#5a5040;
  --fire:#E8521A;--fire2:#FF7043;--fire3:#FFB347;
  --green:#2D6A4F;--green2:#52B788;--green3:#86efac;
  --gold:#F5A623;--sky:#38BDF8;--purple:#7c3aed;
  --pizza:#c2410c;--pizza2:#fed7aa;
  --sb:env(safe-area-inset-bottom,0px);--st:env(safe-area-inset-top,0px);
  --r:12px;--rl:20px;--nav:56px;--bnav:62px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
html{overflow-x:hidden;scroll-behavior:smooth;}
body{font-family:'Outfit',sans-serif;background:var(--ink);color:var(--text);min-height:100dvh;overflow-x:hidden;-webkit-font-smoothing:antialiased;padding-bottom:calc(var(--bnav) + var(--sb) + 8px);}
a{color:inherit;text-decoration:none;}
button{cursor:pointer;font-family:inherit;border:none;background:none;}
img{display:block;max-width:100%;}
::-webkit-scrollbar{width:3px;height:3px;}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px;}

/* ════════════════════════════════════════
   HEADER — identical to homes_listing
════════════════════════════════════════ */
.hdr{
  position:sticky;top:0;z-index:200;
  background:rgba(8,4,0,.96);
  backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);
  border-bottom:1px solid var(--border);
  padding-top:var(--st);
}
.hdr-row{height:var(--nav);display:flex;align-items:center;gap:10px;padding:0 14px;}
.back-btn{width:36px;height:36px;border-radius:50%;background:var(--surface);border:1px solid var(--border2);display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:transform .15s;}
.back-btn:active{transform:scale(.9);}
.back-btn svg{width:17px;height:17px;color:var(--text);}
.hdr-brand{flex:1;font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:2px;}
.hdr-brand span{color:var(--fire2);}
.hdr-acts{display:flex;gap:7px;}
.ico-btn{width:36px;height:36px;border-radius:50%;background:var(--surface);border:1px solid var(--border2);display:flex;align-items:center;justify-content:center;font-size:15px;transition:transform .15s;position:relative;}
.ico-btn:active{transform:scale(.9);}
.cart-badge{position:absolute;top:-4px;right:-4px;background:var(--fire);color:#fff;font-size:9px;font-weight:800;width:16px;height:16px;border-radius:50%;display:none;align-items:center;justify-content:center;border:2px solid var(--ink);}
.cart-badge.show{display:flex;}

/* Search */
.srch-row{padding:9px 14px;}
.srch-box{display:flex;align-items:center;gap:9px;background:var(--surface);border:1.5px solid var(--border2);border-radius:30px;padding:0 15px;transition:border-color .2s;}
.srch-box:focus-within{border-color:var(--fire2);}
.srch-box svg{color:var(--muted);flex-shrink:0;width:14px;height:14px;}
.srch-box input{flex:1;padding:11px 0;background:transparent;border:none;outline:none;font-family:inherit;font-size:14px;color:var(--text);}
.srch-box input::placeholder{color:var(--muted);}

/* Chips */
.chips-row{display:flex;gap:7px;padding:0 14px 10px;overflow-x:auto;scrollbar-width:none;}
.chips-row::-webkit-scrollbar{display:none;}
.chip{display:inline-flex;align-items:center;gap:5px;padding:6px 13px;border-radius:30px;border:1px solid var(--border2);background:var(--surface);font-size:12px;font-weight:500;color:var(--muted);white-space:nowrap;flex-shrink:0;transition:all .2s;cursor:pointer;}
.chip.on{background:var(--fire);border-color:var(--fire);color:#fff;font-weight:700;}
.chip:active{transform:scale(.95);}
/* pizza chip special */
.chip-pizza{background:rgba(194,65,12,.15);border-color:rgba(194,65,12,.4);color:var(--pizza2);}
.chip-pizza.on{background:var(--pizza);border-color:var(--pizza);}

/* ════════════════════════════════════════
   🍕 PIZZA SPECIAL BANNER
════════════════════════════════════════ */
.pizza-banner{
  margin:4px 14px 2px;
  border-radius:var(--rl);
  overflow:hidden;position:relative;
  background:linear-gradient(135deg,#1a0500,#2d0a00,#3d1200);
  border:1px solid rgba(194,65,12,.35);
  padding:16px 14px;
  cursor:pointer;transition:all .2s;
  display:flex;align-items:center;gap:14px;
}
.pizza-banner:active{transform:scale(.99);}
.pizza-banner::before{
  content:'🍕';
  position:absolute;right:8px;top:50%;
  transform:translateY(-50%);font-size:68px;opacity:.12;
}
.pb-left{flex:1;position:relative;z-index:1;}
.pb-eyebrow{
  font-size:9px;font-weight:800;letter-spacing:2px;text-transform:uppercase;
  color:var(--pizza2);margin-bottom:5px;
  display:flex;align-items:center;gap:6px;
}
.pb-live-dot{
  width:6px;height:6px;border-radius:50%;background:#ff6b35;
  animation:pdot 1.5s ease infinite;
}
@keyframes pdot{0%,100%{box-shadow:0 0 0 0 rgba(255,107,53,.5)}55%{box-shadow:0 0 0 6px rgba(255,107,53,0)}}
.pb-title{
  font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:.5px;
  color:#fff;margin-bottom:4px;line-height:1.1;
}
.pb-title span{color:var(--fire3);}
.pb-sub{font-size:12px;color:rgba(255,200,150,.55);line-height:1.5;margin-bottom:10px;}
.pb-timer{
  display:inline-flex;align-items:center;gap:6px;
  background:rgba(194,65,12,.2);border:1px solid rgba(194,65,12,.3);
  border-radius:8px;padding:5px 10px;
  font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.5px;color:var(--fire2);
}
.pb-timer-val{color:#fff;}
.pb-right{
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  background:rgba(194,65,12,.2);border:1px solid rgba(194,65,12,.3);
  border-radius:12px;padding:12px 10px;text-align:center;flex-shrink:0;
  min-width:78px;position:relative;z-index:1;
}
.pb-bogo{font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:1px;color:var(--pizza2);margin-bottom:2px;}
.pb-bogo-main{font-family:'Bebas Neue',sans-serif;font-size:26px;color:#fff;line-height:1;margin-bottom:2px;}
.pb-bogo-sub{font-size:9px;color:rgba(255,200,150,.5);letter-spacing:.5px;}

/* When NOT special day — subtle locked state */
.pizza-banner.locked{
  background:linear-gradient(135deg,#110800,#1c0e00);
  border-color:rgba(255,255,255,.06);
  cursor:default;
}
.pizza-banner.locked .pb-live-dot{background:var(--muted);animation:none;}
.pizza-banner.locked .pb-timer{background:rgba(255,255,255,.04);border-color:rgba(255,255,255,.07);}
.pizza-banner.locked .pb-right{background:rgba(255,255,255,.03);border-color:rgba(255,255,255,.06);}

/* Next pizza day indicator */
.next-pizza-tag{
  display:inline-flex;align-items:center;gap:5px;
  background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);
  border-radius:20px;padding:4px 11px;font-size:10px;font-weight:700;color:var(--muted);
  margin:6px 14px 2px;
}

/* ════════════════════════════════════════
   SECTION HEAD
════════════════════════════════════════ */
.sec-head{display:flex;align-items:center;justify-content:space-between;padding:8px 14px;}
.sec-head h2{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.5px;}
.sec-head h2 span{color:var(--fire2);}
.res-count{font-size:11px;color:var(--dim);padding:0 14px 8px;}

/* ════════════════════════════════════════
   FOOD CARDS — full width, rich layout
════════════════════════════════════════ */
.food-list{padding:0 14px;display:flex;flex-direction:column;gap:12px;}

.fcard{
  background:var(--card);border-radius:var(--rl);border:1px solid var(--border);
  overflow:hidden;cursor:pointer;
  animation:fadeUp .38s ease both;
  transition:transform .18s,border-color .18s,box-shadow .18s;
  position:relative;
}
@keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
.fcard:active{transform:scale(.988);}
@media(hover:hover){.fcard:hover{transform:translateY(-3px);box-shadow:0 12px 32px rgba(0,0,0,.5);border-color:var(--border2);}}

/* Pizza flair */
.fcard.pizza-item{border-color:rgba(194,65,12,.22);}
.fcard.pizza-item:hover{border-color:rgba(194,65,12,.45);}
.pizza-deal-tag{
  display:inline-flex;align-items:center;gap:4px;
  font-size:9px;font-weight:800;letter-spacing:.6px;text-transform:uppercase;
  background:rgba(194,65,12,.18);color:var(--pizza2);border:1px solid rgba(194,65,12,.3);
  padding:2px 8px;border-radius:8px;margin-right:6px;
  vertical-align:middle;
}

/* Image */
.fcard-img-wrap{
  position:relative;height:180px;overflow:hidden;
  border-radius:var(--rl) var(--rl) 0 0;
}
@media(min-width:480px){.fcard-img-wrap{height:210px;}}
.fcard-img-wrap img{
  width:100%;height:100%;object-fit:cover;
  transition:transform .5s ease;
}
.fcard:hover .fcard-img-wrap img{transform:scale(1.04);}
.fcard-img-grad{
  position:absolute;inset:0;
  background:linear-gradient(to top,rgba(8,4,0,.92) 0%,rgba(8,4,0,.1) 50%,transparent 100%);
}
.fcard-badges{
  position:absolute;top:10px;left:10px;right:10px;
  display:flex;justify-content:space-between;align-items:flex-start;z-index:2;
}
.fbadge{font-size:10px;font-weight:700;padding:3px 9px;border-radius:20px;backdrop-filter:blur(8px);}
.fb-hot {background:rgba(232,82,26,.85);color:#fff;}
.fb-new {background:rgba(82,183,136,.85);color:#fff;}
.fb-bogo{background:rgba(194,65,12,.9);color:#fff;}
.fb-def {background:rgba(255,255,255,.15);color:#fff;}
.fcard-wish{
  width:30px;height:30px;border-radius:50%;
  background:rgba(8,4,0,.7);backdrop-filter:blur(6px);
  border:1px solid rgba(255,255,255,.12);
  display:flex;align-items:center;justify-content:center;font-size:14px;
  transition:all .2s;
}
.fcard-wish:active{transform:scale(.85);}
.fcard-wish.liked{background:rgba(255,60,60,.2);color:#ff6b6b;}
.fcard-price-tag{
  position:absolute;bottom:12px;left:14px;z-index:2;
  font-family:'Bebas Neue',sans-serif;font-size:22px;color:#fff;
  text-shadow:0 2px 8px rgba(0,0,0,.6);
}

/* Card body */
.fcard-body{padding:12px 14px 4px;}
.fcard-name{font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;margin-bottom:3px;line-height:1.2;}
.fcard-meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:7px;}
.fcard-rat{font-size:12px;color:var(--gold);display:flex;align-items:center;gap:2px;}
.fcard-loc{font-size:11px;color:var(--muted);display:flex;align-items:center;gap:3px;}
.fcard-desc{font-size:12px;color:var(--muted);line-height:1.5;margin-bottom:9px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}

/* Footer CTA */
.fcard-foot{display:flex;gap:7px;padding:8px 14px 13px;}
.btn-add{
  flex:1;padding:10px 12px;
  background:linear-gradient(135deg,var(--fire),var(--fire2));
  color:#fff;border-radius:var(--r);
  font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:.3px;
  transition:all .18s;display:flex;align-items:center;justify-content:center;gap:5px;
  box-shadow:0 3px 12px rgba(232,82,26,.32);
}
.btn-add:active{transform:scale(.96);}
/* Pizza lipa button */
.btn-lipa{
  flex:1;padding:10px 12px;
  background:linear-gradient(135deg,var(--pizza),rgba(194,65,12,.85));
  color:#fff;border-radius:var(--r);
  font-family:'Bebas Neue',sans-serif;font-size:14px;letter-spacing:.3px;
  transition:all .18s;display:flex;align-items:center;justify-content:center;gap:5px;
  box-shadow:0 3px 12px rgba(194,65,12,.3);
}
.btn-lipa:active{transform:scale(.96);}
/* Qty row */
.qty-row{
  display:flex;align-items:center;
  background:var(--surface);border:1px solid var(--border2);border-radius:30px;
  overflow:hidden;flex-shrink:0;
}
.qb{width:28px;height:28px;font-size:15px;font-weight:700;color:var(--text);display:flex;align-items:center;justify-content:center;transition:background .15s;}
.qb:active{background:rgba(232,82,26,.2);}
.qn{padding:0 7px;font-family:'Bebas Neue',sans-serif;font-size:14px;min-width:20px;text-align:center;}
.btn-wa-sm{
  width:42px;border-radius:var(--r);background:#25D366;color:#fff;
  font-size:18px;display:flex;align-items:center;justify-content:center;
  flex-shrink:0;transition:all .18s;box-shadow:0 3px 12px rgba(37,211,102,.28);
}
.btn-wa-sm:active{transform:scale(.94);}

/* ════════════════════════════════════════
   CART STRIP
════════════════════════════════════════ */
.cart-strip{
  position:fixed;bottom:calc(var(--bnav) + var(--sb) + 6px);
  left:12px;right:12px;z-index:190;
  background:var(--fire);border-radius:var(--rl);padding:12px 18px;
  display:flex;align-items:center;justify-content:space-between;
  transform:translateY(calc(160% + 80px));
  transition:transform .4s cubic-bezier(.32,1,.68,1);
  box-shadow:0 8px 28px rgba(232,82,26,.45);
}
.cart-strip.show{transform:translateY(0);}
.cs-left strong{font-family:'Bebas Neue',sans-serif;font-size:15px;color:#fff;letter-spacing:.3px;}
.cs-left span{font-size:11px;color:rgba(255,255,255,.7);}
.cs-cta{background:rgba(255,255,255,.2);color:#fff;padding:9px 18px;border-radius:30px;font-family:'Bebas Neue',sans-serif;font-size:14px;letter-spacing:.3px;}
.cs-cta:active{background:rgba(255,255,255,.3);}

/* ════════════════════════════════════════
   SKELETON
════════════════════════════════════════ */
.skel{background:linear-gradient(90deg,var(--surface) 25%,rgba(255,255,255,.04) 50%,var(--surface) 75%);background-size:200% 100%;animation:shim 1.4s infinite;}
@keyframes shim{0%{background-position:200% 0}100%{background-position:-200% 0}}
.skel-card{background:var(--card);border-radius:var(--rl);overflow:hidden;border:1px solid var(--border);margin-bottom:12px;}
.sk-img{height:180px;}
.sk-body{padding:14px;display:flex;flex-direction:column;gap:9px;}
.sk-ln{height:12px;border-radius:4px;}

/* ════════════════════════════════════════
   BOTTOM NAV — identical to homes_listing
════════════════════════════════════════ */
.bnav{position:fixed;bottom:0;left:0;right:0;z-index:200;height:calc(var(--bnav) + var(--sb));padding-bottom:var(--sb);background:rgba(8,4,0,.95);backdrop-filter:blur(28px);-webkit-backdrop-filter:blur(28px);border-top:1px solid rgba(255,255,255,.07);display:flex;align-items:stretch;}
.bni{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:0 4px;-webkit-tap-highlight-color:transparent;transition:all .2s;position:relative;}
.bni-ico{font-size:20px;color:rgba(255,255,255,.38);transition:all .22s;line-height:1.15;}
.bni-lbl{font-size:9px;font-weight:700;color:rgba(255,255,255,.3);letter-spacing:.5px;text-transform:uppercase;transition:all .22s;}
.bni.active .bni-ico{color:var(--fire2);}
.bni.active .bni-lbl{color:var(--fire2);}
.bni.active::before{content:'';position:absolute;bottom:2px;width:20px;height:2px;border-radius:1px;background:var(--fire2);animation:indIn .3s ease;}
@keyframes indIn{from{width:0;opacity:0;}to{width:20px;opacity:1;}}
.bni-center{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;-webkit-tap-highlight-color:transparent;cursor:pointer;position:relative;}
.bni-center-btn{width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#6366f1);display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:0 -2px 16px rgba(124,58,237,.5);margin-top:-16px;border:3px solid rgba(8,4,0,.95);transition:all .22s;}
.bni-center:active .bni-center-btn{transform:scale(.92);}
.bni-center-lbl{font-size:9px;font-weight:700;color:rgba(139,92,246,.75);letter-spacing:.5px;text-transform:uppercase;}

/* ════════════════════════════════════════
   TOAST
════════════════════════════════════════ */
.toast{position:fixed;bottom:calc(var(--bnav) + var(--sb) + 14px);left:50%;transform:translateX(-50%) translateY(8px);background:var(--text);color:var(--ink);padding:10px 20px;border-radius:30px;font-size:13px;font-weight:600;z-index:999;opacity:0;pointer-events:none;transition:all .22s;white-space:nowrap;box-shadow:0 8px 24px rgba(0,0,0,.4);}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}

/* ════════════════════════════════════════
   OVERLAY + SHEET
════════════════════════════════════════ */
.overlay{position:fixed;inset:0;z-index:400;background:rgba(0,0,0,.82);backdrop-filter:blur(6px);opacity:0;pointer-events:none;transition:opacity .25s;display:flex;align-items:flex-end;}
.overlay.open{opacity:1;pointer-events:all;}
.sheet{width:100%;background:var(--ink2);border-radius:24px 24px 0 0;border:1px solid rgba(255,255,255,.08);transform:translateY(100%);transition:transform .38s cubic-bezier(.32,1,.68,1);max-height:94dvh;overflow-y:auto;padding-bottom:calc(20px + var(--sb));}
.overlay.open .sheet{transform:translateY(0);}
.sh-grip{display:flex;align-items:center;justify-content:space-between;padding:13px 16px 0;}
.sh-handle{width:38px;height:4px;border-radius:2px;background:rgba(255,255,255,.1);}
.sh-x{width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.5);font-size:14px;}
.sh-x:active{transform:scale(.9);}

/* ── FOOD PREVIEW SHEET ── */
.prev-img{width:100%;height:220px;object-fit:cover;}
.prev-body{padding:14px 16px;}
.prev-badge{display:inline-block;font-size:10px;font-weight:700;padding:3px 10px;border-radius:10px;background:rgba(232,82,26,.15);color:var(--fire2);margin-bottom:8px;}
.prev-title{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:.4px;margin-bottom:4px;}
.prev-price{font-family:'Bebas Neue',sans-serif;font-size:26px;color:var(--fire2);margin-bottom:8px;}
.prev-desc{font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:12px;}
.prev-meta{display:flex;gap:14px;font-size:12px;color:var(--muted);margin-bottom:14px;flex-wrap:wrap;}
.prev-feats{display:grid;grid-template-columns:1fr 1fr;gap:8px;background:rgba(255,255,255,.03);border-radius:var(--r);padding:12px;margin-bottom:14px;border:1px solid var(--border);}
.pf{display:flex;align-items:center;gap:7px;font-size:12px;color:var(--muted);}
.pf-i{font-size:15px;}

/* BOGO callout in preview */
.bogo-notice{
  background:linear-gradient(135deg,rgba(194,65,12,.15),rgba(194,65,12,.07));
  border:1px solid rgba(194,65,12,.3);
  border-radius:var(--r);padding:13px 14px;margin-bottom:14px;
  display:flex;align-items:flex-start;gap:10px;
}
.bn-ico{font-size:24px;flex-shrink:0;}
.bn-title{font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.3px;color:var(--pizza2);margin-bottom:3px;}
.bn-sub{font-size:12px;color:rgba(255,200,150,.55);line-height:1.5;}

.btn-primary{
  width:100%;padding:14px;
  background:linear-gradient(135deg,var(--fire),var(--fire2));color:#fff;
  border:none;border-radius:var(--rl);
  font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;
  cursor:pointer;transition:all .2s;margin-bottom:8px;
  box-shadow:0 4px 16px rgba(232,82,26,.3);
  display:flex;align-items:center;justify-content:center;gap:7px;
}
.btn-primary:active{transform:scale(.98);}
.btn-pizza-lipa{
  width:100%;padding:13px;
  background:linear-gradient(135deg,var(--pizza),rgba(194,65,12,.85));color:#fff;
  border:none;border-radius:var(--rl);
  font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.3px;
  cursor:pointer;transition:all .2s;margin-bottom:8px;
  box-shadow:0 4px 16px rgba(194,65,12,.28);
  display:flex;align-items:center;justify-content:center;gap:7px;
}
.btn-pizza-lipa:active{transform:scale(.98);}
.btn-wa-full{
  width:100%;padding:13px;background:#25D366;color:#fff;
  border:none;border-radius:var(--rl);
  font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.3px;
  cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px;
  box-shadow:0 4px 14px rgba(37,211,102,.28);
}
.btn-wa-full:active{transform:scale(.98);}

/* ── CHECKOUT FORM ── */
.bk-steps{display:flex;align-items:center;margin-bottom:18px;}
.bks{display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;}
.bks:last-child{flex:0;flex-shrink:0;}
.bks-dot{width:26px;height:26px;border-radius:50%;border:2px solid var(--border2);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:var(--muted);transition:all .28s;}
.bks-dot.done  {background:var(--green2);border-color:var(--green2);color:#000;font-size:12px;}
.bks-dot.active{background:var(--fire);border-color:var(--fire);color:#fff;box-shadow:0 0 0 4px rgba(232,82,26,.18);}
.bks-lbl{font-size:9px;font-weight:600;color:var(--muted);letter-spacing:.2px;text-align:center;}
.bks-lbl.active{color:var(--fire2);}
.bks-lbl.done  {color:var(--green2);}
.bks-line{flex:1;height:2px;background:var(--border2);margin:0 4px;margin-bottom:14px;transition:background .28s;}
.bks-line.done{background:var(--green2);}
.bk-panel{display:none;animation:panelIn .22s ease;}
.bk-panel.active{display:block;}
@keyframes panelIn{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:translateX(0)}}
.field{margin-bottom:11px;}
.field label{display:block;font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:5px;}
.field input,.field textarea,.field select{width:100%;padding:11px 13px;border-radius:var(--r);background:rgba(255,255,255,.05);border:1.5px solid var(--border2);color:var(--text);font-family:inherit;font-size:14px;outline:none;transition:border-color .2s;}
.field input:focus,.field textarea:focus,.field select:focus{border-color:var(--fire2);}
.field input::placeholder,.field textarea::placeholder{color:rgba(255,255,255,.22);}
.field textarea{resize:vertical;min-height:64px;}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.pay-opts{display:flex;flex-direction:column;gap:8px;margin-bottom:14px;}
.po{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:var(--r);border:2px solid var(--border2);cursor:pointer;transition:all .2s;}
.po.sel{border-color:var(--fire);background:rgba(232,82,26,.07);}
.po:active{transform:scale(.99);}
.po-ico{font-size:20px;}
.po-txt strong{display:block;font-size:14px;font-weight:600;}
.po-txt span{font-size:12px;color:var(--muted);}
.po-dot{width:18px;height:18px;border-radius:50%;border:2px solid var(--muted);margin-left:auto;flex-shrink:0;transition:all .2s;display:flex;align-items:center;justify-content:center;}
.po.sel .po-dot{border-color:var(--fire);background:var(--fire);}
.po.sel .po-dot::after{content:'';width:7px;height:7px;border-radius:50%;background:#fff;}

.cart-sum{background:rgba(255,255,255,.03);border-radius:var(--r);padding:12px;margin-bottom:12px;border:1px solid var(--border);}
.cs-row{display:flex;justify-content:space-between;font-size:13px;color:var(--muted);padding:4px 0;}
.cs-row.tot{font-size:15px;font-weight:700;color:var(--text);padding-top:8px;border-top:1px solid var(--border);margin-top:4px;}

.bk-nav{display:flex;gap:8px;padding-top:4px;}
.bk-back{padding:12px 16px;background:rgba(255,255,255,.06);border:1px solid var(--border2);border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;color:var(--muted);cursor:pointer;}
.bk-next{flex:1;padding:13px;background:linear-gradient(135deg,var(--fire),var(--fire2));color:#fff;border:none;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.3px;cursor:pointer;transition:all .18s;box-shadow:0 4px 16px rgba(232,82,26,.3);}
.bk-next:active{transform:scale(.98);}

/* Processing spinner */
.proc-wrap{text-align:center;padding:40px 20px;}
.spinner{width:44px;height:44px;border:3px solid var(--border2);border-top-color:var(--green2);border-radius:50%;animation:spin .7s linear infinite;margin:0 auto 16px;}
@keyframes spin{to{transform:rotate(360deg)}}

/* Success */
.suc-wrap{text-align:center;padding:28px 0 8px;}
.suc-ico{font-size:54px;margin-bottom:10px;}
.suc-title{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:.5px;margin-bottom:6px;}
.suc-sub{font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:14px;}
.suc-det{background:rgba(255,255,255,.03);border-radius:var(--r);padding:11px;text-align:left;margin-bottom:14px;border:1px solid var(--border);}
.sd-row{display:flex;justify-content:space-between;font-size:13px;padding:5px 0;border-bottom:1px solid var(--border);}
.sd-row:last-child{border-bottom:none;}
.sd-row span:first-child{color:var(--muted);}
.sd-row span:last-child{font-weight:600;}
.bk-wa{width:100%;padding:13px;background:#25D366;color:#fff;border:none;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.3px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px;margin-bottom:8px;transition:all .2s;}
.bk-wa:active{transform:scale(.98);}
.bk-done{width:100%;padding:12px;background:rgba(255,255,255,.05);color:var(--muted);border:1px solid var(--border2);border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;cursor:pointer;}

/* ── LIPA MDOGO MDOGO PIZZA SHEET ── */
.lipa-prod{display:flex;gap:12px;padding:12px 16px 14px;border-bottom:1px solid var(--border);}
.lipa-img{width:64px;height:64px;border-radius:12px;object-fit:cover;flex-shrink:0;}
.lipa-img-ph{width:64px;height:64px;border-radius:12px;background:rgba(255,255,255,.05);display:flex;align-items:center;justify-content:center;font-size:26px;flex-shrink:0;}
.lipa-name{font-family:'Bebas Neue',sans-serif;font-size:16px;color:var(--text);margin-bottom:3px;}
.lipa-price{font-family:'Bebas Neue',sans-serif;font-size:20px;color:var(--fire2);}
.lipa-special-badge{font-size:10px;font-weight:800;color:var(--pizza2);background:rgba(194,65,12,.15);border:1px solid rgba(194,65,12,.25);border-radius:8px;padding:2px 8px;display:inline-block;margin-top:3px;}

/* Next pizza day countdown */
.next-day-box{
  margin:0 16px 14px;padding:12px 14px;
  background:rgba(194,65,12,.08);border:1px solid rgba(194,65,12,.2);
  border-radius:12px;
  display:flex;align-items:center;gap:12px;
}
.ndb-ico{font-size:26px;flex-shrink:0;}
.ndb-title{font-family:'Bebas Neue',sans-serif;font-size:15px;color:var(--pizza2);letter-spacing:.3px;margin-bottom:2px;}
.ndb-count{font-size:12px;color:rgba(255,200,150,.6);line-height:1.5;}
.ndb-days{font-family:'Bebas Neue',sans-serif;font-size:20px;color:#fff;}

/* Payment plans */
.lipa-plans-title{padding:14px 16px 5px;font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;}
.lipa-plans-sub{padding:0 16px 12px;font-size:12px;color:rgba(255,200,150,.5);line-height:1.55;}
.lipa-plan-list{display:flex;flex-direction:column;gap:8px;padding:0 16px 14px;}
.lplan{
  display:flex;align-items:center;gap:11px;padding:13px 14px;
  border-radius:13px;border:2px solid var(--border2);
  background:rgba(255,255,255,.02);cursor:pointer;transition:all .18s;
}
.lplan.sel{border-color:rgba(194,65,12,.5);background:rgba(194,65,12,.08);}
.lplan-radio{width:18px;height:18px;border-radius:50%;border:2px solid rgba(255,255,255,.2);flex-shrink:0;display:flex;align-items:center;justify-content:center;transition:all .18s;}
.lplan.sel .lplan-radio{background:var(--pizza);border-color:var(--pizza);}
.lplan.sel .lplan-radio::after{content:'';width:7px;height:7px;border-radius:50%;background:#fff;}
.lplan-info{flex:1;}
.lplan-name{font-size:13px;font-weight:700;color:var(--text);margin-bottom:1px;}
.lplan-detail{font-size:11px;color:var(--muted);}
.lplan-right{text-align:right;flex-shrink:0;}
.lplan-amount{font-family:'Bebas Neue',sans-serif;font-size:17px;color:var(--pizza2);}
.lplan-when{font-size:9px;color:var(--muted);}

/* Pay-first rule */
.lipa-rule{
  margin:0 16px 12px;padding:10px 13px;
  background:rgba(194,65,12,.07);border:1px solid rgba(194,65,12,.18);
  border-radius:10px;font-size:12px;color:rgba(255,200,150,.7);line-height:1.55;
}
.lipa-rule strong{color:var(--pizza2);}

/* Lipa details fields */
.lipa-submit{
  margin:4px 16px 0;width:calc(100% - 32px);padding:14px;
  background:linear-gradient(135deg,var(--pizza),rgba(194,65,12,.85));color:#fff;
  border:none;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;
  cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px;
  box-shadow:0 5px 20px rgba(194,65,12,.32);transition:all .18s;
}
.lipa-submit:active{transform:scale(.98);}
.lipa-submit:disabled{opacity:.45;pointer-events:none;}
</style>
</head>
<body>

<!-- ════════════════ HEADER ════════════════ -->
<header class="hdr">
  <div class="hdr-row">
    <a href="index.php" class="back-btn">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M19 12H5M5 12l7-7M5 12l7 7"/></svg>
    </a>
    <div class="hdr-brand">Malaba <span>Food</span></div>
    <div class="hdr-acts">
      <button class="ico-btn" onclick="openCheckout()" title="View Cart">
        &#x1F6D2;
        <span class="cart-badge" id="cartBadge">0</span>
      </button>
    </div>
  </div>

  <div class="srch-row">
    <div class="srch-box">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      <input type="search" id="srchInput" placeholder="Search food, restaurant, dish…" autocomplete="off" enterkeyhint="search">
    </div>
  </div>

  <div class="chips-row" id="chipsRow">
    <button class="chip on" data-f="">&#x1F374; All</button>
    <button class="chip chip-pizza" data-f="pizza">&#x1F355; Pizza</button>
    <button class="chip" data-f="burger">&#x1F354; Burgers</button>
    <button class="chip" data-f="rice">&#x1F35A; Rice</button>
    <button class="chip" data-f="pilau">&#x1F35B; Pilau</button>
    <button class="chip" data-f="meat">&#x1F969; Nyama</button>
    <button class="chip" data-f="snack">&#x1F960; Snacks</button>
    <button class="chip" data-f="vegetarian">&#x1F331; Veg</button>
  </div>
</header>

<!-- ════════════════ PIZZA SPECIAL BANNER ════════════════ -->
<div id="pizzaBannerWrap"></div>

<!-- ════════════════ SECTION HEAD ════════════════ -->
<div class="sec-head">
  <h2>&#x1F354; <span id="sectionTitle">Order</span> Now</h2>
  <span id="resCount" style="font-size:11px;color:var(--dim);"></span>
</div>

<!-- ════════════════ FOOD LIST ════════════════ -->
<div class="food-list" id="foodList">
  <div class="skel-card"><div class="sk-img skel"></div><div class="sk-body"><div class="sk-ln skel" style="width:70%"></div><div class="sk-ln skel" style="width:50%"></div></div></div>
  <div class="skel-card"><div class="sk-img skel"></div><div class="sk-body"><div class="sk-ln skel" style="width:80%"></div><div class="sk-ln skel" style="width:45%"></div></div></div>
  <div class="skel-card"><div class="sk-img skel"></div><div class="sk-body"><div class="sk-ln skel" style="width:65%"></div><div class="sk-ln skel" style="width:55%"></div></div></div>
</div>

<!-- ════════════════ CART STRIP ════════════════ -->
<div class="cart-strip" id="cartStrip">
  <div class="cs-left">
    <strong id="csItems">0 items</strong><br>
    <span id="csTotal">KSH 0</span>
  </div>
  <button class="cs-cta" onclick="openCheckout()">View Order &rarr;</button>
</div>

<!-- ════════════════ BOTTOM NAV (identical to homes_listing) ════════════════ -->
<nav class="bnav">
  <a href="index.php" class="bni">
    <div class="bni-ico">&#x1F3E1;</div>
    <div class="bni-lbl">Home</div>
  </a>
  <a href="homes_listing.php" class="bni">
    <div class="bni-ico">&#x1F3E0;</div>
    <div class="bni-lbl">Homes</div>
  </a>
  <a href="video_feed.php" class="bni-center">
    <div class="bni-center-btn">&#x25B6;</div>
    <div class="bni-center-lbl">Watch</div>
  </a>
  <a href="food_listing.php" class="bni active">
    <div class="bni-ico">&#x1F354;</div>
    <div class="bni-lbl">Food</div>
  </a>
  <a href="shop_listing.php" class="bni">
    <div class="bni-ico">&#x1F6D2;</div>
    <div class="bni-lbl">Shop</div>
  </a>
</nav>

<!-- ════════════════ OVERLAY ════════════════ -->
<div class="overlay" id="overlay" onclick="handleOvClick(event)">
  <div class="sheet" id="mainSheet">
    <div id="sheetContent"></div>
  </div>
</div>

<div class="toast" id="toast"></div>
<script src="data.js" onerror="window.MalabaAPI=null"></script>
<script src="mh_user.js" onerror="window.MhUser=null"></script>
<script>
/* ════════════════════════════════════════
   API BASE
════════════════════════════════════════ */
var API_BASE = (function(){
  var s = document.querySelectorAll('script[src]');
  for(var i=0;i<s.length;i++){if(s[i].src&&s[i].src.indexOf('data.js')!==-1)return s[i].src.replace(/\/data\.js[^\/]*$/,'/api');}
  return '<?php echo htmlspecialchars($apiBase, ENT_QUOTES); ?>';
})();

/* ════════════════════════════════════════
   PIZZA DAY ENGINE
   Special days: Wednesday (3) and Saturday (6) [getDay()]
════════════════════════════════════════ */
var PIZZA_DAYS = [3, 6]; // Wed=3, Sat=6

function getPizzaStatus() {
  var now     = new Date();
  var day     = now.getDay();       // 0=Sun … 6=Sat
  var hour    = now.getHours();
  var isToday = PIZZA_DAYS.indexOf(day) !== -1;
  var isActive= isToday && hour >= 0 && hour < 24; // active all-day on special days

  /* Find next special day */
  var daysUntil = Infinity, nextDay = null;
  for(var offset=1; offset<=7; offset++){
    var check = (day + offset) % 7;
    if(PIZZA_DAYS.indexOf(check) !== -1){
      daysUntil = offset; nextDay = check; break;
    }
  }
  var NAMES = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  var FULL  = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

  /* Time remaining today if active */
  var endOfDay = new Date(now);
  endOfDay.setHours(23,59,59,999);
  var msLeft  = endOfDay - now;
  var hLeft   = Math.floor(msLeft/3600000);
  var mLeft   = Math.floor((msLeft%3600000)/60000);

  return {
    isActive:   isActive,
    isToday:    isToday,
    daysUntil:  daysUntil,
    nextDayName:FULL[nextDay] || '',
    nextDayShort:NAMES[nextDay] || '',
    hLeft:      hLeft,
    mLeft:      mLeft,
    dayName:    FULL[day],
  };
}

/* ════════════════════════════════════════
   BUILD PIZZA BANNER
════════════════════════════════════════ */
function buildPizzaBanner() {
  var ps  = getPizzaStatus();
  var wrap= document.getElementById('pizzaBannerWrap');
  if (!wrap) return;

  if (ps.isActive) {
    wrap.innerHTML =
      '<div class="pizza-banner" onclick="filterPizza()">' +
        '<div class="pb-left">' +
          '<div class="pb-eyebrow"><div class="pb-live-dot"></div> TODAY ONLY &bull; PIZZA SPECIAL</div>' +
          '<div class="pb-title">Buy One, <span>Get One Free!</span></div>' +
          '<div class="pb-sub">Every pizza today is Buy 1 Get 1 FREE. Limited time!</div>' +
          '<div class="pb-timer">&#x23F1; Ends in <span class="pb-timer-val" id="pizzaCountdown">'+pad(ps.hLeft)+'h '+pad(ps.mLeft)+'m</span></div>' +
        '</div>' +
        '<div class="pb-right">' +
          '<div class="pb-bogo">DEAL</div>' +
          '<div class="pb-bogo-main">2&#x00D7;1</div>' +
          '<div class="pb-bogo-sub">PIZZAS</div>' +
        '</div>' +
      '</div>';
    // Tick down
    startPizzaTimer();
  } else {
    wrap.innerHTML =
      '<div class="pizza-banner locked">' +
        '<div class="pb-left">' +
          '<div class="pb-eyebrow"><div class="pb-live-dot"></div> PIZZA SPECIAL &bull; WED &amp; SAT</div>' +
          '<div class="pb-title">Buy One, <span>Get One Free</span></div>' +
          '<div class="pb-sub">Next special day: <strong>'+ps.nextDayName+'</strong> (in '+ps.daysUntil+' day'+(ps.daysUntil===1?'':'s')+').</div>' +
          '<div class="pb-timer" style="cursor:default">&#x1F4C5; Next: <span class="pb-timer-val">'+ps.nextDayShort+'</span></div>' +
        '</div>' +
        '<div class="pb-right">' +
          '<div class="pb-bogo">NEXT</div>' +
          '<div class="pb-bogo-main" style="font-size:18px">'+ps.daysUntil+'d</div>' +
          '<div class="pb-bogo-sub">AWAY</div>' +
        '</div>' +
      '</div>' +
      '<div class="next-pizza-tag">&#x1F355; Use <strong>Lipa Mdogo Mdogo</strong> on pizza specials — pay daily until Wed/Sat &amp; get your pizza then!</div>';
  }
}

function startPizzaTimer() {
  setInterval(function(){
    var ps = getPizzaStatus();
    var el = document.getElementById('pizzaCountdown');
    if(el) el.textContent = pad(ps.hLeft)+'h '+pad(ps.mLeft)+'m';
    if(!ps.isActive) buildPizzaBanner(); // refresh when day ends
  }, 30000);
}
function pad(n){ return n<10?'0'+n:String(n); }

function filterPizza() {
  document.querySelectorAll('.chip').forEach(function(c){
    c.classList.toggle('on', c.dataset.f==='pizza');
  });
  activeFilter='pizza';
  renderFood(getFiltered());
  document.getElementById('sectionTitle').textContent='Pizza';
}

/* ════════════════════════════════════════
   STATE
════════════════════════════════════════ */
var allFood  = [];
var cart     = [];
var qtys     = {};
var wishlist = [];
var activeFilter = '';
var currentItem  = null;
var orderPay     = 'mpesa';
var ckStep       = 1;
var selectedPlan = null;
var lipaItem     = null;

try { cart     = JSON.parse(localStorage.getItem('mh_food_cart')  || '[]'); } catch(e){}
try { wishlist = JSON.parse(localStorage.getItem('mh_food_wish')  || '[]'); } catch(e){}

/* ════════════════════════════════════════
   INIT
════════════════════════════════════════ */
(function init(){
  buildPizzaBanner();

  var xhr = new XMLHttpRequest();
  xhr.open('GET', API_BASE+'/listings.php?type=food&limit=60&sort=smart', true);
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout = 9000;
  xhr.onload = function() {
    try {
      var d = JSON.parse(xhr.responseText);
      if(d && d.success && d.data && d.data.length){
        allFood = d.data; renderFood(allFood); updateCart(); return;
      }
    } catch(e){}
    loadFallback();
  };
  xhr.onerror = xhr.ontimeout = function(){ loadFallback(); };
  xhr.send();

  // Chip filter wiring
  document.querySelectorAll('.chip').forEach(function(c){
    c.addEventListener('click', function(){
      document.querySelectorAll('.chip').forEach(function(x){ x.classList.remove('on'); });
      c.classList.add('on');
      activeFilter = c.dataset.f;
      var title = activeFilter ? c.textContent.replace(/^[^\s]+ /,'') : 'Order';
      document.getElementById('sectionTitle').textContent = title;
      renderFood(getFiltered());
    });
  });

  // Search
  var st;
  document.getElementById('srchInput').addEventListener('input', function(){
    clearTimeout(st); st = setTimeout(function(){ renderFood(getFiltered()); }, 280);
  });

  // Swipe-down sheet close
  document.getElementById('mainSheet').addEventListener('touchstart', function(e){ window._tsY = e.touches[0].clientY; },{passive:true});
  document.getElementById('mainSheet').addEventListener('touchend',   function(e){
    if(e.changedTouches[0].clientY - window._tsY > 80 && document.getElementById('mainSheet').scrollTop === 0) closeOverlay();
  },{passive:true});
})();

function loadFallback() {
  allFood = [
    {id:'f1',type:'food',title:'Nyama Choma Platter',price:'KSH 800',image:'https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=800&q=80',contact_phone:'254700000000',location:'Malaba Town',rating:'4.8',prep_time:'25 min',description:'Juicy grilled meat with ugali and kachumbari.'},
    {id:'f2',type:'food',title:'Chicken Burger Combo',price:'KSH 450',image:'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80',contact_phone:'254700000000',location:'CBD',rating:'4.7',prep_time:'15 min',badge:'🔥 Bestseller',description:'Crispy chicken burger with fries and cold drink.'},
    {id:'p1',type:'food',title:'Margherita Pizza',price:'KSH 650',image:'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&q=80',contact_phone:'254700000000',location:'Malaba Town',rating:'4.9',prep_time:'20 min',badge:'🍕 Special',sub_category:'pizza',description:'Classic Italian pizza with fresh tomato sauce and mozzarella.'},
    {id:'p2',type:'food',title:'Pepperoni Pizza',price:'KSH 750',image:'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=800&q=80',contact_phone:'254700000000',location:'Malaba Town',rating:'4.8',prep_time:'22 min',badge:'🍕 Special',sub_category:'pizza',description:'Loaded pepperoni with extra cheese on thin crust.'},
    {id:'f3',type:'food',title:'Pilau Special',price:'KSH 350',image:'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=800&q=80',contact_phone:'254700000000',location:'Malaba Market',rating:'4.6',prep_time:'10 min',description:'Aromatic Kenyan pilau with beef or chicken.'},
    {id:'f4',type:'food',title:'Fish & Chips',price:'KSH 500',image:'https://images.unsplash.com/photo-1585032226651-759b368d7246?w=800&q=80',contact_phone:'254700000000',location:'Riverside',rating:'4.7',prep_time:'18 min',description:'Crispy tilapia with seasoned fries.'},
  ];
  renderFood(allFood); updateCart();
}

/* ════════════════════════════════════════
   HELPERS
════════════════════════════════════════ */
function isPizza(item) {
  var t = ((item.title||'')+(item.sub_category||'')+(item.description||'')+(item.badge||'')).toLowerCase();
  return t.indexOf('pizza') !== -1;
}
function getBadgeCls(b){
  if(!b) return 'fb-def';
  var l = String(b).toLowerCase();
  if(l.indexOf('hot')!==-1||l.indexOf('best')!==-1) return 'fb-hot';
  if(l.indexOf('new')!==-1) return 'fb-new';
  if(l.indexOf('pizza')!==-1||l.indexOf('bogo')!==-1) return 'fb-bogo';
  return 'fb-def';
}
function px(s){ var n=parseInt((s||'').replace(/[^0-9]/g,'')); return isNaN(n)?0:n; }
function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function normWA(p){ var d=(p||'').replace(/\D/g,''); if(d.length===9)return'254'+d; if(d.length===10&&d[0]==='0')return'254'+d.substring(1); if(d.length===12&&d.substring(0,3)==='254')return d; return d||'254700000000'; }
function showToast(msg){ var t=document.getElementById('toast'); t.innerHTML=msg; t.classList.add('show'); setTimeout(function(){t.classList.remove('show');},2400); }
function openOverlay()  { document.getElementById('overlay').classList.add('open'); document.body.style.overflow='hidden'; }
function closeOverlay() { document.getElementById('overlay').classList.remove('open'); document.body.style.overflow=''; }
function handleOvClick(e){ if(e.target===e.currentTarget) closeOverlay(); }
function prefill(nId,pId,aId){
  var d=null;
  try{ if(window.MhUser) d=MhUser.getDetails(); else d=JSON.parse(localStorage.getItem('mh_user_details')||'null'); }catch(e){}
  if(!d) return;
  var ne=document.getElementById(nId),pe=document.getElementById(pId);
  if(ne&&d.name&&!ne.value)ne.value=d.name;
  if(pe&&d.phone&&!pe.value)pe.value=d.phone;
  if(aId){var ae=document.getElementById(aId);if(ae&&d.address&&!ae.value)ae.value=d.address;}
}
function saveUser(n,p,a){
  try{
    var d={name:n,phone:p};if(a)d.address=a;
    if(window.MhUser) MhUser.saveDetails(d);
    else localStorage.setItem('mh_user_details',JSON.stringify(d));
  }catch(e){}
}

/* ════════════════════════════════════════
   FILTER
════════════════════════════════════════ */
function getFiltered(){
  var q = (document.getElementById('srchInput').value||'').toLowerCase();
  return allFood.filter(function(f){
    var mq = !q||((f.title||'')+(f.location||'')+(f.description||'')).toLowerCase().indexOf(q)!==-1;
    var mf = !activeFilter||(
      (f.title||'').toLowerCase().indexOf(activeFilter)!==-1||
      (f.description||'').toLowerCase().indexOf(activeFilter)!==-1||
      (f.sub_category||'').toLowerCase().indexOf(activeFilter)!==-1||
      (f.badge||'').toLowerCase().indexOf(activeFilter)!==-1
    );
    return mq && mf;
  });
}

/* ════════════════════════════════════════
   RENDER FOOD CARDS
════════════════════════════════════════ */
function renderFood(items){
  var ps   = getPizzaStatus();
  var list = document.getElementById('foodList');
  var cnt  = document.getElementById('resCount');
  if(cnt) cnt.textContent = items.length + ' item' + (items.length!==1?'s':'') + ' available';

  if(!items.length){
    list.innerHTML='<div style="text-align:center;padding:44px 20px;"><div style="font-size:48px;margin-bottom:12px;">😕</div><div style="font-family:\'Bebas Neue\',sans-serif;font-size:20px;margin-bottom:6px;">Nothing found</div><div style="font-size:13px;color:var(--muted);">Try another category or clear search</div></div>';
    return;
  }

  var html = '';
  items.forEach(function(f, i){
    if(!qtys[f.id]) qtys[f.id]=1;
    var inCart  = cart.find(function(c){return c.id===f.id;});
    var liked   = wishlist.indexOf(f.id) !== -1;
    var pz      = isPizza(f);
    var img     = f.image||f.image_url||'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80';
    var phone   = (f.contact&&f.contact.phone)?f.contact.phone:(f.contact_phone||'');
    var waNum   = normWA(phone);
    var waMsg   = encodeURIComponent('Hi! I\'d like to order *'+f.title+'* ('+f.price+') from Malaba Food.');
    var bdgCls  = getBadgeCls(f.badge);
    var displayBadge = f.badge ? f.badge : (pz&&ps.isActive?'&#x1F355; BOGO TODAY':'');

    html +=
      '<div class="fcard'+(pz?' pizza-item':'')+'" style="animation-delay:'+(Math.min(i,6)*.07)+'s">' +
        '<div class="fcard-img-wrap" onclick="openPreview(\''+esc(f.id)+'\')">' +
          '<img src="'+esc(img)+'" alt="'+esc(f.title)+'" loading="lazy" onerror="this.src=\'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80\'">' +
          '<div class="fcard-img-grad"></div>' +
          '<div class="fcard-badges">' +
            (displayBadge?'<div class="fbadge '+bdgCls+'">'+displayBadge+'</div>':'<div></div>') +
            '<button class="fcard-wish'+(liked?' liked':'')+'" onclick="toggleWish(event,\''+esc(f.id)+'\',this)">'+(liked?'&#x2665;':'&#x2661;')+'</button>' +
          '</div>' +
          '<div class="fcard-price-tag">'+esc(f.price)+'</div>' +
        '</div>' +

        '<div class="fcard-body" onclick="openPreview(\''+esc(f.id)+'\')">' +
          '<div class="fcard-name">'+(pz&&ps.isActive?'<span class="pizza-deal-tag">2&times;1</span>':'')+esc(f.title)+'</div>' +
          '<div class="fcard-meta">' +
            (f.rating?'<span class="fcard-rat">&#x2605; '+parseFloat(f.rating).toFixed(1)+'</span>':'')+
            (f.prep_time?'<span>&#x23F1; '+(f.prep_time||'20 min')+'</span>':'')+
            (f.location?'<span class="fcard-loc">&#x1F4CD; '+esc((f.location||'').split(',')[0])+'</span>':'') +
          '</div>' +
          (f.description?'<div class="fcard-desc">'+esc((f.description||'').substring(0,90))+'</div>':'') +
        '</div>' +

        '<div class="fcard-foot">' +
          (inCart ?
            '<div class="qty-row">'+
              '<button class="qb" onclick="changeQty(\''+esc(f.id)+'\',-1)">&#x2212;</button>'+
              '<span class="qn" id="qn-'+esc(f.id)+'">'+inCart.qty+'</span>'+
              '<button class="qb" onclick="changeQty(\''+esc(f.id)+'\',1)">+</button>'+
            '</div>'
          :
            '<button class="btn-add" onclick="addToCart(\''+esc(f.id)+'\')">&#x1F6D2; Add '+esc(f.price)+'</button>'
          ) +
          (pz && ps.isActive ?
            '<button class="btn-lipa" onclick="openPizzaLipa(\''+esc(f.id)+'\')" title="Pay Later">&#x1F4B0; Lipa Later</button>'
          : '') +
          '<a class="btn-wa-sm" href="https://wa.me/'+waNum+'?text='+waMsg+'" target="_blank" rel="noopener">&#x1F4AC;</a>' +
        '</div>' +
      '</div>';
  });
  list.innerHTML = html;
}

/* ════════════════════════════════════════
   WISHLIST
════════════════════════════════════════ */
function toggleWish(ev,id,btn){
  ev.stopPropagation();
  var i=wishlist.indexOf(id);
  if(i!==-1){wishlist.splice(i,1);btn.innerHTML='&#x2661;';btn.classList.remove('liked');showToast('Removed from saved');}
  else{wishlist.unshift(id);btn.innerHTML='&#x2665;';btn.classList.add('liked');showToast('&#x2665; Saved!');}
  localStorage.setItem('mh_food_wish',JSON.stringify(wishlist));
}

/* ════════════════════════════════════════
   CART MANAGEMENT
════════════════════════════════════════ */
function addToCart(id){
  var item=allFood.find(function(f){return f.id===id;}); if(!item) return;
  var q=qtys[id]||1;
  var ex=cart.find(function(c){return c.id===id;});
  if(ex){ex.qty+=q;}
  else{cart.push({id:id,title:item.title,price:item.price,qty:q,phone:(item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'')});}
  localStorage.setItem('mh_food_cart',JSON.stringify(cart));
  updateCart(); showToast('&#x1F6D2; '+item.title+' added!');
  renderFood(getFiltered());
}
function changeQty(id,d){
  var ex=cart.find(function(c){return c.id===id;}); if(!ex) return;
  ex.qty=Math.max(0,ex.qty+d);
  if(!ex.qty) cart=cart.filter(function(c){return c.id!==id;});
  localStorage.setItem('mh_food_cart',JSON.stringify(cart));
  updateCart();
  var el=document.getElementById('qn-'+id); if(el) el.textContent=ex.qty||0;
  if(!ex.qty||ex.qty===0) renderFood(getFiltered());
}
function updateCart(){
  var n   = cart.reduce(function(s,c){return s+c.qty;},0);
  var tot = cart.reduce(function(s,c){return s+px(c.price)*c.qty;},0);
  var bdg = document.getElementById('cartBadge');
  bdg.textContent=n; bdg.classList.toggle('show',n>0);
  document.getElementById('csItems').textContent=n+' item'+(n!==1?'s':'');
  document.getElementById('csTotal').textContent='KSH '+tot.toLocaleString();
  document.getElementById('cartStrip').classList.toggle('show',n>0);
}

/* ════════════════════════════════════════
   FOOD PREVIEW SHEET
════════════════════════════════════════ */
function openPreview(id){
  currentItem=allFood.find(function(f){return f.id===id;}); if(!currentItem) return;
  var ps    = getPizzaStatus();
  var pz    = isPizza(currentItem);
  var img   = currentItem.image||currentItem.image_url||'';
  var phone = (currentItem.contact&&currentItem.contact.phone)?currentItem.contact.phone:(currentItem.contact_phone||'');
  var waNum = normWA(phone);
  var waMsg = encodeURIComponent('Hi! I\'d like to order *'+currentItem.title+'* ('+currentItem.price+') from Malaba Food.');

  var bogoHTML = (pz&&ps.isActive) ?
    '<div class="bogo-notice">' +
      '<div class="bn-ico">&#x1F355;</div>' +
      '<div><div class="bn-title">&#x1F389; BUY 1 GET 1 FREE TODAY!</div>' +
      '<div class="bn-sub">Order this pizza now and get a second one FREE. Offer ends '+pad(ps.hLeft)+'h '+pad(ps.mLeft)+'m.</div></div>' +
    '</div>' : (pz&&!ps.isActive?
    '<div style="background:rgba(194,65,12,.07);border:1px solid rgba(194,65,12,.18);border-radius:var(--r);padding:11px 13px;margin-bottom:14px;font-size:12px;color:rgba(255,200,150,.6);">' +
      '&#x1F4C5; <strong style="color:var(--pizza2)">Pizza BOGO deal</strong> returns on '+getPizzaStatus().nextDayName+'. Use <em>Lipa Mdogo Mdogo</em> to pre-pay now and collect on that day!' +
    '</div>' : '');

  var featHTML = (currentItem.features&&currentItem.features.length) ?
    '<div class="prev-feats">' +
    currentItem.features.map(function(f){return '<div class="pf"><span class="pf-i">'+(f.icon||'✅')+'</span>'+esc(f.text||f.feature_text||'')+'</div>';}).join('') +
    '</div>' : '';

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-grip"><div class="sh-handle"></div><button class="sh-x" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<img src="'+esc(img)+'" class="prev-img" loading="lazy" onerror="this.src=\'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80\'">' +
    '<div class="prev-body">' +
      (currentItem.badge?'<div class="prev-badge">'+esc(currentItem.badge)+'</div>':'') +
      '<div class="prev-title">'+esc(currentItem.title||'')+'</div>' +
      '<div class="prev-price">'+esc(currentItem.price||'')+'</div>' +
      '<div class="prev-desc">'+esc(currentItem.description||'')+'</div>' +
      '<div class="prev-meta">' +
        (currentItem.prep_time?'<span>&#x23F1; '+esc(currentItem.prep_time)+'</span>':'')+
        (currentItem.location?'<span>&#x1F4CD; '+esc((currentItem.location||'').split(',')[0])+'</span>':'')+
        (currentItem.rating?'<span>&#x2605; '+parseFloat(currentItem.rating).toFixed(1)+'</span>':'')+
      '</div>' +
      bogoHTML +
      featHTML +
      '<button class="btn-primary" onclick="addToCart(\''+esc(id)+'\');closeOverlay();">&#x1F6D2; Add to Cart &mdash; '+esc(currentItem.price||'')+'</button>' +
      (pz&&ps.isActive?
        '<button class="btn-pizza-lipa" onclick="closeOverlay();openPizzaLipa(\''+esc(id)+'\');">&#x1F4B0; Lipa Mdogo Mdogo &mdash; Pay Later</button>' : '') +
      (pz&&!ps.isActive?
        '<button class="btn-pizza-lipa" onclick="closeOverlay();openPizzaLipa(\''+esc(id)+'\');">&#x1F4B0; Pre-Pay for '+getPizzaStatus().nextDayName+'</button>' : '') +
      '<button class="btn-wa-full" onclick="window.open(\'https://wa.me/'+waNum+'?text='+waMsg+'\',\'_blank\')">&#x1F4AC; Order via WhatsApp</button>' +
    '</div>';
  openOverlay();
}

/* ════════════════════════════════════════
   CHECKOUT (3-step)
════════════════════════════════════════ */
function openCheckout(){
  if(!cart.length){ showToast('Your cart is empty'); return; }
  ckStep=1;
  var sub=cart.reduce(function(s,c){return s+px(c.price)*c.qty;},0);
  var dlv=50, tot=sub+dlv;
  window._ckTot=tot; window._ckDlv=dlv; orderPay='mpesa';

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-grip"><div class="sh-handle"></div><button class="sh-x" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<div style="padding:12px 16px 0;">' +

    /* Steps */
    '<div class="bk-steps">' +
      '<div class="bks"><div class="bks-dot active" id="bkD1">1</div><div class="bks-lbl active" id="bkL1">Details</div></div>' +
      '<div class="bks-line" id="bkLn1"></div>' +
      '<div class="bks"><div class="bks-dot" id="bkD2">2</div><div class="bks-lbl" id="bkL2">Payment</div></div>' +
      '<div class="bks-line" id="bkLn2"></div>' +
      '<div class="bks"><div class="bks-dot" id="bkD3">3</div><div class="bks-lbl" id="bkL3">Confirm</div></div>' +
    '</div>' +

    /* Panel 1 */
    '<div class="bk-panel active" id="ckP1">' +
      '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:20px;letter-spacing:.3px;margin-bottom:4px;">Your Details</div>' +
      '<div style="font-size:12px;color:var(--muted);margin-bottom:14px;">Tell us where to deliver</div>' +
      '<div class="row2"><div class="field"><label>Full Name *</label><input id="ck_name" type="text" placeholder="Kevin Otieno" autocomplete="name"></div>' +
      '<div class="field"><label>Phone *</label><input id="ck_phone" type="tel" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div></div>' +
      '<div class="field"><label>Delivery Address *</label><input id="ck_addr" type="text" placeholder="e.g. Near Malaba Market, Gate 3"></div>' +
      '<div class="field"><label>Special Instructions</label><textarea id="ck_note" placeholder="e.g. No onions, call when near…" style="min-height:52px;resize:none;"></textarea></div>' +
    '</div>' +

    /* Panel 2 */
    '<div class="bk-panel" id="ckP2">' +
      '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:20px;letter-spacing:.3px;margin-bottom:4px;">How to Pay?</div>' +
      '<div style="font-size:12px;color:var(--muted);margin-bottom:14px;">Choose your payment method</div>' +
      '<div class="pay-opts">' +
        '<div class="po sel" id="po_mpesa" onclick="selPay(\'mpesa\',this)"><div class="po-ico">&#x1F4F1;</div><div class="po-txt"><strong>M-Pesa</strong><span>STK push to your Safaricom number</span></div><div class="po-dot"></div></div>' +
        '<div class="po" id="po_cash" onclick="selPay(\'cash\',this)"><div class="po-ico">&#x1F4B5;</div><div class="po-txt"><strong>Cash on Delivery</strong><span>Pay when food arrives at your door</span></div><div class="po-dot"></div></div>' +
      '</div>' +
      '<div id="mpesaField" class="field"><label>M-Pesa Number *</label><input id="ck_mpesa" type="tel" placeholder="0712 345 678" inputmode="numeric"></div>' +
    '</div>' +

    /* Panel 3 */
    '<div class="bk-panel" id="ckP3">' +
      '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:20px;letter-spacing:.3px;margin-bottom:4px;">Confirm Order</div>' +
      '<div style="font-size:12px;color:var(--muted);margin-bottom:14px;">Review before placing</div>' +
      '<div class="cart-sum" id="ckSummary"></div>' +
      '<div id="ckPayNote" style="font-size:13px;color:var(--muted);background:rgba(255,255,255,.03);border-radius:var(--r);padding:12px;margin-top:10px;border:1px solid var(--border);"></div>' +
    '</div>' +

    /* Nav */
    '<div class="bk-nav" id="ckNav">' +
      '<button class="bk-back" id="ckBack" onclick="ckGo(-1)" style="display:none;">&#x2190; Back</button>' +
      '<button class="bk-next" id="ckNext" onclick="ckGo(1)">Next &rarr;</button>' +
    '</div>' +
    '</div>';

  openOverlay();
  prefill('ck_name','ck_phone','ck_addr');
}

function selPay(m,el){
  orderPay=m;
  document.querySelectorAll('.po').forEach(function(o){o.classList.remove('sel');});
  el.classList.add('sel');
  document.getElementById('mpesaField').style.display=(m==='mpesa'?'':'none');
}

function ckGo(dir){
  var next=ckStep+dir;
  if(dir>0){
    if(ckStep===1){
      var n=(document.getElementById('ck_name').value||'').trim();
      var p=(document.getElementById('ck_phone').value||'').trim();
      var a=(document.getElementById('ck_addr').value||'').trim();
      if(!n){showToast('Enter your name');return;}
      if(!p||p.replace(/\D/g,'').length<9){showToast('Enter a valid phone number');return;}
      if(!a){showToast('Enter delivery address');return;}
    }
    if(ckStep===2){
      if(orderPay==='mpesa'){
        var mp=(document.getElementById('ck_mpesa').value||'').trim();
        if(!mp||mp.replace(/\D/g,'').length<9){showToast('Enter your M-Pesa number');return;}
      }
      buildOrderSummary();
    }
  }
  if(next<1||next>3) return;
  /* Update dots */
  for(var s=1;s<=3;s++){
    var dot=document.getElementById('bkD'+s),lbl=document.getElementById('bkL'+s),ln=document.getElementById('bkLn'+s);
    if(dot){dot.classList.remove('active','done');if(s<next)dot.classList.add('done');else if(s===next)dot.classList.add('active');}
    if(lbl){lbl.classList.remove('active','done');if(s<next)lbl.classList.add('done');else if(s===next)lbl.classList.add('active');}
    if(ln)ln.classList.toggle('done',s<next);
    var panel=document.getElementById('ckP'+s);if(panel)panel.classList.toggle('active',s===next);
  }
  ckStep=next;
  var back=document.getElementById('ckBack');if(back)back.style.display=ckStep>1?'':'none';
  var nxt=document.getElementById('ckNext');
  if(nxt){
    if(ckStep===3){nxt.textContent='&#x2705; Place Order';nxt.onclick=function(){submitFoodOrder();};}
    else{nxt.textContent='Next &rarr;';nxt.onclick=function(){ckGo(1);};}
  }
}

function buildOrderSummary(){
  var n=(document.getElementById('ck_name').value||'').trim();
  var a=(document.getElementById('ck_addr').value||'').trim();
  var tot=window._ckTot, dlv=window._ckDlv;
  var itemsHTML=cart.map(function(c){return '<div class="cs-row"><span>'+esc(c.title)+' &times;'+c.qty+'</span><span>KSH '+(px(c.price)*c.qty).toLocaleString()+'</span></div>';}).join('');
  document.getElementById('ckSummary').innerHTML=
    itemsHTML+
    '<div class="cs-row"><span>Delivery</span><span>KSH '+dlv+'</span></div>'+
    '<div class="cs-row tot"><span>Total</span><span>KSH '+tot.toLocaleString()+'</span></div>'+
    '<div class="cs-row"><span>Name</span><span>'+esc(n)+'</span></div>'+
    '<div class="cs-row"><span>Deliver to</span><span>'+esc(a)+'</span></div>';
  var mp=(document.getElementById('ck_mpesa')&&document.getElementById('ck_mpesa').value)||'';
  var ph=(document.getElementById('ck_phone').value||'').trim();
  document.getElementById('ckPayNote').innerHTML=orderPay==='mpesa'
    ?'&#x1F4F1; M-Pesa STK push will be sent to <strong>'+esc(mp||ph)+'</strong> after confirmation.'
    :'&#x1F4B5; Pay <strong>KSH '+tot.toLocaleString()+'</strong> cash when food arrives.';
}

function submitFoodOrder(){
  var name =(document.getElementById('ck_name').value||'').trim();
  var phone=(document.getElementById('ck_phone').value||'').trim();
  var addr =(document.getElementById('ck_addr').value||'').trim();
  var note =(document.getElementById('ck_note')&&document.getElementById('ck_note').value||'').trim();
  var mpNum=(document.getElementById('ck_mpesa')&&document.getElementById('ck_mpesa').value||phone).trim();
  var tot  =window._ckTot||0;
  var btn  =document.getElementById('ckNext'); if(btn){btn.disabled=true;btn.textContent='Placing order…';}
  saveUser(name,phone,addr);
  var names=cart.map(function(c){return c.title;}).join(', ');
  var restPhone=cart[0]&&cart[0].phone||'';

  if(orderPay==='mpesa'){
    document.getElementById('sheetContent').innerHTML=
      '<div class="sh-grip"><div class="sh-handle"></div><div></div></div>'+
      '<div class="proc-wrap"><div class="spinner"></div>'+
      '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:17px;margin-bottom:8px;">Processing M-Pesa…</div>'+
      '<p style="color:var(--muted);font-size:13px;">STK push sent to <strong style="color:var(--text)">'+esc(mpNum)+'</strong><br>Enter your M-Pesa PIN on your phone</p></div>';
  }

  var xhr=new XMLHttpRequest();
  xhr.open('POST',API_BASE+'/order.php',true);
  xhr.setRequestHeader('Content-Type','application/json');
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout=12000;
  xhr.onload=function(){
    var ref='';
    try{var d=JSON.parse(xhr.responseText);ref=d.order_ref||'';}catch(e){}
    var wm=encodeURIComponent('Hi!\n*New Order from '+name+'*\nRef: '+(ref||'—')+'\nPhone: '+phone+'\nDelivery: '+addr+'\n\nItems: '+names+'\nTotal: KSH '+tot.toLocaleString()+'\nPayment: '+(orderPay==='mpesa'?'M-Pesa ('+mpNum+')':'Cash on Delivery'));
    cart=[];localStorage.removeItem('mh_food_cart');updateCart();

    if(orderPay==='mpesa'){setTimeout(function(){showSuccess(ref,name,phone,addr,tot,wm,restPhone);},1800);}
    else{showSuccess(ref,name,phone,addr,tot,wm,restPhone);}
  };
  xhr.onerror=xhr.ontimeout=function(){
    showToast('Order placed! We\'ll contact you shortly.');
    closeOverlay(); cart=[];localStorage.removeItem('mh_food_cart');updateCart();
  };
  xhr.send(JSON.stringify({
    category:'food',listing_id:cart[0]&&cart[0].id||'',
    name:name,phone:phone,address:addr,payment_method:orderPay==='mpesa'?'mpesa':'cash',
    total_amount:tot,notes:'Items:'+names+'|Pay:'+orderPay+(note?'|Note:'+note:'')+(orderPay==='mpesa'?'|MPesa:'+mpNum:''),
    cart_items:cart.map(function(c){return{id:c.id,title:c.title,price:c.price,qty:c.qty};}),
  }));
}
function showSuccess(ref,name,phone,addr,tot,wm,restPhone){
  var waN=normWA(restPhone||'254700000000');
  document.getElementById('sheetContent').innerHTML=
    '<div class="sh-grip"><div class="sh-handle"></div><button class="sh-x" onclick="closeOverlay()">&#x2715;</button></div>'+
    '<div style="padding:16px 16px 0;">'+
    '<div class="suc-wrap">'+
      '<div class="suc-ico">&#x1F389;</div>'+
      '<div class="suc-title">Order Confirmed!</div>'+
      '<div class="suc-sub">'+(orderPay==='mpesa'?'M-Pesa payment received. Your food is being prepared!':'Order placed! Pay KSH '+tot.toLocaleString()+' cash when food arrives.')+'</div>'+
      (ref?'<div style="text-align:center;font-size:12px;color:var(--muted);margin-bottom:12px;">Order ref: <strong style="color:var(--text)">'+esc(ref)+'</strong></div>':'')+
      '<div class="suc-det">'+
        '<div class="sd-row"><span>Name</span><span>'+esc(name)+'</span></div>'+
        '<div class="sd-row"><span>Deliver to</span><span>'+esc(addr)+'</span></div>'+
        '<div class="sd-row"><span>Total</span><span>KSH '+tot.toLocaleString()+'</span></div>'+
        '<div class="sd-row"><span>Payment</span><span>'+(orderPay==='mpesa'?'M-Pesa':'Cash on Delivery')+'</span></div>'+
        '<div class="sd-row"><span>Est. Time</span><span>25–35 mins</span></div>'+
      '</div>'+
      '<button class="bk-wa" onclick="window.open(\'https://wa.me/'+waN+'?text='+wm+'\',\'_blank\')">&#x1F4AC; Track Order on WhatsApp</button>'+
      '<button class="bk-done" onclick="closeOverlay()">Done</button>'+
    '</div></div>';
}

/* ════════════════════════════════════════
   🍕 LIPA MDOGO MDOGO — PIZZA SPECIAL
   User pays daily installments UNTIL the next
   Wednesday or Saturday pizza day, then receives
   their pizza on that day after full payment.
════════════════════════════════════════ */
function openPizzaLipa(id){
  lipaItem=allFood.find(function(f){return f.id===id;}); if(!lipaItem) return;
  var ps  = getPizzaStatus();
  var raw = px(lipaItem.price||'0');
  if(!raw){ showToast('Price unavailable'); return; }

  /* Calculate payment plans based on days until next pizza day */
  var plans = buildLipaPlans(raw, ps);
  var img   = lipaItem.image||lipaItem.image_url||'';

  /* Next pizza day context */
  var deliverDay = ps.isActive ? 'Today ('+ps.dayName+')' : ps.nextDayName;
  var daysLeft   = ps.isActive ? 0 : ps.daysUntil;

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-grip"><div class="sh-handle"></div><button class="sh-x" onclick="closeOverlay()">&#x2715;</button></div>' +

    /* Product header */
    '<div class="lipa-prod">' +
      (img?'<img class="lipa-img" src="'+esc(img)+'" loading="lazy" onerror="this.style.display=\'none\'">':'<div class="lipa-img-ph">&#x1F355;</div>') +
      '<div>' +
        '<div class="lipa-name">'+esc(lipaItem.title||'')+'</div>' +
        '<div class="lipa-price">'+esc(lipaItem.price||'')+'</div>' +
        '<span class="lipa-special-badge">&#x1F355; Pizza Special</span>' +
      '</div>' +
    '</div>' +

    /* Next pizza day box */
    '<div class="next-day-box">' +
      '<div class="ndb-ico">'+(ps.isActive?'&#x1F7E2;':'&#x1F4C5;')+'</div>' +
      '<div>' +
        '<div class="ndb-title">'+(ps.isActive?'Pizza Day is TODAY!':'Next Pizza Day')+'</div>' +
        '<div class="ndb-count">' +
          (ps.isActive
            ? 'Pay <strong>now</strong> and your pizza is ready right away!'
            : 'Pay daily for the next <span class="ndb-days">'+daysLeft+' day'+(daysLeft===1?'':'s')+'</span> and get your pizza on <strong>'+deliverDay+'</strong>.') +
        '</div>' +
      '</div>' +
    '</div>' +

    /* Rule */
    '<div class="lipa-rule"><strong>&#x1F512; Pay first, eat on pizza day.</strong> Choose a plan below. Pay installments until '+(ps.isActive?'today':'next '+ps.nextDayName)+'. Your pizza with BOGO deal is ready when fully paid!</div>' +

    /* Plans */
    '<div class="lipa-plans-title">Choose Your Payment Plan</div>' +
    '<div class="lipa-plans-sub">Based on '+daysLeft+' day'+(daysLeft===1?'':'s')+' until your pizza. All plans include Buy 1 Get 1 FREE!</div>' +
    '<div class="lipa-plan-list" id="lipaPlanList">'+buildPlanHTML(plans)+'</div>' +

    /* Details */
    '<div class="field" style="margin:0 16px 11px;"><label>Full Name *</label><input type="text" id="lp_name" placeholder="Your full name" autocomplete="name"></div>' +
    '<div class="field" style="margin:0 16px 11px;"><label>Phone (M-Pesa) *</label><input type="tel" id="lp_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>' +
    '<div class="field" style="margin:0 16px 11px;"><label>Delivery Address *</label><input type="text" id="lp_addr" placeholder="e.g. Near Malaba Market"></div>' +

    '<button class="lipa-submit" id="lipaSubBtn" onclick="submitPizzaLipa()">&#x1F355; Reserve My Pizza Plan</button>' +
    '<div style="height:8px;"></div>';

  window._lipaplans=plans;
  selectedPlan=plans[0];
  openOverlay();
  prefill('lp_name','lp_phone','lp_addr');
}

function buildLipaPlans(price, ps){
  var ksh=function(n){return 'KSH '+Math.round(n).toLocaleString('en-KE');};
  var daysLeft = ps.isActive ? 0 : ps.daysUntil;

  /* If today is pizza day, only 1 option: pay now */
  if(ps.isActive){
    return [{id:'now',label:'Pay Now',days:0,installments:1,perDay:ksh(price),total:ksh(price),totalRaw:price,desc:'Full payment. Get your BOGO pizza immediately!'}];
  }

  /* Build plans for daysLeft days (max 4 installments) */
  var plans=[];
  if(daysLeft >= 1) plans.push({id:'d'+daysLeft,label:'Daily ('+daysLeft+' payments)',days:daysLeft,installments:daysLeft,perDay:ksh(price/daysLeft),total:ksh(price),totalRaw:price,desc:'Pay once a day for '+daysLeft+' day'+(daysLeft===1?'':'s')+' until pizza day.'});
  if(daysLeft >= 2) plans.push({id:'2x',label:'2× total',days:daysLeft,installments:2,perDay:ksh(price/2),total:ksh(price),totalRaw:price,desc:'2 equal payments, any 2 of the '+daysLeft+' days.'});
  plans.push({id:'full',label:'Pay in full now',days:0,installments:1,perDay:ksh(price),total:ksh(price),totalRaw:price,desc:'Pay everything upfront and secure your pizza deal now.'});
  return plans;
}

function buildPlanHTML(plans){
  return plans.map(function(p,i){
    return '<div class="lplan'+(i===0?' sel':'')+'" onclick="selLipaPlan('+i+',this)">' +
      '<div class="lplan-radio"></div>' +
      '<div class="lplan-info"><div class="lplan-name">'+esc(p.label)+'</div><div class="lplan-detail">'+esc(p.desc)+'</div></div>' +
      '<div class="lplan-right"><div class="lplan-amount">'+esc(p.perDay)+'</div><div class="lplan-when">per payment</div></div>' +
      '</div>';
  }).join('');
}
function selLipaPlan(i,el){
  selectedPlan=window._lipaplans[i];
  document.querySelectorAll('.lplan').forEach(function(p){p.classList.remove('sel');});
  el.classList.add('sel');
}

function submitPizzaLipa(){
  var name =(document.getElementById('lp_name').value||'').trim();
  var phone=(document.getElementById('lp_phone').value||'').trim();
  var addr =(document.getElementById('lp_addr').value||'').trim();
  if(!name){showToast('Enter your name');return;}
  if(!phone||phone.replace(/\D/g,'').length<9){showToast('Enter your phone number');return;}
  if(!addr){showToast('Enter delivery address');return;}
  if(!selectedPlan){showToast('Choose a payment plan');return;}

  var btn=document.getElementById('lipaSubBtn'); btn.disabled=true; btn.textContent='Sending…';
  saveUser(name,phone,addr);

  var ps       = getPizzaStatus();
  var delivDay = ps.isActive?ps.dayName:'next '+ps.nextDayName;
  var note='Pizza Lipa Mdogo: Plan: '+selectedPlan.label+' | Per payment: '+selectedPlan.perDay+' | Total: '+selectedPlan.total+' | Pizza ready on: '+delivDay+' | BOGO deal included | Pay-first rule';
  var waN =normWA((lipaItem.contact&&lipaItem.contact.phone)?lipaItem.contact.phone:(lipaItem.contact_phone||''));

  var xhr=new XMLHttpRequest();
  xhr.open('POST',API_BASE+'/order.php',true);
  xhr.setRequestHeader('Content-Type','application/json');
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout=10000;
  xhr.onload=function(){
    var ref='';
    try{var d=JSON.parse(xhr.responseText);ref=d.order_ref||'';}catch(e){}
    var wm=encodeURIComponent(
      '&#x1F355; Pizza Lipa Mdogo — Malaba Food\n'+
      'Item: *'+(lipaItem.title||'')+'*\n'+
      'Plan: '+selectedPlan.label+'\n'+
      'Per payment: '+selectedPlan.perDay+'\n'+
      'Total: '+selectedPlan.total+'\n'+
      'Pizza ready on: '+delivDay+' (BOGO included)\n'+
      'Ref: '+(ref||'—')+'\n'+
      'Name: '+name+' | Phone: '+phone+'\n'+
      'Address: '+addr+'\n'+
      '(Pizza dispatched after full payment received)'
    );
    document.getElementById('sheetContent').innerHTML=
      '<div class="sh-grip"><div class="sh-handle"></div><button class="sh-x" onclick="closeOverlay()">&#x2715;</button></div>'+
      '<div style="padding:16px;">'+
      '<div class="suc-wrap">'+
        '<div class="suc-ico">&#x1F355;</div>'+
        '<div class="suc-title">Pizza Reserved!</div>'+
        '<div class="suc-sub">Your Lipa Mdogo Mdogo plan is confirmed. Pay <strong>'+esc(selectedPlan.perDay)+'</strong> per installment. Your pizza + BOGO deal will be ready on <strong>'+esc(delivDay)+'</strong> after full payment!</div>'+
        (ref?'<div style="text-align:center;font-size:12px;color:var(--muted);margin-bottom:12px;">Ref: <strong style="color:var(--text)">'+esc(ref)+'</strong></div>':'')+
        '<div class="suc-det">'+
          '<div class="sd-row"><span>Pizza</span><span>'+esc(lipaItem.title||'')+'</span></div>'+
          '<div class="sd-row"><span>Plan</span><span>'+esc(selectedPlan.label)+'</span></div>'+
          '<div class="sd-row"><span>Total</span><span>'+esc(selectedPlan.total)+'</span></div>'+
          '<div class="sd-row"><span>Ready on</span><span>'+esc(delivDay)+'</span></div>'+
          '<div class="sd-row"><span>Deal</span><span>&#x1F355; Buy 1 Get 1 FREE</span></div>'+
        '</div>'+
        '<button class="bk-wa" onclick="window.open(\'https://wa.me/'+waN+'?text='+encodeURIComponent(wm)+'\',\'_blank\')">&#x1F4AC; Confirm on WhatsApp</button>'+
        '<button class="bk-done" onclick="closeOverlay()">Done</button>'+
      '</div></div>';
  };
  xhr.onerror=function(){
    btn.disabled=false; btn.textContent='&#x1F355; Reserve My Pizza Plan';
    showToast('Network error. Try again.');
  };
  xhr.send(JSON.stringify({
    category:'food',listing_id:lipaItem.id||'',
    listing_title:lipaItem.title||'',listing_price:lipaItem.price||'',
    name:name,phone:phone,address:addr,
    payment_method:'mpesa',notes:note,total_amount:selectedPlan.totalRaw||0,
  }));
}
</script>
</body>
</html>