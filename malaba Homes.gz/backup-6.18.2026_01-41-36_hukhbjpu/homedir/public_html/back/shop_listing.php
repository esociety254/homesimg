<?php
$apiBase = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/api';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1">
<meta name="theme-color" content="#080400">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>Shop — Malaba Homes</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
/* ── TOKENS ── */
:root{
  --ink:#080400;--ink2:#100a00;--surface:#161210;--card:#1c1812;
  --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);
  --text:#F5F0EB;--muted:#8a8078;--dim:#5a534c;
  --amber:#E8521A;--amber2:#FF7043;--gold:#F5A623;
  --green:#22C55E;--blue:#4895EF;--purple:#7c3aed;
  --sb:env(safe-area-inset-bottom,0px);
  --st:env(safe-area-inset-top,0px);
  --r:12px;--rl:18px;--nav:56px;--bnav:62px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
html{overflow-x:hidden;}
body{font-family:'Outfit',sans-serif;background:var(--ink);color:var(--text);min-height:100dvh;overflow-x:hidden;-webkit-font-smoothing:antialiased;padding-bottom:calc(var(--bnav) + var(--sb) + 8px);}
a{color:inherit;text-decoration:none;}
button{cursor:pointer;font-family:inherit;border:none;background:none;}
img{display:block;max-width:100%;}
::-webkit-scrollbar{width:3px;height:3px;}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px;}

/* ── HEADER ── */
.hdr{
  position:sticky;top:0;z-index:200;
  background:rgba(8,4,0,.96);backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);
  border-bottom:1px solid var(--border);
  padding:var(--st) 14px 0;
}
.hdr-row{height:var(--nav);display:flex;align-items:center;gap:10px;}
.back-btn{
  width:36px;height:36px;border-radius:50%;
  background:var(--surface);border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;transition:transform .15s;
}
.back-btn:active{transform:scale(.9);}
.back-btn svg{width:17px;height:17px;color:var(--text);}
.hdr-brand{
  flex:1;
  font-family:'Bebas Neue',sans-serif;
  font-size:20px;letter-spacing:2px;color:var(--text);
}
.hdr-brand span{color:var(--amber2);}
.hdr-acts{display:flex;gap:7px;}
.ico-btn{
  width:36px;height:36px;border-radius:50%;
  background:var(--surface);border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;
  font-size:15px;position:relative;transition:transform .15s;
}
.ico-btn:active{transform:scale(.9);}
.hbadge{
  position:absolute;top:-3px;right:-3px;
  width:17px;height:17px;border-radius:50%;
  background:var(--amber);color:#fff;
  font-size:9px;font-weight:800;
  display:none;align-items:center;justify-content:center;
  border:2px solid var(--ink);
}
.hbadge.on{display:flex;}
/* Search */
.srch-row{padding:9px 0;}
.srch-box{
  display:flex;align-items:center;gap:9px;
  background:var(--surface);border:1.5px solid var(--border2);
  border-radius:30px;padding:0 15px;
  transition:border-color .2s;
}
.srch-box:focus-within{border-color:var(--amber);}
.srch-box svg{color:var(--muted);flex-shrink:0;width:14px;height:14px;}
.srch-box input{
  flex:1;padding:11px 0;background:transparent;
  border:none;outline:none;font-family:inherit;
  font-size:14px;color:var(--text);
}
.srch-box input::placeholder{color:var(--muted);}
/* Cats */
.cats-row{
  display:flex;gap:7px;padding:0 0 10px;
  overflow-x:auto;scrollbar-width:none;
}
.cats-row::-webkit-scrollbar{display:none;}
.cat-tab{
  display:inline-flex;align-items:center;gap:5px;
  padding:6px 13px;border-radius:30px;
  border:1px solid var(--border2);background:var(--surface);
  font-size:12px;font-weight:500;color:var(--muted);
  white-space:nowrap;flex-shrink:0;transition:all .2s;
}
.cat-tab.on{background:var(--amber);border-color:var(--amber);color:#fff;font-weight:700;}
.cat-tab:active{transform:scale(.95);}

/* ── SECTION HEAD ── */
.sec-head{display:flex;align-items:center;justify-content:space-between;padding:8px 14px 8px;}
.sec-head h2{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.5px;}
.sec-head h2 span{color:var(--amber2);}
.sort-btn{
  display:flex;align-items:center;gap:5px;
  padding:6px 12px;border-radius:9px;
  background:var(--surface);border:1px solid var(--border2);
  font-size:11px;font-weight:600;color:var(--muted);transition:all .2s;
}
.sort-btn:active{border-color:var(--amber);color:var(--amber);}
.res-count{font-size:11px;color:var(--dim);padding:0 14px 8px;}

/* ── GRID ── */
.shop-grid{
  display:grid;gap:10px;
  grid-template-columns:repeat(2,1fr);
  padding:0 10px;
}
@media(min-width:480px){.shop-grid{gap:12px;padding:0 14px;}}
@media(min-width:640px){.shop-grid{grid-template-columns:repeat(3,1fr);}}
@media(min-width:900px){.shop-grid{grid-template-columns:repeat(4,1fr);padding:0 20px;}}

/* ── PRODUCT CARD ── */
.pcard{
  background:var(--card);border-radius:var(--rl);
  border:1px solid var(--border);overflow:hidden;
  display:flex;flex-direction:column;cursor:pointer;
  animation:fadeUp .35s ease both;
  transition:transform .2s,box-shadow .2s,border-color .2s;
  position:relative;
}
@keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
.pcard:active{transform:scale(.97);}
@media(hover:hover){.pcard:hover{transform:translateY(-4px);box-shadow:0 14px 36px rgba(0,0,0,.5);border-color:var(--border2);}}

.pcard-img{position:relative;aspect-ratio:1/1;overflow:hidden;}
.pcard-img img{width:100%;height:100%;object-fit:cover;transition:transform .5s;will-change:transform;}
.pcard:hover .pcard-img img{transform:scale(1.06);}

.pbadge{
  position:absolute;top:7px;left:7px;
  background:rgba(8,4,0,.82);backdrop-filter:blur(6px);
  color:var(--text);font-size:9px;font-weight:700;
  padding:3px 8px;border-radius:12px;white-space:nowrap;
}
/* Lipa badge on card */
.plipa-badge{
  position:absolute;bottom:7px;left:7px;
  background:linear-gradient(135deg,rgba(245,166,35,.9),rgba(232,82,26,.9));
  backdrop-filter:blur(4px);
  color:#fff;font-size:8px;font-weight:800;
  padding:3px 7px;border-radius:10px;white-space:nowrap;
  letter-spacing:.3px;
}
.wish{
  position:absolute;top:6px;right:6px;
  width:28px;height:28px;border-radius:50%;
  background:rgba(8,4,0,.7);backdrop-filter:blur(6px);
  display:flex;align-items:center;justify-content:center;font-size:13px;
  transition:all .2s;z-index:2;
}
.wish:active{transform:scale(.85);}
.wish.liked{background:rgba(232,82,26,.25);}

.pcard-body{padding:9px 9px 2px;flex:1;}
.ptitle{
  font-family:'Outfit',sans-serif;font-weight:700;
  font-size:12px;color:var(--text);line-height:1.3;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;
  margin-bottom:3px;
}
.prating{display:flex;align-items:center;gap:2px;font-size:10px;color:var(--gold);}
.prating span{color:var(--muted);}
.ploc{font-size:10px;color:var(--dim);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}

.pprice{
  font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;
  color:var(--amber2);padding:4px 9px 2px;
}

/* Card footer — TWO BUY BUTTONS */
.pcard-foot{display:flex;gap:5px;padding:5px 7px 8px;}
.btn-order{
  flex:1;padding:8px 6px;border-radius:var(--r);
  background:var(--amber);color:#fff;
  font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:.3px;
  transition:all .18s;display:flex;align-items:center;justify-content:center;gap:3px;
}
.btn-order:active{transform:scale(.95);background:var(--amber2);}
.btn-lipa{
  padding:8px 7px;border-radius:var(--r);
  background:linear-gradient(135deg,var(--gold),var(--amber));
  color:#fff;
  font-size:10px;font-weight:800;
  transition:all .18s;display:flex;align-items:center;justify-content:center;
  white-space:nowrap;flex-shrink:0;letter-spacing:.3px;
}
.btn-lipa:active{transform:scale(.95);}
.btn-qv{
  width:32px;border-radius:var(--r);
  background:var(--surface);border:1px solid var(--border2);
  color:var(--muted);font-size:13px;
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;transition:all .18s;
}
.btn-qv:active{border-color:var(--amber);color:var(--amber);}

/* ── SKELETON ── */
.skel{
  background:linear-gradient(90deg,var(--surface) 25%,rgba(255,255,255,.04) 50%,var(--surface) 75%);
  background-size:200% 100%;animation:shim 1.4s infinite;
}
@keyframes shim{0%{background-position:200% 0}100%{background-position:-200% 0}}
.skel-card{background:var(--card);border-radius:var(--rl);overflow:hidden;border:1px solid var(--border);}
.skel-sq{aspect-ratio:1/1;}
.skel-ln{height:10px;border-radius:3px;margin:9px 9px 5px;}

/* Infinite scroll */
.load-more{display:flex;align-items:center;justify-content:center;height:64px;}
.spin{width:24px;height:24px;border:3px solid var(--border2);border-top-color:var(--amber);border-radius:50%;animation:spin .65s linear infinite;}
@keyframes spin{to{transform:rotate(360deg)}}
.load-end{font-size:12px;color:var(--dim);}
.empty{grid-column:1/-1;text-align:center;padding:48px 20px;}
.empty-ico{font-size:48px;margin-bottom:12px;}
.empty h3{font-family:'Bebas Neue',sans-serif;font-size:22px;margin-bottom:6px;}
.empty p{color:var(--muted);font-size:13px;}

/* ── OVERLAY & SHEETS ── */
.overlay{
  position:fixed;inset:0;z-index:400;
  background:rgba(0,0,0,.82);backdrop-filter:blur(6px);
  opacity:0;pointer-events:none;transition:opacity .25s;
  display:flex;align-items:flex-end;
}
.overlay.open{opacity:1;pointer-events:all;}
.sheet{
  width:100%;background:var(--ink2);
  border-radius:24px 24px 0 0;
  border:1px solid rgba(255,255,255,.08);
  transform:translateY(100%);
  transition:transform .38s cubic-bezier(.32,1,.68,1);
  max-height:94dvh;overflow-y:auto;
  padding-bottom:calc(20px + var(--sb));
}
.overlay.open .sheet{transform:translateY(0);}
.sh-top{display:flex;align-items:center;justify-content:space-between;padding:13px 16px 0;}
.sh-handle{width:38px;height:4px;border-radius:2px;background:rgba(255,255,255,.1);}
.sh-close{
  width:28px;height:28px;border-radius:50%;
  background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
  display:flex;align-items:center;justify-content:center;
  color:rgba(255,255,255,.5);font-size:14px;
}
.sh-close:active{transform:scale(.9);}

/* ── QUICK VIEW SHEET ── */
.qv-img{width:100%;height:220px;object-fit:cover;}
.qv-pad{padding:14px 16px;}
.qv-badge{display:inline-block;font-size:10px;font-weight:700;padding:3px 10px;border-radius:12px;background:rgba(232,82,26,.12);color:var(--amber2);margin-bottom:7px;}
.qv-title{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:.5px;margin-bottom:4px;}
.qv-price{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:.5px;color:var(--amber2);margin-bottom:8px;}
.qv-desc{font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:12px;}
.qv-feats{display:grid;grid-template-columns:1fr 1fr;gap:7px;background:rgba(255,255,255,.03);border-radius:var(--r);padding:12px;margin-bottom:14px;border:1px solid var(--border);}
.qf{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--muted);}
.qf-ico{font-size:14px;}
.qty-row{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.03);border-radius:var(--r);padding:10px 13px;margin-bottom:14px;border:1px solid var(--border);}
.qty-row label{font-size:13px;font-weight:600;}
.qty-ctrl{display:flex;align-items:center;background:var(--ink);border:1.5px solid var(--border2);border-radius:30px;overflow:hidden;}
.qbtn{width:34px;height:34px;font-size:16px;font-weight:700;color:var(--text);display:flex;align-items:center;justify-content:center;transition:background .13s;}
.qbtn:active{background:rgba(232,82,26,.15);}
.qnum{padding:0 12px;font-family:'Bebas Neue',sans-serif;font-size:16px;min-width:32px;text-align:center;}

/* ── BUY OPTION CARDS (in quick view) ── */
.buy-options{display:flex;flex-direction:column;gap:8px;margin-bottom:14px;}
.buy-opt{
  display:flex;align-items:center;gap:12px;
  padding:14px 14px;border-radius:var(--rl);
  border:2px solid var(--border2);
  cursor:pointer;transition:all .2s;
  background:rgba(255,255,255,.02);
}
.buy-opt:active{transform:scale(.99);}
.buy-opt.opt-full:hover,.buy-opt.opt-full:active{border-color:var(--amber);background:rgba(232,82,26,.07);}
.buy-opt.opt-lipa:hover,.buy-opt.opt-lipa:active{border-color:var(--gold);background:rgba(245,166,35,.07);}
.buy-opt.opt-watch:hover,.buy-opt.opt-watch:active{border-color:var(--purple);background:rgba(124,58,237,.07);}
.bo-icon{
  width:40px;height:40px;border-radius:12px;
  display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;
}
.boi-full {background:rgba(232,82,26,.15);}
.boi-lipa {background:rgba(245,166,35,.15);}
.boi-watch{background:rgba(124,58,237,.15);}
.bo-info{flex:1;}
.bo-title{font-size:14px;font-weight:700;color:var(--text);margin-bottom:2px;}
.bo-sub{font-size:11px;color:var(--muted);}
.bo-arrow{font-size:16px;color:var(--muted);}

/* ── DIRECT ORDER FORM (full purchase) ── */
.field{margin-bottom:11px;}
.field label{display:block;font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:5px;}
.field input{
  width:100%;padding:11px 13px;border-radius:var(--r);
  background:rgba(255,255,255,.05);border:1.5px solid var(--border2);
  color:var(--text);font-family:inherit;font-size:14px;outline:none;
  transition:border-color .2s;
}
.field input:focus{border-color:var(--amber);}
.field input::placeholder{color:rgba(255,255,255,.22);}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.pay-opts{display:flex;flex-direction:column;gap:7px;margin-bottom:12px;}
.po{
  display:flex;align-items:center;gap:11px;
  padding:11px 12px;border-radius:var(--r);
  border:2px solid var(--border2);cursor:pointer;transition:all .18s;
}
.po.sel{border-color:var(--amber);background:rgba(232,82,26,.07);}
.po:active{transform:scale(.99);}
.po-ico{font-size:18px;}
.po-txt strong{display:block;font-size:13px;font-weight:600;}
.po-txt span{font-size:11px;color:var(--muted);}
.po-dot{width:17px;height:17px;border-radius:50%;border:2px solid var(--dim);margin-left:auto;flex-shrink:0;display:flex;align-items:center;justify-content:center;}
.po.sel .po-dot{border-color:var(--amber);background:var(--amber);}
.po.sel .po-dot::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}
.order-sum{background:rgba(255,255,255,.03);border-radius:var(--r);padding:11px;margin-bottom:12px;border:1px solid var(--border);}
.os-row{display:flex;justify-content:space-between;font-size:13px;color:var(--muted);padding:3px 0;}
.os-row.tot{font-size:14px;font-weight:700;color:var(--text);padding-top:8px;border-top:1px solid var(--border);margin-top:4px;}
.sbtn{
  width:100%;padding:14px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;border-radius:var(--rl);
  font-family:'Bebas Neue',sans-serif;font-weight:400;font-size:18px;letter-spacing:.5px;
  transition:all .2s;
  box-shadow:0 4px 18px rgba(232,82,26,.35);
}
.sbtn:active{transform:scale(.98);}
.sbtn.green{background:linear-gradient(135deg,#16a34a,#22c55e);}

/* ── LIPA MDOGO MDOGO SHEET ── */
.lipa-header{
  padding:16px 16px 0;
  background:linear-gradient(135deg,rgba(245,166,35,.08),rgba(232,82,26,.05));
  border-bottom:1px solid rgba(245,166,35,.12);
  margin-bottom:14px;
}
.lipa-product-row{display:flex;gap:12px;padding:0 0 14px;}
.lipa-pimg{width:58px;height:58px;border-radius:12px;object-fit:cover;flex-shrink:0;}
.lipa-pimg-ph{width:58px;height:58px;border-radius:12px;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0;}
.lipa-pname{font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.3px;margin-bottom:2px;}
.lipa-pwas{font-size:11px;color:var(--dim);text-decoration:line-through;}
.lipa-ptag{font-size:10px;color:var(--gold);font-weight:700;margin-top:2px;}

/* Step progress */
.lipa-steps{display:flex;align-items:center;padding:0 16px 14px;}
.lstep{display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;}
.lstep:last-child{flex:0;flex-shrink:0;}
.ls-dot{
  width:26px;height:26px;border-radius:50%;border:2px solid var(--border2);
  display:flex;align-items:center;justify-content:center;
  font-size:10px;font-weight:800;color:var(--muted);transition:all .3s;
}
.ls-dot.done  {background:var(--green);border-color:var(--green);color:#000;font-size:11px;}
.ls-dot.active{background:var(--amber);border-color:var(--amber);color:#fff;box-shadow:0 0 0 4px rgba(232,82,26,.18);}
.ls-lbl{font-size:9px;font-weight:600;color:var(--muted);letter-spacing:.2px;text-align:center;}
.ls-lbl.active{color:var(--amber);}
.ls-lbl.done  {color:var(--green);}
.ls-line{flex:1;height:2px;background:var(--border2);margin:0 4px;margin-bottom:14px;transition:background .3s;}
.ls-line.done {background:var(--green);}

/* Panels */
.lipa-panel{display:none;padding:0 16px;}
.lipa-panel.active{display:block;animation:panelIn .22s ease;}
@keyframes panelIn{from{opacity:0;transform:translateX(10px)}to{opacity:1;transform:translateX(0)}}

.lipa-sec-title{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.3px;margin-bottom:4px;}
.lipa-sec-sub{font-size:12px;color:var(--muted);margin-bottom:14px;line-height:1.5;}

/* Frequency options */
.lipa-freqs{display:flex;flex-direction:column;gap:7px;margin-bottom:14px;}
.lipa-freq{
  display:flex;align-items:center;gap:10px;padding:13px 13px;
  border-radius:var(--rl);border:2px solid var(--border2);
  background:rgba(255,255,255,.02);cursor:pointer;transition:all .18s;
}
.lipa-freq.sel{border-color:rgba(245,166,35,.55);background:rgba(245,166,35,.07);}
.lipa-freq:active{transform:scale(.99);}
.lf-radio{width:17px;height:17px;border-radius:50%;border:2px solid var(--dim);flex-shrink:0;display:flex;align-items:center;justify-content:center;transition:all .18s;}
.lipa-freq.sel .lf-radio{background:var(--gold);border-color:var(--gold);}
.lipa-freq.sel .lf-radio::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}
.lf-info{flex:1;}
.lf-name{font-size:13px;font-weight:700;color:var(--text);margin-bottom:1px;}
.lf-desc{font-size:11px;color:var(--muted);}
.lf-right{text-align:right;flex-shrink:0;}
.lf-amount{font-family:'Bebas Neue',sans-serif;font-size:16px;color:var(--gold);letter-spacing:.3px;}
.lf-per{font-size:9px;color:var(--muted);margin-top:1px;}

/* Duration grid */
.lipa-durs{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;}
.lipa-dur{
  padding:13px 11px;border-radius:var(--rl);
  border:2px solid var(--border2);background:rgba(255,255,255,.02);
  cursor:pointer;transition:all .18s;text-align:center;
}
.lipa-dur.sel{border-color:rgba(245,166,35,.55);background:rgba(245,166,35,.07);}
.lipa-dur:active{transform:scale(.97);}
.ld-weeks{font-family:'Bebas Neue',sans-serif;font-size:22px;color:var(--text);letter-spacing:.3px;}
.ld-label{font-size:10px;color:var(--muted);margin-bottom:4px;}
.ld-per{font-size:12px;font-weight:700;color:var(--gold);}
.ld-total{font-size:10px;color:var(--dim);margin-top:2px;}

/* Summary box */
.lipa-summary{
  background:rgba(245,166,35,.07);border:1px solid rgba(245,166,35,.18);
  border-radius:var(--r);padding:12px 13px;margin-bottom:12px;display:none;
}
.ls-row{display:flex;justify-content:space-between;font-size:12px;padding:3px 0;}
.ls-row .lbl{color:var(--muted);}
.ls-row .val{font-weight:700;color:var(--text);}
.ls-row .val.hi{color:var(--gold);}

/* Lipa pay options */
.lipa-pay .po.sel{border-color:var(--gold);background:rgba(245,166,35,.07);}
.lipa-pay .po.sel .po-dot{border-color:var(--gold);background:var(--gold);}

/* Rule box */
.lipa-rule{
  background:rgba(232,82,26,.07);border:1px solid rgba(232,82,26,.15);
  border-radius:var(--r);padding:10px 12px;margin-bottom:12px;
  font-size:11px;color:rgba(255,190,120,.85);line-height:1.6;
}
.lipa-rule strong{color:var(--amber2);}

/* Nav buttons */
.lipa-nav{display:flex;gap:8px;padding-bottom:2px;}
.lipa-back{
  padding:12px 16px;background:rgba(255,255,255,.06);
  border:1px solid var(--border2);border-radius:var(--rl);
  font-family:inherit;font-weight:600;font-size:13px;color:var(--muted);cursor:pointer;transition:all .18s;
}
.lipa-back:active{background:rgba(255,255,255,.1);}
.lipa-next{
  flex:1;padding:13px;
  background:linear-gradient(135deg,var(--gold),var(--amber));
  color:#fff;border:none;border-radius:var(--rl);
  font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.3px;
  cursor:pointer;transition:all .18s;
  box-shadow:0 4px 16px rgba(245,166,35,.3);
}
.lipa-next:active{transform:scale(.98);}

/* ── SUCCESS STATE ── */
.suc-wrap{text-align:center;padding:24px 16px 10px;}
.suc-ico{font-size:52px;margin-bottom:12px;}
.suc-title{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:.5px;margin-bottom:6px;}
.suc-sub{font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:12px;}
.suc-ref{font-size:12px;color:var(--amber);font-weight:700;margin-bottom:16px;}
.suc-det{background:rgba(255,255,255,.03);border-radius:var(--r);padding:11px;text-align:left;margin-bottom:14px;border:1px solid var(--border);}
.sdet-row{display:flex;justify-content:space-between;font-size:13px;padding:5px 0;border-bottom:1px solid var(--border);}
.sdet-row:last-child{border-bottom:none;}
.sdet-row span:first-child{color:var(--muted);}
.sdet-row span:last-child{font-weight:600;}
.wa-btn{
  width:100%;padding:13px;background:#25D366;color:#fff;
  border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;
  display:flex;align-items:center;justify-content:center;gap:7px;
  transition:all .2s;margin-bottom:8px;
}
.done-btn{
  width:100%;padding:12px;
  background:rgba(255,255,255,.05);color:var(--muted);
  border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;
  border:1px solid var(--border2);transition:all .2s;
}

/* ── SORT SHEET ── */
.sort-opt{padding:14px 18px;font-size:15px;color:var(--text);cursor:pointer;transition:background .13s;}
.sort-opt:active,.sort-opt:hover{background:rgba(255,255,255,.04);}
.sort-opt.sel{color:var(--amber);}

/* ── CART BADGE SHEET ── */
.cart-sum{background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:var(--r);padding:11px;margin-bottom:12px;}
.csr{display:flex;justify-content:space-between;font-size:13px;color:var(--muted);padding:4px 0;}
.csr.tot{font-size:14px;font-weight:700;color:var(--text);padding-top:8px;border-top:1px solid var(--border);margin-top:4px;}

/* ── BOTTOM NAV (matches index.php exactly) ── */
.bnav{
  position:fixed;bottom:0;left:0;right:0;z-index:200;
  height:calc(var(--bnav) + var(--sb));padding-bottom:var(--sb);
  background:rgba(8,4,0,.95);
  backdrop-filter:blur(28px);-webkit-backdrop-filter:blur(28px);
  border-top:1px solid rgba(255,255,255,.07);
  display:flex;align-items:stretch;
}
.bni{
  flex:1;display:flex;flex-direction:column;
  align-items:center;justify-content:center;
  gap:3px;padding:0 4px;
  -webkit-tap-highlight-color:transparent;
  transition:all .2s;
}
.bni-ico{font-size:20px;color:rgba(255,255,255,.38);transition:all .22s;line-height:1.15;}
.bni-lbl{font-size:9px;font-weight:700;color:rgba(255,255,255,.3);letter-spacing:.5px;text-transform:uppercase;transition:all .22s;}
.bni.active .bni-ico,.bni.active .bni-lbl{color:var(--amber);}
.bni.active::before{
  content:'';position:absolute;bottom:2px;
  width:20px;height:2px;border-radius:1px;background:var(--amber);
  animation:indIn .3s ease;
}
@keyframes indIn{from{width:0;opacity:0;}to{width:20px;opacity:1;}}
.bni{position:relative;}
/* Cart fab in nav */
.bni-cart{
  flex:1;display:flex;flex-direction:column;
  align-items:center;justify-content:center;gap:4px;
  -webkit-tap-highlight-color:transparent;
  cursor:pointer;position:relative;
}
.bni-cart-btn{
  width:48px;height:48px;border-radius:50%;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  display:flex;align-items:center;justify-content:center;font-size:18px;
  box-shadow:0 -2px 16px rgba(232,82,26,.5);
  margin-top:-16px;
  border:3px solid rgba(8,4,0,.95);
  transition:all .22s;
}
.bni-cart:active .bni-cart-btn{transform:scale(.92);}
.bni-cart-lbl{font-size:9px;font-weight:700;color:rgba(232,82,26,.75);letter-spacing:.5px;text-transform:uppercase;}
.cart-badge{
  position:absolute;top:2px;right:calc(50% - 24px);
  width:17px;height:17px;border-radius:50%;
  background:var(--gold);color:#000;
  font-size:9px;font-weight:800;
  display:none;align-items:center;justify-content:center;
  border:2px solid rgba(8,4,0,.95);
}
.cart-badge.on{display:flex;}

/* ── TOAST ── */
.toast{
  position:fixed;bottom:calc(var(--bnav) + var(--sb) + 14px);left:50%;
  transform:translateX(-50%) translateY(8px);
  background:var(--text);color:var(--ink);
  padding:10px 20px;border-radius:30px;
  font-size:13px;font-weight:600;z-index:999;
  opacity:0;pointer-events:none;transition:all .22s;white-space:nowrap;
  box-shadow:0 8px 24px rgba(0,0,0,.4);
}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
</style>
</head>
<body>

<!-- HEADER -->
<header class="hdr">
  <div class="hdr-row">
    <a href="index.php" class="back-btn">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M19 12H5M5 12l7-7M5 12l7 7"/></svg>
    </a>
    <div class="hdr-brand">Malaba <span>Shop</span></div>
    <div class="hdr-acts">
      <button class="ico-btn" onclick="openSortSheet()" title="Sort">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="11" y1="18" x2="13" y2="18"/></svg>
      </button>
      <button class="ico-btn" onclick="openCart()" title="Cart">
        &#x1F6D2;<span class="hbadge" id="hBadge">0</span>
      </button>
    </div>
  </div>
  <div class="srch-row">
    <div class="srch-box">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      <input type="search" id="srchInput" placeholder="Search products…" autocomplete="off" enterkeyhint="search">
    </div>
  </div>
  <div class="cats-row">
    <button class="cat-tab on" data-sub="">&#x2728; For You</button>
    <button class="cat-tab" data-sub="kitchen">&#x1F373; Kitchen</button>
    <button class="cat-tab" data-sub="decor">&#x1F5BC; Decor</button>
    <button class="cat-tab" data-sub="appliances">&#x26A1; Appliances</button>
    <button class="cat-tab" data-sub="storage">&#x1F9FA; Storage</button>
    <button class="cat-tab" data-sub="furniture">&#x1F6CB; Furniture</button>
    <button class="cat-tab" data-sub="cleaning">&#x1F9F9; Cleaning</button>
    <button class="cat-tab" data-sub="lighting">&#x1F4A1; Lighting</button>
  </div>
</header>

<div class="sec-head">
  <h2>&#x2728; <span id="gridTitle">For You</span></h2>
  <button class="sort-btn" onclick="openSortSheet()">
    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="15" y2="12"/><line x1="3" y1="18" x2="9" y2="18"/></svg>
    <span id="sortLbl">Smart</span>
  </button>
</div>
<div class="res-count" id="resCount"></div>

<div class="shop-grid" id="shopGrid">
  <div class="skel-card"><div class="skel-sq skel"></div><div class="skel-ln skel" style="width:75%"></div><div class="skel-ln skel" style="width:50%;margin-bottom:9px"></div></div>
  <div class="skel-card"><div class="skel-sq skel"></div><div class="skel-ln skel" style="width:70%"></div><div class="skel-ln skel" style="width:45%;margin-bottom:9px"></div></div>
  <div class="skel-card"><div class="skel-sq skel"></div><div class="skel-ln skel" style="width:80%"></div><div class="skel-ln skel" style="width:55%;margin-bottom:9px"></div></div>
  <div class="skel-card"><div class="skel-sq skel"></div><div class="skel-ln skel" style="width:65%"></div><div class="skel-ln skel" style="width:42%;margin-bottom:9px"></div></div>
</div>
<div class="load-more" id="loadMore">
  <div class="spin" id="loadSpin" style="display:none"></div>
  <div class="load-end" id="loadEnd" style="display:none">&#x1F389; You've seen everything!</div>
</div>

<!-- BOTTOM NAV — matches index.php -->
<nav class="bnav">
  <a href="index.php" class="bni">
    <div class="bni-ico">&#x1F3E1;</div>
    <div class="bni-lbl">Home</div>
  </a>
  <a href="homes_listing.php" class="bni">
    <div class="bni-ico">&#x1F3E0;</div>
    <div class="bni-lbl">Homes</div>
  </a>
  <a href="video_feed.php" style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;-webkit-tap-highlight-color:transparent;cursor:pointer;position:relative;text-decoration:none;">
    <div style="width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#6366f1);display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:0 -2px 16px rgba(124,58,237,.5);margin-top:-16px;border:3px solid rgba(8,4,0,.95);transition:all .22s;">&#x25B6;</div>
    <div style="font-size:9px;font-weight:700;color:rgba(139,92,246,.75);letter-spacing:.5px;text-transform:uppercase;">Watch</div>
  </a>
  <a href="food_listing.php" class="bni">
    <div class="bni-ico">&#x1F354;</div>
    <div class="bni-lbl">Food</div>
  </a>
  <div class="bni active" onclick="openCart()">
    <div class="bni-ico">&#x1F6D2;</div>
    <div class="bni-lbl">Shop</div>
  </div>
</nav>

<!-- OVERLAY — hosts all sheets -->
<div class="overlay" id="overlay" onclick="handleOvClick(event)">
  <div class="sheet" id="activeSheet">
    <div id="sheetContent"></div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script src="data.js"></script>
<script src="mh_user.js"></script>
<script>
/* ════════════════════════════════════════
   STATE
════════════════════════════════════════ */
var ST = {
  items:[], page:1, limit:20, total:0,
  loading:false, done:false,
  sub:'', sort:'smart', search:'',
  pMin:0, pMax:0
};
var cart     = [];
var wishlist = [];
var currentItem = null;
var payMode     = 'cash';
var lipaFreq    = null;
var lipaDur     = null;
var lipaPayMode = 'mpesa';
var lipaStep    = 1;
var lipaFreqOpts= [];
var lipaDurOpts = [];

try { cart     = JSON.parse(localStorage.getItem('mh_shop_cart') || '[]'); } catch(e){}
try { wishlist = JSON.parse(localStorage.getItem('mh_shop_wish') || '[]'); } catch(e){}

/* ════════════════════════════════════════
   API BASE
════════════════════════════════════════ */
var API_BASE = (function(){
  var scripts = document.querySelectorAll('script[src]');
  for (var i=0; i<scripts.length; i++) {
    if (scripts[i].src && scripts[i].src.indexOf('data.js') !== -1) {
      return scripts[i].src.replace(/\/data\.js[^\/]*$/, '/api');
    }
  }
  return '<?php echo htmlspecialchars($apiBase, ENT_QUOTES); ?>';
})();

/* ════════════════════════════════════════
   LIPA PLAN CALCULATOR
════════════════════════════════════════ */
function calcFrequencies(raw) {
  if (!raw || raw < 200) return [];
  var ksh = function(n){ return 'KSH ' + Math.round(n).toLocaleString('en-KE'); };
  return [
    { id:'daily',  label:'Daily',        per:'day',   factor:1.0,
      desc:'No extra charge — best value',
      amount: function(total, weeks){ return total / (weeks*7); } },
    { id:'3xweek', label:'3× per week',  per:'week',  factor:1.02,
      desc:'+2% total — great flexibility',
      amount: function(total, weeks){ return total / (weeks*3); } },
    { id:'2xweek', label:'Twice a week', per:'week',  factor:1.04,
      desc:'+4% total — comfortable pace',
      amount: function(total, weeks){ return total / (weeks*2); } },
    { id:'weekly', label:'Weekly',       per:'week',  factor:1.07,
      desc:'+7% total — once a week',
      amount: function(total, weeks){ return total / weeks; } },
  ];
}
function calcDurations(raw, freq) {
  if (!freq) return [];
  var ksh   = function(n){ return 'KSH ' + Math.round(n).toLocaleString('en-KE'); };
  var total = raw * freq.factor;
  return [
    { weeks:2,  label:'2 Weeks',  deposit:raw*.25, total:total },
    { weeks:4,  label:'4 Weeks',  deposit:raw*.2,  total:total },
    { weeks:8,  label:'8 Weeks',  deposit:raw*.15, total:total*1.03 },
    { weeks:12, label:'12 Weeks', deposit:raw*.1,  total:total*1.06 },
  ].map(function(d){
    var perPay = freq.amount(d.total, d.weeks);
    return {
      weeks:d.weeks, label:d.label,
      depositAmt:d.deposit, deposit:ksh(d.deposit),
      total:d.total, totalStr:ksh(d.total),
      perPay:perPay, perPayStr:ksh(perPay),
    };
  });
}

/* ════════════════════════════════════════
   INIT
════════════════════════════════════════ */
window.addEventListener('DOMContentLoaded', function(){
  renderBadges();
  loadItems(true);
  initInfiniteScroll();
  initSearch();
  initCats();
  // Swipe-down to close sheet
  var sheet = document.getElementById('activeSheet');
  var tsY = 0;
  sheet.addEventListener('touchstart', function(e){ tsY = e.touches[0].clientY; }, {passive:true});
  sheet.addEventListener('touchend', function(e){
    if (e.changedTouches[0].clientY - tsY > 80 && sheet.scrollTop === 0) closeOverlay();
  }, {passive:true});
});

/* ════════════════════════════════════════
   LOAD ITEMS
════════════════════════════════════════ */
function loadItems(reset) {
  if (ST.loading || (ST.done && !reset)) return;
  ST.loading = true;
  if (reset) { ST.page=1; ST.items=[]; ST.done=false; }
  showSpin(true);

  var useRec = ST.sort==='smart' && ST.sub==='' && ST.search==='';
  var url;
  if (useRec) {
    url = API_BASE+'/recommended.php?page='+ST.page+'&limit='+ST.limit+'&pMin='+ST.pMin+'&pMax='+(ST.pMax||0);
  } else {
    url = API_BASE+'/listings.php?type=items&page='+ST.page+'&limit='+ST.limit+'&search='+encodeURIComponent(ST.search)+'&sort='+ST.sort+'&filter='+ST.sub+'&priceMin='+ST.pMin+'&priceMax='+(ST.pMax||0);
  }

  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout = 9000;
  xhr.onload = function() {
    var newItems = [];
    try {
      var d = JSON.parse(xhr.responseText);
      if (d && d.success) { newItems=d.data; ST.total=d.meta.total; if(ST.page>=d.meta.pages) ST.done=true; }
    } catch(e){}
    finish(newItems, reset);
  };
  xhr.onerror = xhr.ontimeout = function() { finish([], reset); };
  xhr.send();

  function finish(newItems, reset) {
    if (!newItems.length) {
      var seed = (window.MalabaAPI && MalabaAPI._seed && MalabaAPI._seed.items) ? MalabaAPI._seed.items : [];
      if (ST.sub) seed = seed.filter(function(i){ return i.subCategory===ST.sub; });
      if (ST.search) {
        var q = ST.search.toLowerCase();
        seed = seed.filter(function(i){ return ((i.title||'')+(i.description||'')).toLowerCase().indexOf(q)!==-1; });
      }
      newItems = seed; ST.total=seed.length; ST.done=true;
    }
    if (reset) { ST.items=newItems; renderGrid(true); }
    else { newItems.forEach(function(i){ ST.items.push(i); }); renderGrid(false, newItems); }
    ST.page++; ST.loading=false;
    showSpin(false);
    var el = document.getElementById('resCount');
    if (el) el.textContent = ST.items.length + (ST.done?'':'+') + ' product' + (ST.items.length!==1?'s':'');
    if (ST.done) { var le=document.getElementById('loadEnd'); if(le) le.style.display='block'; }
  }
}

/* ════════════════════════════════════════
   RENDER GRID
════════════════════════════════════════ */
function renderGrid(reset, newItems) {
  var grid = document.getElementById('shopGrid');
  if (reset) grid.innerHTML = '';
  var items = newItems || ST.items;
  if (!items.length && reset) {
    grid.innerHTML = '<div class="empty"><div class="empty-ico">&#x1F50D;</div><h3>Nothing Found</h3><p>Try a different search or category</p></div>';
    return;
  }
  var frag = document.createDocumentFragment();
  items.forEach(function(item, i) {
    var el = document.createElement('div');
    el.className = 'pcard';
    el.style.animationDelay = Math.min(i, 8) * 0.05 + 's';
    el.innerHTML = cardHTML(item);
    frag.appendChild(el);
  });
  grid.appendChild(frag);
}

function cardHTML(item) {
  var liked  = wishlist.indexOf(item.id) !== -1;
  var inCart = cart.find(function(c){ return c.id===item.id; });
  var raw    = parseFloat(String(item.price||'0').replace(/[^0-9.]/g,'')) || 0;
  var hasLipa= raw >= 200;
  var hasVid = !!(item.video_url || item.has_video);
  var img    = item.image || item.image_url || 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=800&q=80';
  var rating = item.rating ? parseFloat(item.rating).toFixed(1) : (3.9 + Math.random()*.9).toFixed(1);

  return (
    '<div class="pcard-img" onclick="openQV(\'' + esc(item.id) + '\')">' +
      '<img src="' + esc(img) + '" alt="' + esc(item.title) + '" loading="lazy" onerror="this.src=\'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=800&q=80\'">' +
      (item.badge ? '<div class="pbadge">' + esc(item.badge) + '</div>' : '') +
      (hasLipa ? '<div class="plipa-badge">&#x1F4B0; Lipa Mdogo</div>' : '') +
      '<button class="wish ' + (liked?'liked':'') + '" onclick="toggleWish(event,\'' + esc(item.id) + '\',this)">' + (liked?'&#x2665;':'&#x2661;') + '</button>' +
    '</div>' +
    '<div class="pcard-body" onclick="openQV(\'' + esc(item.id) + '\')">' +
      '<div class="ptitle">' + esc(item.title) + '</div>' +
      '<div class="prating">&#x2605;&#x2605;&#x2605;&#x2605;' + (parseFloat(rating)>=4.5?'&#x2605;':'&#x2606;') + '<span>' + rating + '</span></div>' +
      '<div class="ploc">&#x1F4CD; ' + esc((item.location||'').split(',')[0]) + '</div>' +
    '</div>' +
    '<div class="pprice" onclick="openQV(\'' + esc(item.id) + '\')">' + esc(item.price) + '</div>' +
    '<div class="pcard-foot">' +
      '<button class="btn-order ' + (inCart?'added':'') + '" id="btn-' + esc(item.id) + '" onclick="quickOrder(event,\'' + esc(item.id) + '\')">' +
        (inCart ? '&#x2713; In Cart' : '&#x1F6D2; Buy') +
      '</button>' +
      (hasLipa ?
      '<button class="btn-lipa" onclick="openLipa(event,\'' + esc(item.id) + '\')" title="Pay in instalments">&#x1F4B0;</button>'
      : '') +
      '<button class="btn-qv" onclick="openQV(\'' + esc(item.id) + '\')" title="Quick view">&#x1F441;</button>' +
    '</div>'
  );
}

/* ════════════════════════════════════════
   QUICK ORDER (tap Buy on card → instant form)
════════════════════════════════════════ */
function quickOrder(ev, id) {
  ev.stopPropagation();
  var item = ST.items.find(function(i){ return i.id===id; });
  if (!item) return;
  currentItem = item;
  // Add to cart first, then open cart
  var ex = cart.find(function(c){ return c.id===id; });
  if (!ex) {
    cart.push({id:id, title:item.title, price:item.price, qty:1,
               shop:item.location||'', phone:(item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'')});
    saveCart(); renderBadges();
    var btn = document.getElementById('btn-'+id);
    if (btn) { btn.innerHTML='&#x2713; In Cart'; btn.classList.add('added'); }
  }
  openCart();
}

/* ════════════════════════════════════════
   QUICK VIEW
════════════════════════════════════════ */
function openQV(id) {
  var item = ST.items.find(function(i){ return i.id===id; });
  if (!item) return;
  currentItem = item;
  var img    = item.image || item.image_url || '';
  var raw    = parseFloat(String(item.price||'0').replace(/[^0-9.]/g,'')) || 0;
  var hasLipa= raw >= 200;
  var hasVid = !!(item.video_url || item.has_video);
  var inCart = cart.find(function(c){ return c.id===id; });

  var featsHTML = '';
  if (item.features && item.features.length) {
    featsHTML = '<div class="qv-feats">' +
      item.features.map(function(f){ return '<div class="qf"><span class="qf-ico">'+(f.icon||'&#x2705;')+'</span>'+esc(f.text||f.feature_text||'')+'</div>'; }).join('') +
      '</div>';
  }

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div><button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +
    (img ? '<img src="'+esc(img)+'" class="qv-img" loading="lazy" onerror="this.src=\'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=800&q=80\'">' : '') +
    '<div class="qv-pad">' +
      (item.badge ? '<div class="qv-badge">'+esc(item.badge)+'</div>' : '') +
      '<div class="qv-title">'+esc(item.title)+'</div>' +
      '<div class="qv-price">'+esc(item.price)+'</div>' +
      (item.description ? '<div class="qv-desc">'+esc(item.description)+'</div>' : '') +
      featsHTML +
      // BUY OPTIONS
      '<div class="buy-options">' +
        '<div class="buy-opt opt-full" onclick="openDirectOrder(\''+esc(id)+'\')">' +
          '<div class="bo-icon boi-full">&#x1F6D2;</div>' +
          '<div class="bo-info"><div class="bo-title">Buy Now — '+esc(item.price)+'</div><div class="bo-sub">Pay full price. Cash or M-Pesa on delivery.</div></div>' +
          '<div class="bo-arrow">&#x203A;</div>' +
        '</div>' +
        (hasLipa ?
        '<div class="buy-opt opt-lipa" onclick="openLipaFromQV(\''+esc(id)+'\')">' +
          '<div class="bo-icon boi-lipa">&#x1F4B0;</div>' +
          '<div class="bo-info"><div class="bo-title">Lipa Mdogo Mdogo</div><div class="bo-sub">Pay daily, weekly or twice a week. Get it after full payment.</div></div>' +
          '<div class="bo-arrow">&#x203A;</div>' +
        '</div>' : '') +
        (hasVid ?
        '<div class="buy-opt opt-watch" onclick="location.href=\'video_feed.php?id='+esc(id)+'&cat=items\'">' +
          '<div class="bo-icon boi-watch">&#x25B6;</div>' +
          '<div class="bo-info"><div class="bo-title">Watch Video</div><div class="bo-sub">See this product in action on Watch &amp; Shop.</div></div>' +
          '<div class="bo-arrow">&#x203A;</div>' +
        '</div>' : '') +
      '</div>' +
      (inCart ?
      '<div style="text-align:center;font-size:13px;color:var(--green);padding:4px 0 8px;">&#x2713; Already in your cart — <button onclick="openCart()" style="color:var(--amber);font-weight:700;font-size:13px;cursor:pointer;">View Cart</button></div>'
      : '') +
    '</div>';

  openSheet();
  if (window.MalabaAPI) MalabaAPI.trackView(id);
}

/* ════════════════════════════════════════
   DIRECT ORDER FORM (full purchase)
════════════════════════════════════════ */
function openDirectOrder(id) {
  var item = id ? (ST.items.find(function(i){ return i.id===id; }) || currentItem) : currentItem;
  if (!item) return;
  currentItem = item;
  payMode = 'cash';

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div><button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<div style="padding:14px 16px 0;">' +
      // Mini product header
      '<div style="display:flex;align-items:center;gap:10px;padding-bottom:14px;border-bottom:1px solid var(--border);margin-bottom:16px;">' +
        '<div style="font-size:26px;">&#x1F6D2;</div>' +
        '<div><div style="font-family:\'Bebas Neue\',sans-serif;font-size:17px;letter-spacing:.3px;">' + esc(item.title) + '</div>' +
        '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:20px;color:var(--amber2);">' + esc(item.price) + '</div></div>' +
      '</div>' +
      '<div class="row2">' +
        '<div class="field"><label>Full Name *</label><input type="text" id="do_name" placeholder="Your name" autocomplete="name"></div>' +
        '<div class="field"><label>Phone *</label><input type="tel" id="do_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>' +
      '</div>' +
      '<div class="field"><label>Delivery Address *</label><input type="text" id="do_addr" placeholder="e.g. Near Malaba Market"></div>' +
      '<div style="font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:8px;">Payment Method</div>' +
      '<div class="pay-opts">' +
        '<div class="po sel" id="do_cash" onclick="setDirectPay(\'cash\',this)"><div class="po-ico">&#x1F4B5;</div><div class="po-txt"><strong>Cash on Delivery</strong><span>Pay when item arrives</span></div><div class="po-dot"></div></div>' +
        '<div class="po" id="do_mpesa" onclick="setDirectPay(\'mpesa\',this)"><div class="po-ico">&#x1F4F1;</div><div class="po-txt"><strong>M-Pesa on Delivery</strong><span>Send M-Pesa when delivered</span></div><div class="po-dot"></div></div>' +
      '</div>' +
      '<button class="sbtn" id="doSubmitBtn" onclick="submitDirectOrder()">&#x1F6D2; Place Order — ' + esc(item.price) + '</button>' +
    '</div>';

  openSheet();
  prefillSaved();
}

function setDirectPay(mode, el) {
  payMode = mode;
  document.getElementById('do_cash').classList.toggle('sel', mode==='cash');
  document.getElementById('do_mpesa').classList.toggle('sel', mode==='mpesa');
}

function submitDirectOrder() {
  var name  = (document.getElementById('do_name').value||'').trim();
  var phone = (document.getElementById('do_phone').value||'').trim();
  var addr  = (document.getElementById('do_addr').value||'').trim();
  if (!name)  { showToast('Enter your full name'); return; }
  if (!phone || phone.replace(/\D/g,'').length < 9) { showToast('Enter a valid phone number'); return; }
  if (!addr)  { showToast('Enter your delivery address'); return; }

  var btn = document.getElementById('doSubmitBtn');
  if (btn) { btn.disabled=true; btn.textContent='Placing order…'; }

  saveMhUser(name, phone, addr);
  var item = currentItem;
  var phone2 = (item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'');
  var waNum  = normWA(phone2);

  postOrder({
    category:'items', listing_id:item.id||'',
    listing_title:item.title||'', listing_price:item.price||'',
    name:name, phone:phone, address:addr,
    payment_method:payMode==='mpesa'?'mpesa_on_delivery':'cash_on_delivery',
    total_amount:item.price||'0',
    notes:'Direct buy from shop — '+payMode,
  }, function(d) {
    var ref = d && d.order_ref ? d.order_ref : '';
    var msg = encodeURIComponent('Hi! I ordered *'+item.title+'* ('+item.price+')\nRef: '+(ref||'—')+'\nName: '+name+'\nPhone: '+phone+'\nAddress: '+addr+'\nPayment: '+payMode);
    showSuccess('&#x2705; Order Placed!',
      payMode==='cash' ? 'Pay '+item.price+' cash when your item arrives.' : 'Our agent will arrange M-Pesa payment on delivery.',
      ref,
      function(){ window.open('https://wa.me/'+waNum+'?text='+msg,'_blank'); }
    );
  }, function() {
    if (btn) { btn.disabled=false; btn.textContent='&#x1F6D2; Place Order — '+item.price; }
    showToast('Network error. Please try again.');
  });
}

/* ════════════════════════════════════════
   LIPA MDOGO MDOGO
════════════════════════════════════════ */
function openLipa(ev, id) {
  if (ev) ev.stopPropagation();
  var item = ST.items.find(function(i){ return i.id===id; });
  if (!item) return;
  currentItem = item;
  startLipaSheet();
}
function openLipaFromQV(id) {
  var item = ST.items.find(function(i){ return i.id===id; }) || currentItem;
  if (!item) return;
  currentItem = item;
  startLipaSheet();
}

function startLipaSheet() {
  var item = currentItem;
  if (!item) return;
  lipaFreq = null; lipaDur = null; lipaStep = 1;
  var raw  = parseFloat(String(item.price||'0').replace(/[^0-9.]/g,'')) || 0;
  lipaFreqOpts = calcFrequencies(raw);
  if (!lipaFreqOpts.length) { openDirectOrder(item.id); return; }
  var img = item.image || item.image_url || '';

  document.getElementById('sheetContent').innerHTML =
    // handle
    '<div class="sh-top"><div class="sh-handle"></div><button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +
    // product header
    '<div class="lipa-header">' +
      '<div class="lipa-product-row">' +
        (img ? '<img class="lipa-pimg" src="'+esc(img)+'" onerror="this.style.display=\'none\'">' : '<div class="lipa-pimg-ph">&#x1F4E6;</div>') +
        '<div><div class="lipa-pname">'+esc(item.title)+'</div>' +
        '<div class="lipa-pwas">'+esc(item.price)+' full price</div>' +
        '<div class="lipa-ptag">&#x1F4B0; Instalment plan available</div></div>' +
      '</div>' +
      // step indicators
      '<div class="lipa-steps">' +
        '<div class="lstep"><div class="ls-dot active" id="lsd1">1</div><div class="ls-lbl active" id="lsl1">Frequency</div></div>' +
        '<div class="ls-line" id="lsl1l"></div>' +
        '<div class="lstep"><div class="ls-dot" id="lsd2">2</div><div class="ls-lbl" id="lsl2">Duration</div></div>' +
        '<div class="ls-line" id="lsl2l"></div>' +
        '<div class="lstep"><div class="ls-dot" id="lsd3">3</div><div class="ls-lbl" id="lsl3">Details</div></div>' +
      '</div>' +
    '</div>' +
    // STEP 1 — Frequency
    '<div class="lipa-panel active" id="lp1">' +
      '<div class="lipa-sec-title">How often can you pay?</div>' +
      '<div class="lipa-sec-sub">Choose the frequency that works for you. Daily payments have zero markup.</div>' +
      buildFrequencyHTML() +
      '<div class="lipa-nav"><button class="lipa-next" onclick="lipaNext(1)">Next: Choose Duration &#x2192;</button></div>' +
    '</div>' +
    // STEP 2 — Duration
    '<div class="lipa-panel" id="lp2">' +
      '<div class="lipa-sec-title">How long to pay?</div>' +
      '<div class="lipa-sec-sub">Shorter plans = larger payments. Longer plans = smaller payments with a small markup.</div>' +
      '<div class="lipa-durs" id="lipaDurGrid"></div>' +
      '<div class="lipa-summary" id="lipaSummary"></div>' +
      '<div class="lipa-nav">' +
        '<button class="lipa-back" onclick="lipaBack(2)">&#x2190; Back</button>' +
        '<button class="lipa-next" onclick="lipaNext(2)">Next: Your Details &#x2192;</button>' +
      '</div>' +
    '</div>' +
    // STEP 3 — Details
    '<div class="lipa-panel" id="lp3">' +
      '<div class="lipa-sec-title">Your Details</div>' +
      '<div class="lipa-rule"><strong>&#x26A0; Important:</strong> Product is delivered ONLY after all payments are received. Your first payment secures the order.</div>' +
      '<div class="field"><label>Full Name *</label><input type="text" id="lp_name" placeholder="Your full name" autocomplete="name"></div>' +
      '<div class="field"><label>Phone *</label><input type="tel" id="lp_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>' +
      '<div class="field"><label>Delivery Address *</label><input type="text" id="lp_addr" placeholder="e.g. Near Malaba Market"></div>' +
      '<div style="font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:8px;padding:0 0 2px;">First payment method</div>' +
      '<div class="pay-opts lipa-pay">' +
        '<div class="po sel" id="lpo_mpesa" onclick="setLipaPay(\'mpesa\',this)"><div class="po-ico">&#x1F4F1;</div><div class="po-txt"><strong>M-Pesa</strong><span>Send M-Pesa for first instalment</span></div><div class="po-dot"></div></div>' +
        '<div class="po" id="lpo_cash" onclick="setLipaPay(\'cash\',this)"><div class="po-ico">&#x1F4B5;</div><div class="po-txt"><strong>Cash</strong><span>Pay first instalment in cash</span></div><div class="po-dot"></div></div>' +
      '</div>' +
      '<div class="lipa-nav">' +
        '<button class="lipa-back" onclick="lipaBack(3)">&#x2190; Back</button>' +
        '<button class="lipa-next" id="lipaSubmitBtn" onclick="submitLipa()">&#x1F4B0; Submit Plan Request</button>' +
      '</div>' +
    '</div>';

  openSheet();
  prefillSaved();
}

function buildFrequencyHTML() {
  if (!lipaFreqOpts.length) return '';
  var html = '<div class="lipa-freqs">';
  lipaFreqOpts.forEach(function(f, i) {
    // Estimate amount using 4-week default for display
    var estAmount = (parseFloat(String(currentItem.price||'0').replace(/[^0-9.]/g,''))||0) * f.factor;
    var perPay    = f.amount(estAmount, 4);
    html +=
      '<div class="lipa-freq" id="lf-'+f.id+'" onclick="selFreq(\''+f.id+'\','+i+')">' +
        '<div class="lf-radio"></div>' +
        '<div class="lf-info"><div class="lf-name">'+f.label+'</div><div class="lf-desc">'+f.desc+'</div></div>' +
        '<div class="lf-right">' +
          '<div class="lf-amount">KSH '+Math.round(perPay).toLocaleString('en-KE')+'</div>' +
          '<div class="lf-per">/'+f.per+' (est.)</div>' +
        '</div>' +
      '</div>';
  });
  html += '</div>';
  return html;
}

function selFreq(id, i) {
  lipaFreq = lipaFreqOpts[i];
  document.querySelectorAll('.lipa-freq').forEach(function(el){ el.classList.remove('sel'); });
  var el = document.getElementById('lf-'+id);
  if (el) el.classList.add('sel');
  // Rebuild duration options with this frequency
  var raw = parseFloat(String(currentItem.price||'0').replace(/[^0-9.]/g,'')) || 0;
  lipaDurOpts = calcDurations(raw, lipaFreq);
  buildDurGrid();
}

function buildDurGrid() {
  var grid = document.getElementById('lipaDurGrid');
  if (!grid) return;
  lipaDur = null;
  var html = '';
  lipaDurOpts.forEach(function(d, i) {
    html +=
      '<div class="lipa-dur" id="ld-'+i+'" onclick="selDur('+i+')">' +
        '<div class="ld-weeks">'+d.weeks+'</div>' +
        '<div class="ld-label">weeks</div>' +
        '<div class="ld-per">'+d.perPayStr+'</div>' +
        '<div class="ld-total">Total: '+d.totalStr+'</div>' +
      '</div>';
  });
  grid.innerHTML = html;
  var s = document.getElementById('lipaSummary');
  if (s) s.style.display='none';
}

function selDur(i) {
  lipaDur = lipaDurOpts[i];
  document.querySelectorAll('.lipa-dur').forEach(function(el){ el.classList.remove('sel'); });
  var el = document.getElementById('ld-'+i);
  if (el) el.classList.add('sel');
  // Show summary
  var s = document.getElementById('lipaSummary');
  if (s) {
    s.style.display = 'block';
    s.innerHTML =
      '<div class="ls-row"><span class="lbl">Frequency</span><span class="val">'+lipaFreq.label+'</span></div>' +
      '<div class="ls-row"><span class="lbl">Duration</span><span class="val">'+lipaDur.label+'</span></div>' +
      '<div class="ls-row"><span class="lbl">Per payment</span><span class="val hi">'+lipaDur.perPayStr+'</span></div>' +
      '<div class="ls-row"><span class="lbl">First deposit</span><span class="val">'+lipaDur.deposit+'</span></div>' +
      '<div class="ls-row"><span class="lbl">Grand total</span><span class="val">'+lipaDur.totalStr+'</span></div>';
  }
}

function lipaNext(step) {
  if (step===1) {
    if (!lipaFreq) { showToast('Please select a payment frequency'); return; }
    if (!lipaDurOpts.length) {
      var raw = parseFloat(String(currentItem.price||'0').replace(/[^0-9.]/g,'')) || 0;
      lipaDurOpts = calcDurations(raw, lipaFreq);
      buildDurGrid();
    }
  }
  if (step===2) {
    if (!lipaDur) { showToast('Please select a duration'); return; }
  }
  setLipaStep(step+1);
}
function lipaBack(step){ setLipaStep(step-1); }

function setLipaStep(s) {
  lipaStep = s;
  // Update panels
  [1,2,3].forEach(function(n) {
    var p = document.getElementById('lp'+n);
    if (p) p.className = 'lipa-panel' + (n===s?' active':'');
  });
  // Update indicators
  [1,2,3].forEach(function(n) {
    var dot = document.getElementById('lsd'+n);
    var lbl = document.getElementById('lsl'+n);
    var ln  = document.getElementById('lsl'+n+'l');
    if (!dot) return;
    if (n < s) { dot.className='ls-dot done'; dot.innerHTML='&#x2713;'; lbl.className='ls-lbl done'; if(ln)ln.className='ls-line done'; }
    else if (n===s) { dot.className='ls-dot active'; dot.innerHTML=n; lbl.className='ls-lbl active'; }
    else { dot.className='ls-dot'; dot.innerHTML=n; lbl.className='ls-lbl'; if(ln)ln.className='ls-line'; }
  });
}

function setLipaPay(mode, el) {
  lipaPayMode = mode;
  ['lpo_mpesa','lpo_cash'].forEach(function(id){ var e=document.getElementById(id); if(e)e.classList.remove('sel'); });
  el.classList.add('sel');
}

function submitLipa() {
  if (!lipaFreq || !lipaDur) { showToast('Complete all steps first'); return; }
  var name  = (document.getElementById('lp_name').value||'').trim();
  var phone = (document.getElementById('lp_phone').value||'').trim();
  var addr  = (document.getElementById('lp_addr').value||'').trim();
  if (!name)  { showToast('Enter your full name'); return; }
  if (!phone || phone.replace(/\D/g,'').length < 9) { showToast('Enter a valid phone number'); return; }
  if (!addr)  { showToast('Enter your delivery address'); return; }

  var btn = document.getElementById('lipaSubmitBtn');
  if (btn) { btn.disabled=true; btn.textContent='Sending…'; }

  saveMhUser(name, phone, addr);
  var item = currentItem;
  var notes = 'LIPA MDOGO MDOGO | Freq: '+lipaFreq.label+' | Duration: '+lipaDur.label+' | Per payment: '+lipaDur.perPayStr+' | Deposit: '+lipaDur.deposit+' | Total: '+lipaDur.totalStr+' | First pay: '+lipaPayMode+' | DELIVER AFTER FULL PAYMENT ONLY';
  var phone2 = (item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'');
  var waNum  = normWA(phone2);

  postOrder({
    category:'items', listing_id:item.id||'',
    listing_title:item.title||'', listing_price:item.price||'',
    name:name, phone:phone, address:addr,
    payment_method:lipaPayMode,
    total_amount:String(lipaDur.total||'0'),
    notes:notes,
  }, function(d) {
    var ref = d && d.order_ref ? d.order_ref : '';
    var msg = encodeURIComponent(
      'Hi! Lipa Mdogo Mdogo request:\n*'+item.title+'*\n' +
      'Frequency: '+lipaFreq.label+'\nDuration: '+lipaDur.label+'\nPer payment: '+lipaDur.perPayStr+'\nDeposit: '+lipaDur.deposit+'\nTotal: '+lipaDur.totalStr+'\n' +
      'Ref: '+(ref||'—')+'\nName: '+name+'\nPhone: '+phone+'\nAddress: '+addr+'\nFirst payment: '+lipaPayMode+'\n\n' +
      '⚠️ Product delivered ONLY after all payments received.'
    );
    showSuccess('&#x1F389; Request Sent!',
      'Your '+lipaFreq.label+' plan over '+lipaDur.label+' has been received. We\'ll confirm via WhatsApp.',
      ref,
      function(){ window.open('https://wa.me/'+waNum+'?text='+msg,'_blank'); }
    );
  }, function() {
    if (btn) { btn.disabled=false; btn.textContent='&#x1F4B0; Submit Plan Request'; }
    showToast('Network error. Please try again.');
  });
}

/* ════════════════════════════════════════
   CART
════════════════════════════════════════ */
function openCart() {
  var total = cart.reduce(function(s,c){ return s + px(c.price)*c.qty; }, 0);
  var n     = cart.reduce(function(s,c){ return s + c.qty; }, 0);
  var dlv   = total >= 2000 ? 0 : 100;
  var grand = total + dlv;

  if (!n) { showToast('Your cart is empty'); return; }

  var itemsHTML = cart.map(function(c) {
    return '<div style="display:flex;align-items:center;gap:10px;background:rgba(255,255,255,.03);border-radius:var(--r);padding:10px;border:1px solid var(--border);">' +
      '<div style="flex:1;min-width:0;">' +
        '<div style="font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">'+esc(c.title)+'</div>' +
        '<div style="font-size:11px;color:var(--muted);margin-top:1px;">'+esc((c.shop||'').split(',')[0])+'</div>' +
      '</div>' +
      '<div style="display:flex;align-items:center;gap:5px;">' +
        '<button style="width:24px;height:24px;border-radius:50%;background:var(--surface);border:1px solid var(--border2);color:var(--text);font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:center;cursor:pointer;" onclick="cartQty(\''+esc(c.id)+'\',-1)">&#x2212;</button>' +
        '<span style="font-family:\'Bebas Neue\',sans-serif;font-size:14px;min-width:14px;text-align:center;">'+c.qty+'</span>' +
        '<button style="width:24px;height:24px;border-radius:50%;background:var(--surface);border:1px solid var(--border2);color:var(--text);font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:center;cursor:pointer;" onclick="cartQty(\''+esc(c.id)+'\',1)">+</button>' +
      '</div>' +
      '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:14px;color:var(--amber2);letter-spacing:.3px;">KSH '+( px(c.price)*c.qty ).toLocaleString()+'</div>' +
      '<button style="color:var(--muted);font-size:14px;padding:2px 4px;cursor:pointer;" onclick="cartQty(\''+esc(c.id)+'\',0)">&#x2715;</button>' +
    '</div>';
  }).join('');

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div><button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<div style="padding:14px 16px 0;">' +
      '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:22px;letter-spacing:.5px;margin-bottom:14px;">&#x1F6D2; Cart <span style="color:var(--amber2);">('+n+' item'+(n!==1?'s':'')+')</span></div>' +
      '<div style="display:flex;flex-direction:column;gap:7px;margin-bottom:14px;">'+itemsHTML+'</div>' +
      '<div class="cart-sum">' +
        '<div class="csr"><span>Subtotal</span><span>KSH '+total.toLocaleString()+'</span></div>' +
        '<div class="csr"><span>Delivery</span><span>'+(dlv===0?'<span style="color:var(--green);">FREE</span>':'KSH '+dlv)+'</span></div>' +
        '<div class="csr tot"><span>Total on Delivery</span><span>KSH '+grand.toLocaleString()+'</span></div>' +
      '</div>' +
      // Checkout form inline
      '<div class="row2">' +
        '<div class="field"><label>Full Name *</label><input type="text" id="cart_name" placeholder="Your name" autocomplete="name"></div>' +
        '<div class="field"><label>Phone *</label><input type="tel" id="cart_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>' +
      '</div>' +
      '<div class="field"><label>Delivery Address *</label><input type="text" id="cart_addr" placeholder="e.g. Near Malaba Market"></div>' +
      '<div class="pay-opts">' +
        '<div class="po sel" id="cart_cash"  onclick="setCartPay(\'cash\',this)"><div class="po-ico">&#x1F4B5;</div><div class="po-txt"><strong>Cash on Delivery</strong><span>Pay when items arrive</span></div><div class="po-dot"></div></div>' +
        '<div class="po" id="cart_mpesa" onclick="setCartPay(\'mpesa\',this)"><div class="po-ico">&#x1F4F1;</div><div class="po-txt"><strong>M-Pesa on Delivery</strong><span>Send M-Pesa when delivered</span></div><div class="po-dot"></div></div>' +
      '</div>' +
      '<button class="sbtn" id="cartSubmitBtn" onclick="submitCart()">&#x2705; Place Order — KSH '+grand.toLocaleString()+'</button>' +
    '</div>';

  openSheet();
  prefillSaved();
  window._cartGrand = grand; window._cartDlv = dlv;
}

function setCartPay(mode, el) {
  payMode = mode;
  ['cart_cash','cart_mpesa'].forEach(function(id){ var e=document.getElementById(id); if(e)e.classList.remove('sel'); });
  el.classList.add('sel');
}

function cartQty(id, d) {
  var ex = cart.find(function(c){ return c.id===id; });
  if (!ex) return;
  if (d === 0) { cart = cart.filter(function(c){ return c.id!==id; }); }
  else {
    ex.qty = Math.max(0, ex.qty + d);
    if (!ex.qty) cart = cart.filter(function(c){ return c.id!==id; });
  }
  saveCart(); renderBadges();
  if (!cart.length) { closeOverlay(); return; }
  openCart();
}

function submitCart() {
  var name  = (document.getElementById('cart_name').value||'').trim();
  var phone = (document.getElementById('cart_phone').value||'').trim();
  var addr  = (document.getElementById('cart_addr').value||'').trim();
  if (!name)  { showToast('Enter your full name'); return; }
  if (!phone || phone.replace(/\D/g,'').length < 9) { showToast('Enter a valid phone number'); return; }
  if (!addr)  { showToast('Enter your delivery address'); return; }

  var btn = document.getElementById('cartSubmitBtn');
  if (btn) { btn.disabled=true; btn.textContent='Placing order…'; }

  saveMhUser(name, phone, addr);
  var grand     = window._cartGrand || 0;
  var items     = cart.map(function(c){ return c.title; }).join(', ');
  var shopPhone = cart[0] && cart[0].phone ? cart[0].phone : '';
  var waNum     = normWA(shopPhone);
  var snapshot  = cart.slice();

  postOrder({
    category:'items',
    listing_id: snapshot[0] && snapshot[0].id ? snapshot[0].id : '',
    name:name, phone:phone, address:addr,
    payment_method:payMode==='mpesa'?'mpesa_on_delivery':'cash_on_delivery',
    total_amount:String(grand),
    notes:'Cart order: '+items+' | Addr:'+addr+' | Pay:'+payMode,
    cart_items:snapshot.map(function(c){ return {id:c.id,title:c.title,price:c.price,qty:c.qty}; }),
  }, function(d) {
    var ref = d && d.order_ref ? d.order_ref : '';
    var msg = encodeURIComponent('Hi!\nOrder from *'+name+'*\nPhone: '+phone+'\nAddress: '+addr+'\nItems: '+items+'\nTotal: KSH '+grand.toLocaleString()+'\nPayment: '+payMode+'\nRef: '+(ref||'—'));
    // Clear cart
    snapshot.forEach(function(c) {
      var btn2 = document.getElementById('btn-'+c.id);
      if (btn2) { btn2.innerHTML='+ Buy'; btn2.classList.remove('added'); }
    });
    cart = []; saveCart(); renderBadges();
    showSuccess('&#x1F389; Order Placed!',
      payMode==='cash' ? 'Pay KSH '+grand.toLocaleString()+' cash when your items arrive.' : 'Our agent will arrange M-Pesa payment on delivery.',
      ref,
      function(){ window.open('https://wa.me/'+waNum+'?text='+msg,'_blank'); }
    );
  }, function() {
    if (btn) { btn.disabled=false; btn.textContent='&#x2705; Place Order — KSH '+grand.toLocaleString(); }
    showToast('Network error. Please try again.');
  });
}

/* ════════════════════════════════════════
   SUCCESS STATE
════════════════════════════════════════ */
function showSuccess(title, sub, ref, waFn) {
  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div><button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<div class="suc-wrap">' +
      '<div class="suc-ico">'+title.charAt(0)+'</div>' +
      // actually use the emoji in title
    '</div>';

  // Rewrite properly
  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div><button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<div class="suc-wrap">' +
      '<div class="suc-ico">'+( title.indexOf('Plan')!==-1 ? '&#x1F389;' : '&#x2705;' )+'</div>' +
      '<div class="suc-title">'+title.replace(/^[^ ]+ /,'')+'</div>' +
      '<div class="suc-sub">'+sub+'</div>' +
      (ref ? '<div class="suc-ref">Order Ref: '+esc(ref)+'</div>' : '') +
      '<button class="wa-btn" id="sucWaBtn">&#x1F4AC; Confirm on WhatsApp</button>' +
      '<button class="done-btn" onclick="closeOverlay()">Continue Shopping</button>' +
    '</div>';

  var waBtn = document.getElementById('sucWaBtn');
  if (waBtn) waBtn.onclick = waFn;
}

/* ════════════════════════════════════════
   SORT SHEET
════════════════════════════════════════ */
function openSortSheet() {
  var sorts = [
    {v:'smart',     l:'&#x2728; Smart (For You)'},
    {v:'newest',    l:'&#x1F195; Newest First'},
    {v:'popular',   l:'&#x1F525; Most Popular'},
    {v:'price_asc', l:'&#x1F4B8; Price: Low to High'},
    {v:'price_desc',l:'&#x1F48E; Price: High to Low'},
  ];
  var html =
    '<div class="sh-top"><div class="sh-handle"></div><button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<div style="padding:4px 0 8px;">';
  sorts.forEach(function(s) {
    html += '<div class="sort-opt '+(ST.sort===s.v?'sel':'')+'" onclick="applySort(\''+s.v+'\',\''+s.l+'\')">'+s.l+'</div>';
  });
  html += '</div>';
  document.getElementById('sheetContent').innerHTML = html;
  openSheet();
}

function applySort(v, l) {
  ST.sort = v;
  var el = document.getElementById('sortLbl');
  if (el) el.textContent = v.charAt(0).toUpperCase()+v.slice(1).replace('_',' ');
  closeOverlay();
  loadItems(true);
}

/* ════════════════════════════════════════
   CATS + SEARCH + INFINITE SCROLL
════════════════════════════════════════ */
function initCats() {
  document.querySelectorAll('.cat-tab').forEach(function(c) {
    c.addEventListener('click', function() {
      document.querySelectorAll('.cat-tab').forEach(function(x){ x.classList.remove('on'); });
      c.classList.add('on');
      ST.sub = c.dataset.sub;
      var el = document.getElementById('gridTitle');
      if (el) el.textContent = c.dataset.sub || 'For You';
      loadItems(true);
    });
  });
}
function initSearch() {
  var t;
  document.getElementById('srchInput').addEventListener('input', function(e) {
    clearTimeout(t);
    var q = e.target.value.trim();
    t = setTimeout(function(){ ST.search = q; loadItems(true); }, 350);
  });
}
function initInfiniteScroll() {
  var obs = new IntersectionObserver(function(entries) {
    if (entries[0].isIntersecting && !ST.done && !ST.loading) loadItems(false);
  }, {rootMargin:'200px'});
  obs.observe(document.getElementById('loadMore'));
}

/* ════════════════════════════════════════
   WISHLIST
════════════════════════════════════════ */
function toggleWish(ev, id, btn) {
  ev.stopPropagation();
  var i = wishlist.indexOf(id);
  if (i !== -1) { wishlist.splice(i,1); btn.innerHTML='&#x2661;'; btn.classList.remove('liked'); showToast('Removed from saved'); }
  else          { wishlist.unshift(id); btn.innerHTML='&#x2665;'; btn.classList.add('liked');    showToast('&#x2665; Saved!'); }
  localStorage.setItem('mh_shop_wish', JSON.stringify(wishlist));
}

/* ════════════════════════════════════════
   SHEET / OVERLAY HELPERS
════════════════════════════════════════ */
function openSheet() {
  document.getElementById('overlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeOverlay() {
  document.getElementById('overlay').classList.remove('open');
  document.body.style.overflow = '';
}
function handleOvClick(e) {
  if (e.target === e.currentTarget) closeOverlay();
}

/* ════════════════════════════════════════
   ORDER API
════════════════════════════════════════ */
function postOrder(data, onOk, onErr) {
  var xhr = new XMLHttpRequest();
  xhr.open('POST', API_BASE+'/order.php', true);
  xhr.setRequestHeader('Content-Type','application/json');
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout = 12000;
  xhr.onload = function() {
    try { var d = JSON.parse(xhr.responseText); if(typeof onOk==='function') onOk(d); }
    catch(e) { if(typeof onOk==='function') onOk({}); }
  };
  xhr.onerror = xhr.ontimeout = function() { if(typeof onErr==='function') onErr(); };
  xhr.send(JSON.stringify(data));
}

/* ════════════════════════════════════════
   CART PERSISTENCE
════════════════════════════════════════ */
function saveCart() {
  localStorage.setItem('mh_shop_cart', JSON.stringify(cart));
}
function renderBadges() {
  var n = cart.reduce(function(s,c){ return s+c.qty; }, 0);
  ['hBadge'].forEach(function(id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.textContent = n;
    el.classList.toggle('on', n > 0);
  });
}

/* ════════════════════════════════════════
   SAVED DETAILS (mh_user.js)
════════════════════════════════════════ */
function saveMhUser(name, phone, addr) {
  try {
    if (window.MhUser) MhUser.saveDetails({name:name,phone:phone,address:addr});
    else {
      var d = {name:name,phone:phone,address:addr};
      localStorage.setItem('mh_user_details',JSON.stringify(d));
    }
  } catch(e){}
}
function prefillSaved() {
  var d = null;
  try {
    if (window.MhUser) d = MhUser.getDetails();
    else d = JSON.parse(localStorage.getItem('mh_user_details')||'null');
  } catch(e){}
  if (!d) return;
  var fields = {
    do_name:'name',do_phone:'phone',do_addr:'address',
    lp_name:'name',lp_phone:'phone',lp_addr:'address',
    cart_name:'name',cart_phone:'phone',cart_addr:'address',
  };
  Object.keys(fields).forEach(function(fid) {
    var el = document.getElementById(fid);
    if (el && d[fields[fid]] && !el.value) el.value = d[fields[fid]];
  });
}

/* ════════════════════════════════════════
   UTILITIES
════════════════════════════════════════ */
function px(str) {
  var n = parseInt(String(str||'').replace(/[^0-9]/g,''));
  return isNaN(n) ? 0 : n;
}
function normWA(p) {
  var d = (p||'').replace(/\D/g,'');
  if (d.length===9)  return '254'+d;
  if (d.length===10 && d[0]==='0') return '254'+d.substring(1);
  if (d.length===12 && d.substring(0,3)==='254') return d;
  return d || '254700000000';
}
function esc(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function showSpin(on) {
  var el = document.getElementById('loadSpin');
  if (el) el.style.display = on ? 'block' : 'none';
}
function showToast(msg) {
  var t = document.getElementById('toast');
  t.innerHTML = msg; t.classList.add('show');
  setTimeout(function(){ t.classList.remove('show'); }, 2400);
}
</script>
</body>
</html>