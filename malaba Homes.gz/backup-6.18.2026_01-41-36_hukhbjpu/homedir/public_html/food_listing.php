<?php
$apiBase      = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/api';
$phpNow       = (int)date('N');
$isSpecialDay = ($phpNow == 3 || $phpNow == 6);
$nextDay      = ($phpNow == 3) ? 'Saturday' : 'Wednesday';
$daysUntil    = ($phpNow < 3) ? 3-$phpNow : ($phpNow < 6 ? 6-$phpNow : 7-$phpNow+3);
if ($daysUntil <= 0) $daysUntil += 7;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1">
<meta name="theme-color" content="#080400">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>Order Food — Malaba Homes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="perf_styles.css">
<style>
:root{
  --ink:#080400;--ink2:#0f0800;--surface:#160c00;--card:#1c1000;
  --border:rgba(255,150,60,.07);--border2:rgba(255,120,40,.16);
  --text:#FFF5E8;--muted:#A08060;--dim:#5a4030;
  --amber:#E8521A;--amber2:#FF7043;--gold:#F5A623;
  --green:#22C55E;--red:#c0392b;
  --sb:env(safe-area-inset-bottom,0px);--st:env(safe-area-inset-top,0px);
  --r:12px;--rl:20px;--nav:56px;--bnav:62px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
html{overflow-x:hidden;}
body{font-family:'Outfit',sans-serif;background:var(--ink);color:var(--text);
  min-height:100dvh;overflow-x:hidden;-webkit-font-smoothing:antialiased;
  padding-bottom:calc(var(--bnav) + var(--sb) + 80px);}
a{color:inherit;text-decoration:none;}
button{cursor:pointer;font-family:inherit;border:none;background:none;}
img{display:block;max-width:100%;}
.hdr{position:sticky;top:0;z-index:200;background:rgba(8,4,0,.97);
  backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);
  border-bottom:1px solid var(--border);padding-top:var(--st);transition:box-shadow .3s;}
.hdr.scrolled{box-shadow:0 4px 24px rgba(0,0,0,.6);}
.hdr-row{height:var(--nav);display:flex;align-items:center;gap:10px;padding:0 14px;}
.back-btn{width:36px;height:36px;border-radius:50%;background:var(--surface);
  border:1px solid var(--border2);display:flex;align-items:center;justify-content:center;
  flex-shrink:0;transition:transform .15s;}
.back-btn:active{transform:scale(.9);}
.back-btn svg{width:17px;height:17px;color:var(--text);}
.hdr-brand{flex:1;font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:2px;}
.hdr-brand span{color:var(--amber2);}
.cart-ico{width:36px;height:36px;border-radius:50%;background:var(--surface);
  border:1px solid var(--border2);display:flex;align-items:center;justify-content:center;
  font-size:16px;position:relative;transition:transform .15s;}
.cart-ico:active{transform:scale(.88);}
.cbadge{position:absolute;top:-3px;right:-3px;width:17px;height:17px;border-radius:50%;
  background:var(--amber);color:#fff;font-size:9px;font-weight:800;
  display:none;align-items:center;justify-content:center;border:2px solid var(--ink);}
.cbadge.on{display:flex;animation:badgePop .3s cubic-bezier(.34,1.56,.64,1);}
@keyframes badgePop{from{transform:scale(0)}to{transform:scale(1)}}
.srch-row{padding:9px 14px;}
.srch-box{display:flex;align-items:center;gap:9px;background:var(--surface);
  border:1.5px solid var(--border2);border-radius:30px;padding:0 15px;transition:border-color .2s;}
.srch-box:focus-within{border-color:var(--amber);}
.srch-box svg{color:var(--muted);flex-shrink:0;width:14px;height:14px;}
.srch-box input{flex:1;padding:11px 0;background:transparent;border:none;outline:none;
  font-family:inherit;font-size:14px;color:var(--text);}
.srch-box input::placeholder{color:var(--muted);}
.srch-clear{width:18px;height:18px;border-radius:50%;background:rgba(255,255,255,.15);
  border:none;color:var(--text);font-size:11px;display:none;align-items:center;
  justify-content:center;cursor:pointer;flex-shrink:0;}
.srch-clear.show{display:flex;}
.cats-row{display:flex;gap:7px;padding:0 14px 10px;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;}
.cats-row::-webkit-scrollbar{display:none;}
.cat{display:inline-flex;align-items:center;gap:5px;padding:6px 13px;border-radius:30px;
  border:1px solid var(--border2);background:var(--surface);
  font-size:12px;font-weight:500;color:var(--muted);white-space:nowrap;flex-shrink:0;transition:all .2s;}
.cat.on{background:var(--amber);border-color:var(--amber);color:#fff;font-weight:700;}
.cat:active{transform:scale(.95);}
.bogo-banner{margin:8px 14px 4px;border-radius:var(--rl);overflow:hidden;cursor:pointer;transition:transform .2s;}
.bogo-banner:active{transform:scale(.98);}
.bb-bg{background:linear-gradient(135deg,#3d0000 0%,#700000 50%,#3d0000 100%);
  padding:14px 16px;border:1px solid rgba(200,0,0,.3);position:relative;overflow:hidden;}
.bb-bg::before{content:'';position:absolute;inset:0;
  background:linear-gradient(105deg,transparent 40%,rgba(255,255,255,.06) 50%,transparent 60%);
  transform:translateX(-100%);animation:bannerShimmer 3s ease-in-out infinite;}
@keyframes bannerShimmer{0%{transform:translateX(-100%);}60%,100%{transform:translateX(100%);}}
.bb-row{display:flex;align-items:center;gap:12px;}
.bb-emoji{font-size:36px;flex-shrink:0;filter:drop-shadow(0 2px 8px rgba(0,0,0,.5));}
.bb-eyebrow{font-size:9px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:rgba(255,160,120,.7);margin-bottom:2px;}
.bb-title{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:.5px;color:#fff;line-height:1;margin-bottom:3px;}
.bb-title em{color:#ff6b6b;font-style:normal;}
.bb-sub{font-size:11px;color:rgba(255,180,140,.6);line-height:1.4;}
.bb-badge{display:inline-flex;align-items:center;gap:5px;background:rgba(255,107,107,.18);
  border:1px solid rgba(255,107,107,.3);border-radius:20px;padding:3px 10px;
  margin-top:6px;font-size:10px;font-weight:700;color:#ff9999;}
.bb-pulse{width:6px;height:6px;border-radius:50%;background:#ff6b6b;animation:pulse 2s ease infinite;}
@keyframes pulse{0%,100%{box-shadow:0 0 0 0 rgba(255,107,107,.5);}50%{box-shadow:0 0 0 6px rgba(255,107,107,0);}}
.bb-countdown{display:flex;gap:5px;margin-top:8px;}
.bcu{background:rgba(0,0,0,.4);border-radius:7px;padding:4px 7px;text-align:center;min-width:38px;}
.bcu-n{font-family:'Bebas Neue',sans-serif;font-size:16px;color:#ff6b6b;letter-spacing:.5px;line-height:1;}
.bcu-l{font-size:8px;font-weight:700;color:rgba(255,150,120,.5);letter-spacing:.5px;text-transform:uppercase;}
.sec-head{display:flex;align-items:center;justify-content:space-between;padding:14px 14px 8px;}
.sec-head h2{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.5px;}
.sec-head h2 span{color:var(--amber2);}
.res-count{font-size:11px;color:var(--dim);}
/* OFFERS - taller, crisper images */
.offer-scroll{display:flex;gap:10px;padding:0 14px 4px;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;}
.offer-scroll::-webkit-scrollbar{display:none;}
.offer-card{flex-shrink:0;width:155px;border-radius:var(--rl);overflow:hidden;background:var(--card);
  border:1px solid rgba(245,158,11,.2);cursor:pointer;transition:transform .18s;position:relative;}
.offer-card:active{transform:scale(.96);}
.offer-card-img{height:108px;position:relative;overflow:hidden;background:var(--surface);}
.offer-card-img img{width:100%;height:100%;object-fit:cover;object-position:center 35%;
  opacity:0;transition:opacity .4s;image-rendering:auto;}
.offer-card-img img.img-loaded{opacity:1;}
.offer-card-img-grad{position:absolute;inset:0;background:linear-gradient(to top,rgba(8,4,0,.7),transparent 55%);}
.offer-discount{position:absolute;top:6px;right:6px;background:var(--gold);color:#000;
  font-size:9px;font-weight:800;padding:2px 7px;border-radius:10px;}
.offer-card-body{padding:7px 9px 9px;}
.offer-card-name{font-size:12px;font-weight:700;color:var(--text);margin-bottom:2px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.offer-card-price{font-family:'Bebas Neue',sans-serif;font-size:14px;color:var(--amber2);}
.offer-rest{font-size:10px;color:var(--muted);margin-top:1px;}
/* RESTAURANT CARDS - taller hero */
.rcard{background:var(--card);border-radius:var(--rl);border:1px solid var(--border);
  overflow:hidden;cursor:pointer;animation:slideUp .38s ease both;
  transition:transform .2s,box-shadow .2s,border-color .2s;position:relative;contain:layout style;}
@keyframes slideUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
.rcard:active{transform:scale(.985);}
@media(hover:hover){.rcard:hover{transform:translateY(-3px);box-shadow:0 12px 32px rgba(0,0,0,.5);border-color:var(--border2);}}
.rcard-hero{position:relative;height:165px;overflow:hidden;background:var(--surface);}
.rcard-hero img{width:100%;height:100%;object-fit:cover;object-position:center 40%;
  opacity:0;transition:opacity .45s ease;image-rendering:auto;}
.rcard-hero img.img-loaded{opacity:1;}
.rcard-hero-grad{position:absolute;inset:0;background:linear-gradient(to top,rgba(8,4,0,.95) 0%,rgba(8,4,0,.15) 45%,transparent 100%);}
.rcard-badges{position:absolute;top:8px;left:10px;right:10px;display:flex;align-items:center;justify-content:space-between;z-index:2;}
.rbadge{font-size:9px;font-weight:800;padding:3px 8px;border-radius:10px;backdrop-filter:blur(6px);white-space:nowrap;}
.rb-open{background:rgba(34,197,94,.85);color:#fff;}
.rb-closed{background:rgba(100,100,100,.85);color:#fff;}
.rb-hot{background:rgba(232,82,26,.85);color:#fff;}
.rb-bogo{background:rgba(139,0,0,.85);color:#ff9999;border:1px solid rgba(255,100,100,.3);}
.rb-new{background:rgba(72,149,239,.85);color:#fff;}
.rcard-rating-badge{display:flex;align-items:center;gap:4px;background:rgba(0,0,0,.75);
  backdrop-filter:blur(8px);padding:4px 9px;border-radius:20px;font-size:11px;font-weight:700;color:#fff;}
.rcard-rating-badge span{color:var(--gold);}
.rcard-info-overlay{position:absolute;bottom:0;left:0;right:0;z-index:2;padding:10px 12px;}
.rcard-name{font-family:'Bebas Neue',sans-serif;font-size:19px;letter-spacing:.5px;
  color:#fff;text-shadow:0 2px 8px rgba(0,0,0,.5);margin-bottom:2px;}
.rcard-meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.rcard-tag{font-size:10px;color:rgba(255,255,255,.55);display:flex;align-items:center;gap:3px;}
.rcard-body{padding:10px 12px 4px;}
.rcard-desc{font-size:12px;color:var(--muted);line-height:1.4;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-bottom:8px;}
.rcard-items{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;padding-bottom:4px;}
.rcard-items::-webkit-scrollbar{display:none;}
/* Crisper food thumbnails - wider, better framed */
.ri-thumb{flex-shrink:0;display:flex;flex-direction:column;align-items:center;gap:3px;cursor:pointer;transition:transform .15s;}
.ri-thumb:active{transform:scale(.92);}
.ri-img{width:58px;height:58px;border-radius:10px;object-fit:cover;object-position:center 30%;
  background:var(--surface);flex-shrink:0;opacity:0;transition:opacity .3s;
  border:1px solid rgba(255,255,255,.07);image-rendering:auto;}
.ri-img.img-loaded{opacity:1;}
.ri-name{font-size:9px;color:var(--muted);text-align:center;max-width:58px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.ri-price{font-size:10px;font-weight:700;color:var(--amber2);}
.rcard-foot{display:flex;gap:7px;padding:8px 12px 12px;}
.btn-view-rest{flex:1;padding:10px 12px;background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;border-radius:var(--r);font-family:'Bebas Neue',sans-serif;font-size:14px;letter-spacing:.3px;
  display:flex;align-items:center;justify-content:center;gap:6px;
  box-shadow:0 3px 12px rgba(232,82,26,.35);transition:all .18s;}
.btn-view-rest:active{transform:scale(.96);}
.btn-wa-rest{width:42px;border-radius:var(--r);background:#25D366;color:#fff;font-size:18px;
  display:flex;align-items:center;justify-content:center;flex-shrink:0;
  box-shadow:0 3px 12px rgba(37,211,102,.3);transition:all .18s;}
.btn-wa-rest:active{transform:scale(.93);}
/* RESTAURANT PANEL */
.rest-panel{position:fixed;inset:0;z-index:300;background:var(--ink);
  transform:translateX(100%);transition:transform .38s cubic-bezier(.32,1,.68,1);
  overflow-y:auto;padding-bottom:calc(var(--bnav) + var(--sb) + 80px);}
.rest-panel.open{transform:translateX(0);}
.rp-hero{position:relative;height:220px;overflow:hidden;flex-shrink:0;background:var(--surface);}
.rp-hero img{width:100%;height:100%;object-fit:cover;object-position:center 35%;
  opacity:0;transition:opacity .45s;image-rendering:auto;}
.rp-hero img.img-loaded{opacity:1;}
.rp-hero-grad{position:absolute;inset:0;background:linear-gradient(to top,rgba(8,4,0,1) 0%,rgba(8,4,0,.2) 50%,transparent 100%);}
/* FIX 3: Visible back button - solid dark bg, SVG arrow, always legible */
.rp-back{position:absolute;top:calc(var(--st) + 12px);left:14px;z-index:10;width:40px;height:40px;
  border-radius:50%;background:rgba(8,4,0,.85);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);
  border:1.5px solid rgba(255,255,255,.25);display:flex;align-items:center;justify-content:center;
  transition:transform .15s,background .2s;box-shadow:0 2px 14px rgba(0,0,0,.6);}
.rp-back:active{transform:scale(.9);background:rgba(232,82,26,.5);}
.rp-back svg{width:18px;height:18px;color:#fff;display:block;flex-shrink:0;}
.rp-info{position:absolute;bottom:12px;left:14px;right:14px;z-index:2;}
.rp-name{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:.5px;
  color:#fff;text-shadow:0 2px 12px rgba(0,0,0,.6);margin-bottom:4px;}
.rp-meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.rp-tag{font-size:11px;color:rgba(255,255,255,.55);display:flex;align-items:center;gap:3px;}
.rp-rating{display:flex;align-items:center;gap:4px;background:rgba(0,0,0,.6);
  backdrop-filter:blur(6px);padding:3px 9px;border-radius:20px;font-size:11px;font-weight:700;color:#fff;}
.rp-rating span{color:var(--gold);}
.rp-cats{display:flex;gap:6px;padding:12px 14px 4px;overflow-x:auto;scrollbar-width:none;}
.rp-cats::-webkit-scrollbar{display:none;}
.rp-cat{padding:6px 14px;border-radius:30px;border:1px solid var(--border2);
  background:var(--surface);font-size:12px;font-weight:500;color:var(--muted);
  white-space:nowrap;flex-shrink:0;transition:all .2s;}
.rp-cat.on{background:var(--amber);border-color:var(--amber);color:#fff;font-weight:700;}
.rp-cat:active{transform:scale(.95);}
.rp-srch{padding:6px 14px 8px;}
.rp-srch-box{display:flex;align-items:center;gap:8px;background:var(--surface);
  border:1.5px solid var(--border2);border-radius:30px;padding:0 14px;transition:border-color .2s;}
.rp-srch-box:focus-within{border-color:var(--amber);}
.rp-srch-box svg{color:var(--muted);flex-shrink:0;width:13px;height:13px;}
.rp-srch-box input{flex:1;padding:10px 0;background:transparent;border:none;outline:none;
  font-family:inherit;font-size:13px;color:var(--text);}
.rp-srch-box input::placeholder{color:var(--muted);}
.rp-items{padding:0 14px;display:flex;flex-direction:column;gap:10px;}
/* FOOD ITEM CARDS - wider image, more text padding */
.fitem{display:flex;align-items:stretch;background:var(--card);border-radius:var(--rl);
  border:1px solid var(--border);overflow:hidden;cursor:pointer;
  transition:border-color .2s,transform .15s;contain:layout style;animation:slideUp .3s ease both;}
.fitem:active{transform:scale(.985);}
.fitem.is-offer{border-color:rgba(245,158,11,.25);}
.fitem.is-pizza-bogo{border-color:rgba(200,0,0,.35);}
/* FIX 2: Wider image + good food photography framing */
.fitem-img{width:110px;flex-shrink:0;position:relative;overflow:hidden;background:var(--surface);}
.fitem-img img{width:100%;height:100%;object-fit:cover;object-position:center 25%;
  min-height:112px;opacity:0;transition:opacity .4s ease;image-rendering:auto;}
.fitem-img img.img-loaded{opacity:1;}
.fitem-badge{position:absolute;top:6px;left:6px;font-size:8px;font-weight:800;
  padding:2px 6px;border-radius:8px;backdrop-filter:blur(4px);z-index:2;}
.fb-offer{background:rgba(245,158,11,.9);color:#000;}
.fb-bogo{background:rgba(139,0,0,.9);color:#ffaaaa;border:1px solid rgba(255,100,100,.3);}
.fb-new{background:rgba(34,197,94,.85);color:#fff;}
.fb-hot{background:rgba(232,82,26,.85);color:#fff;}
.fitem-soldout{position:absolute;inset:0;background:rgba(8,4,0,.7);
  display:flex;align-items:center;justify-content:center;
  font-size:10px;font-weight:800;color:rgba(255,255,255,.5);letter-spacing:.5px;text-transform:uppercase;}
/* FIX 2: padding-left for text breathing room */
.fitem-body{flex:1;padding:11px 8px 9px 13px;display:flex;flex-direction:column;gap:3px;min-width:0;}
.fitem-name{font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:.2px;color:var(--text);
  line-height:1.25;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
.fitem-desc{font-size:11.5px;color:var(--muted);line-height:1.4;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
.fitem-tags{display:flex;gap:4px;flex-wrap:wrap;margin-top:2px;}
.ftag{font-size:9px;padding:2px 6px;border-radius:6px;font-weight:600;}
.ft-spicy{background:rgba(232,82,26,.12);color:var(--amber2);}
.ft-veg{background:rgba(34,197,94,.12);color:#4ade80;}
.ft-fast{background:rgba(72,149,239,.12);color:#93c5fd;}
.fitem-price-row{display:flex;align-items:center;gap:6px;margin-top:auto;padding-top:5px;}
.fitem-price{font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;color:var(--amber2);}
.fitem-bogo{font-size:10px;font-weight:800;color:#ff9999;}
.fitem-right{display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:8px;padding:10px 10px 10px 0;flex-shrink:0;}
.add-btn{width:34px;height:34px;border-radius:50%;background:var(--amber);color:#fff;
  font-size:20px;font-weight:700;display:flex;align-items:center;justify-content:center;
  transition:all .18s;box-shadow:0 2px 8px rgba(232,82,26,.35);}
.add-btn:active{transform:scale(.85);}
.qty-ctrl{display:flex;align-items:center;background:var(--surface);border:1px solid var(--border2);
  border-radius:30px;overflow:hidden;opacity:0;transform:scale(.8);pointer-events:none;
  transition:all .22s cubic-bezier(.34,1.56,.64,1);}
.qty-ctrl.show{opacity:1;transform:scale(1);pointer-events:all;}
.qbtn{width:28px;height:28px;font-size:15px;font-weight:700;color:var(--text);
  display:flex;align-items:center;justify-content:center;transition:background .13s;}
.qbtn:active{background:rgba(232,82,26,.2);}
.qnum{padding:0 5px;font-family:'Bebas Neue',sans-serif;font-size:14px;min-width:16px;text-align:center;}
/* CART STRIP - visible above restaurant panel (z-index 310 > panel 300) */
.cart-strip{position:fixed;bottom:calc(var(--bnav) + var(--sb) + 8px);left:12px;right:12px;z-index:310;
  background:var(--amber);border-radius:var(--rl);padding:0;
  transform:translateY(calc(160% + 80px));transition:transform .42s cubic-bezier(.32,1,.68,1);
  box-shadow:0 8px 28px rgba(232,82,26,.55);overflow:hidden;}
.cart-strip.show{transform:translateY(0);}
.cs-progress{height:3px;background:rgba(255,255,255,.2);}
.cs-progress-fill{height:100%;background:rgba(255,255,255,.5);width:0%;transition:width .3s;}
.cs-body{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;}
.cs-left{display:flex;flex-direction:column;gap:1px;}
.cs-count{font-family:'Bebas Neue',sans-serif;font-size:15px;color:#fff;letter-spacing:.3px;}
.cs-total{font-size:11px;color:rgba(255,255,255,.75);}
.cs-actions{display:flex;align-items:center;gap:6px;}
.cs-orders-btn{background:rgba(255,255,255,.18);color:rgba(255,255,255,.92);padding:7px 11px;
  border-radius:20px;font-size:11px;font-weight:700;letter-spacing:.2px;
  display:flex;align-items:center;gap:4px;transition:all .2s;white-space:nowrap;text-decoration:none;}
.cs-orders-btn:active{background:rgba(255,255,255,.28);}
.cs-btn{background:rgba(255,255,255,.22);color:#fff;padding:9px 16px;border-radius:30px;
  font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:.3px;
  display:flex;align-items:center;gap:5px;transition:all .2s;white-space:nowrap;}
.cs-btn:active{background:rgba(255,255,255,.32);}
/* OVERLAY + SHEETS */
.overlay{position:fixed;inset:0;z-index:400;background:rgba(0,0,0,.82);
  backdrop-filter:blur(6px);opacity:0;pointer-events:none;transition:opacity .25s;
  display:flex;align-items:flex-end;}
.overlay.open{opacity:1;pointer-events:all;}
.sheet{width:100%;background:var(--ink2);border-radius:24px 24px 0 0;
  border:1px solid rgba(255,255,255,.08);transform:translateY(100%);
  transition:transform .38s cubic-bezier(.32,1,.68,1);max-height:94dvh;overflow-y:auto;
  padding-bottom:calc(20px + var(--sb));}
.overlay.open .sheet{transform:translateY(0);}
.sh-grip{display:flex;align-items:center;justify-content:space-between;padding:13px 16px 0;}
.sh-handle{width:38px;height:4px;border-radius:2px;background:rgba(255,255,255,.1);}
.sh-x{width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.06);
  border:1px solid rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;
  font-size:14px;color:rgba(255,255,255,.5);}
.sh-x:active{transform:scale(.9);}
/* FIX 1: 3-STEP PROGRESSIVE CHECKOUT */
.checkout-steps-bar{display:flex;align-items:center;padding:10px 16px 6px;}
.cstep{display:flex;align-items:center;gap:5px;}
.cstep-dot{width:22px;height:22px;border-radius:50%;border:2px solid var(--border2);
  display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;
  color:var(--muted);transition:all .3s;flex-shrink:0;}
.cstep.active .cstep-dot{background:var(--amber);border-color:var(--amber);color:#fff;box-shadow:0 0 0 4px rgba(232,82,26,.18);}
.cstep.done .cstep-dot{background:var(--green);border-color:var(--green);color:#000;}
.cstep-lbl{font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.3px;text-transform:uppercase;transition:color .3s;}
.cstep.active .cstep-lbl{color:var(--amber);}
.cstep.done .cstep-lbl{color:var(--green);}
.cstep-line{flex:1;height:2px;background:var(--border2);margin:0 6px;transition:background .3s;}
.cstep-line.done{background:var(--green);}
.co-panel{display:none;animation:coPanelIn .28s ease;}
.co-panel.active{display:block;}
@keyframes coPanelIn{from{opacity:0;transform:translateX(10px);}to{opacity:1;transform:translateX(0);}}
.co-nav{display:flex;gap:8px;padding:6px 16px 4px;}
.co-back-btn{padding:11px 16px;background:rgba(255,255,255,.06);border:1px solid var(--border2);
  border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;color:var(--muted);cursor:pointer;transition:all .2s;}
.co-back-btn:active{background:rgba(255,255,255,.1);}
.co-next-btn{flex:1;padding:13px;background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;border:none;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;
  font-size:17px;letter-spacing:.3px;cursor:pointer;transition:all .18s;box-shadow:0 4px 14px rgba(232,82,26,.35);}
.co-next-btn:active{transform:scale(.98);}
.co-next-btn:disabled{opacity:.6;}
.co-confirm-item{display:flex;align-items:center;gap:9px;padding:8px 0;border-bottom:1px solid var(--border);}
.co-confirm-item:last-child{border-bottom:none;}
.co-ci-img{width:38px;height:38px;border-radius:8px;object-fit:cover;object-position:center 25%;flex-shrink:0;background:var(--surface);}
.co-ci-name{flex:1;font-size:12px;font-weight:600;color:var(--text);line-height:1.3;}
.co-ci-qty{font-size:11px;color:var(--muted);flex-shrink:0;}
.co-ci-price{font-family:'Bebas Neue',sans-serif;font-size:13px;color:var(--amber2);flex-shrink:0;}
.cart-item{display:flex;align-items:center;gap:10px;background:rgba(255,255,255,.03);
  border-radius:var(--r);padding:10px 12px;border:1px solid var(--border);transition:all .2s;animation:slideUp .25s ease both;}
.ci-img{width:44px;height:44px;border-radius:8px;object-fit:cover;object-position:center 25%;flex-shrink:0;background:var(--surface);}
.ci-info{flex:1;min-width:0;}
.ci-name{font-size:13px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.ci-rest{font-size:10px;color:var(--muted);}
.ci-price{font-family:'Bebas Neue',sans-serif;font-size:14px;color:var(--amber2);flex-shrink:0;}
.ci-controls{display:flex;align-items:center;gap:5px;}
.ci-qbtn{width:24px;height:24px;border-radius:50%;background:var(--surface);
  border:1px solid var(--border2);color:var(--text);font-size:13px;font-weight:700;
  display:flex;align-items:center;justify-content:center;cursor:pointer;transition:background .13s;}
.ci-qbtn:active{background:rgba(232,82,26,.2);}
.ci-qty{font-family:'Bebas Neue',sans-serif;font-size:14px;min-width:14px;text-align:center;}
.ci-del{color:var(--muted);font-size:14px;padding:2px 4px;cursor:pointer;}
.cart-total-box{background:rgba(255,255,255,.03);border-radius:var(--r);
  padding:11px 13px;border:1px solid var(--border);margin-top:8px;}
.ctr{display:flex;justify-content:space-between;font-size:13px;color:var(--muted);padding:3px 0;}
.ctr.tot{font-size:15px;font-weight:700;color:var(--text);padding-top:8px;border-top:1px solid var(--border);margin-top:4px;}
.field{margin-bottom:11px;}
.field label{display:block;font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:5px;}
.field input{width:100%;padding:11px 13px;border-radius:var(--r);
  background:rgba(255,255,255,.05);border:1.5px solid var(--border2);
  color:var(--text);font-family:inherit;font-size:14px;outline:none;transition:border-color .2s;}
.field input:focus{border-color:var(--amber);}
.field input::placeholder{color:rgba(255,255,255,.22);}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.pay-opts{display:flex;flex-direction:column;gap:7px;margin-bottom:12px;}
.po{display:flex;align-items:center;gap:11px;padding:11px 12px;border-radius:var(--r);border:2px solid var(--border2);cursor:pointer;transition:all .18s;}
.po.sel{border-color:var(--amber);background:rgba(232,82,26,.07);}
.po:active{transform:scale(.99);}
.po-ico{font-size:18px;}
.po-txt strong{display:block;font-size:13px;font-weight:600;}
.po-txt span{font-size:11px;color:var(--muted);}
.po-dot{width:17px;height:17px;border-radius:50%;border:2px solid var(--dim);margin-left:auto;flex-shrink:0;display:flex;align-items:center;justify-content:center;}
.po.sel .po-dot{border-color:var(--amber);background:var(--amber);}
.po.sel .po-dot::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}
.sbtn{width:100%;padding:14px;background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:18px;
  letter-spacing:.5px;transition:all .18s;box-shadow:0 4px 18px rgba(232,82,26,.35);
  display:flex;align-items:center;justify-content:center;gap:7px;}
.sbtn:active{transform:scale(.98);}
.sbtn:disabled{opacity:.6;}
.success-wrap{text-align:center;padding:24px 16px 10px;}
.success-anim{width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,var(--green),#16a34a);
  display:flex;align-items:center;justify-content:center;font-size:36px;
  margin:0 auto 16px;animation:successPop .6s cubic-bezier(.34,1.56,.64,1);box-shadow:0 8px 24px rgba(34,197,94,.4);}
@keyframes successPop{from{transform:scale(0);opacity:0;}to{transform:scale(1);opacity:1;}}
.confetti-wrap{position:relative;height:60px;overflow:hidden;margin-bottom:8px;}
.confetti-dot{position:absolute;width:8px;height:8px;border-radius:50%;animation:confettiFall 1.2s ease-out both;}
@keyframes confettiFall{from{transform:translateY(-20px) rotate(0deg);opacity:1;}to{transform:translateY(60px) rotate(360deg);opacity:0;}}
.suc-title{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:.5px;margin-bottom:6px;}
.suc-sub{font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:12px;}
.suc-ref{font-size:12px;color:var(--amber);font-weight:700;margin-bottom:14px;}
.order-tracker{background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px;}
.ot-title{font-size:12px;font-weight:700;color:var(--text);margin-bottom:12px;}
.ot-steps{display:flex;align-items:center;justify-content:space-between;position:relative;}
.ot-steps::before{content:'';position:absolute;top:12px;left:12px;right:12px;height:2px;background:rgba(255,255,255,.08);}
.ot-fill{position:absolute;top:12px;left:12px;height:2px;background:linear-gradient(90deg,var(--green),var(--amber));width:0%;transition:width 1.5s ease;border-radius:1px;}
.ot-step{display:flex;flex-direction:column;align-items:center;gap:4px;position:relative;z-index:1;}
.ot-dot{width:26px;height:26px;border-radius:50%;background:var(--surface);border:2px solid rgba(255,255,255,.12);display:flex;align-items:center;justify-content:center;font-size:12px;transition:all .5s;}
.ot-dot.done{background:var(--green);border-color:var(--green);}
.ot-dot.active{background:var(--amber);border-color:var(--amber);box-shadow:0 0 0 6px rgba(232,82,26,.15);animation:pulse 2s ease infinite;}
.ot-lbl{font-size:9px;font-weight:700;color:var(--muted);letter-spacing:.3px;text-transform:uppercase;}
.ot-lbl.active{color:var(--amber);}.ot-lbl.done{color:var(--green);}
.wa-btn{width:100%;padding:13px;background:#25D366;color:#fff;border-radius:var(--rl);
  font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.3px;
  display:flex;align-items:center;justify-content:center;gap:7px;margin-bottom:8px;transition:all .2s;}
.track-btn{width:100%;padding:12px;background:rgba(255,255,255,.05);color:var(--muted);
  border:1px solid var(--border2);border-radius:var(--rl);font-family:inherit;
  font-weight:600;font-size:13px;margin-bottom:8px;display:flex;align-items:center;justify-content:center;gap:6px;text-decoration:none;}
.done-btn{width:100%;padding:12px;background:transparent;color:var(--muted);border:none;font-family:inherit;font-size:13px;cursor:pointer;}
/* PIZZA LIPA */
.lipa-product{display:flex;gap:11px;padding:14px 16px 0;}
.lipa-img{width:56px;height:56px;border-radius:11px;object-fit:cover;object-position:center 25%;flex-shrink:0;border:2px solid rgba(139,0,0,.3);}
.lipa-name{font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.3px;margin-bottom:2px;}
.lipa-was{font-size:11px;color:var(--dim);text-decoration:line-through;}
.lipa-tag{font-size:10px;color:#ff9999;font-weight:700;margin-top:2px;}
.lipa-steps{display:flex;align-items:center;padding:12px 16px 10px;}
.lstep{display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;}
.ls-dot{width:24px;height:24px;border-radius:50%;border:2px solid var(--border2);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:var(--muted);transition:all .28s;}
.ls-dot.done{background:var(--green);border-color:var(--green);color:#000;}
.ls-dot.active{background:var(--red);border-color:var(--red);color:#fff;box-shadow:0 0 0 4px rgba(192,57,43,.2);}
.ls-lbl{font-size:9px;font-weight:600;color:var(--muted);letter-spacing:.2px;text-align:center;}
.ls-lbl.active{color:#ff9999;}.ls-lbl.done{color:var(--green);}
.ls-line{flex:1;height:2px;background:var(--border2);margin:0 4px;margin-bottom:12px;transition:background .28s;}
.ls-line.done{background:var(--green);}
.lipa-panel{display:none;padding:0 16px;animation:slideIn .22s ease;}
.lipa-panel.active{display:block;}
@keyframes slideIn{from{opacity:0;transform:translateX(10px)}to{opacity:1;transform:translateX(0)}}
.lipa-nav{display:flex;gap:8px;padding:0 0 4px;}
.lipa-back{padding:12px 16px;background:rgba(255,255,255,.06);border:1px solid var(--border2);border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;color:var(--muted);cursor:pointer;}
.lipa-next{flex:1;padding:13px;background:var(--red);color:#fff;border:none;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;cursor:pointer;transition:all .18s;box-shadow:0 4px 14px rgba(139,0,0,.3);}
.lipa-next:active{transform:scale(.98);}
.pizza-plan{display:flex;align-items:center;gap:10px;padding:12px 13px;border-radius:var(--rl);border:2px solid var(--border2);background:rgba(255,255,255,.02);cursor:pointer;transition:all .18s;margin-bottom:8px;}
.pizza-plan.sel{border-color:rgba(200,0,0,.5);background:rgba(139,0,0,.1);}
.pp-radio{width:17px;height:17px;border-radius:50%;border:2px solid var(--dim);flex-shrink:0;display:flex;align-items:center;justify-content:center;transition:all .18s;}
.pizza-plan.sel .pp-radio{background:var(--red);border-color:var(--red);}
.pizza-plan.sel .pp-radio::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}
.pp-info{flex:1;}.pp-name{font-size:13px;font-weight:700;color:var(--text);margin-bottom:1px;}
.pp-desc{font-size:11px;color:var(--muted);}
.pp-amt{font-family:'Bebas Neue',sans-serif;font-size:15px;color:#ff9999;text-align:right;}
.pizza-summary{background:rgba(139,0,0,.08);border:1px solid rgba(139,0,0,.25);border-radius:var(--r);padding:11px 12px;margin-bottom:11px;display:none;}
.psr{display:flex;justify-content:space-between;font-size:12px;padding:3px 0;}
.psr .lbl{color:var(--muted);}.psr .val{font-weight:700;color:var(--text);}
.psr .val.hi{color:#ff9999;}
.delivery-day{background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.2);border-radius:var(--r);padding:11px 12px;margin-bottom:11px;}
.dd-title{font-size:12px;font-weight:700;color:var(--green);margin-bottom:3px;}
.dd-date{font-family:'Bebas Neue',sans-serif;font-size:17px;color:var(--text);}
.dd-sub{font-size:11px;color:var(--muted);margin-top:1px;}
.lipa-rule{background:rgba(232,82,26,.07);border:1px solid rgba(232,82,26,.15);border-radius:var(--r);padding:10px 12px;margin-bottom:11px;font-size:11px;color:rgba(255,190,120,.85);line-height:1.6;}
.lipa-rule strong{color:var(--amber2);}
/* BOTTOM NAV */
.bnav{position:fixed;bottom:0;left:0;right:0;z-index:200;height:calc(var(--bnav) + var(--sb));
  padding-bottom:var(--sb);background:rgba(8,4,0,.95);backdrop-filter:blur(28px);-webkit-backdrop-filter:blur(28px);
  border-top:1px solid rgba(255,255,255,.07);display:flex;align-items:stretch;}
.bni{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;
  gap:3px;padding:0 4px;-webkit-tap-highlight-color:transparent;transition:all .2s;position:relative;}
.bni-ico{font-size:20px;color:rgba(255,255,255,.38);transition:all .22s;line-height:1.15;}
.bni-lbl{font-size:9px;font-weight:700;color:rgba(255,255,255,.3);letter-spacing:.5px;text-transform:uppercase;transition:all .22s;}
.bni.active .bni-ico,.bni.active .bni-lbl{color:var(--amber);}
.bni.active::before{content:'';position:absolute;bottom:2px;width:20px;height:2px;border-radius:1px;background:var(--amber);animation:indIn .3s ease;}
@keyframes indIn{from{width:0;opacity:0;}to{width:20px;opacity:1;}}
.bni-center{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;-webkit-tap-highlight-color:transparent;cursor:pointer;position:relative;text-decoration:none;}
.bni-center-btn{width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#6366f1);display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:0 -2px 16px rgba(124,58,237,.5);margin-top:-16px;border:3px solid rgba(8,4,0,.95);transition:all .22s;}
.bni-center:active .bni-center-btn{transform:scale(.92);}
.bni-center-lbl{font-size:9px;font-weight:700;color:rgba(139,92,246,.75);letter-spacing:.5px;text-transform:uppercase;}
.toast{position:fixed;bottom:calc(var(--bnav) + var(--sb) + 76px);left:50%;
  transform:translateX(-50%) translateY(8px);background:var(--text);color:var(--ink);
  padding:10px 20px;border-radius:30px;font-size:13px;font-weight:600;z-index:999;
  opacity:0;pointer-events:none;transition:all .22s;white-space:nowrap;box-shadow:0 8px 24px rgba(0,0,0,.4);}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
.skel{background:linear-gradient(90deg,var(--surface) 25%,rgba(255,255,255,.04) 50%,var(--surface) 75%);background-size:200% 100%;animation:shim 1.4s infinite;}
@keyframes shim{0%{background-position:200% 0}100%{background-position:-200% 0}}
.skel-card{background:var(--card);border-radius:var(--rl);overflow:hidden;border:1px solid var(--border);margin-bottom:14px;}
.skel-hero{height:165px;}.skel-body{padding:12px;display:flex;flex-direction:column;gap:8px;}
.skel-ln{height:10px;border-radius:3px;}

/* ── FOOD LOADER OVERLAY ── */
#foodLoader{
  position:fixed;inset:0;z-index:9999;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  background:rgba(8,4,0,.96);
  transition:opacity .5s ease, visibility .5s ease;
}
#foodLoader.hide{opacity:0;visibility:hidden;}
.fl-scene{position:relative;width:160px;height:160px;}
/* Orbit ring */
.fl-ring{
  position:absolute;inset:0;border-radius:50%;
  border:1.5px dashed rgba(232,82,26,.25);
  animation:flSpin 4s linear infinite;
}
@keyframes flSpin{to{transform:rotate(360deg);}}
/* Orbiting dot */
.fl-dot{
  position:absolute;top:0;left:50%;
  width:10px;height:10px;margin-left:-5px;margin-top:-5px;
  border-radius:50%;background:var(--amber2);
  box-shadow:0 0 12px var(--amber2);
  animation:flSpin 4s linear infinite;
  transform-origin:5px 85px;
}
/* Steam wisps */
.fl-steam{
  position:absolute;left:50%;bottom:calc(50% + 38px);
  width:2px;border-radius:1px;background:rgba(255,150,80,.5);
  animation:flSteam 1.8s ease-out infinite;
  transform-origin:50% 100%;
}
.fl-steam:nth-child(1){margin-left:-8px;height:14px;animation-delay:0s;}
.fl-steam:nth-child(2){margin-left:0px;height:20px;animation-delay:.35s;}
.fl-steam:nth-child(3){margin-left:8px;height:12px;animation-delay:.7s;}
@keyframes flSteam{
  0%{transform:scaleX(1) translateY(0);opacity:.7;}
  100%{transform:scaleX(1.6) translateY(-22px);opacity:0;}
}
/* Plate */
.fl-plate{
  position:absolute;bottom:24px;left:50%;transform:translateX(-50%);
  width:72px;height:7px;border-radius:50%;
  background:rgba(255,120,40,.18);border:1px solid rgba(232,82,26,.3);
}
/* Bowl */
.fl-bowl{
  position:absolute;bottom:30px;left:50%;transform:translateX(-50%);
  width:52px;height:28px;border-radius:0 0 30px 30px;
  background:var(--card);border:1.5px solid rgba(232,82,26,.35);
  overflow:hidden;
}
/* Liquid fill animates up */
.fl-bowl-fill{
  position:absolute;bottom:0;left:0;right:0;height:0%;
  background:linear-gradient(to top,rgba(232,82,26,.5),rgba(245,120,50,.3));
  animation:flFill 2s ease-in-out infinite alternate;
}
@keyframes flFill{
  0%{height:20%;}
  100%{height:85%;}
}
/* Chopsticks */
.fl-chop{
  position:absolute;bottom:34px;
  width:3px;border-radius:2px;
  background:linear-gradient(to bottom,rgba(245,166,35,.9),rgba(200,100,20,.6));
  transform-origin:50% 100%;
}
.fl-chop:nth-child(1){
  height:44px;left:calc(50% - 14px);
  animation:flChopL 1.6s ease-in-out infinite;
}
.fl-chop:nth-child(2){
  height:44px;left:calc(50% + 10px);
  animation:flChopR 1.6s ease-in-out infinite;
}
@keyframes flChopL{
  0%,100%{transform:rotate(-18deg);}
  50%{transform:rotate(-8deg);}
}
@keyframes flChopR{
  0%,100%{transform:rotate(18deg);}
  50%{transform:rotate(8deg);}
}
/* Food bits bouncing out of bowl */
.fl-bit{
  position:absolute;width:6px;height:6px;border-radius:50%;
  animation:flBit 1.6s ease-in-out infinite;
}
.fl-bit:nth-child(1){background:#ff7043;bottom:52px;left:calc(50% - 4px);animation-delay:.1s;}
.fl-bit:nth-child(2){background:#f5a623;bottom:52px;left:calc(50% + 6px);animation-delay:.4s;}
.fl-bit:nth-child(3){background:#e8521a;bottom:52px;left:calc(50% - 14px);animation-delay:.7s;}
@keyframes flBit{
  0%,100%{transform:translateY(0);opacity:0;}
  30%{opacity:1;}
  60%{transform:translateY(-12px);opacity:.8;}
  100%{transform:translateY(0);opacity:0;}
}
/* Pulsing amber aura behind everything */
.fl-aura{
  position:absolute;inset:20px;border-radius:50%;
  background:radial-gradient(circle,rgba(232,82,26,.12) 0%,transparent 70%);
  animation:flAura 2s ease-in-out infinite alternate;
}
@keyframes flAura{
  from{transform:scale(.9);opacity:.6;}
  to{transform:scale(1.15);opacity:1;}
}
/* Text + dots */
.fl-label{
  font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:3px;
  color:var(--muted);margin-top:20px;
}
.fl-dots span{
  display:inline-block;width:5px;height:5px;border-radius:50%;
  background:var(--amber);margin:0 3px;margin-top:10px;
  animation:flDot .9s ease-in-out infinite;
}
.fl-dots span:nth-child(2){animation-delay:.2s;}
.fl-dots span:nth-child(3){animation-delay:.4s;}
@keyframes flDot{
  0%,100%{transform:translateY(0);opacity:.4;}
  50%{transform:translateY(-7px);opacity:1;}
}
</style>
</head>
<body>

<!-- FOOD LOADER OVERLAY -->
<div id="foodLoader" role="status" aria-label="Loading Malaba Food">
  <div class="fl-scene">
    <div class="fl-aura"></div>
    <div class="fl-ring"></div>
    <div class="fl-dot"></div>
    <!-- steam -->
    <div class="fl-steam"></div>
    <div class="fl-steam"></div>
    <div class="fl-steam"></div>
    <!-- food bits -->
    <div class="fl-bit"></div>
    <div class="fl-bit"></div>
    <div class="fl-bit"></div>
    <!-- chopsticks -->
    <div class="fl-chop"></div>
    <div class="fl-chop"></div>
    <!-- bowl + plate -->
    <div class="fl-bowl"><div class="fl-bowl-fill"></div></div>
    <div class="fl-plate"></div>
  </div>
  <div class="fl-label">LOADING FOOD</div>
  <div class="fl-dots">
    <span></span><span></span><span></span>
  </div>
</div>
<header class="hdr" id="mainHdr">
  <div class="hdr-row">
    <a href="index.php" class="back-btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M19 12H5M5 12l7-7M5 12l7 7"/></svg></a>
    <div class="hdr-brand">Malaba <span>Food</span></div>
    <button class="cart-ico" id="cartIco" onclick="openCartSheet()">&#x1F6D2;<span class="cbadge" id="cartBadge">0</span></button>
  </div>
  <div class="srch-row">
    <div class="srch-box">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      <input type="search" id="srchInput" placeholder="Search restaurants or dishes&#x2026;" autocomplete="off" enterkeyhint="search">
      <button class="srch-clear" id="srchClear" onclick="clearSearch()">&#x2715;</button>
    </div>
  </div>
  <div class="cats-row" id="mainCats">
    <button class="cat on" data-f="">&#x1F374; All</button>
    <button class="cat" data-f="pizza">&#x1F355; Pizza</button>
    <button class="cat" data-f="burger">&#x1F354; Burgers</button>
    <button class="cat" data-f="rice">&#x1F35A; Rice</button>
    <button class="cat" data-f="pilau">Pilau</button>
    <button class="cat" data-f="nyama">&#x1F356; Nyama</button>
    <button class="cat" data-f="snacks">&#x1F9C2; Snacks</button>
    <button class="cat" data-f="drinks">&#x1F964; Drinks</button>
  </div>
</header>
<?php if ($isSpecialDay): ?>
<div class="bogo-banner" onclick="filterCat('pizza')">
  <div class="bb-bg"><div class="bb-row"><div class="bb-emoji">&#x1F355;</div><div class="bb-text">
    <div class="bb-eyebrow">Today Only</div>
    <div class="bb-title">PIZZA <em>BOGO</em> DAY!</div>
    <div class="bb-sub">Buy one pizza, get one FREE &#x2014; every Wednesday &amp; Saturday</div>
    <div class="bb-badge"><div class="bb-pulse"></div>Active now &bull; Tap to see pizzas</div>
  </div></div></div>
</div>
<?php else: ?>
<div class="bogo-banner" onclick="filterCat('pizza')">
  <div class="bb-bg"><div class="bb-row"><div class="bb-emoji">&#x1F355;</div><div class="bb-text">
    <div class="bb-eyebrow">Coming in <?php echo $daysUntil; ?> day<?php echo $daysUntil>1?'s':''; ?></div>
    <div class="bb-title">PIZZA <em>BOGO</em> DAY</div>
    <div class="bb-sub">Every Wed &amp; Sat &#x2014; Buy one pizza get one FREE</div>
    <div class="bb-badge" style="background:rgba(245,158,11,.15);border-color:rgba(245,158,11,.3);color:#fcd34d;">
      <div class="bb-pulse" style="background:#f59e0b;"></div>Next: <?php echo $nextDay; ?> &bull; Pre-order with Lipa
    </div>
  </div></div>
  <div class="bb-countdown" id="bogoCountdown"></div>
  </div>
</div>
<?php endif; ?>
<div class="sec-head"><h2>&#x1F525; <span>Hot Offers</span></h2><span class="res-count" id="offersCount"></span></div>
<div class="offer-scroll" id="offerScroll"></div>
<div class="sec-head" style="padding-top:16px;"><h2>&#x1F3E9; <span id="restTitle">Restaurants</span></h2><span class="res-count" id="restCount"></span></div>
<div id="restList" style="padding:0 0 8px;">
  <div class="skel-card" style="margin:0 14px 14px;"><div class="skel-hero skel"></div><div class="skel-body"><div class="skel-ln skel" style="width:65%;height:12px;"></div><div class="skel-ln skel" style="width:45%;"></div></div></div>
  <div class="skel-card" style="margin:0 14px 14px;"><div class="skel-hero skel"></div><div class="skel-body"><div class="skel-ln skel" style="width:75%;height:12px;"></div><div class="skel-ln skel" style="width:50%;"></div></div></div>
</div>
<div class="rest-panel" id="restPanel"><div id="restPanelContent"></div></div>
<div class="cart-strip" id="cartStrip">
  <div class="cs-progress"><div class="cs-progress-fill" id="csProgressFill"></div></div>
  <div class="cs-body">
    <div class="cs-left"><div class="cs-count" id="csCount">0 items</div><div class="cs-total" id="csTotal">KSH 0</div></div>
    <div class="cs-actions">
      <a href="track_order.php" class="cs-orders-btn">&#x1F4E6; Orders</a>
      <button class="cs-btn" onclick="openCartSheet()">Checkout &#x2192;</button>
    </div>
  </div>
</div>
<nav class="bnav">
  <a href="index.php" class="bni"><div class="bni-ico">&#x1F3E1;</div><div class="bni-lbl">Home</div></a>
  <a href="shop_listing.php" class="bni"><div class="bni-ico">&#x1F6D2;</div><div class="bni-lbl">Shop</div></a>
  <a href="video_feed.php" class="bni-center"><div class="bni-center-btn">&#x25B6;</div><div class="bni-center-lbl">Watch</div></a>
  <a href="food_listing.php" class="bni active"><div class="bni-ico">&#x1F354;</div><div class="bni-lbl">Food</div></a>
  <a href="homes_listing.php" class="bni"><div class="bni-ico">&#127976;</div><div class="bni-lbl">Rentals</div></a>
</nav>
<div class="overlay" id="overlay" onclick="handleOvClick(event)">
  <div class="sheet" id="mainSheet"><div id="sheetContent"></div></div>
</div>
<div class="toast" id="toast"></div>
<script src="data.js"></script>
<script src="mh_user.js"></script>
<script src="img_perf_1.js"></script>
<script src="perf_patch_1.js"></script>
<script>
var IS_SPECIAL=<?php echo $isSpecialDay?'true':'false';?>;
var NEXT_DAY='<?php echo $nextDay;?>';
var DAYS_UNTIL=<?php echo $daysUntil;?>;
var API='<?php echo htmlspecialchars($apiBase,ENT_QUOTES);?>';
var allRestaurants=[],allItems=[],filteredRests=[],cart=[],activeFilter='',searchQ='',currentRest=null;
var restSearchQ='',restCatFilter='',payMode='cash',pizzaStep=1,selPizzaPlan=null,pizzaPlans=[];
var checkoutStep=1;
try{cart=JSON.parse(localStorage.getItem('mh_food_cart')||'[]');}catch(e){}

function scoreRestaurant(r){
  var s=0;
  s+=(parseFloat(r.views||r.total_orders||0))*.4;
  s+=(parseFloat(r.rating||0))*20;
  s+=(r.is_featured==1)?30:0;
  var hasOffer=(r.items||[]).some(function(i){return i.badge||i.discount||i.is_offer;});
  s+=hasOffer?15:0;
  s+=Math.random()*10;
  if(IS_SPECIAL){
    var n=(r.title||r.name||r.cuisine||'').toLowerCase();
    if(n.indexOf('pizza')!==-1)s+=25;
    if((r.items||[]).some(function(i){return(i.title||'').toLowerCase().indexOf('pizza')!==-1;}))s+=15;
  }
  if(r.created_at){var a=(Date.now()-new Date(r.created_at).getTime())/86400000;if(a<7)s+=20;}
  return s;
}
function sortRests(l){return l.slice().sort(function(a,b){return scoreRestaurant(b)-scoreRestaurant(a);});}

window.addEventListener('DOMContentLoaded',function(){
  window._loaderStart=Date.now();
  /* Safety net — never block UI for more than 5 s */
  setTimeout(function(){
    var l=document.getElementById('foodLoader');
    if(l&&!l.classList.contains('hide')){l.classList.add('hide');setTimeout(function(){l.style.display='none';},520);}
  },5000);
  loadFood();initSearch();initCats();updateCartUI();prefillSaved();renderCountdown();
  setInterval(renderCountdown,1000);
  var hdr=document.getElementById('mainHdr');
  window.addEventListener('scroll',function(){hdr.classList.toggle('scrolled',window.scrollY>40);},{passive:true});
  var sh=document.getElementById('mainSheet'),ty=0;
  sh.addEventListener('touchstart',function(e){ty=e.touches[0].clientY;},{passive:true});
  sh.addEventListener('touchend',function(e){if(e.changedTouches[0].clientY-ty>80&&sh.scrollTop===0)closeOverlay();},{passive:true});

  /* Hardware back button — intercept when restaurant panel is open */
  window.addEventListener('popstate',function(e){
    if(document.getElementById('restPanel').classList.contains('open')){
      /* Close the panel and stay on the food listing — do NOT navigate away */
      document.getElementById('restPanel').classList.remove('open');
      document.body.style.overflow='';
      currentRest=null;
    }
    /* If the overlay sheet is open, close that too */
    if(document.getElementById('overlay').classList.contains('open')){
      closeOverlay();
    }
  });

  /* If the page loaded with #menu in the URL (e.g. restored session),
     clear it so the back button doesn't get confused */
  if(location.hash==='#menu') history.replaceState(null,'',location.pathname);
});

function loadFood(){
  var x=new XMLHttpRequest();
  x.open('GET',API+'/restaurants.php?limit=60&sort=smart',true);
  x.setRequestHeader('X-Requested-With','XMLHttpRequest');
  x.timeout=9000;
  x.onload=function(){try{var d=JSON.parse(x.responseText);if(d&&d.success&&d.data&&d.data.length){processData(d.data);return;}}catch(e){}loadSeed();};
  x.onerror=x.ontimeout=function(){loadSeed();};
  x.send();
}
function loadSeed(){
  var seed=(window.MalabaAPI&&MalabaAPI._seed&&MalabaAPI._seed.food)||getFallbackData();
  var map={};
  seed.forEach(function(item){
    var k=item.contact_phone||item.restaurant_id||'rest1';
    if(!map[k])map[k]={id:k,title:item.restaurant||(item.contact_name||'Restaurant'),description:'Serving delicious food in Malaba',rating:(3.9+Math.random()*.9).toFixed(1),image:item.image||item.image_url||'',views:Math.floor(Math.random()*300),is_featured:Math.random()>.7?1:0,contact_phone:k,location:item.location||'Malaba',cuisine:item.cuisine||'Local Food',delivery_time:(10+Math.floor(Math.random()*20))+' min',items:[]};
    map[k].items.push(item);
  });
  processData(Object.values(map));
}
function processData(data){
  allRestaurants=data.map(function(r){if(!r.items)r.items=[];return r;});
  allItems=[];
  allRestaurants.forEach(function(r){(r.items||[]).forEach(function(i){i._restId=r.id;i._restName=r.title||r.name||'';i._restPhone=r.contact_phone||'';allItems.push(i);});});
  filteredRests=sortRests(allRestaurants);
  renderRestaurants(filteredRests);renderOffers();
  if(window.MhPerfPatch)MhPerfPatch.run();
  /* Dismiss the loader — min 1.2 s so the animation is seen, not just a flash */
  var loader=document.getElementById('foodLoader');
  if(loader){
    var elapsed=Date.now()-window._loaderStart;
    var delay=Math.max(0,1200-elapsed);
    setTimeout(function(){
      loader.classList.add('hide');
      setTimeout(function(){loader.style.display='none';},520);
    },delay);
  }
}
function renderRestaurants(list){
  var el=document.getElementById('restList'),cnt=document.getElementById('restCount');
  if(cnt)cnt.textContent=list.length+' restaurant'+(list.length!==1?'s':'');
  if(!list.length){el.innerHTML='<div style="text-align:center;padding:40px 20px;"><div style="font-size:48px;margin-bottom:12px;">&#x1F37D;</div><div style="font-family:\'Bebas Neue\',sans-serif;font-size:22px;margin-bottom:6px;">No restaurants found</div><div style="font-size:13px;color:var(--muted);">Try a different search or category</div></div>';return;}
  var h='';list.forEach(function(r,i){h+=restCardHTML(r,i);});
  el.innerHTML=h;fadeInImages(el);
}
function restCardHTML(r,idx){
  var img=r.image||r.image_url||'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80';
  var heroSrc=window.MhImgPerf?MhImgPerf.imgCard(img):img;
  var rating=parseFloat(r.rating||4.2).toFixed(1);
  var delay=Math.min(idx,6)*.07+'s';
  var phone=r.contact_phone||'',waNum=normWA(phone);
  var waMsg=encodeURIComponent('Hi! I want to order from '+(r.title||r.name||'')+'.');
  var hasPizza=(r.cuisine||'').toLowerCase().indexOf('pizza')!==-1||(r.items||[]).some(function(i){return(i.title||'').toLowerCase().indexOf('pizza')!==-1;});
  var hasOffer=(r.items||[]).some(function(i){return i.badge||i.discount||i.is_offer;});
  var isOpen=r.is_open!==false&&r.is_open!==0;
  var badge=isOpen?'<span class="rbadge rb-open">&#x1F7E2; Open</span>':'<span class="rbadge rb-closed">&#x1F534; Closed</span>';
  if(IS_SPECIAL&&hasPizza)badge+=' <span class="rbadge rb-bogo">&#x1F355; BOGO</span>';
  else if(hasOffer)badge+=' <span class="rbadge rb-hot">&#x1F525; Offers</span>';
  var previews=(r.items||[]).slice(0,5).map(function(item){
    var ts=window.MhImgPerf?MhImgPerf.imgThumb(item.image||item.image_url||''):(item.image||item.image_url||'');
    return '<div class="ri-thumb" onclick="openRestaurant(\''+esc(r.id)+'\',\''+esc(item.id||'')+'\');event.stopPropagation();"><img class="ri-img" src="'+esc(ts)+'" loading="lazy" width="58" height="58" onload="this.classList.add(\'img-loaded\')"><div class="ri-name">'+esc((item.title||'').split(' ').slice(0,2).join(' '))+'</div><div class="ri-price">'+esc(item.price||'')+'</div></div>';
  }).join('');
  return '<div class="rcard" style="margin:0 14px 14px;animation-delay:'+delay+';" onclick="openRestaurant(\''+esc(r.id)+'\',null)">'+
    '<div class="rcard-hero"><img src="'+esc(heroSrc)+'" alt="'+esc(r.title||r.name||'')+'" loading="lazy" width="600" height="165" onload="this.classList.add(\'img-loaded\')"><div class="rcard-hero-grad"></div>'+
    '<div class="rcard-badges">'+badge+'<div class="rcard-rating-badge"><span>&#x2605;</span>'+rating+'</div></div>'+
    '<div class="rcard-info-overlay"><div class="rcard-name">'+esc(r.title||r.name||'')+'</div><div class="rcard-meta"><div class="rcard-tag">&#x1F4CD; '+esc((r.location||'').split(',')[0])+'</div><div class="rcard-tag">&#x23F1; '+(r.delivery_time||'15-30 min')+'</div>'+(r.cuisine?'<div class="rcard-tag">'+esc(r.cuisine)+'</div>':'')+'</div></div></div>'+
    (r.description?'<div class="rcard-body"><div class="rcard-desc">'+esc(r.description)+'</div>'+(previews?'<div class="rcard-items">'+previews+'</div>':'')+'</div>':'')+
    '<div class="rcard-foot"><button class="btn-view-rest">&#x1F374; View Menu</button><a href="https://wa.me/'+waNum+'?text='+waMsg+'" target="_blank" rel="noopener" class="btn-wa-rest" onclick="event.stopPropagation()">&#x1F4AC;</a></div></div>';
}
function renderOffers(){
  var offers=allItems.filter(function(i){return i.badge||i.discount||i.is_offer||(IS_SPECIAL&&(i.title||'').toLowerCase().indexOf('pizza')!==-1);}).slice(0,12);
  var el=document.getElementById('offerScroll'),cnt=document.getElementById('offersCount');
  if(cnt)cnt.textContent=offers.length?offers.length+' deals':'';
  if(!offers.length)return;
  el.innerHTML=offers.map(function(item){
    var img=item.image||item.image_url||'',src=window.MhImgPerf?MhImgPerf.imgCard(img):img;
    var raw=parseFloat(String(item.price||'').replace(/[^0-9.]/g,''))||0;
    var disc=item.discount||(IS_SPECIAL&&(item.title||'').toLowerCase().indexOf('pizza')!==-1?'BOGO':null);
    return '<div class="offer-card" onclick="openRestaurant(\''+esc(item._restId)+'\',\''+esc(item.id||'')+'\')"><div class="offer-card-img"><img src="'+esc(src)+'" loading="lazy" alt="'+esc(item.title||'')+'" width="155" height="108" onload="this.classList.add(\'img-loaded\')" style="opacity:0;transition:opacity .4s;"><div class="offer-card-img-grad"></div>'+(disc?'<div class="offer-discount">'+esc(String(disc))+'</div>':'')+'</div><div class="offer-card-body"><div class="offer-card-name">'+esc(item.title||'')+'</div><div class="offer-card-price">KSH '+Math.round(raw).toLocaleString('en-KE')+'</div><div class="offer-rest">&#x1F3E9; '+esc(item._restName||'')+'</div></div></div>';
  }).join('');
}
function openRestaurant(restId,scrollToId){
  var rest=allRestaurants.find(function(r){return r.id==restId;});
  if(!rest)return;
  currentRest=rest;restSearchQ='';restCatFilter='';
  document.getElementById('restPanelContent').innerHTML=buildRestPanel(rest);
  document.getElementById('restPanel').classList.add('open');
  document.body.style.overflow='hidden';
  fadeInImages(document.getElementById('restPanel'));
  if(scrollToId)setTimeout(function(){var el=document.getElementById('fitem-'+scrollToId);if(el)el.scrollIntoView({behavior:'smooth',block:'center'});},450);
  if(window.MhPerfPatch)MhPerfPatch.run();
  /* Push a history entry so the hardware back button hits popstate, not the previous page */
  history.pushState({restPanel:true,restId:restId},'','#menu');
}
function closeRestPanel(){
  document.getElementById('restPanel').classList.remove('open');
  document.body.style.overflow='';
  currentRest=null;
  /* If we still have the #menu hash in the URL, pop it cleanly */
  if(location.hash==='#menu') history.back();
}
function buildRestPanel(rest){
  var img=rest.image||rest.image_url||'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=900&q=80';
  var heroSrc=window.MhImgPerf?MhImgPerf.imgHero(img):img;
  var rating=parseFloat(rest.rating||4.2).toFixed(1);
  var phone=rest.contact_phone||'',waNum=normWA(phone);
  var waMsg=encodeURIComponent('Hi! I want to order from *'+(rest.title||rest.name||'')+'*.');
  var cats=['All'];
  (rest.items||[]).forEach(function(item){var c=item.category||item.subCategory||item.food_type||'';if(c&&cats.indexOf(c)===-1)cats.push(c);});
  var catTabs=cats.length>1?cats.map(function(c,i){return '<button class="rp-cat'+(i===0?' on':'')+'" onclick="filterRestCat(this,\''+esc(c)+'\')">'+esc(c)+'</button>';}).join(''):'';
  return '<div class="rp-hero"><img src="'+esc(heroSrc)+'" alt="'+esc(rest.title||rest.name||'')+'" width="900" height="220" onload="this.classList.add(\'img-loaded\')" onerror="this.src=\'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=900&q=70\'"><div class="rp-hero-grad"></div>'+
    '<button class="rp-back" onclick="closeRestPanel()" aria-label="Back"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M5 12l7-7M5 12l7 7"/></svg></button>'+
    '<div class="rp-info"><div class="rp-name">'+esc(rest.title||rest.name||'')+'</div><div class="rp-meta"><div class="rp-rating"><span>&#x2605;</span>'+rating+'</div><div class="rp-tag">&#x23F1; '+(rest.delivery_time||'15-30 min')+'</div><div class="rp-tag">&#x1F4CD; '+esc((rest.location||'').split(',')[0])+'</div>'+(rest.cuisine?'<div class="rp-tag">'+esc(rest.cuisine)+'</div>':'')+'<a href="https://wa.me/'+waNum+'?text='+waMsg+'" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:4px;background:#25D366;color:#fff;padding:3px 10px;border-radius:14px;font-size:10px;font-weight:700;text-decoration:none;">&#x1F4AC; WhatsApp</a></div></div></div>'+
    (catTabs?'<div class="rp-cats" id="rpCats">'+catTabs+'</div>':'')+
    '<div class="rp-srch"><div class="rp-srch-box"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg><input type="search" id="rpSrch" placeholder="Search in '+(rest.title||rest.name||'')+'&#x2026;" autocomplete="off" oninput="filterRestItems(this.value)"></div></div>'+
    '<div class="rp-items" id="rpItems">'+buildItemsHTML(rest.items||[],rest)+'</div>';
}
function buildItemsHTML(items,rest){
  if(!items.length)return '<div style="text-align:center;padding:32px 20px;color:var(--muted);font-size:14px;">No items found</div>';
  return items.map(function(item,i){return foodItemHTML(item,rest,i);}).join('');
}
function foodItemHTML(item,rest,idx){
  var img=item.image||item.image_url||'',src=window.MhImgPerf?MhImgPerf.imgCard(img):img;
  var raw=parseFloat(String(item.price||'').replace(/[^0-9.]/g,''))||0;
  var delay=Math.min(idx,6)*.055+'s';
  var inCart=cart.find(function(c){return c.id===item.id;}),qty=inCart?inCart.qty:0;
  var isBogo=IS_SPECIAL&&(item.title||'').toLowerCase().indexOf('pizza')!==-1;
  var isSold=item.is_sold_out==1||item.stock===0;
  var restId=rest?rest.id:(item._restId||'');
  var badge='';
  if(isBogo)badge='<div class="fitem-badge fb-bogo">BOGO</div>';
  else if(item.discount)badge='<div class="fitem-badge fb-offer">-'+item.discount+'%</div>';
  else if(item.badge=='New')badge='<div class="fitem-badge fb-new">New</div>';
  else if(item.badge=='Hot')badge='<div class="fitem-badge fb-hot">Hot</div>';
  else if(item.badge&&item.badge!='BOGO')badge='<div class="fitem-badge fb-offer">'+esc(item.badge)+'</div>';
  var tags='';
  if(item.is_spicy)tags+='<span class="ftag ft-spicy">&#x1F336; Spicy</span>';
  if(item.is_veg)tags+='<span class="ftag ft-veg">&#x1F33F; Veg</span>';
  if(item.prep_time)tags+='<span class="ftag ft-fast">&#x23F1; '+esc(item.prep_time)+'</span>';
  var isPizzaItem=(item.title||'').toLowerCase().indexOf('pizza')!==-1;
  var pizzaLipaBtn=(!isBogo&&isPizzaItem)?'<div onclick="openPizzaLipa(event,\''+esc(item.id)+'\',\''+esc(restId)+'\');event.stopPropagation();" style="font-size:10px;font-weight:700;color:#ff9999;cursor:pointer;margin-top:3px;">&#x1F4B0; Pre-order with Lipa</div>':'';
  var controls=isSold?'<div style="font-size:10px;color:var(--muted);text-align:center;">Sold<br>out</div>':(qty>0?'<div class="qty-ctrl show" id="qc-'+esc(item.id)+'"><button class="qbtn" onclick="changeQty(event,\''+esc(item.id)+'\',\''+esc(restId)+'\',-1)">&#x2212;</button><div class="qnum" id="qnum-'+esc(item.id)+'">'+qty+'</div><button class="qbtn" onclick="changeQty(event,\''+esc(item.id)+'\',\''+esc(restId)+'\',1)">+</button></div>':'<button class="add-btn" id="addbtn-'+esc(item.id)+'" onclick="quickAdd(event,\''+esc(item.id)+'\',\''+esc(restId)+'\')">+</button>');
  return '<div class="fitem'+(isBogo?' is-pizza-bogo':'')+(item.badge||item.discount?' is-offer':'')+'" id="fitem-'+esc(item.id)+'" style="animation-delay:'+delay+';" onclick="quickAdd(event,\''+esc(item.id)+'\',\''+esc(restId)+'\')">'+'<div class="fitem-img"><img src="'+esc(src)+'" alt="'+esc(item.title||'')+'" loading="lazy" width="110" height="112" onerror="this.src=\'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=220&q=70\'" onload="this.classList.add(\'img-loaded\')" style="opacity:0;transition:opacity .4s;">'+badge+(isSold?'<div class="fitem-soldout">Sold Out</div>':'')+'</div>'+'<div class="fitem-body"><div class="fitem-name">'+esc(item.title||'')+'</div>'+(item.description?'<div class="fitem-desc">'+esc(item.description)+'</div>':'')+(tags?'<div class="fitem-tags">'+tags+'</div>':'')+'<div class="fitem-price-row"><div class="fitem-price">'+esc(item.price||'')+'</div>'+(isBogo?'<div class="fitem-bogo">+1 FREE &#x1F389;</div>':'')+'</div>'+pizzaLipaBtn+'</div>'+'<div class="fitem-right" id="fir-'+esc(item.id)+'">'+controls+'</div></div>';
}
function filterRestCat(btn,cat){document.querySelectorAll('.rp-cat').forEach(function(b){b.classList.remove('on');});btn.classList.add('on');restCatFilter=(cat==='All')?'':cat.toLowerCase();renderRestItems();}
function filterRestItems(q){restSearchQ=q.trim().toLowerCase();renderRestItems();}
function renderRestItems(){
  if(!currentRest)return;
  var items=(currentRest.items||[]).filter(function(item){var txt=((item.title||'')+(item.description||'')+(item.category||'')).toLowerCase();return(!restSearchQ||txt.indexOf(restSearchQ)!==-1)&&(!restCatFilter||txt.indexOf(restCatFilter)!==-1);});
  var el=document.getElementById('rpItems');if(el){el.innerHTML=buildItemsHTML(items,currentRest);fadeInImages(el);}
}
function quickAdd(ev,itemId,restId){
  if(ev)ev.stopPropagation();
  var rest=allRestaurants.find(function(r){return r.id==restId;})||currentRest;if(!rest)return;
  var item=(rest.items||[]).find(function(i){return i.id===itemId;})||(allItems.find(function(i){return i.id===itemId;}));
  if(!item||item.is_sold_out)return;
  var raw=parseFloat(String(item.price||'').replace(/[^0-9.]/g,''))||0;
  var isBogo=IS_SPECIAL&&(item.title||'').toLowerCase().indexOf('pizza')!==-1;
  var ex=cart.find(function(c){return c.id===itemId;});
  if(ex){ex.qty++;}else{cart.push({id:itemId,name:item.title||'',price:item.price||'',raw:raw,qty:1,restName:rest.title||rest.name||'',restPhone:rest.contact_phone||'',img:item.image||item.image_url||'',isBogo:isBogo});}
  saveCart();
  var fir=document.getElementById('fir-'+itemId),qnum=document.getElementById('qnum-'+itemId),qc=document.getElementById('qc-'+itemId),nq=ex?ex.qty:1;
  if(qnum){qnum.textContent=nq;}
  else if(fir){fir.innerHTML='<div class="qty-ctrl show" id="qc-'+esc(itemId)+'"><button class="qbtn" onclick="changeQty(event,\''+esc(itemId)+'\',\''+esc(restId)+'\',-1)">&#x2212;</button><div class="qnum" id="qnum-'+esc(itemId)+'">1</div><button class="qbtn" onclick="changeQty(event,\''+esc(itemId)+'\',\''+esc(restId)+'\',1)">+</button></div>';}
  if(qc)qc.classList.add('show');
  showToast(isBogo?'&#x1F355; BOGO! 2 pizzas for '+item.price:'&#x2705; Added to cart');
}
function changeQty(ev,itemId,restId,delta){
  if(ev)ev.stopPropagation();
  var ex=cart.find(function(c){return c.id===itemId;});if(!ex)return;
  ex.qty=Math.max(0,ex.qty+delta);if(!ex.qty)cart=cart.filter(function(c){return c.id!==itemId;});
  saveCart();
  var qnum=document.getElementById('qnum-'+itemId),fir=document.getElementById('fir-'+itemId);
  if(!cart.find(function(c){return c.id===itemId;})){if(fir)fir.innerHTML='<button class="add-btn" id="addbtn-'+esc(itemId)+'" onclick="quickAdd(event,\''+esc(itemId)+'\',\''+esc(restId)+'\')">+</button>';}
  else if(qnum){qnum.textContent=ex.qty;}
}
function saveCart(){localStorage.setItem('mh_food_cart',JSON.stringify(cart));updateCartUI();}
function updateCartUI(){
  var n=cart.reduce(function(s,c){return s+c.qty;},0);
  var total=cart.reduce(function(s,c){return s+(c.raw||0)*c.qty;},0);
  var badge=document.getElementById('cartBadge');if(badge){badge.textContent=n;badge.classList.toggle('on',n>0);}
  var strip=document.getElementById('cartStrip'),csC=document.getElementById('csCount'),csT=document.getElementById('csTotal'),csFill=document.getElementById('csProgressFill');
  if(csC)csC.textContent=n+' item'+(n!==1?'s':'');
  if(csT)csT.textContent='KSH '+total.toLocaleString('en-KE');
  if(strip)strip.classList.toggle('show',n>0);
  if(csFill)csFill.style.width=Math.min((total/500)*100,100)+'%';
}
/* === 3-STEP PROGRESSIVE CHECKOUT === */
function openCartSheet(){var n=cart.reduce(function(s,c){return s+c.qty;},0);if(!n){showToast('Your cart is empty');return;}checkoutStep=1;renderCheckoutSheet();openOverlay();}
function stepDot(n,label){var cls=n<checkoutStep?'cstep done':(n===checkoutStep?'cstep active':'cstep');var inner=n<checkoutStep?'&#x2713;':String(n);return '<div class="'+cls+'"><div class="cstep-dot">'+inner+'</div><div class="cstep-lbl">'+label+'</div></div>';}
function renderCheckoutSheet(){
  var n=cart.reduce(function(s,c){return s+c.qty;},0);
  var total=cart.reduce(function(s,c){return s+(c.raw||0)*c.qty;},0);
  var dlv=total>=500?0:50,grand=total+dlv;
  window._cartGrand=grand;
  var stepsBar='<div class="checkout-steps-bar">'+stepDot(1,'Cart')+'<div class="cstep-line'+(checkoutStep>1?' done':'')+'"></div>'+stepDot(2,'Delivery')+'<div class="cstep-line'+(checkoutStep>2?' done':'')+'"></div>'+stepDot(3,'Confirm')+'</div>';
  var bodyHTML='';
  if(checkoutStep===1){
    var itemsHTML=cart.map(function(c){
      var imgSrc=window.MhImgPerf?MhImgPerf.imgThumb(c.img||''):(c.img||'');
      return '<div class="cart-item" id="ci-'+esc(c.id)+'">'+(imgSrc?'<img class="ci-img" src="'+esc(imgSrc)+'" loading="lazy" width="44" height="44" onload="this.style.opacity=1" style="opacity:0;transition:opacity .3s;">':'<div class="ci-img"></div>')+'<div class="ci-info"><div class="ci-name">'+esc(c.name)+(c.isBogo?' <span style="color:#ff9999;font-size:10px;">(BOGO x2)</span>':'')+'</div><div class="ci-rest">&#x1F3E9; '+esc(c.restName)+'</div></div><div class="ci-controls"><button class="ci-qbtn" onclick="cartQty(\''+esc(c.id)+'\',-1)">&#x2212;</button><div class="ci-qty" id="ciq-'+esc(c.id)+'">'+c.qty+'</div><button class="ci-qbtn" onclick="cartQty(\''+esc(c.id)+'\',1)">+</button></div><div class="ci-price">KSH '+(((c.raw||0)*c.qty).toLocaleString('en-KE'))+'</div><button class="ci-del" onclick="cartQty(\''+esc(c.id)+'\',0)">&#x2715;</button></div>';
    }).join('');
    bodyHTML='<div style="padding:10px 16px 0;"><div style="font-family:\'Bebas Neue\',sans-serif;font-size:20px;letter-spacing:.5px;margin-bottom:10px;">&#x1F6D2; Your Order <span style="color:var(--amber2);">('+n+')</span></div>'+
      '<div style="display:flex;flex-direction:column;gap:7px;margin-bottom:12px;">'+itemsHTML+'</div>'+
      (dlv>0?'<div style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.18);border-radius:var(--r);padding:10px 12px;margin-bottom:10px;font-size:12px;color:rgba(245,200,80,.85);">&#x1F6F5; Add KSH '+(500-total).toLocaleString('en-KE')+' more for FREE delivery!</div>':'<div style="background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.18);border-radius:var(--r);padding:10px 12px;margin-bottom:10px;font-size:12px;color:rgba(100,220,120,.85);">&#x1F389; You qualify for FREE delivery!</div>')+
      '<div class="cart-total-box"><div class="ctr"><span>Subtotal</span><span>KSH '+total.toLocaleString('en-KE')+'</span></div><div class="ctr"><span>Delivery</span><span>'+(dlv===0?'<span style="color:var(--green);">FREE</span>':'KSH '+dlv)+'</span></div><div class="ctr tot"><span>Total</span><span>KSH '+grand.toLocaleString('en-KE')+'</span></div></div></div>'+
      '<div class="co-nav"><button class="co-next-btn" onclick="goCheckoutStep(2)">Next: Delivery Details &#x2192;</button></div>';
  } else if(checkoutStep===2){
    bodyHTML='<div style="padding:12px 16px 0;"><div style="font-family:\'Bebas Neue\',sans-serif;font-size:20px;letter-spacing:.5px;margin-bottom:4px;">&#x1F4CD; Delivery Details</div><div style="font-size:12px;color:var(--muted);margin-bottom:14px;">Where should we bring your food?</div>'+
      '<div class="row2"><div class="field"><label>Full Name *</label><input type="text" id="ct_name" placeholder="Your name" autocomplete="name"></div><div class="field"><label>Phone *</label><input type="tel" id="ct_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div></div>'+
      '<div class="field"><label>Delivery Address *</label><input type="text" id="ct_addr" placeholder="e.g. Near Malaba Market, Gate 3"></div>'+
      '<div class="field"><label>Note for Rider (optional)</label><input type="text" id="ct_note" placeholder="e.g. Call when near, blue gate"></div></div>'+
      '<div class="co-nav"><button class="co-back-btn" onclick="goCheckoutStep(1)">&#x2190; Back</button><button class="co-next-btn" onclick="goCheckoutStep(3)">Review Order &#x2192;</button></div>';
  } else if(checkoutStep===3){
    var savedName=window._coName||'',savedPhone=window._coPhone||'',savedAddr=window._coAddr||'',savedNote=window._coNote||'';
    var confirmItems=cart.map(function(c){var imgSrc=window.MhImgPerf?MhImgPerf.imgThumb(c.img||''):(c.img||'');return '<div class="co-confirm-item">'+(imgSrc?'<img class="co-ci-img" src="'+esc(imgSrc)+'" loading="lazy" width="38" height="38" onload="this.style.opacity=1" style="opacity:0;transition:opacity .3s;">':'<div class="co-ci-img"></div>')+'<div class="co-ci-name">'+esc(c.name)+(c.isBogo?' <span style="color:#ff9999;">(x2 BOGO)</span>':'')+'</div><div class="co-ci-qty">x'+c.qty+'</div><div class="co-ci-price">KSH '+(((c.raw||0)*c.qty).toLocaleString('en-KE'))+'</div></div>';}).join('');
    bodyHTML='<div style="padding:12px 16px 0;"><div style="font-family:\'Bebas Neue\',sans-serif;font-size:20px;letter-spacing:.5px;margin-bottom:10px;">&#x2705; Confirm Your Order</div>'+
      '<div style="background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:var(--r);padding:10px 12px;margin-bottom:10px;"><div style="font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.5px;text-transform:uppercase;margin-bottom:8px;">&#x1F374; Items</div>'+confirmItems+
      '<div style="display:flex;justify-content:space-between;font-size:14px;font-weight:700;color:var(--text);padding-top:8px;border-top:1px solid var(--border);margin-top:6px;"><span>Total (incl. delivery)</span><span style="color:var(--amber2);">KSH '+grand.toLocaleString('en-KE')+'</span></div></div>'+
      '<div style="background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:var(--r);padding:10px 12px;margin-bottom:10px;"><div style="font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.5px;text-transform:uppercase;margin-bottom:7px;">&#x1F4CD; Delivering to</div>'+
      '<div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:2px;">'+esc(savedName)+' &bull; '+esc(savedPhone)+'</div>'+
      '<div style="font-size:12px;color:var(--muted);">'+esc(savedAddr)+(savedNote?' &bull; '+esc(savedNote):'')+'</div>'+
      '<button onclick="goCheckoutStep(2)" style="font-size:10px;font-weight:700;color:var(--amber2);background:none;border:none;cursor:pointer;padding:4px 0;margin-top:4px;">&#x270E; Edit details</button></div>'+
      '<div style="font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.5px;text-transform:uppercase;margin-bottom:8px;">&#x1F4B0; Payment Method</div>'+
      '<div class="pay-opts"><div class="po'+(payMode==='cash'?' sel':'')+'" id="ct_cash" onclick="setCartPay(\'cash\',this)"><div class="po-ico">&#x1F4B5;</div><div class="po-txt"><strong>Cash on Delivery</strong><span>Pay when food arrives</span></div><div class="po-dot"></div></div>'+
      '<div class="po'+(payMode==='mpesa'?' sel':'')+'" id="ct_mpesa" onclick="setCartPay(\'mpesa\',this)"><div class="po-ico">&#x1F4F1;</div><div class="po-txt"><strong>M-Pesa on Delivery</strong><span>Send M-Pesa when delivered</span></div><div class="po-dot"></div></div></div>'+
      '<button class="sbtn" id="cartSubmitBtn" onclick="submitCartOrder()">&#x1F355; Place Order &mdash; KSH '+grand.toLocaleString('en-KE')+'</button></div>'+
      '<div class="co-nav"><button class="co-back-btn" onclick="goCheckoutStep(2)">&#x2190; Back</button></div>';
  }
  document.getElementById('sheetContent').innerHTML='<div class="sh-grip"><div class="sh-handle"></div><button class="sh-x" onclick="closeOverlay()">&#x2715;</button></div>'+stepsBar+'<div class="co-panel active">'+bodyHTML+'</div>';
  var sh=document.getElementById('mainSheet');if(sh)sh.scrollTop=0;
  if(checkoutStep===2){
    prefillSaved();
    if(window._coName&&document.getElementById('ct_name'))document.getElementById('ct_name').value=window._coName;
    if(window._coPhone&&document.getElementById('ct_phone'))document.getElementById('ct_phone').value=window._coPhone;
    if(window._coAddr&&document.getElementById('ct_addr'))document.getElementById('ct_addr').value=window._coAddr;
    if(window._coNote&&document.getElementById('ct_note'))document.getElementById('ct_note').value=window._coNote;
  }
  if(checkoutStep===3)fadeInImages(document.getElementById('mainSheet'));
}
function goCheckoutStep(step){
  if(checkoutStep===2){
    var name=(document.getElementById('ct_name')&&document.getElementById('ct_name').value||'').trim();
    var phone=(document.getElementById('ct_phone')&&document.getElementById('ct_phone').value||'').trim();
    var addr=(document.getElementById('ct_addr')&&document.getElementById('ct_addr').value||'').trim();
    var note=(document.getElementById('ct_note')&&document.getElementById('ct_note').value||'').trim();
    if(step===3){if(!name){showToast('Enter your full name');return;}if(!phone||phone.replace(/\D/g,'').length<9){showToast('Enter a valid phone number');return;}if(!addr){showToast('Enter your delivery address');return;}}
    window._coName=name;window._coPhone=phone;window._coAddr=addr;window._coNote=note;
  }
  checkoutStep=step;renderCheckoutSheet();
}
function cartQty(id,d){
  var ex=cart.find(function(c){return c.id===id;});if(!ex)return;
  if(d===0){cart=cart.filter(function(c){return c.id!==id;});}else{ex.qty=Math.max(0,ex.qty+d);if(!ex.qty)cart=cart.filter(function(c){return c.id!==id;});}
  saveCart();
  if(!cart.length){closeOverlay();return;}
  if(checkoutStep===1){renderCheckoutSheet();return;}
  var qEl=document.getElementById('ciq-'+id);if(qEl&&ex&&ex.qty>0)qEl.textContent=ex.qty;
  if(!cart.find(function(c){return c.id===id;})){var ciEl=document.getElementById('ci-'+id);if(ciEl){ciEl.style.cssText='opacity:0;transform:translateX(40px);transition:all .25s;';setTimeout(function(){if(ciEl.parentNode)ciEl.parentNode.removeChild(ciEl);},250);}}
  var t=cart.reduce(function(s,c){return s+(c.raw||0)*c.qty;},0),dlv=t>=500?0:50,grand=t+dlv;
  window._cartGrand=grand;
  var btn=document.getElementById('cartSubmitBtn');if(btn)btn.innerHTML='&#x1F355; Place Order &mdash; KSH '+grand.toLocaleString('en-KE');
}
function setCartPay(mode,el){payMode=mode;['ct_cash','ct_mpesa'].forEach(function(id){var e=document.getElementById(id);if(e)e.classList.remove('sel');});el.classList.add('sel');}
function submitCartOrder(){
  var name=window._coName||'',phone=window._coPhone||'',addr=window._coAddr||'',note=window._coNote||'';
  if(!name||!phone||!addr){showToast('Please complete delivery details');goCheckoutStep(2);return;}
  var btn=document.getElementById('cartSubmitBtn');if(btn){btn.disabled=true;btn.innerHTML='Placing order&#x2026;';}
  saveMhUser(name,phone,addr);
  var grand=window._cartGrand||0;
  var items=cart.map(function(c){return c.name+(c.isBogo?' (BOGO x2)':'');}).join(', ');
  var ph2=cart[0]&&cart[0].restPhone?cart[0].restPhone:'',waNum=normWA(ph2),snap=cart.slice();
  postOrder({category:'food',listing_id:snap[0]&&snap[0].id?snap[0].id:'',listing_title:snap[0]&&snap[0].name?snap[0].name:'Food Order',listing_price:'KSH '+grand.toLocaleString('en-KE'),name:name,phone:phone,address:addr,payment_method:payMode==='mpesa'?'mpesa_on_delivery':'cash_on_delivery',total_amount:String(grand),notes:'Food order: '+items+' | '+addr+(note?' | Note: '+note:'')+' | '+payMode,cart_items:snap.map(function(c){return{id:c.id,title:c.name,price:c.price,qty:c.qty};})},
  function(d){
    var ref=d&&d.order_ref?d.order_ref:'';
    var msg=encodeURIComponent('*New Food Order!*\nName: '+name+'\nPhone: '+phone+'\nAddress: '+addr+(note?'\nNote: '+note:'')+'\nItems: '+items+'\nTotal: KSH '+grand.toLocaleString('en-KE')+'\nPayment: '+payMode+'\nRef: '+(ref||'—'));
    cart=[];window._coName='';window._coPhone='';window._coAddr='';window._coNote='';saveCart();showOrderSuccess(ref,grand,name,waNum,msg);
  },function(){if(btn){btn.disabled=false;btn.innerHTML='&#x1F355; Place Order &mdash; KSH '+grand.toLocaleString('en-KE');}showToast('Network error. Try again.');});
}
function showOrderSuccess(ref,grand,name,waNum,waMsg){
  var colors=['#E8521A','#F5A623','#22C55E','#FF7043','#fcd34d'],confetti='';
  for(var i=0;i<12;i++)confetti+='<div class="confetti-dot" style="left:'+(10+Math.random()*80)+'%;background:'+colors[i%5]+';animation-delay:'+(Math.random()*.6)+'s;"></div>';
  document.getElementById('sheetContent').innerHTML='<div class="sh-grip"><div class="sh-handle"></div><button class="sh-x" onclick="closeOverlay()">&#x2715;</button></div><div class="success-wrap"><div class="confetti-wrap">'+confetti+'</div><div class="success-anim">&#x2705;</div><div class="suc-title">Order Placed!</div><div class="suc-sub">Your food is being prepared.<br>Estimated delivery: <strong style="color:var(--amber2);">20&#x2013;35 minutes</strong></div>'+(ref?'<div class="suc-ref">Ref: '+esc(ref)+'</div>':'')+
    '<div class="order-tracker"><div class="ot-title">&#x1F4E6; Order Status</div><div class="ot-steps"><div class="ot-fill" id="otFill"></div><div class="ot-step"><div class="ot-dot done">&#x2713;</div><div class="ot-lbl done">Received</div></div><div class="ot-step"><div class="ot-dot active">&#x1F373;</div><div class="ot-lbl active">Preparing</div></div><div class="ot-step"><div class="ot-dot">&#x1F6F5;</div><div class="ot-lbl">On Way</div></div><div class="ot-step"><div class="ot-dot">&#x1F3E0;</div><div class="ot-lbl">Delivered</div></div></div></div>'+
    '<button class="wa-btn" id="sucWaBtn">&#x1F4AC; Confirm on WhatsApp</button><a href="track_order.php" class="track-btn">&#x1F4E6; Track My Order</a><button class="done-btn" onclick="closeOverlay()">Continue Browsing</button></div>';
  setTimeout(function(){var f=document.getElementById('otFill');if(f)f.style.width='33%';},400);
  var wb=document.getElementById('sucWaBtn');if(wb)wb.onclick=function(){window.open('https://wa.me/'+waNum+'?text='+waMsg,'_blank');};
}
/* === PIZZA LIPA === */
function getPizzaPlans(raw){
  var ksh=function(n){return 'KSH '+Math.round(n).toLocaleString('en-KE');};
  var today=new Date();
  function daysTo(wd){var d=today.getDay(),diff=wd-d;if(diff<=0)diff+=7;return diff;}
  var ns=Math.min(daysTo(3),daysTo(6));
  var dd=new Date(today.getTime()+ns*86400000);
  var months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  var dws=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  var delivStr=dws[dd.getDay()]+', '+dd.getDate()+' '+months[dd.getMonth()];
  var plans=[{id:'lump',name:'Pay Full Now',desc:ksh(raw)+' now — get pizza on '+delivStr,payments:[{day:'Today',amt:raw}],total:raw,perPayStr:ksh(raw),delivStr:delivStr}];
  if(ns>=2){
    var ppd=Math.ceil(raw/ns),pays=[];
    for(var i=1;i<=ns;i++){var d2=new Date(today.getTime()+i*86400000);pays.push({day:dws[d2.getDay()]+' '+d2.getDate()+' '+months[d2.getMonth()],amt:(i===ns?raw-ppd*(ns-1):ppd)});}
    plans.push({id:'daily',name:'Daily — '+ns+' payments',desc:ksh(ppd)+'/day — pizza on '+delivStr,payments:pays,total:raw,perPayStr:ksh(ppd),delivStr:delivStr});
  }
  return {plans:plans,delivStr:delivStr};
}
function openPizzaLipa(ev,itemId,restId){
  if(ev)ev.stopPropagation();
  var rest=allRestaurants.find(function(r){return r.id==restId;})||currentRest;if(!rest)return;
  var item=(rest.items||[]).find(function(i){return i.id===itemId;});if(!item)return;
  var raw=parseFloat(String(item.price||'').replace(/[^0-9.]/g,''))||0;
  var data=getPizzaPlans(raw);pizzaPlans=data.plans;selPizzaPlan=null;pizzaStep=1;
  var img=item.image||item.image_url||'';
  document.getElementById('sheetContent').innerHTML=
    '<div class="sh-grip"><div class="sh-handle"></div><button class="sh-x" onclick="closeOverlay()">&#x2715;</button></div>'+
    '<div class="lipa-product">'+(img?'<img class="lipa-img" src="'+esc(img)+'" loading="lazy" width="56" height="56">':'<div style="width:56px;height:56px;border-radius:11px;background:var(--surface);display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0;">&#x1F355;</div>')+
    '<div><div class="lipa-name">'+esc(item.title||'')+'</div><div class="lipa-was">'+esc(item.price||'')+' full price</div><div class="lipa-tag">&#x1F355; Pay before BOGO day</div></div></div>'+
    '<div class="lipa-steps"><div class="lstep"><div class="ls-dot active" id="pzsd1">1</div><div class="ls-lbl active" id="pzsl1">Plan</div></div><div class="ls-line" id="pzsl1l"></div><div class="lstep"><div class="ls-dot" id="pzsd2">2</div><div class="ls-lbl" id="pzsl2">Timeline</div></div><div class="ls-line" id="pzsl2l"></div><div class="lstep"><div class="ls-dot" id="pzsd3">3</div><div class="ls-lbl" id="pzsl3">Details</div></div></div>'+
    '<div class="lipa-panel active" id="pzp1"><div style="padding:0 16px 6px;font-family:\'Bebas Neue\',sans-serif;font-size:18px;letter-spacing:.3px;">Choose Payment Plan</div><div style="padding:0 16px 12px;font-size:12px;color:var(--muted);">Pizza delivered on <strong style="color:var(--text);">'+data.delivStr+'</strong> after full payment.</div>'+
    '<div style="padding:0 16px 12px;">'+pizzaPlans.map(function(p,i){return '<div class="pizza-plan" id="ppl-'+p.id+'" onclick="selPlanFn(\''+p.id+'\','+i+')"><div class="pp-radio"></div><div class="pp-info"><div class="pp-name">'+p.name+'</div><div class="pp-desc">'+p.desc+'</div></div><div class="pp-amt">'+p.perPayStr+'</div></div>';}).join('')+'</div>'+
    '<div class="pizza-summary" id="pzSummary"></div><div class="lipa-nav" style="padding:0 16px 8px;"><button class="lipa-next" onclick="pzNext(1)">Next: See Timeline &#x2192;</button></div></div>'+
    '<div class="lipa-panel" id="pzp2"><div style="padding:0 16px 6px;font-family:\'Bebas Neue\',sans-serif;font-size:18px;letter-spacing:.3px;">Payment Timeline</div><div class="delivery-day" style="margin:0 16px 12px;"><div class="dd-title">&#x1F355; Delivery Date</div><div class="dd-date">'+data.delivStr+'</div><div class="dd-sub">Pizza delivered on next BOGO day after all payments</div></div><div id="pzTimeline" style="padding:0 16px 12px;"></div><div class="lipa-nav" style="padding:0 16px 8px;"><button class="lipa-back" onclick="pzBack(2)">&#x2190; Back</button><button class="lipa-next" onclick="pzNext(2)">Next: Your Details &#x2192;</button></div></div>'+
    '<div class="lipa-panel" id="pzp3"><div style="padding:0 16px 6px;font-family:\'Bebas Neue\',sans-serif;font-size:18px;letter-spacing:.3px;">Your Details</div><div class="lipa-rule" style="margin:0 16px 12px;"><strong>&#x26A0;</strong> Pizza delivered ONLY on BOGO day after all payments received.</div><div style="padding:0 16px;"><div class="row2"><div class="field"><label>Full Name *</label><input type="text" id="pz_name" placeholder="Your name" autocomplete="name"></div><div class="field"><label>Phone *</label><input type="tel" id="pz_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div></div><div class="field"><label>Address *</label><input type="text" id="pz_addr" placeholder="e.g. Near Malaba Market"></div></div>'+
    '<div class="lipa-nav" style="padding:0 16px 4px;"><button class="lipa-back" onclick="pzBack(3)">&#x2190; Back</button><button class="lipa-next" id="pzSubmitBtn" onclick="submitPizzaLipa(\''+esc(itemId)+'\',\''+esc(restId)+'\')">&#x1F355; Confirm Pre-order</button></div></div>';
  openOverlay();prefillSaved('pz_name','pz_phone','pz_addr');
}
function selPlanFn(id,i){
  selPizzaPlan=pizzaPlans[i];
  document.querySelectorAll('.pizza-plan').forEach(function(p){p.classList.remove('sel');});
  var el=document.getElementById('ppl-'+id);if(el)el.classList.add('sel');
  var sum=document.getElementById('pzSummary');
  if(sum&&selPizzaPlan){sum.style.display='block';sum.innerHTML='<div class="psr"><span class="lbl">Plan</span><span class="val">'+selPizzaPlan.name+'</span></div><div class="psr"><span class="lbl">Per payment</span><span class="val hi">'+selPizzaPlan.perPayStr+'</span></div><div class="psr"><span class="lbl">Payments</span><span class="val">'+selPizzaPlan.payments.length+'</span></div><div class="psr"><span class="lbl">Delivery</span><span class="val" style="color:var(--green);">'+selPizzaPlan.delivStr+'</span></div>';}
}
function pzNext(step){if(step===1&&!selPizzaPlan){showToast('Choose a payment plan');return;}if(step===2)buildPzTimeline();setPzStep(step+1);}
function pzBack(step){setPzStep(step-1);}
function buildPzTimeline(){
  var el=document.getElementById('pzTimeline');if(!el||!selPizzaPlan)return;
  var html='<div style="display:flex;flex-direction:column;gap:0;">';
  selPizzaPlan.payments.forEach(function(p,i){html+='<div style="display:flex;align-items:flex-start;gap:10px;padding-bottom:14px;position:relative;">'+(i<selPizzaPlan.payments.length-1?'<div style="position:absolute;left:9px;top:21px;bottom:0;width:2px;background:rgba(255,255,255,.06);"></div>':'')+'<div style="width:20px;height:20px;border-radius:50%;background:rgba(232,82,26,.2);border:2px solid var(--amber);color:var(--amber);font-size:9px;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0;z-index:1;">'+(i+1)+'</div><div><div style="font-size:13px;font-weight:700;color:var(--text);">'+esc(p.day)+'</div><div style="font-size:11px;color:var(--muted);">Payment '+(i+1)+' of '+selPizzaPlan.payments.length+'</div><div style="font-size:12px;font-weight:700;color:var(--gold);">KSH '+Math.round(p.amt).toLocaleString('en-KE')+'</div></div></div>';});
  html+='<div style="display:flex;align-items:flex-start;gap:10px;"><div style="width:20px;height:20px;border-radius:50%;background:rgba(34,197,94,.2);border:2px solid var(--green);color:var(--green);font-size:11px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">&#x1F355;</div><div><div style="font-size:13px;font-weight:700;color:var(--text);">'+esc(selPizzaPlan.delivStr)+'</div><div style="font-size:11px;color:var(--muted);">&#x1F389; Pizza Delivery Day (BOGO &#x2014; 2 pizzas!)</div></div></div></div>';
  el.innerHTML=html;
}
function setPzStep(s){
  [1,2,3].forEach(function(n){
    var p=document.getElementById('pzp'+n);if(p)p.className='lipa-panel'+(n===s?' active':'');
    var dot=document.getElementById('pzsd'+n),lbl=document.getElementById('pzsl'+n),ln=document.getElementById('pzsl'+n+'l');if(!dot)return;
    if(n<s){dot.className='ls-dot done';dot.innerHTML='&#x2713;';lbl.className='ls-lbl done';if(ln)ln.className='ls-line done';}
    else if(n===s){dot.className='ls-dot active';dot.innerHTML=n;lbl.className='ls-lbl active';}
    else{dot.className='ls-dot';dot.innerHTML=n;lbl.className='ls-lbl';if(ln)ln.className='ls-line';}
  });pizzaStep=s;
}
function submitPizzaLipa(itemId,restId){
  if(!selPizzaPlan){showToast('Complete all steps');return;}
  var name=(document.getElementById('pz_name').value||'').trim(),phone=(document.getElementById('pz_phone').value||'').trim(),addr=(document.getElementById('pz_addr').value||'').trim();
  if(!name){showToast('Enter your full name');return;}if(!phone||phone.replace(/\D/g,'').length<9){showToast('Enter a valid phone number');return;}if(!addr){showToast('Enter your delivery address');return;}
  var btn=document.getElementById('pzSubmitBtn');if(btn){btn.disabled=true;btn.innerHTML='Sending&#x2026;';}
  saveMhUser(name,phone,addr);
  var rest=allRestaurants.find(function(r){return r.id==restId;})||currentRest;
  var item=rest?(rest.items||[]).find(function(i){return i.id===itemId;}):null;
  var waNum=normWA(rest?(rest.contact_phone||''):'');
  var planPays=selPizzaPlan.payments.map(function(p){return p.day+': KSH '+Math.round(p.amt).toLocaleString('en-KE');}).join('\n');
  postOrder({category:'food',listing_id:itemId||'',listing_title:'[PIZZA PRE-ORDER] '+(item?item.title:'Pizza'),listing_price:item?item.price||'0':'0',name:name,phone:phone,address:addr,payment_method:'mpesa',total_amount:String(selPizzaPlan.total||0),notes:'PIZZA LIPA MDOGO MDOGO | '+selPizzaPlan.name+' | Deliver: '+selPizzaPlan.delivStr+' | BOGO day only after full payment'},
  function(d){
    var ref=d&&d.order_ref?d.order_ref:'';
    var waMsg=encodeURIComponent('Pizza Pre-order: *'+(item?item.title:'Pizza')+'*\nPlan: '+selPizzaPlan.name+'\nPayments:\n'+planPays+'\nDelivery: '+selPizzaPlan.delivStr+' (BOGO!)\nRef: '+(ref||'?')+'\nName: '+name+'\nPhone: '+phone+'\nAddress: '+addr);
    document.getElementById('sheetContent').innerHTML='<div class="sh-grip"><div class="sh-handle"></div><button class="sh-x" onclick="closeOverlay()">&#x2715;</button></div><div class="success-wrap"><div class="success-anim">&#x1F355;</div><div class="suc-title">Pizza Pre-order Confirmed!</div><div class="suc-sub">'+selPizzaPlan.payments.length+'-payment plan set. Pizza on <strong style="color:var(--green);">'+selPizzaPlan.delivStr+'</strong></div>'+(ref?'<div class="suc-ref">Ref: '+esc(ref)+'</div>':'')+'<button class="wa-btn" id="pzWaBtn">&#x1F4AC; Confirm on WhatsApp</button><button class="done-btn" onclick="closeOverlay()">Continue</button></div>';
    var pwb=document.getElementById('pzWaBtn');if(pwb)pwb.onclick=function(){window.open('https://wa.me/'+waNum+'?text='+waMsg,'_blank');};
  },function(){if(btn){btn.disabled=false;btn.innerHTML='&#x1F355; Confirm Pre-order';}showToast('Network error. Try again.');});
}
/* === SEARCH + FILTER + COUNTDOWN + HELPERS === */
var srchTimer;
function initSearch(){
  var inp=document.getElementById('srchInput'),clr=document.getElementById('srchClear');
  inp.addEventListener('input',function(){var q=this.value.trim();clr.classList.toggle('show',q.length>0);clearTimeout(srchTimer);srchTimer=setTimeout(function(){searchQ=q.toLowerCase();applyFilter();},300);});
  inp.addEventListener('keydown',function(e){if(e.key==='Escape')clearSearch();});
}
function clearSearch(){document.getElementById('srchInput').value='';document.getElementById('srchClear').classList.remove('show');searchQ='';applyFilter();}
function filterCat(f){activeFilter=f;document.querySelectorAll('.cat').forEach(function(c){c.classList.toggle('on',c.dataset.f===f);});applyFilter();}
function initCats(){document.querySelectorAll('.cat').forEach(function(c){c.addEventListener('click',function(){document.querySelectorAll('.cat').forEach(function(x){x.classList.remove('on');});c.classList.add('on');activeFilter=c.dataset.f;applyFilter();});});}
function applyFilter(){
  filteredRests=allRestaurants.filter(function(r){
    var txt=((r.title||r.name||'')+(r.description||'')+(r.cuisine||'')+(r.location||'')).toLowerCase();
    var itemMatch=(r.items||[]).some(function(i){return((i.title||'')+(i.description||'')+(i.category||'')).toLowerCase().indexOf(searchQ||activeFilter||'')!==-1;});
    return(!searchQ||txt.indexOf(searchQ)!==-1||itemMatch)&&(!activeFilter||txt.indexOf(activeFilter)!==-1||itemMatch);
  });
  filteredRests=sortRests(filteredRests);
  var t=document.getElementById('restTitle');if(t)t.textContent=activeFilter?(activeFilter.charAt(0).toUpperCase()+activeFilter.slice(1)+' Restaurants'):'Restaurants';
  renderRestaurants(filteredRests);
}
function renderCountdown(){
  var el=document.getElementById('bogoCountdown');if(!el)return;
  var now=new Date();
  function dTo(wd){var d=now.getDay(),diff=wd-d;if(diff<=0)diff+=7;return diff;}
  var nW=new Date(now.getTime()+dTo(3)*86400000);nW.setHours(0,0,0,0);
  var nS=new Date(now.getTime()+dTo(6)*86400000);nS.setHours(0,0,0,0);
  var diff=Math.max(0,(nW<nS?nW:nS)-now);
  var d=Math.floor(diff/86400000),h=Math.floor((diff%86400000)/3600000),m=Math.floor((diff%3600000)/60000),s=Math.floor((diff%60000)/1000);
  el.innerHTML=u(d,'Days')+u(h,'Hrs')+u(m,'Min')+u(s,'Sec');
}
function u(n,l){return '<div class="bcu"><div class="bcu-n">'+pad(n)+'</div><div class="bcu-l">'+l+'</div></div>';}
function pad(n){return n<10?'0'+n:n;}
function getFallbackData(){
  return[
    {id:'f1',title:'Chicken Burger Combo',price:'KSH 450',image:'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80',contact_phone:'254700000001',location:'CBD',rating:'4.8',restaurant:'Malaba Bites',cuisine:'Burgers',badge:'Hot'},
    {id:'f2',title:'Beef Pilau',price:'KSH 300',image:'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80',contact_phone:'254700000002',location:'CBD',rating:'4.6',restaurant:'Mama Pima',cuisine:'Pilau'},
    {id:'f3',title:'Margherita Pizza',price:'KSH 650',image:'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=800&q=80',contact_phone:'254700000003',location:'CBD',rating:'4.9',restaurant:'Malaba Pizza House',cuisine:'Pizza',badge:'BOGO'},
    {id:'f4',title:'Pepperoni Pizza',price:'KSH 750',image:'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&q=80',contact_phone:'254700000003',location:'CBD',rating:'4.8',restaurant:'Malaba Pizza House',cuisine:'Pizza',badge:'BOGO'},
    {id:'f5',title:'Nyama Choma Platter',price:'KSH 800',image:'https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=800&q=80',contact_phone:'254700000004',location:'CBD',rating:'4.7',restaurant:'Nyama Joint',cuisine:'Nyama Choma'},
    {id:'f6',title:'Chips & Kachumbari',price:'KSH 180',image:'https://images.unsplash.com/photo-1585325701956-60dd9c8553bc?w=800&q=80',contact_phone:'254700000001',location:'CBD',rating:'4.3',restaurant:'Malaba Bites',cuisine:'Snacks',badge:'Offer',discount:20}
  ];
}
function fadeInImages(container){container.querySelectorAll('img').forEach(function(img){img.addEventListener('load',function(){img.classList.add('img-loaded');img.style.opacity='1';},{once:true});if(img.complete&&img.naturalWidth>0){img.classList.add('img-loaded');img.style.opacity='1';}});}
function openOverlay(){document.getElementById('overlay').classList.add('open');document.body.style.overflow='hidden';}
function closeOverlay(){document.getElementById('overlay').classList.remove('open');document.body.style.overflow='';}
function handleOvClick(e){if(e.target===e.currentTarget)closeOverlay();}
function postOrder(data,onOk,onErr){
  var x=new XMLHttpRequest();x.open('POST',API+'/order.php',true);
  x.setRequestHeader('Content-Type','application/json');x.setRequestHeader('X-Requested-With','XMLHttpRequest');
  x.timeout=12000;
  x.onload=function(){try{var d=JSON.parse(x.responseText);if(typeof onOk==='function')onOk(d);}catch(e){if(typeof onOk==='function')onOk({});}};
  x.onerror=x.ontimeout=function(){if(typeof onErr==='function')onErr();};
  x.send(JSON.stringify(data));
}
function saveMhUser(name,phone,addr){try{if(window.MhUser)MhUser.saveDetails({name:name,phone:phone,address:addr});else localStorage.setItem('mh_user_details',JSON.stringify({name:name,phone:phone,address:addr}));}catch(e){}}
function prefillSaved(nId,pId,aId){
  nId=nId||'ct_name';pId=pId||'ct_phone';aId=aId||'ct_addr';
  var d=null;try{if(window.MhUser)d=MhUser.getDetails();else d=JSON.parse(localStorage.getItem('mh_user_details')||'null');}catch(e){}
  if(!d)return;
  var m={};m[nId]='name';m[pId]='phone';if(aId)m[aId]='address';
  Object.keys(m).forEach(function(fid){var el=document.getElementById(fid);if(el&&d[m[fid]]&&!el.value)el.value=d[m[fid]];});
}
function normWA(p){var d=(p||'').replace(/\D/g,'');if(d.length===9)return'254'+d;if(d.length===10&&d[0]==='0')return'254'+d.substring(1);if(d.length===12&&d.substring(0,3)==='254')return d;return d||'254700000000';}
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function showToast(msg){var t=document.getElementById('toast');t.innerHTML=msg;t.classList.add('show');setTimeout(function(){t.classList.remove('show');},2400);}
</script>
</body>
</html>