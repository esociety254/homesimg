/* image-performance-helper.js
   Unified helpers to improve image performance:
   - fixed sizing / aspect ratio compatible markup
   - native lazy loading
   - optional CDN resizing (Cloudinary + Unsplash)
*/
(function () {
  'use strict';

  function safeStr(v) {
    if (v === null || v === undefined) return '';
    return String(v);
  }

  function isCloudinary(url) {
    return url && url.indexOf('cloudinary.com') !== -1;
  }

  function isUnsplash(url) {
    return url && url.indexOf('images.unsplash.com') !== -1;
  }

  // Cloudinary transform: /upload/<...>
  // We inject: /upload/w_<w>,h_<h>,c_fill,f_auto,q_auto/
  function transformCloudinary(url, w, h) {
    if (!url) return '';
    // If URL already contains /upload/ just inject after it.
    var needle = '/upload/';
    var idx = url.indexOf(needle);
    if (idx === -1) return url;

    var before = url.slice(0, idx + needle.length);
    var after = url.slice(idx + needle.length);
    // avoid double-inserting if it already has w_ and h_
    if (after.indexOf('w_') === 0 || after.indexOf('w_') !== -1) {
      return url;
    }
    return before + 'w_' + w + ',h_' + h + ',c_fill,f_auto,q_auto/' + after;
  }

  // Unsplash: add w + q, keep existing query params.
  function transformUnsplash(url, w, h) {
    if (!url) return '';
    // Unsplash supports w and q; it ignores h but good enough for bandwidth.
    // Keep base without hash.
    var base = url.split('?')[0];
    var q = 70;
    return base + '?w=' + w + '&q=' + q + '&auto=format';
  }

  function cdnTransform(url, w, h) {
    url = safeStr(url);
    if (!url) return '';
    if (isCloudinary(url)) return transformCloudinary(url, w, h);
    if (isUnsplash(url)) return transformUnsplash(url, w, h);
    return url;
  }

  // Build an <img> inside a reserved space container.
  // If container already has fixed height/aspect ratio, you can skip wrapper by wrapperStyle=null.
  function buildImgHTML(opts) {
    opts = opts || {};
    var src = safeStr(opts.src);
    var alt = safeStr(opts.alt);

    var w = opts.w || 480;
    var h = opts.h || 320;
    var className = safeStr(opts.className);

    var loading = opts.loading || 'lazy';
    var decoding = opts.decoding || 'async';
    var fetchpriority = opts.fetchpriority; // usually undefined

    var fit = opts.fit || 'cover';
    var style = opts.style ? safeStr(opts.style) : '';

    // CDN sizing
    var finalSrc = src;
    if (opts.cdn !== false) {
      finalSrc = cdnTransform(src, w, h);
    }

    // basic onerror fallback: keep layout stable
    var onerror = opts.onerror;
    if (!onerror) {
      // hide on error and keep background behind container
      onerror = "this.style.opacity='0.001';";
    }

    var fp = fetchpriority ? (' fetchpriority="' + safeStr(fetchpriority) + '"') : '';

    // wrapper: optional
    var wrapperStyle = opts.wrapperStyle; // string or null
    if (wrapperStyle) {
      // wrapperStyle may contain aspect-ratio or height.
      return (
        '<div style="' + safeStr(wrapperStyle) + '">' +
          '<img' +
            ' src="' + finalSrc.replace(/"/g, '"') + '"' +
            ' alt="' + alt.replace(/"/g, '"') + '"' +
            ' class="' + className.replace(/"/g, '"') + '"' +
            ' loading="' + safeStr(loading) + '"' +
            ' decoding="' + safeStr(decoding) + '"' +
            fp +
            ' onerror="' + safeStr(onerror).replace(/"/g, '"') + '"' +
            ' style="width:100%;height:100%;object-fit:' + safeStr(fit) + ';' + safeStr(style) + ';"' +
          '/>' +
        '</div>'
      );
    }

    // no wrapper: rely on parent CSS (recommended)
    return (
      '<img' +
        ' src="' + finalSrc.replace(/"/g, '"') + '"' +
        ' alt="' + alt.replace(/"/g, '"') + '"' +
        ' class="' + className.replace(/"/g, '"') + '"' +
        ' loading="' + safeStr(loading) + '"' +
        ' decoding="' + safeStr(decoding) + '"' +
        fp +
        ' onerror="' + safeStr(onerror).replace(/"/g, '"') + '"' +
        ' style="object-fit:' + safeStr(fit) + ';' + safeStr(style) + ';"' +
      '/>'
    );
  }

  // Reserved space helper using aspect ratio.
  function aspectWrapperStyle(ratioW, ratioH) {
    // aspect-ratio: W / H
    return 'aspect-ratio:' + ratioW + '/' + ratioH + ';width:100%;overflow:hidden;position:relative;background:rgba(255,255,255,.03);';
  }

  // Export globals
  window.MhImgPerf = {
    cdnTransform: cdnTransform,
    buildImgHTML: buildImgHTML,
    aspectWrapperStyle: aspectWrapperStyle
  };
})();

