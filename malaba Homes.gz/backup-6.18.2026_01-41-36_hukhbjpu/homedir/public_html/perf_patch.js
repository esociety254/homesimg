/**
 * perf_patch.js — Drop-in performance patch for all listing pages
 * Include AFTER img_perf.js on food, shop and homes pages
 *
 * <script src="img_perf.js"></script>
 * <script src="perf_patch.js"></script>
 *
 * What this does:
 * 1. Intercepts all <img> tags after DOM loads and applies lazy loading
 * 2. Wraps bare images in aspect-ratio boxes to prevent layout shift
 * 3. Applies CDN optimisation to every image src automatically
 * 4. Throttles card animation so only 8 animate at a time
 * 5. Adds network-aware quality (saves data on slow connections)
 */
(function() {
  'use strict';

  /* ── Detect connection quality ──────────────────────────── */
  var isSlowConnection = false;
  try {
    var conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    if (conn) {
      var slow = ['slow-2g','2g','3g'];
      isSlowConnection = slow.indexOf(conn.effectiveType) !== -1;
    }
  } catch(e){}
  var IMG_QUALITY = isSlowConnection ? 55 : 75;

  /* ── Fix every img tag on the page ─────────────────────── */
  function patchAllImages() {
    var imgs = document.querySelectorAll('img[src]:not([data-patched])');
    imgs.forEach(function(img) {
      img.setAttribute('data-patched', '1');

      // 1. Ensure lazy loading
      if (!img.getAttribute('loading')) {
        img.setAttribute('loading', 'lazy');
      }
      if (!img.getAttribute('decoding')) {
        img.setAttribute('decoding', 'async');
      }

      // 2. Optimise src via CDN helper
      var src = img.src || img.getAttribute('src') || '';
      if (src && window.MhImgPerf) {
        var w = img.naturalWidth || parseInt(img.getAttribute('width')) || 600;
        var h = img.naturalHeight || parseInt(img.getAttribute('height')) || 450;
        // Only apply if the size would change
        if (src.indexOf('cloudinary.com') !== -1 || src.indexOf('unsplash.com') !== -1) {
          var optimised = MhImgPerf.cdnImg(src, w, h, IMG_QUALITY);
          if (optimised !== src) img.src = optimised;
        }
      }

      // 3. Blur-up placeholder while loading
      if (!img.complete) {
        img.style.opacity = '0';
        img.style.transition = 'opacity .5s ease';
        img.onload = function() {
          img.style.opacity = '1';
        };
        img.onerror = function() {
          img.style.opacity = '1';
          // Fallback image
          img.src = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=400&q=60';
        };
      }
    });
  }

  /* ── Prevent layout shift on dynamically added cards ─────── */
  function fixAspectRatios() {
    // Card image containers — add aspect-ratio if missing
    var selectors = [
      '.fcard-img',      // food cards
      '.pcard-img',      // shop cards
      '.hcard-carousel', // home carousels
      '.cat-card-bg',    // category cards on index
    ];
    selectors.forEach(function(sel) {
      document.querySelectorAll(sel + ':not([data-ar-fixed])').forEach(function(el) {
        el.setAttribute('data-ar-fixed', '1');
        // Only add aspect-ratio if not already set
        var cs = window.getComputedStyle(el);
        if (!el.style.aspectRatio && cs.height === 'auto') {
          el.style.overflow  = 'hidden';
          el.style.position  = 'relative';
        }
      });
    });
  }

  /* ── Throttle card fade-in animations ────────────────────── */
  function throttleAnimations() {
    var animated = document.querySelectorAll('.fcard,.pcard,.hcard,.cat-card');
    var inView   = 0;
    animated.forEach(function(card) {
      if (!card.getAttribute('data-anim')) {
        card.setAttribute('data-anim','1');
        // Remove animation from cards more than 8 positions down
        // so browser doesn't animate 40 cards at once
        inView++;
        if (inView > 8) {
          card.style.animation = 'none';
          card.style.opacity   = '1';
          card.style.transform = 'none';
        }
      }
    });
  }

  /* ── MutationObserver: patch images as they're added ─────── */
  if ('MutationObserver' in window) {
    var mo = new MutationObserver(function(mutations) {
      var needsPatch = false;
      mutations.forEach(function(m) {
        if (m.addedNodes.length) needsPatch = true;
      });
      if (needsPatch) {
        requestAnimationFrame(function() {
          patchAllImages();
          fixAspectRatios();
          throttleAnimations();
        });
      }
    });
    mo.observe(document.body, { childList: true, subtree: true });
  }

  /* ── Run on initial load ─────────────────────────────────── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      patchAllImages();
      fixAspectRatios();
      throttleAnimations();
    });
  } else {
    patchAllImages();
    fixAspectRatios();
    throttleAnimations();
  }

  /* ── Expose for manual calls after AJAX renders ─────────── */
  window.MhPerfPatch = {
    run: function() {
      patchAllImages();
      fixAspectRatios();
      throttleAnimations();
    }
  };

})();
