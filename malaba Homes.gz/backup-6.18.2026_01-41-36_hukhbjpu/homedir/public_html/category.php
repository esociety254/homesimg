<?php
/* ═══════════════════════════════════════════════════════════
   category.php — Malaba Homes Shop: Subcategory Browse Page
   URL: category.php?sub=kitchen&sort=smart&q=
   ═══════════════════════════════════════════════════════════ */
$apiBase  = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/api';
$rawSub   = isset($_GET['sub'])  ? trim($_GET['sub'])  : '';
$rawSort  = isset($_GET['sort']) ? trim($_GET['sort'])  : 'smart';
$rawQ     = isset($_GET['q'])    ? trim($_GET['q'])     : '';
$sub  = htmlspecialchars($rawSub,  ENT_QUOTES);
$sort = htmlspecialchars($rawSort, ENT_QUOTES);
$q    = htmlspecialchars($rawQ,    ENT_QUOTES);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1">
<meta name="theme-color" content="#080400">
<meta name="apple-mobile-web-app-capable" content="yes">
<title id="pageTitle">Shop — Malaba Homes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<?php if(file_exists('pwa_head.php')) include 'pwa_head.php'; ?>
<?php if(file_exists('perf_styles.css')) { ?><link rel="stylesheet" href="perf_styles.css"><?php } ?>

<style>
/* ── TOKENS ── */
:root{
  --ink:#080400;--ink2:#100a00;--surface:#161210;--card:#1c1812;
  --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);
  --text:#F5F0EB;--muted:#8a8078;--dim:#5a534c;
  --amber:#E8521A;--amber2:#FF7043;--gold:#F5A623;
  --green:#22C55E;--blue:#4895EF;
  --sb:env(safe-area-inset-bottom,0px);--st:env(safe-area-inset-top,0px);
  --r:12px;--rl:18px;--nav:56px;--bnav:62px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
html{overflow-x:hidden;}
body{
  font-family:'Outfit',sans-serif;background:var(--ink);color:var(--text);
  min-height:100dvh;overflow-x:hidden;-webkit-font-smoothing:antialiased;
  padding-bottom:calc(var(--bnav) + var(--sb) + 80px);
}
a{color:inherit;text-decoration:none;}
button{cursor:pointer;font-family:inherit;border:none;background:none;}
img{display:block;max-width:100%;}
::-webkit-scrollbar{width:3px;height:3px;}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px;}

/* ── FIXED HEADER ── */
.hdr{
  position:fixed;top:0;left:0;right:0;z-index:200;
  background:rgba(8,4,0,.97);
  backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);
  border-bottom:1px solid var(--border);
  padding:var(--st) 0 0;
  box-shadow:0 2px 20px rgba(0,0,0,.45);
}
.hdr-row{
  height:var(--nav);display:flex;align-items:center;gap:10px;padding:0 14px;
}
.back-btn{
  width:36px;height:36px;border-radius:50%;
  background:var(--surface);border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;flex-shrink:0;
  transition:transform .15s;
}
.back-btn:active{transform:scale(.9);}
.back-btn svg{width:17px;height:17px;color:var(--text);}
.hdr-title{
  flex:1;font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:1.5px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}
.hdr-title span{color:var(--amber2);}
.hdr-acts{display:flex;gap:7px;flex-shrink:0;}
.ico-btn{
  width:36px;height:36px;border-radius:50%;
  background:var(--surface);border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;
  font-size:15px;position:relative;transition:transform .15s;
}
.ico-btn:active{transform:scale(.9);}
.hbadge{
  position:absolute;top:-3px;right:-3px;width:17px;height:17px;border-radius:50%;
  background:var(--amber);color:#fff;font-size:9px;font-weight:800;
  display:none;align-items:center;justify-content:center;border:2px solid var(--ink);
}
.hbadge.on{display:flex;}

/* ── SEARCH ROW ── */
.srch-row{padding:0 14px 10px;}
.srch-box{
  display:flex;align-items:center;gap:9px;
  background:var(--surface);border:1.5px solid var(--border2);
  border-radius:30px;padding:0 15px;height:42px;
  transition:border-color .2s,box-shadow .2s;
}
.srch-box:focus-within{border-color:var(--amber);box-shadow:0 0 0 3px rgba(232,82,26,.12);}
.srch-box svg{color:var(--muted);flex-shrink:0;width:14px;height:14px;}
.srch-box input{
  flex:1;padding:0;height:100%;background:transparent;
  border:none;outline:none;font-family:inherit;font-size:14px;color:var(--text);
}
.srch-box input::placeholder{color:var(--muted);}
.srch-clear{
  width:20px;height:20px;border-radius:50%;
  background:rgba(255,255,255,.12);color:rgba(255,255,255,.6);
  font-size:11px;display:none;align-items:center;justify-content:center;
  flex-shrink:0;cursor:pointer;transition:background .15s;
}
.srch-clear.show{display:flex;}
.srch-clear:active{background:rgba(255,255,255,.25);}

/* ── SUBCATEGORY CHIPS STRIP ── */
.sub-strip-wrap{
  overflow:hidden;
  /* The strip collapses into a single scrollable row */
}
.sub-strip{
  display:flex;gap:7px;
  padding:0 14px 10px;
  overflow-x:auto;scrollbar-width:none;
  -webkit-overflow-scrolling:touch;
}
.sub-strip::-webkit-scrollbar{display:none;}
.sub-chip{
  display:inline-flex;align-items:center;gap:5px;
  padding:7px 14px;border-radius:30px;
  border:1.5px solid var(--border2);background:var(--surface);
  font-size:12px;font-weight:600;color:var(--muted);
  white-space:nowrap;flex-shrink:0;
  transition:all .2s;cursor:pointer;
}
.sub-chip.on{
  background:var(--amber);border-color:var(--amber);
  color:#fff;font-weight:700;
}
.sub-chip:active{transform:scale(.95);}
.sub-chip-icon{font-size:14px;}

/* ── SORT + COUNT BAR ── */
.toolbar{
  display:flex;align-items:center;justify-content:space-between;
  padding:4px 14px 8px;
}
.res-count{font-size:12px;color:var(--muted);}
.sort-btn{
  display:flex;align-items:center;gap:5px;
  padding:6px 12px;border-radius:20px;
  background:var(--surface);border:1px solid var(--border2);
  font-size:12px;font-weight:600;color:var(--muted);
  transition:all .2s;
}
.sort-btn:active{border-color:var(--amber);color:var(--amber);}

/* ── GRID ── */
.shop-grid{
  display:grid;
  grid-template-columns:repeat(2,1fr);
  gap:10px;padding:0 10px;
}
@media(min-width:480px){.shop-grid{gap:12px;padding:0 14px;}}
@media(min-width:640px){.shop-grid{grid-template-columns:repeat(3,1fr);}}
@media(min-width:900px){.shop-grid{grid-template-columns:repeat(4,1fr);padding:0 20px;}}

/* ── PRODUCT CARD ── */
.pcard{
  background:var(--card);border-radius:var(--rl);
  border:1px solid var(--border);overflow:hidden;
  display:flex;flex-direction:column;cursor:pointer;
  transition:transform .2s,box-shadow .2s,border-color .2s;
  position:relative;contain:layout style;
}
@media(hover:hover){.pcard:hover{transform:translateY(-3px);box-shadow:0 12px 30px rgba(0,0,0,.5);border-color:var(--border2);}}
.pcard:active{transform:scale(.97);}
.pcard-img{
  position:relative;width:100%;aspect-ratio:1/1;overflow:hidden;
  background:linear-gradient(135deg,var(--surface),var(--card));
  border-radius:var(--rl) var(--rl) 0 0;
}
@supports not (aspect-ratio:1/1){
  .pcard-img::before{content:'';display:block;padding-top:100%;}
  .pcard-img img{position:absolute;}
}
.pcard-img img{
  position:absolute;inset:0;width:100%;height:100%;object-fit:cover;
  opacity:1;transition:none;
}
.pcard-img img.await-load{opacity:0;transition:opacity .35s ease;}
.pcard-img img.img-loaded{opacity:1;}
@media(hover:hover){
  .pcard:hover .pcard-img img{transform:scale(1.05);transition:opacity .35s ease,transform .55s cubic-bezier(.25,.46,.45,.94);}
}
.pbadge{
  position:absolute;top:7px;left:7px;z-index:2;
  background:rgba(8,4,0,.82);backdrop-filter:blur(6px);
  color:var(--text);font-size:9px;font-weight:700;
  padding:3px 8px;border-radius:12px;white-space:nowrap;
}
.plipa-badge{
  position:absolute;bottom:7px;left:7px;z-index:2;
  background:linear-gradient(135deg,rgba(245,166,35,.92),rgba(232,82,26,.92));
  color:#fff;font-size:8px;font-weight:800;
  padding:3px 7px;border-radius:10px;white-space:nowrap;
}
.wish{
  position:absolute;top:6px;right:6px;z-index:2;
  width:28px;height:28px;border-radius:50%;
  background:rgba(8,4,0,.7);backdrop-filter:blur(6px);
  display:flex;align-items:center;justify-content:center;font-size:13px;
  transition:all .2s;
}
.wish:active{transform:scale(.85);}
.wish.liked{background:rgba(232,82,26,.25);}
.pcard-body{padding:9px 9px 2px;flex:1;}
.ptitle{
  font-weight:700;font-size:12px;color:var(--text);line-height:1.3;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;
  overflow:hidden;margin-bottom:3px;
}
.pprice{font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;color:var(--amber2);padding:4px 9px 2px;}
.pcard-foot{display:flex;gap:6px;padding:6px 8px 9px;}
.btn-cart{
  flex:1;padding:9px 6px;border-radius:var(--r);
  background:rgba(255,255,255,.07);border:1px solid var(--border2);
  color:var(--text);font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:.3px;
  transition:all .18s;display:flex;align-items:center;justify-content:center;gap:3px;
}
.btn-cart:active{transform:scale(.95);}
.btn-cart.added{background:rgba(34,197,94,.15);border-color:var(--green);color:var(--green);}
.btn-buy{
  flex:1;padding:9px 6px;border-radius:var(--r);
  background:var(--amber);color:#fff;
  font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:.3px;
  transition:all .18s;display:flex;align-items:center;justify-content:center;gap:3px;
}
.btn-buy:active{transform:scale(.95);background:var(--amber2);}

/* ── SKELETON ── */
.skel{background:rgba(255,255,255,.06);position:relative;overflow:hidden;}
.skel::after{
  content:'';position:absolute;inset:0;transform:translateX(-100%);
  background:linear-gradient(90deg,transparent,rgba(255,255,255,.1),transparent);
  animation:skelSh 1.15s ease-in-out infinite;
}
@keyframes skelSh{to{transform:translateX(100%);}}
.skel-card{background:var(--card);border-radius:var(--rl);border:1px solid var(--border);overflow:hidden;}
.skel-sq{padding-top:100%;} /* 1:1 */

/* ── LOAD MORE / SPINNER ── */
.load-wrap{display:flex;justify-content:center;padding:24px 14px 12px;}
.spin{
  width:24px;height:24px;border-radius:50%;
  border:2px solid var(--border2);border-top-color:var(--amber);
  animation:spin .65s linear infinite;
}
@keyframes spin{to{transform:rotate(360deg);}}
.load-end{font-size:13px;color:var(--dim);text-align:center;padding:20px 0 8px;}

/* ── EMPTY STATE ── */
.empty-state{
  grid-column:1/-1;text-align:center;padding:48px 20px;
}
.empty-state .ei{font-size:48px;margin-bottom:14px;}
.empty-state h3{font-family:'Bebas Neue',sans-serif;font-size:24px;margin-bottom:6px;}
.empty-state p{font-size:13px;color:var(--muted);margin-bottom:18px;}
.empty-state button{
  padding:11px 22px;border-radius:var(--rl);
  background:var(--amber);color:#fff;
  font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:.3px;
}

/* ── BOTTOM NAV ── */
.bnav{
  position:fixed;bottom:0;left:0;right:0;z-index:200;
  height:calc(var(--bnav) + var(--sb));padding-bottom:var(--sb);
  background:rgba(8,4,0,.95);backdrop-filter:blur(28px);
  border-top:1px solid rgba(255,255,255,.07);
  display:flex;align-items:stretch;
}
.bni{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:0 4px;transition:all .2s;position:relative;}
.bni-ico{font-size:20px;color:rgba(255,255,255,.38);transition:all .22s;line-height:1.15;}
.bni-lbl{font-size:9px;font-weight:700;color:rgba(255,255,255,.3);letter-spacing:.5px;text-transform:uppercase;transition:all .22s;}
.bni.active .bni-ico,.bni.active .bni-lbl{color:var(--amber);}
.bni.active::before{content:'';position:absolute;bottom:2px;width:20px;height:2px;border-radius:1px;background:var(--amber);}
.bni-center{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;cursor:pointer;position:relative;text-decoration:none;}
.bni-center-btn{width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#6366f1);display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:0 -2px 16px rgba(124,58,237,.5);margin-top:-16px;border:3px solid rgba(8,4,0,.95);transition:all .22s;}
.bni-center-lbl{font-size:9px;font-weight:700;color:rgba(139,92,246,.75);letter-spacing:.5px;text-transform:uppercase;}

/* ── CHECKOUT BAR ── */
.checkout-bar{
  position:fixed;bottom:calc(var(--bnav) + var(--sb) + 8px);
  left:14px;right:14px;z-index:190;
  display:flex;align-items:center;gap:10px;
  background:linear-gradient(135deg,#1a0e00,#2a1500);
  border:1px solid rgba(232,82,26,.35);border-radius:20px;
  padding:10px 14px 10px 16px;
  box-shadow:0 8px 32px rgba(0,0,0,.6),0 0 0 1px rgba(232,82,26,.12);
  transform:translateY(calc(100% + 24px));opacity:0;
  transition:transform .38s cubic-bezier(.32,1,.68,1),opacity .28s;
  pointer-events:none;
}
.checkout-bar.show{transform:translateY(0);opacity:1;pointer-events:all;}
.chk-info{flex:1;min-width:0;}
.chk-items{font-size:11px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:1px;}
.chk-total{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:.3px;color:var(--amber2);line-height:1;}
.chk-btn{
  display:flex;align-items:center;gap:7px;padding:11px 20px;border-radius:14px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.5px;
  box-shadow:0 4px 16px rgba(232,82,26,.4);transition:transform .18s;white-space:nowrap;flex-shrink:0;
}
.chk-btn:active{transform:scale(.97);}
.chk-count{
  width:22px;height:22px;border-radius:50%;background:rgba(255,255,255,.2);
  font-size:11px;font-weight:800;display:flex;align-items:center;justify-content:center;
}

/* ── OVERLAY / SHEET (for checkout + sort) ── */
.overlay{
  position:fixed;inset:0;z-index:500;
  background:rgba(0,0,0,.82);backdrop-filter:blur(6px);
  opacity:0;pointer-events:none;transition:opacity .25s;
  display:flex;align-items:flex-end;
}
.overlay.open{opacity:1;pointer-events:all;}
.sheet{
  width:100%;background:var(--ink2);border-radius:24px 24px 0 0;
  border:1px solid rgba(255,255,255,.08);
  transform:translateY(100%);
  transition:transform .38s cubic-bezier(.32,1,.68,1);
  max-height:94dvh;overflow-y:auto;
  padding-bottom:calc(20px + var(--sb));
}
.overlay.open .sheet{transform:translateY(0);}
.sh-top{display:flex;align-items:center;justify-content:space-between;padding:13px 16px 0;}
.sh-handle{width:38px;height:4px;border-radius:2px;background:rgba(255,255,255,.1);}
.sh-close{
  width:28px;height:28px;border-radius:50%;
  background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
  display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.5);font-size:14px;
}
/* Shared form */
.field{margin-bottom:11px;}
.field label{display:block;font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:5px;}
.field input{
  width:100%;padding:11px 13px;border-radius:var(--r);
  background:rgba(255,255,255,.05);border:1.5px solid var(--border2);
  color:var(--text);font-family:inherit;font-size:14px;outline:none;transition:border-color .2s;
}
.field input:focus{border-color:var(--amber);}
.field input::placeholder{color:rgba(255,255,255,.22);}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.pay-opts{display:flex;flex-direction:column;gap:7px;margin-bottom:12px;}
.po{display:flex;align-items:center;gap:11px;padding:11px 12px;border-radius:var(--r);border:2px solid var(--border2);cursor:pointer;transition:all .18s;}
.po.sel{border-color:var(--amber);background:rgba(232,82,26,.07);}
.po-ico{font-size:18px;}
.po-txt strong{display:block;font-size:13px;font-weight:600;}
.po-txt span{font-size:11px;color:var(--muted);}
.po-dot{width:17px;height:17px;border-radius:50%;border:2px solid var(--dim);margin-left:auto;flex-shrink:0;display:flex;align-items:center;justify-content:center;}
.po.sel .po-dot{border-color:var(--amber);background:var(--amber);}
.po.sel .po-dot::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}
.sbtn{
  width:100%;padding:14px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;border-radius:var(--rl);
  font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.5px;
  display:flex;align-items:center;justify-content:center;gap:7px;
  box-shadow:0 4px 18px rgba(232,82,26,.35);transition:all .2s;
}
/* Sort option */
.sort-opt{padding:14px 18px;font-size:15px;color:var(--text);cursor:pointer;transition:background .13s;border-radius:var(--r);}
.sort-opt:active,.sort-opt:hover{background:rgba(255,255,255,.04);}
.sort-opt.sel{color:var(--amber);}
/* Progressive checkout steps */
.co-steps{display:flex;align-items:center;padding:14px 16px 0;margin-bottom:4px;}
.co-step{display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;}
.co-step:last-child{flex:0;flex-shrink:0;}
.co-dot{width:28px;height:28px;border-radius:50%;border:2px solid var(--border2);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;color:var(--muted);transition:all .3s;}
.co-dot.done{background:var(--green);border-color:var(--green);color:#000;}
.co-dot.active{background:var(--amber);border-color:var(--amber);color:#fff;box-shadow:0 0 0 4px rgba(232,82,26,.18);}
.co-lbl{font-size:9px;font-weight:700;color:var(--muted);letter-spacing:.3px;text-align:center;}
.co-lbl.active{color:var(--amber);}
.co-lbl.done{color:var(--green);}
.co-line{flex:1;height:2px;background:var(--border2);margin:0 4px;margin-bottom:14px;transition:background .3s;}
.co-line.done{background:var(--green);}
.co-panel{display:none;padding:0 16px;}
.co-panel.active{display:block;animation:coIn .22s ease;}
@keyframes coIn{from{opacity:0;transform:translateX(14px)}to{opacity:1;transform:translateX(0)}}
.co-item{display:flex;align-items:center;gap:10px;background:rgba(255,255,255,.03);border-radius:var(--r);padding:10px 11px;border:1px solid var(--border);margin-bottom:7px;}
.co-item-img{width:46px;height:46px;border-radius:10px;object-fit:cover;flex-shrink:0;background:var(--surface);}
.co-item-info{flex:1;min-width:0;}
.co-item-title{font-size:13px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:2px;}
.co-item-shop{font-size:10px;color:var(--muted);}
.co-item-qty{display:flex;align-items:center;gap:6px;margin-top:5px;}
.qty-btn{width:24px;height:24px;border-radius:50%;background:var(--surface);border:1px solid var(--border2);color:var(--text);font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:center;transition:border-color .15s;}
.qty-btn:active{border-color:var(--amber);}
.qty-val{font-family:'Bebas Neue',sans-serif;font-size:15px;min-width:16px;text-align:center;}
.co-item-price{font-family:'Bebas Neue',sans-serif;font-size:14px;color:var(--amber2);flex-shrink:0;}
.co-item-del{color:var(--dim);font-size:15px;padding:3px 4px;flex-shrink:0;}
.co-item-del:active{color:#ef4444;}
.co-summary{background:rgba(255,255,255,.03);border-radius:var(--r);padding:11px 13px;border:1px solid var(--border);margin-bottom:14px;}
.co-sum-row{display:flex;justify-content:space-between;font-size:13px;color:var(--muted);padding:3px 0;}
.co-sum-row.tot{font-size:15px;font-weight:700;color:var(--text);padding-top:9px;border-top:1px solid var(--border);margin-top:5px;}
.co-sum-row .free{color:var(--green);font-weight:700;}
.co-nav{display:flex;gap:8px;padding:12px 0 4px;}
.co-back{padding:12px 18px;background:rgba(255,255,255,.06);border:1px solid var(--border2);border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;color:var(--muted);transition:all .18s;}
.co-next{flex:1;padding:13px;background:linear-gradient(135deg,var(--amber),var(--amber2));color:#fff;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.4px;box-shadow:0 4px 16px rgba(232,82,26,.35);transition:all .18s;}
.co-next:active{transform:scale(.98);}
.co-next:disabled{opacity:.6;transform:none;}
.suc-wrap{text-align:center;padding:24px 16px 10px;}
.suc-ico{font-size:52px;margin-bottom:12px;}
.suc-title{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:.5px;margin-bottom:6px;}
.suc-sub{font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:12px;}
.suc-ref{font-size:12px;color:var(--amber);font-weight:700;margin-bottom:16px;}
.wa-btn{width:100%;padding:13px;background:#25D366;color:#fff;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;display:flex;align-items:center;justify-content:center;gap:7px;transition:all .2s;margin-bottom:8px;}
.done-btn{width:100%;padding:12px;background:rgba(255,255,255,.05);color:var(--muted);border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;border:1px solid var(--border2);}
/* Toast */
.toast{
  position:fixed;bottom:calc(var(--bnav) + var(--sb) + 14px);left:50%;
  transform:translateX(-50%) translateY(8px);
  background:var(--text);color:var(--ink);
  padding:10px 20px;border-radius:30px;font-size:13px;font-weight:600;
  z-index:999;opacity:0;pointer-events:none;transition:all .22s;white-space:nowrap;
}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
/* page wrap */
#pageWrap{padding-top:168px;}
</style>
</head>
<body>

<!-- FIXED HEADER -->
<header class="hdr" id="mainHdr">
  <div class="hdr-row">
    <a href="shop_listing.php" class="back-btn">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
        <path d="M19 12H5M5 12l7-7M5 12l7 7"/>
      </svg>
    </a>
    <div class="hdr-title" id="hdrTitle">Malaba <span>Shop</span></div>
    <div class="hdr-acts">
      <button class="ico-btn" onclick="openSortSheet()" title="Sort">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="16" y2="12"/>
          <line x1="11" y1="18" x2="13" y2="18"/>
        </svg>
      </button>
      <button class="ico-btn" onclick="openCheckout()" title="Cart">
        &#x1F6D2;<span class="hbadge" id="hBadge">0</span>
      </button>
    </div>
  </div>
  <!-- Always-visible search -->
  <div class="srch-row">
    <div class="srch-box">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
        <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
      </svg>
      <input type="search" id="srchInput" placeholder="Search in this category..."
             autocomplete="off" enterkeyhint="search">
      <span class="srch-clear" id="srchClear" onclick="clearSearch()">&#x2715;</span>
    </div>
  </div>
  <!-- Subcategory chips -->
  <div class="sub-strip-wrap">
    <div class="sub-strip" id="subStrip">
      <!-- Populated by JS from loaded data -->
      <div class="sub-chip on" data-sub="">&#x2728; All Items</div>
    </div>
  </div>
</header>

<div id="pageWrap">
  <!-- Toolbar -->
  <div class="toolbar">
    <div class="res-count" id="resCount"></div>
    <button class="sort-btn" onclick="openSortSheet()">
      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="15" y2="12"/>
        <line x1="3" y1="18" x2="9" y2="18"/>
      </svg>
      <span id="sortLbl">Smart</span>
    </button>
  </div>

  <!-- Grid -->
  <div class="shop-grid" id="shopGrid">
    <!-- Skeletons while loading -->
    <div class="skel-card"><div class="skel-sq skel"></div></div>
    <div class="skel-card"><div class="skel-sq skel"></div></div>
    <div class="skel-card"><div class="skel-sq skel"></div></div>
    <div class="skel-card"><div class="skel-sq skel"></div></div>
  </div>

  <!-- Infinite scroll sentinel -->
  <div class="load-wrap" id="loadWrap">
    <div class="spin" id="loadSpin" style="display:none;"></div>
    <div class="load-end" id="loadEnd" style="display:none;">&#x1F389; You've seen everything!</div>
  </div>
</div><!-- /pageWrap -->

<!-- Checkout float bar -->
<div class="checkout-bar" id="checkoutBar">
  <div class="chk-info">
    <div class="chk-items" id="chkItems">0 items</div>
    <div class="chk-total" id="chkTotal">KSH 0</div>
  </div>
  <button class="chk-btn" onclick="openCheckout()">
    Checkout <div class="chk-count" id="chkCount">0</div>
  </button>
</div>

<!-- Bottom Nav -->
<nav class="bnav">
  <a href="index.php" class="bni"><div class="bni-ico">&#x1F3E1;</div><div class="bni-lbl">Home</div></a>
  <a href="shop_listing.php" class="bni active"><div class="bni-ico">&#x1F6D2;</div><div class="bni-lbl">Shop</div></a>
  <a href="video_feed.php" class="bni-center"><div class="bni-center-btn">&#x25B6;</div><div class="bni-center-lbl">Watch</div></a>
  <a href="food_listing.php" class="bni"><div class="bni-ico">&#x1F354;</div><div class="bni-lbl">Food</div></a>
  <a href="homes_listing.php" class="bni"><div class="bni-ico">&#127976;</div><div class="bni-lbl">Rentals</div></a>
</nav>

<!-- Overlay / sheet -->
<div class="overlay" id="overlay" onclick="handleOvClick(event)">
  <div class="sheet" id="activeSheet">
    <div id="sheetContent"></div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script src="data.js"></script>
<script>
/* ══════════════════════════════════════════════════════
   CONFIG — read from URL params
══════════════════════════════════════════════════════ */
var INIT_SUB  = '<?php echo $sub; ?>';
var INIT_SORT = '<?php echo $sort; ?>';
var INIT_Q    = '<?php echo $q; ?>';
var API_BASE  = (function(){
  var scripts = document.querySelectorAll('script[src]');
  for (var i=0; i<scripts.length; i++){
    if(scripts[i].src && scripts[i].src.indexOf('data.js')!==-1)
      return scripts[i].src.replace(/\/data\.js[^\/]*$/,'/api');
  }
  return '<?php echo htmlspecialchars($apiBase, ENT_QUOTES); ?>';
})();

/* ══════════════════════════════════════════════════════
   STATE
══════════════════════════════════════════════════════ */
var ST = {
  items:[], page:1, limit:24, total:0,
  loading:false, done:false,
  sub: INIT_SUB, sort: INIT_SORT, search: INIT_Q
};
var allSubcategories = []; /* discovered from loaded data */
var cart     = [];
var wishlist = [];
var currentItem  = null;
var coStep       = 1;
var coPayMode    = 'cash';
var lipaFreq     = null;
var lipaDur      = null;
var lipaPayMode  = 'mpesa';
var lipaFreqOpts = [];
var lipaDurOpts  = [];

try { cart     = JSON.parse(localStorage.getItem('mh_shop_cart')||'[]'); } catch(e){}
try { wishlist = JSON.parse(localStorage.getItem('mh_shop_wish')||'[]'); } catch(e){}

/* ══════════════════════════════════════════════════════
   SUBCATEGORY META — icons + labels
══════════════════════════════════════════════════════ */
var subMeta = {
  kitchen:    {icon:'🍳', label:'Kitchen'},
  decor:      {icon:'🖼', label:'Décor'},
  appliances: {icon:'⚡', label:'Appliances'},
  storage:    {icon:'🧺', label:'Storage'},
  furniture:  {icon:'🛋', label:'Furniture'},
  cleaning:   {icon:'🧹', label:'Cleaning'},
  lighting:   {icon:'💡', label:'Lighting'},
  bedding:    {icon:'🛏', label:'Bedding'},
  bathroom:   {icon:'🚿', label:'Bathroom'},
  garden:     {icon:'🌱', label:'Garden'},
  electronics:{icon:'💻', label:'Electronics'},
  toys:       {icon:'🧸', label:'Toys'},
  fashion:    {icon:'👗', label:'Fashion'},
  beauty:     {icon:'💄', label:'Beauty'},
  sports:     {icon:'⚽', label:'Sports'},
  tools:      {icon:'🔧', label:'Tools'},
  stationery: {icon:'📚', label:'Stationery'},
  health:     {icon:'💊', label:'Health'},
  baby:       {icon:'👶', label:'Baby & Kids'},
  food:       {icon:'🥗', label:'Food & Snacks'},
};
function subIcon(s){ return (subMeta[s]&&subMeta[s].icon)||'🛍'; }
function subLabel(s){ return (subMeta[s]&&subMeta[s].label)||(s.charAt(0).toUpperCase()+s.slice(1)); }

/* ══════════════════════════════════════════════════════
   BOOT
══════════════════════════════════════════════════════ */
window.addEventListener('DOMContentLoaded', function(){
  setPageOffset();
  window.addEventListener('resize', setPageOffset, {passive:true});
  setTimeout(setPageOffset, 300);

  renderBadges();
  updatePageTitle();

  /* Pre-fill search from URL */
  var si = document.getElementById('srchInput');
  if (si && ST.search) {
    si.value = ST.search;
    var cl = document.getElementById('srchClear');
    if (cl) cl.classList.add('show');
  }

  loadItems(true);
  initSearch();
  initInfiniteScroll();
  initSwipeClose();
  markActiveChip(ST.sub);
});

function setPageOffset(){
  var hdr  = document.getElementById('mainHdr');
  var wrap = document.getElementById('pageWrap');
  if(hdr && wrap) wrap.style.paddingTop = hdr.offsetHeight + 'px';
}

function updatePageTitle(){
  var label = ST.sub ? subLabel(ST.sub) : 'All Items';
  document.title = label + ' — Malaba Shop';
  var h = document.getElementById('hdrTitle');
  if(h) h.innerHTML = 'Malaba <span>' + esc(label) + '</span>';
}

/* ══════════════════════════════════════════════════════
   LOAD ITEMS
══════════════════════════════════════════════════════ */
function loadItems(reset){
  if(ST.loading || (ST.done && !reset)) return;
  ST.loading = true;
  if(reset){ ST.page=1; ST.items=[]; ST.done=false; }
  showSpin(true);

  var url = API_BASE+'/listings.php?type=items'
    +'&page='+ST.page+'&limit='+ST.limit
    +'&search='+encodeURIComponent(ST.search)
    +'&sort='+ST.sort
    +(ST.sub ? '&filter='+encodeURIComponent(ST.sub) : '');

  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout = 9000;
  xhr.onload = function(){
    var newItems = [];
    try{
      var d = JSON.parse(xhr.responseText);
      if(d && d.success){
        newItems = d.data || [];
        if(d.meta){ ST.total=d.meta.total; if(ST.page>=d.meta.pages) ST.done=true; }
      }
    }catch(e){}
    finish(newItems);
  };
  xhr.onerror = xhr.ontimeout = function(){ finish([]); };
  xhr.send();

  function finish(newItems){
    /* Seed fallback */
    if(!newItems.length){
      var seed = (window.MalabaAPI && MalabaAPI._seed && MalabaAPI._seed.items)||[];
      if(ST.sub) seed=seed.filter(function(i){
        return (i.subCategory||i.sub_category||'')=== ST.sub;
      });
      if(ST.search){
        var q=ST.search.toLowerCase();
        seed=seed.filter(function(i){
          return ((i.title||'')+(i.description||'')).toLowerCase().indexOf(q)!==-1;
        });
      }
      newItems = seed; ST.done = true;
    }

    if(reset){
      ST.items = newItems;
      renderGrid(true);
      /* Discover subcategories from first batch */
      discoverSubs(newItems);
    } else {
      newItems.forEach(function(i){ ST.items.push(i); });
      appendCards(newItems);
    }
    ST.page++; ST.loading=false; showSpin(false);
    updateCount();
    if(ST.done){
      var le = document.getElementById('loadEnd');
      if(le) le.style.display='block';
    }
  }
}

/* ══════════════════════════════════════════════════════
   DISCOVER SUBCATEGORIES from loaded data
   Then hit the API for all subs if available
══════════════════════════════════════════════════════ */
function discoverSubs(items){
  /* Index subcategories from the current batch of items */
  var found = {};
  items.forEach(function(it){
    var s = (it.sub_category || it.subCategory || '').toLowerCase().trim();
    if(s) found[s] = true;
  });

  /* Fetch the full authoritative list from the API */
  var xhr = new XMLHttpRequest();
  xhr.open('GET', API_BASE + '/subcategories.php?type=items', true);
  xhr.timeout = 5000;
  xhr.onload = function(){
    try{
      var d = JSON.parse(xhr.responseText);
      if(d && d.success && d.data){
        /* API returns {slug, label, count} objects */
        d.data.forEach(function(s){
          var slug = (s.slug || s.name || s || '').toLowerCase().trim();
          if(slug) found[slug] = true;
        });
      }
    }catch(e){}
    buildSubChips(Object.keys(found));
  };
  xhr.onerror = xhr.ontimeout = function(){ buildSubChips(Object.keys(found)); };
  xhr.send();
}

function buildSubChips(subs){
  /* Sort: active subcategory first, then alphabetically */
  allSubcategories = subs.slice().sort(function(a, b){
    if(a === ST.sub) return -1;
    if(b === ST.sub) return  1;
    return a.localeCompare(b);
  });

  var strip = document.getElementById('subStrip');
  if(!strip) return;

  var html = '<div class="sub-chip' + (ST.sub === '' ? ' on' : '') + '" data-sub="" onclick="switchSub(\'\')">' +
    '<span class="sub-chip-icon">✨</span> All Items</div>';

  allSubcategories.forEach(function(s){
    if(!s) return;
    html += '<div class="sub-chip' + (ST.sub === s ? ' on' : '') + '" data-sub="' + esc(s) + '" onclick="switchSub(\'' + esc(s) + '\')">' +
      '<span class="sub-chip-icon">' + subIcon(s) + '</span> ' + esc(subLabel(s)) + '</div>';
  });

  strip.innerHTML = html;
  setPageOffset();

  /* Scroll active chip into view */
  setTimeout(function(){
    var on = strip.querySelector('.sub-chip.on');
    if(on) on.scrollIntoView({behavior:'smooth', block:'nearest', inline:'center'});
  }, 80);
}

function markActiveChip(sub){
  document.querySelectorAll('.sub-chip').forEach(function(c){
    c.classList.toggle('on', c.dataset.sub === sub);
  });
}

function switchSub(sub){
  if(ST.sub === sub) return; /* already active */
  ST.sub = sub;
  /* Update URL without reload so back button works */
  var params = new URLSearchParams(window.location.search);
  if(sub) params.set('sub', sub); else params.delete('sub');
  history.replaceState(null,'', window.location.pathname+'?'+params.toString());
  markActiveChip(sub);
  updatePageTitle();
  loadItems(true);
  /* Reset scroll to top of grid */
  var grid = document.getElementById('shopGrid');
  if(grid) grid.scrollIntoView({behavior:'smooth', block:'start'});
}

/* ══════════════════════════════════════════════════════
   RENDER GRID + APPEND
══════════════════════════════════════════════════════ */
function renderGrid(reset){
  var grid = document.getElementById('shopGrid');
  if(reset) grid.innerHTML = '';
  var le = document.getElementById('loadEnd');
  if(le) le.style.display = 'none';

  if(!ST.items.length && reset){
    grid.innerHTML =
      '<div class="empty-state">'+
        '<div class="ei">🔍</div>'+
        '<h3>Nothing Found</h3>'+
        '<p>Try a different category or search term</p>'+
        '<button onclick="switchSub(\'\')">Show All Items</button>'+
      '</div>';
    return;
  }
  appendCards(ST.items);
}

function appendCards(items){
  var grid = document.getElementById('shopGrid');
  var frag = document.createDocumentFragment();
  items.forEach(function(item){
    var el = document.createElement('div');
    el.className = 'pcard';
    el.innerHTML = cardHTML(item);
    frag.appendChild(el);
  });
  grid.appendChild(frag);
  initCardImages(grid);
}

function initCardImages(grid){
  grid.querySelectorAll('.pcard:not([data-img-init])').forEach(function(card){
    card.setAttribute('data-img-init','1');
    var img = card.querySelector('.pcard-img img');
    if(!img) return;
    if(img.complete && img.naturalWidth > 0){ img.classList.add('img-loaded'); return; }
    img.classList.add('await-load');
    img.addEventListener('load', function(){ img.classList.remove('await-load'); img.classList.add('img-loaded'); },{once:true});
    img.addEventListener('error', function(){
      img.src='https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=360&q=60';
      img.classList.remove('await-load'); img.classList.add('img-loaded');
    },{once:true});
  });
}

/* ══════════════════════════════════════════════════════
   CARD HTML
══════════════════════════════════════════════════════ */
function cardHTML(item){
  var liked  = wishlist.indexOf(item.id)!==-1;
  var inCart = cart.find(function(c){ return c.id===item.id; });
  var raw    = parseFloat(String(item.price||'').replace(/[^0-9.]/g,''))||0;
  var hasLipa= raw >= 200;
  var img    = item.image||item.image_url||'';
  if(img.indexOf('cloudinary.com')!==-1) img=img.replace('/upload/','/upload/w_360,h_360,c_fill,f_auto,q_70/');
  else if(img.indexOf('unsplash.com')!==-1) img=img.split('?')[0]+'?w=360&h=360&q=70&auto=format&fit=crop';
  if(!img) img='https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=360&q=70';
  return (
    '<div class="pcard-img" onclick="goToItem(\''+esc(item.id)+'\')">' +
      '<img src="'+esc(img)+'" alt="'+esc(item.title)+'" loading="lazy" decoding="async"' +
        ' onerror="this.onerror=null;this.src=\'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=360&q=60\'">' +
      (item.badge?'<div class="pbadge">'+esc(item.badge)+'</div>':'')+
      (hasLipa?'<div class="plipa-badge">&#x1F4B0; Lipa</div>':'')+
      '<button class="wish'+(liked?' liked':'')+'" onclick="toggleWish(event,\''+esc(item.id)+'\',this)">'+(liked?'&#x2665;':'&#x2661;')+'</button>'+
    '</div>'+
    '<div class="pcard-body" onclick="goToItem(\''+esc(item.id)+'\')">' +
      '<div class="ptitle">'+esc(item.title)+'</div>'+
    '</div>'+
    '<div class="pprice" onclick="goToItem(\''+esc(item.id)+'\')">' +esc(item.price)+'</div>'+
    '<div class="pcard-foot">'+
      '<button class="btn-cart'+(inCart?' added':'')+'" id="btn-'+esc(item.id)+'" onclick="addToCart(event,\''+esc(item.id)+'\')">'+(inCart?'&#x2713; Added':'+ Cart')+'</button>'+
      '<button class="btn-buy" onclick="buyNow(event,\''+esc(item.id)+'\')">&#x1F6D2; Buy</button>'+
    '</div>'
  );
}

/* ══════════════════════════════════════════════════════
   SEARCH
══════════════════════════════════════════════════════ */
function initSearch(){
  var si  = document.getElementById('srchInput');
  var clr = document.getElementById('srchClear');
  var tmr = null;
  si.addEventListener('input', function(){
    var q = this.value.trim();
    if(clr) clr.classList.toggle('show', q.length > 0);
    clearTimeout(tmr);
    tmr = setTimeout(function(){
      ST.search = q;
      /* Update URL */
      var params = new URLSearchParams(window.location.search);
      if(q) params.set('q',q); else params.delete('q');
      history.replaceState(null,'',window.location.pathname+'?'+params.toString());
      loadItems(true);
    }, 300);
  });
  si.addEventListener('keydown', function(e){
    if(e.key==='Enter'){ clearTimeout(tmr); ST.search=this.value.trim(); loadItems(true); }
    if(e.key==='Escape'){ clearSearch(); }
  });
}
function clearSearch(){
  ST.search='';
  var si = document.getElementById('srchInput'); if(si) si.value='';
  var cl = document.getElementById('srchClear'); if(cl) cl.classList.remove('show');
  var params = new URLSearchParams(window.location.search);
  params.delete('q'); history.replaceState(null,'',window.location.pathname+'?'+params.toString());
  loadItems(true);
}

/* ══════════════════════════════════════════════════════
   INFINITE SCROLL
══════════════════════════════════════════════════════ */
function initInfiniteScroll(){
  var sentinel = document.getElementById('loadWrap');
  if(!sentinel) return;
  var obs = new IntersectionObserver(function(entries){
    if(entries[0].isIntersecting && !ST.done && !ST.loading) loadItems(false);
  }, {rootMargin:'200px'});
  obs.observe(sentinel);
}

/* ══════════════════════════════════════════════════════
   SORT
══════════════════════════════════════════════════════ */
function openSortSheet(){
  var opts = [
    {k:'smart',  l:'✨ Smart (Recommended)'},
    {k:'popular',l:'🔥 Most Popular'},
    {k:'newest', l:'🆕 Newest First'},
    {k:'price_asc', l:'💰 Price: Low to High'},
    {k:'price_desc',l:'💎 Price: High to Low'},
  ];
  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div>'+
    '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>'+
    '<div style="padding:8px 10px 4px;">'+
    opts.map(function(o){
      return '<div class="sort-opt'+(ST.sort===o.k?' sel':'')+'" onclick="setSort(\''+o.k+'\',\''+o.l+'\')">'+o.l+'</div>';
    }).join('')+'</div>';
  openSheet();
}
function setSort(k, l){
  ST.sort=k;
  var sl=document.getElementById('sortLbl'); if(sl) sl.textContent=l.replace(/^[^ ]+ /,'');
  var params=new URLSearchParams(window.location.search);
  params.set('sort',k); history.replaceState(null,'',window.location.pathname+'?'+params.toString());
  closeOverlay(); loadItems(true);
}

/* ══════════════════════════════════════════════════════
   CART ACTIONS
══════════════════════════════════════════════════════ */
function addToCart(ev, id){
  ev.stopPropagation();
  var item = ST.items.find(function(i){ return i.id===id; });
  if(!item) return;
  currentItem = item;
  var btn = document.getElementById('btn-'+id);
  var ex  = cart.findIndex(function(c){ return c.id===id; });
  if(ex !== -1){
    cart.splice(ex,1); saveCart(); renderBadges();
    if(btn){ btn.innerHTML='+ Cart'; btn.classList.remove('added'); }
    showToast('Removed from cart');
  } else {
    cart.push({id:id,title:item.title,price:item.price,qty:1,
      shop:item.location||'',
      phone:(item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'')});
    saveCart(); renderBadges();
    if(btn){ btn.innerHTML='&#x2713; Added'; btn.classList.add('added'); }
    showToast('&#x2713; Added to cart');
  }
}
function buyNow(ev, id){
  ev.stopPropagation();
  var item = ST.items.find(function(i){ return i.id===id; });
  if(!item) return;
  currentItem = item;
  var ex = cart.findIndex(function(c){ return c.id===id; });
  if(ex === -1){
    cart.push({id:id,title:item.title,price:item.price,qty:1,
      shop:item.location||'',
      phone:(item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'')});
    saveCart(); renderBadges();
    var btn=document.getElementById('btn-'+id);
    if(btn){ btn.innerHTML='&#x2713; Added'; btn.classList.add('added'); }
  }
  coStep=1; coPayMode='cash';
  buildCheckoutSheet(); openSheet(); prefillSaved();
  setTimeout(function(){ setCoStep(2); prefillSaved(); }, 60);
}
function toggleWish(ev, id, btn){
  ev.stopPropagation();
  var i = wishlist.indexOf(id);
  if(i!==-1){ wishlist.splice(i,1); btn.innerHTML='&#x2661;'; btn.classList.remove('liked'); showToast('Removed from saved'); }
  else       { wishlist.unshift(id); btn.innerHTML='&#x2665;'; btn.classList.add('liked'); showToast('&#x2665; Saved!'); }
  try{ localStorage.setItem('mh_shop_wish', JSON.stringify(wishlist)); }catch(e){}
}
function goToItem(id){ window.location.href='item_detail.php?id='+encodeURIComponent(id); }

/* ══════════════════════════════════════════════════════
   PROGRESSIVE CHECKOUT (identical flow to shop_listing)
══════════════════════════════════════════════════════ */
function openCart(){ openCheckout(); }
function openCheckout(){
  var n = cart.reduce(function(s,c){ return s+c.qty; },0);
  if(!n){ showToast('Your cart is empty'); return; }
  coStep=1; coPayMode='cash';
  buildCheckoutSheet(); openSheet(); prefillSaved();
}
function setCoStep(s){
  coStep=s;
  [1,2,3].forEach(function(n){
    var dot=document.getElementById('cod'+n),lbl=document.getElementById('col'+n),ln=document.getElementById('coline'+n);
    if(!dot) return;
    if(n<s){ dot.className='co-dot done';dot.innerHTML='&#x2713;';if(lbl)lbl.className='co-lbl done';if(ln)ln.className='co-line done'; }
    else if(n===s){ dot.className='co-dot active';dot.innerHTML=n;if(lbl)lbl.className='co-lbl active'; }
    else{ dot.className='co-dot';dot.innerHTML=n;if(lbl)lbl.className='co-lbl';if(ln)ln.className='co-line'; }
    var p=document.getElementById('cop'+n); if(p) p.className='co-panel'+(n===s?' active':'');
  });
}
function buildCheckoutSheet(){
  var total=cart.reduce(function(s,c){ return s+px(c.price)*c.qty; },0);
  var dlv=total>=2000?0:100; var grand=total+dlv; window._coGrand=grand;
  var itemsHTML=cart.map(function(c){
    return '<div class="co-item" id="coi-'+esc(c.id)+'">' +
      '<div class="co-item-img" style="background:var(--surface);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;">&#x1F4E6;</div>'+
      '<div class="co-item-info"><div class="co-item-title">'+esc(c.title)+'</div><div class="co-item-shop">'+esc((c.shop||'').split(',')[0])+'</div>'+
      '<div class="co-item-qty">'+
        '<button class="qty-btn" onclick="coQty(\''+esc(c.id)+'\',-1)">&#x2212;</button>'+
        '<span class="qty-val" id="cqv-'+esc(c.id)+'">'+c.qty+'</span>'+
        '<button class="qty-btn" onclick="coQty(\''+esc(c.id)+'\',1)">+</button>'+
      '</div></div>'+
      '<div class="co-item-price" id="cip-'+esc(c.id)+'">KSH '+(px(c.price)*c.qty).toLocaleString('en-KE')+'</div>'+
      '<button class="co-item-del" onclick="coQty(\''+esc(c.id)+'\',0)">&#x2715;</button>'+
    '</div>';
  }).join('');
  var summaryHTML='<div class="co-summary">'+
    '<div class="co-sum-row"><span>Subtotal</span><span>KSH '+total.toLocaleString('en-KE')+'</span></div>'+
    '<div class="co-sum-row"><span>Delivery</span><span>'+(dlv===0?'<span class="free">FREE &#x1F389;</span>':'KSH '+dlv)+'</span></div>'+
    '<div class="co-sum-row tot"><span>Total on Delivery</span><span>KSH '+grand.toLocaleString('en-KE')+'</span></div>'+
  '</div>';
  var detailsHTML=
    '<div class="row2"><div class="field"><label>Full Name *</label><input type="text" id="co_name" placeholder="Your name" autocomplete="name"></div>'+
    '<div class="field"><label>Phone *</label><input type="tel" id="co_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div></div>'+
    '<div class="field"><label>Delivery Address *</label><input type="text" id="co_addr" placeholder="e.g. Near Malaba Market"></div>'+
    '<div class="field"><label>Note (optional)</label><input type="text" id="co_note" placeholder="e.g. Call before delivery"></div>';
  var payHTML='<div class="co-summary" style="margin-bottom:14px;"><div class="co-sum-row tot"><span>Total to pay on delivery</span><span>KSH '+grand.toLocaleString('en-KE')+'</span></div></div>'+
    '<div class="pay-opts">'+
    '<div class="po sel" id="copo_cash" onclick="setCoPayMode(\'cash\',this)"><div class="po-ico">&#x1F4B5;</div><div class="po-txt"><strong>Cash on Delivery</strong><span>Pay when item arrives</span></div><div class="po-dot"></div></div>'+
    '<div class="po" id="copo_mpesa" onclick="setCoPayMode(\'mpesa\',this)"><div class="po-ico">&#x1F4F1;</div><div class="po-txt"><strong>M-Pesa on Delivery</strong><span>Send M-Pesa when delivered</span></div><div class="po-dot"></div></div>'+
    '</div>';
  document.getElementById('sheetContent').innerHTML=
    '<div class="sh-top"><div class="sh-handle"></div><button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>'+
    '<div class="co-steps">'+
      '<div class="co-step"><div class="co-dot active" id="cod1">1</div><div class="co-lbl active" id="col1">Cart</div></div>'+
      '<div class="co-line" id="coline1"></div>'+
      '<div class="co-step"><div class="co-dot" id="cod2">2</div><div class="co-lbl" id="col2">Details</div></div>'+
      '<div class="co-line" id="coline2"></div>'+
      '<div class="co-step" style="flex:0;"><div class="co-dot" id="cod3">3</div><div class="co-lbl" id="col3">Payment</div></div>'+
    '</div>'+
    '<div class="co-panel active" id="cop1" style="overflow-y:auto;max-height:58dvh;"><div style="padding:12px 16px 0;">'+itemsHTML+summaryHTML+'<div class="co-nav"><button class="co-next" onclick="coNext(1)">Continue to Details &#x203A;</button></div></div></div>'+
    '<div class="co-panel" id="cop2"><div style="padding:12px 16px 0;">'+detailsHTML+'<div class="co-nav"><button class="co-back" onclick="setCoStep(1)">&#x2190; Cart</button><button class="co-next" onclick="coNext(2)">Review Payment &#x203A;</button></div></div></div>'+
    '<div class="co-panel" id="cop3"><div style="padding:12px 16px 0;">'+payHTML+'<div class="co-nav"><button class="co-back" onclick="setCoStep(2)">&#x2190; Details</button><button class="co-next" id="coPlaceBtn" onclick="submitCheckout()">&#x2705; Place Order — KSH '+grand.toLocaleString('en-KE')+'</button></div></div></div>';
}
function coNext(step){
  if(step===1){ var n=cart.reduce(function(s,c){ return s+c.qty; },0); if(!n){ closeOverlay(); return; } setCoStep(2); prefillSaved(); }
  else if(step===2){
    var name=(document.getElementById('co_name').value||'').trim();
    var phone=(document.getElementById('co_phone').value||'').trim();
    var addr=(document.getElementById('co_addr').value||'').trim();
    if(!name){ showToast('Enter your full name'); return; }
    if(!phone||phone.replace(/\D/g,'').length<9){ showToast('Enter a valid phone number'); return; }
    if(!addr){ showToast('Enter your delivery address'); return; }
    setCoStep(3);
  }
}
function setCoPayMode(mode,el){
  coPayMode=mode;
  ['copo_cash','copo_mpesa'].forEach(function(id){ var e=document.getElementById(id); if(e)e.classList.remove('sel'); });
  if(el)el.classList.add('sel');
}
function coQty(id,d){
  var ex=cart.find(function(c){ return c.id===id; }); if(!ex)return;
  if(d===0){ cart=cart.filter(function(c){ return c.id!==id; }); }
  else{ ex.qty=Math.max(0,ex.qty+d); if(!ex.qty)cart=cart.filter(function(c){ return c.id!==id; }); }
  saveCart(); renderBadges();
  var btn=document.getElementById('btn-'+id);
  if(btn){ btn.innerHTML='+ Cart'; btn.classList.remove('added'); }
  if(!cart.length){ closeOverlay(); return; }
  buildCheckoutSheet(); prefillSaved();
}
function submitCheckout(){
  var name=(document.getElementById('co_name').value||'').trim();
  var phone=(document.getElementById('co_phone').value||'').trim();
  var addr=(document.getElementById('co_addr').value||'').trim();
  var note=(document.getElementById('co_note')?document.getElementById('co_note').value:'')||'';
  if(!name||!phone||!addr){ setCoStep(2); showToast('Please complete your details'); return; }
  var btn=document.getElementById('coPlaceBtn');
  if(btn){ btn.disabled=true; btn.textContent='Placing order...'; }
  saveMhUser(name,phone,addr);
  var grand=window._coGrand||0;
  var items=cart.map(function(c){ return c.title; }).join(', ');
  var waNum=normWA(cart[0]&&cart[0].phone?cart[0].phone:'');
  var snap=cart.slice();
  postOrder({
    category:'items',listing_id:snap[0]&&snap[0].id?snap[0].id:'',
    name:name,phone:phone,address:addr,
    payment_method:coPayMode==='mpesa'?'mpesa_on_delivery':'cash_on_delivery',
    total_amount:String(grand),
    notes:'Cart: '+items+(note?' | Note: '+note:'')+' | '+coPayMode,
    cart_items:snap.map(function(c){ return {id:c.id,title:c.title,price:c.price,qty:c.qty}; }),
  },function(d){
    var ref=d&&d.order_ref?d.order_ref:'';
    var msg=encodeURIComponent('🛒 *Order from '+name+'*\nPhone: '+phone+'\nAddress: '+addr+'\nItems: '+items+'\nTotal: KSH '+grand.toLocaleString('en-KE')+'\nPayment: '+(coPayMode==='mpesa'?'M-Pesa':'Cash')+' on delivery\nRef: '+(ref||'—'));
    snap.forEach(function(c){ var b=document.getElementById('btn-'+c.id); if(b){ b.innerHTML='+ Cart'; b.classList.remove('added'); }});
    cart=[]; saveCart(); renderBadges();
    document.getElementById('sheetContent').innerHTML=
      '<div class="sh-top"><div class="sh-handle"></div><button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>'+
      '<div class="suc-wrap"><div class="suc-ico">&#x2705;</div>'+
      '<div class="suc-title">Order Placed!</div>'+
      '<div class="suc-sub">'+(coPayMode==='cash'?'Pay KSH '+grand.toLocaleString('en-KE')+' cash when items arrive.':'M-Pesa payment arranged on delivery.')+'</div>'+
      (ref?'<div class="suc-ref">Ref: '+esc(ref)+'</div>':'')+
      '<button class="wa-btn" onclick="window.open(\'https://wa.me/'+waNum+'?text='+msg+'\',\'_blank\')">&#x1F4AC; Confirm on WhatsApp</button>'+
      '<button class="done-btn" onclick="closeOverlay()">Continue Shopping</button></div>';
  },function(){
    if(btn){ btn.disabled=false; btn.textContent='&#x2705; Place Order — KSH '+grand.toLocaleString('en-KE'); }
    showToast('Network error — please try again');
  });
}

/* ══════════════════════════════════════════════════════
   SHEET / OVERLAY HELPERS
══════════════════════════════════════════════════════ */
function openSheet(){ document.getElementById('overlay').classList.add('open'); document.body.style.overflow='hidden'; }
function closeOverlay(){ document.getElementById('overlay').classList.remove('open'); document.body.style.overflow=''; }
function handleOvClick(e){ if(e.target===e.currentTarget) closeOverlay(); }
function initSwipeClose(){
  var sheet=document.getElementById('activeSheet'); var tsY=0;
  sheet.addEventListener('touchstart',function(e){ tsY=e.touches[0].clientY; },{passive:true});
  sheet.addEventListener('touchend',function(e){ if(e.changedTouches[0].clientY-tsY>80&&sheet.scrollTop===0) closeOverlay(); },{passive:true});
}

/* ══════════════════════════════════════════════════════
   UTILS
══════════════════════════════════════════════════════ */
function px(str){ var n=parseInt(String(str||'').replace(/[^0-9]/g,'')); return isNaN(n)?0:n; }
function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function normWA(p){ var d=(p||'').replace(/\D/g,''); if(d.length===9)return'254'+d; if(d.length===10&&d[0]==='0')return'254'+d.substring(1); if(d.length===12)return d; return d||'254700000000'; }
function showToast(msg){ var t=document.getElementById('toast'); t.innerHTML=msg; t.classList.add('show'); setTimeout(function(){ t.classList.remove('show'); },2400); }
function showSpin(on){ var s=document.getElementById('loadSpin'); if(s)s.style.display=on?'block':'none'; }
function saveCart(){ try{ localStorage.setItem('mh_shop_cart',JSON.stringify(cart)); }catch(e){} }
function saveMhUser(n,p,a){ try{ localStorage.setItem('mh_user_details',JSON.stringify({name:n,phone:p,address:a})); }catch(e){} }
function prefillSaved(){
  var d=null; try{ d=JSON.parse(localStorage.getItem('mh_user_details')||'null'); }catch(e){}
  if(!d) return;
  var map={co_name:'name',co_phone:'phone',co_addr:'address'};
  Object.keys(map).forEach(function(fid){ var el=document.getElementById(fid); if(el&&d[map[fid]]&&!el.value)el.value=d[map[fid]]; });
}
function postOrder(data,onOk,onErr){
  var xhr=new XMLHttpRequest(); xhr.open('POST',API_BASE+'/order.php',true);
  xhr.setRequestHeader('Content-Type','application/json');
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout=12000;
  xhr.onload=function(){ try{ var d=JSON.parse(xhr.responseText); if(typeof onOk==='function')onOk(d); }catch(e){ if(typeof onOk==='function')onOk({}); } };
  xhr.onerror=xhr.ontimeout=function(){ if(typeof onErr==='function')onErr(); };
  xhr.send(JSON.stringify(data));
}
function renderBadges(){
  var n=cart.reduce(function(s,c){ return s+c.qty; },0);
  var total=cart.reduce(function(s,c){ return s+px(c.price)*c.qty; },0);
  var dlv=total>=2000?0:100; var grand=total+dlv;
  var el=document.getElementById('hBadge'); if(el){ el.textContent=n; el.classList.toggle('on',n>0); }
  var bar=document.getElementById('checkoutBar');
  var items=document.getElementById('chkItems');
  var tot=document.getElementById('chkTotal');
  var cnt=document.getElementById('chkCount');
  if(bar){
    bar.classList.toggle('show',n>0);
    if(items)items.textContent=n+' item'+(n!==1?'s':'')+' · '+(dlv===0?'Free delivery':'+KSH 100 delivery');
    if(tot)tot.textContent='KSH '+grand.toLocaleString('en-KE');
    if(cnt)cnt.textContent=n;
  }
}
function updateCount(){
  var rc=document.getElementById('resCount');
  if(rc) rc.textContent=ST.items.length+(ST.done?'':'+')+ ' product'+(ST.items.length!==1?'s':'')+(ST.sub?' in '+subLabel(ST.sub):'');
}

/* Lipa stubs — not on this page but postOrder needs lipaPayMode */
var lipaPayMode = 'mpesa';
</script>
</body>
</html>