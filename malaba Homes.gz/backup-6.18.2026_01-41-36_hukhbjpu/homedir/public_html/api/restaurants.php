<?php
/**
 * api/restaurants.php
 * Returns restaurants with their menu items grouped inside.
 * Used by food_listing.php
 */
require_once dirname(__FILE__) . '/../mh-portal-2026/db.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$db     = getDB();
$method = $_SERVER['REQUEST_METHOD'];

/* ── GET restaurants (with items) ── */
if ($method === 'GET') {
    $sort   = isset($_GET['sort'])   ? trim($_GET['sort'])   : 'smart';
    $limit  = isset($_GET['limit'])  ? (int)$_GET['limit']   : 30;
    $search = isset($_GET['search']) ? trim($_GET['search'])  : '';
    $restId = isset($_GET['id'])     ? trim($_GET['id'])      : '';

    /* Single restaurant detail */
    if ($restId) {
        try {
            $s = $db->prepare(
                "SELECT r.*,
                    COUNT(DISTINCT l.id) AS menu_item_count,
                    COALESCE(AVG(l.rating), r.rating) AS computed_rating
                 FROM restaurants r
                 LEFT JOIN listings l ON l.restaurant_id = r.id AND l.is_active = 1
                 WHERE r.id = ? AND r.is_active = 1
                 GROUP BY r.id"
            );
            $s->execute(array($restId));
            $rest = $s->fetch(PDO::FETCH_ASSOC);
            if (!$rest) {
                echo json_encode(array('success'=>false,'error'=>'Not found'));
                exit;
            }
            /* Get menu items */
            $rest['items'] = getMenuItems($db, $restId);
            echo json_encode(array('success'=>true,'data'=>$rest));
        } catch (Exception $e) {
            echo json_encode(array('success'=>false,'error'=>$e->getMessage()));
        }
        exit;
    }

    /* List all restaurants */
    try {
        $where  = array('r.is_active = 1');
        $params = array();

        if ($search) {
            $where[]  = '(r.name LIKE ? OR r.description LIKE ? OR r.cuisine LIKE ? OR r.location LIKE ?)';
            $like = '%'.$search.'%';
            $params[] = $like; $params[] = $like; $params[] = $like; $params[] = $like;
        }

        $whereSQL = implode(' AND ', $where);

        /* Order by smart algorithm:
           views × 0.4 + rating × 20 + is_featured × 30 + order_count × 0.3 */
        $orderSQL = 'r.is_featured DESC, (r.views * 0.4 + COALESCE(r.rating,4) * 20 + r.total_orders * 0.3) DESC, r.created_at DESC';
        if ($sort === 'newest')   $orderSQL = 'r.created_at DESC';
        if ($sort === 'popular')  $orderSQL = 'r.total_orders DESC, r.views DESC';
        if ($sort === 'rating')   $orderSQL = 'r.rating DESC';

        $stmt = $db->prepare(
            "SELECT r.*,
                COUNT(DISTINCT l.id) AS menu_item_count,
                COALESCE(AVG(l.rating), r.rating) AS computed_rating
             FROM restaurants r
             LEFT JOIN listings l ON l.restaurant_id = r.id AND l.is_active = 1
             WHERE $whereSQL
             GROUP BY r.id
             ORDER BY $orderSQL
             LIMIT ?");

        $params[] = $limit;
        $stmt->execute($params);
        $restaurants = $stmt->fetchAll(PDO::FETCH_ASSOC);

        /* Attach menu items to each restaurant */
        foreach ($restaurants as &$rest) {
            $rest['items'] = getMenuItems($db, $rest['id']);
        }
        unset($rest);

        echo json_encode(array(
            'success' => true,
            'data'    => $restaurants,
            'meta'    => array('total' => count($restaurants))
        ));

    } catch (Exception $e) {
        /* Fallback — return empty so JS uses seed data */
        echo json_encode(array('success'=>false,'data'=>array(),'error'=>$e->getMessage()));
    }
    exit;
}

/* ── Helpers ── */
function getMenuItems($db, $restId) {
    try {
        $s = $db->prepare(
            "SELECT l.id, l.title, l.description, l.price, l.image_url,
                    l.badge, l.rating, l.prep_time, l.sub_category,
                    l.is_featured, l.views, l.video_url,
                    l.contact_phone, l.contact_name,
                    COALESCE(li.image_url, l.image_url) AS first_image
             FROM listings l
             LEFT JOIN listing_images li ON li.listing_id = l.id AND li.sort_order = 0
             WHERE l.restaurant_id = ? AND l.is_active = 1
             ORDER BY l.is_featured DESC, l.views DESC, l.created_at DESC"
        );
        $s->execute(array($restId));
        $items = $s->fetchAll(PDO::FETCH_ASSOC);

        /* Attach gallery images to each item */
        foreach ($items as &$item) {
            $si = $db->prepare("SELECT image_url FROM listing_images WHERE listing_id = ? ORDER BY sort_order");
            $si->execute(array($item['id']));
            $imgs = $si->fetchAll(PDO::FETCH_COLUMN);
            $item['images'] = $imgs;
            /* Use image_url as fallback */
            if (!$item['image_url'] && count($imgs)) {
                $item['image_url'] = $imgs[0];
            }
            /* Attach features */
            $sf = $db->prepare("SELECT icon, feature_text FROM listing_features WHERE listing_id = ? ORDER BY sort_order");
            $sf->execute(array($item['id']));
            $item['features'] = $sf->fetchAll(PDO::FETCH_ASSOC);
        }
        unset($item);
        return $items;
    } catch (Exception $e) {
        return array();
    }
}