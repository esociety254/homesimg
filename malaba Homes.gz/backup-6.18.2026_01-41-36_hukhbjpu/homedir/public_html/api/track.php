<?php
/**
 * api/track.php - PHP 5.6+ compatible
 * POST JSON: { id, event }
 */
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(array('success'=>false)); exit;
}

$dbPath = __DIR__ . '/../mh-portal-2026/db.php';
if (!file_exists($dbPath)) { $dbPath = __DIR__ . '/mh-portal-2026/db.php'; }
require_once $dbPath;

try {
    $raw  = file_get_contents('php://input');
    $data = array();
    if ($raw) { $d = json_decode($raw, true); $data = is_array($d) ? $d : array(); }

    $id  = trim(isset($data['id'])    ? $data['id']    : '');
    $evt = trim(isset($data['event']) ? $data['event'] : 'view');
    if ($id === '') { echo json_encode(array('success'=>false)); exit; }

    $db = getDB();
    if ($evt === 'view') {
        $db->prepare("UPDATE listings SET views=IFNULL(views,0)+1 WHERE id=?")->execute(array($id));
    }
    try {
        $db->prepare("INSERT INTO analytics_events (listing_id,event) VALUES (?,?)")->execute(array($id,$evt));
    } catch(Exception $e) {}

    echo json_encode(array('success'=>true));
} catch (Exception $e) {
    echo json_encode(array('success'=>false));
}
