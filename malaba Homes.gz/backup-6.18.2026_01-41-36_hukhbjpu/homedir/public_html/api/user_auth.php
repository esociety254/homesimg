<?php
/**
 * api/user_auth.php - PHP 5.6+ compatible
 * Customer identity: Google login + profile save/load
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204); exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(array('success'=>false,'error'=>'POST required')); exit;
}

$dbPath = __DIR__ . '/../mh-portal-2026/db.php';
if (!file_exists($dbPath)) { $dbPath = __DIR__ . '/mh-portal-2026/db.php'; }
require_once $dbPath;

$raw    = file_get_contents('php://input');
$data   = array();
if ($raw) {
    $decoded = json_decode($raw, true);
    $data    = is_array($decoded) ? $decoded : array();
}
$action = isset($data['action']) ? trim($data['action']) : '';

function arr($a, $k, $def='') { return isset($a[$k]) ? $a[$k] : $def; }
function trimSub($a, $k, $len, $def='') { return substr(trim(isset($a[$k]) ? $a[$k] : $def), 0, $len); }

try {
    $db = getDB();

    // Create customers table if missing
    $db->exec("CREATE TABLE IF NOT EXISTS `customers` (
        `id`            INT(11)       NOT NULL AUTO_INCREMENT,
        `name`          VARCHAR(100)  NOT NULL DEFAULT '',
        `phone`         VARCHAR(20)   DEFAULT NULL,
        `email`         VARCHAR(100)  DEFAULT NULL,
        `address`       VARCHAR(250)  DEFAULT NULL,
        `avatar_url`    VARCHAR(500)  DEFAULT NULL,
        `google_id`     VARCHAR(100)  DEFAULT NULL,
        `session_token` VARCHAR(64)   DEFAULT NULL,
        `created_at`    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at`    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uq_session` (`session_token`),
        UNIQUE KEY `uq_email`   (`email`),
        KEY `idx_phone`         (`phone`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if ($action === 'google_login') {
        $name     = trimSub($data, 'name',     100);
        $email    = strtolower(trim(arr($data, 'email', '')));
        $googleId = trim(arr($data, 'googleId', ''));
        $avatar   = trimSub($data, 'avatar',   500);

        if ($email === '' && $googleId === '') {
            echo json_encode(array('success'=>false,'error'=>'Missing credentials')); exit;
        }

        $stmt = $db->prepare("SELECT * FROM customers WHERE email = ? OR google_id = ? LIMIT 1");
        $stmt->execute(array($email, $googleId));
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);

        $token = bin2hex(openssl_random_pseudo_bytes(32));

        if ($customer) {
            $db->prepare("UPDATE customers SET name=?, avatar_url=?, google_id=?, session_token=? WHERE id=?")
               ->execute(array(
                   $name ? $name : $customer['name'],
                   $avatar ? $avatar : $customer['avatar_url'],
                   $googleId, $token, $customer['id']
               ));
            echo json_encode(array(
                'success' => true,
                'token'   => $token,
                'phone'   => isset($customer['phone'])   ? $customer['phone']   : '',
                'address' => isset($customer['address']) ? $customer['address'] : '',
                'name'    => $customer['name'],
            ));
        } else {
            $db->prepare("INSERT INTO customers (name,email,google_id,avatar_url,session_token) VALUES (?,?,?,?,?)")
               ->execute(array($name, $email, $googleId, $avatar, $token));
            echo json_encode(array('success'=>true,'token'=>$token,'phone'=>'','address'=>'','name'=>$name));
        }

    } elseif ($action === 'update_profile') {
        $token   = trim(arr($data, 'token',   ''));
        $name    = trimSub($data, 'name',    100);
        $phone   = trimSub($data, 'phone',    20);
        $address = trimSub($data, 'address', 250);
        if ($token === '') { echo json_encode(array('success'=>false,'error'=>'Missing token')); exit; }
        $stmt = $db->prepare("UPDATE customers SET
            name    = CASE WHEN ? <> '' THEN ? ELSE name    END,
            phone   = CASE WHEN ? <> '' THEN ? ELSE phone   END,
            address = CASE WHEN ? <> '' THEN ? ELSE address END
            WHERE session_token = ?");
        $stmt->execute(array($name,$name,$phone,$phone,$address,$address,$token));
        echo json_encode(array('success'=>$stmt->rowCount() > 0));

    } elseif ($action === 'get_profile') {
        $token = trim(arr($data, 'token', ''));
        if ($token === '') { echo json_encode(array('success'=>false,'error'=>'Missing token')); exit; }
        $stmt = $db->prepare("SELECT name,phone,address,email,avatar_url AS avatar FROM customers WHERE session_token=? LIMIT 1");
        $stmt->execute(array($token));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) { echo json_encode(array('success'=>false,'error'=>'Not found')); exit; }
        echo json_encode(array('success'=>true,'data'=>$row));

    } else {
        echo json_encode(array('success'=>false,'error'=>'Unknown action: '.$action));
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('success'=>false,'error'=>$e->getMessage()));
}
