<?php
/**
 * api/push_subscribe.php
 * Upload to: public_html/api/push_subscribe.php
 * Saves the FCM device token to the database.
 */

require_once dirname(__FILE__) . '/../mh-portal-2026/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(array('success' => false, 'error' => 'POST only'));
    exit;
}

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data || empty($data['token'])) {
    echo json_encode(array('success' => false, 'error' => 'Token required'));
    exit;
}

$token      = trim(substr($data['token'], 0, 512));
$segment    = isset($data['segment'])    ? trim($data['segment'])    : 'all';
$platform   = isset($data['platform'])   ? trim($data['platform'])   : 'android';
$userAgent  = isset($data['user_agent']) ? trim($data['user_agent']) : '';
$phone      = isset($data['phone'])      ? trim($data['phone'])      : null;
$ip         = isset($_SERVER['HTTP_X_FORWARDED_FOR'])
              ? trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0])
              : (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '');

/* Valid segments */
$validSegments = array('all', 'food', 'shop', 'homes', 'orders');
if (!in_array($segment, $validSegments)) $segment = 'all';

/* Valid platforms */
$validPlatforms = array('android', 'ios', 'web');
if (!in_array($platform, $validPlatforms)) $platform = 'web';

try {
    $db = getDB();

    /* Upsert — insert or update if token already exists */
    $stmt = $db->prepare(
        "INSERT INTO push_subscribers
            (token, platform, segment, phone, ip, user_agent, is_active, created_at, last_seen_at)
         VALUES
            (?, ?, ?, ?, ?, ?, 1, NOW(), NOW())
         ON DUPLICATE KEY UPDATE
            segment      = VALUES(segment),
            platform     = VALUES(platform),
            phone        = COALESCE(VALUES(phone), phone),
            ip           = VALUES(ip),
            is_active    = 1,
            last_seen_at = NOW()"
    );
    $stmt->execute(array($token, $platform, $segment, $phone, $ip, $userAgent));

    echo json_encode(array('success' => true, 'message' => 'Subscribed'));

} catch (Exception $e) {
    /* Don't expose DB errors to the client */
    error_log('push_subscribe error: ' . $e->getMessage());
    echo json_encode(array('success' => false, 'error' => 'Server error'));
}