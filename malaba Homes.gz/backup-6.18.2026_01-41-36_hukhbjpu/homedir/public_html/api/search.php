<?php
/**
 * api/search.php - PHP 5.6+ compatible
 * GET ?q=chicken&limit=20&type=food
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$dbPath = __DIR__ . '/../mh-portal-2026/db.php';
if (!file_exists($dbPath)) { $dbPath = __DIR__ . '/mh-portal-2026/db.php'; }
require_once $dbPath;

$q     = trim(isset($_GET['q'])    ? $_GET['q']    : '');
$type  = trim(isset($_GET['type']) ? $_GET['type'] : '');
$limit = min(60, max(1, (int)(isset($_GET['limit']) ? $_GET['limit'] : 20)));

if ($q === '') {
    echo json_encode(array('success'=>true, 'data'=>array(), 'meta'=>array('total'=>0)));
    exit;
}

try {
    $db = getDB();

    $like   = '%' . $q . '%';
    $where  = array('l.is_active = 1');
    $where[] = '(l.title LIKE ? OR l.description LIKE ? OR l.location LIKE ? OR l.contact_name LIKE ?)';
    $params = array($like, $like, $like, $like);

    if ($type !== '') {
        $where[]  = 'c.slug = ?';
        $params[] = $type;
    }

    $whereSQL = implode(' AND ', $where);

    // Count
    $cntStmt = $db->prepare("SELECT COUNT(*) FROM listings l JOIN categories c ON l.category_id = c.id WHERE $whereSQL");
    $cntStmt->execute($params);
    $total = (int)$cntStmt->fetchColumn();

    // Scoring params (title + location LIKE for relevance)
    $scoreSQL = "(CASE WHEN l.title LIKE ? THEN 30 ELSE 0 END)
                 + (CASE WHEN l.location LIKE ? THEN 10 ELSE 0 END)
                 + (CASE WHEN IFNULL(l.is_featured,0)=1 THEN 20 ELSE 0 END)
                 + IFNULL(l.views,0) * 0.1";

    $allParams = array_merge(array($like, $like), $params);

    $stmt = $db->prepare(
        "SELECT l.id, l.title, l.description, l.price, l.location,
                l.image_url AS image, l.contact_phone, l.contact_name,
                IFNULL(l.badge,'') AS badge,
                IFNULL(l.views,0)  AS views,
                IFNULL(l.is_featured,0) AS is_featured,
                l.created_at,
                c.slug AS type, c.name AS category_name, c.icon AS category_icon,
                ($scoreSQL) AS relevance
         FROM listings l
         JOIN categories c ON l.category_id = c.id
         WHERE $whereSQL
         ORDER BY relevance DESC, l.created_at DESC
         LIMIT $limit"
    );
    $stmt->execute($allParams);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as &$row) {
        unset($row['relevance']);
        $row['contact'] = array(
            'phone' => isset($row['contact_phone']) ? $row['contact_phone'] : '',
            'name'  => isset($row['contact_name'])  ? $row['contact_name']  : '',
        );
        unset($row['contact_phone'], $row['contact_name']);
    }
    unset($row);

    echo json_encode(array(
        'success' => true,
        'data'    => $rows,
        'meta'    => array('total'=>$total, 'query'=>$q),
    ));

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('success'=>false, 'error'=>$e->getMessage()));
}
