<?php
/**
 * api/inquiry.php - PHP 5.6+ compatible
 */
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(array('success'=>false)); exit;
}

$dbPath = __DIR__ . '/../mh-portal-2026/db.php';
if (!file_exists($dbPath)) { $dbPath = __DIR__ . '/mh-portal-2026/db.php'; }
require_once $dbPath;

try {
    $raw  = file_get_contents('php://input');
    $data = array();
    if ($raw) { $d = json_decode($raw, true); $data = is_array($d) ? $d : $_POST; }
    if (empty($data)) { $data = $_POST; }

    $db = getDB();
    $db->prepare("INSERT INTO inquiries (listing_id,user_name,user_phone,message) VALUES (?,?,?,?)")
       ->execute(array(
           isset($data['listing_id']) ? $data['listing_id'] : null,
           substr(trim(isset($data['name'])    ? $data['name']    : ''), 0, 100),
           substr(trim(isset($data['phone'])   ? $data['phone']   : ''), 0, 20),
           substr(trim(isset($data['message']) ? $data['message'] : ''), 0, 1000),
       ));
    echo json_encode(array('success'=>true));
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('success'=>false,'error'=>$e->getMessage()));
}
