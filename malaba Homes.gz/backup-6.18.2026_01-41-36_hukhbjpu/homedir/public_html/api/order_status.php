<?php
/**
 * api/order_status.php
 * Compatible with PHP 5.6+  (no ?? operator, no match(), no arrow functions)
 *
 * GET ?ref=MH-2026-0001
 * GET ?phone=0712345678
 * GET ?ref=MH-2026-0001&phone=07
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$dbPath = __DIR__ . '/../mh-portal-2026/db.php';
if (!file_exists($dbPath)) { $dbPath = __DIR__ . '/mh-portal-2026/db.php'; }
require_once $dbPath;

// ---- Helper: get value from array with default (replaces ??) ----
function arr($arr, $key, $default = '') {
    return isset($arr[$key]) ? $arr[$key] : $default;
}

// ---- Helper: normalise phone to last 9 digits ----
function normalisePhone($p) {
    $d = preg_replace('/\D/', '', $p);
    return substr($d, -9);
}

// ---- Helper: build WhatsApp number ----
function waNum($phone) {
    $d = preg_replace('/\D/', '', $phone);
    if (strlen($d) === 9)  { return '254' . $d; }
    if (strlen($d) === 10 && $d[0] === '0') { return '254' . substr($d, 1); }
    if (strlen($d) === 12 && substr($d, 0, 3) === '254') { return $d; }
    return $d;
}

define('ADMIN_WA', '254700000000'); // change to your WhatsApp number

$STATUS_META = array(
    'pending'    => array('label'=>'Order Received',  'icon'=>'received',    'color'=>'#f59e0b',
                          'hint'=>'Your order has been received and is being reviewed by our team.'),
    'confirmed'  => array('label'=>'Confirmed',       'icon'=>'confirmed',   'color'=>'#0984e3',
                          'hint'=>'Your order is confirmed and will be prepared shortly.'),
    'processing' => array('label'=>'Being Prepared',  'icon'=>'processing',  'color'=>'#8b5cf6',
                          'hint'=>'Your order is being prepared right now!'),
    'dispatched' => array('label'=>'On the Way',      'icon'=>'dispatched',  'color'=>'#0d9488',
                          'hint'=>'Your order is on its way. Please be ready to receive it.'),
    'delivered'  => array('label'=>'Delivered',       'icon'=>'delivered',   'color'=>'#00b894',
                          'hint'=>'Your order has been delivered. Enjoy!'),
    'cancelled'  => array('label'=>'Cancelled',       'icon'=>'cancelled',   'color'=>'#d63031',
                          'hint'=>'This order was cancelled. Contact us on WhatsApp for help.'),
);

$PAY_META = array(
    'pending'  => array('label'=>'Payment Pending',  'icon'=>'pending',  'color'=>'#f59e0b'),
    'received' => array('label'=>'Payment Received', 'icon'=>'received', 'color'=>'#00b894'),
    'failed'   => array('label'=>'Payment Failed',   'icon'=>'failed',   'color'=>'#d63031'),
    'refunded' => array('label'=>'Refunded',         'icon'=>'refunded', 'color'=>'#0984e3'),
);

$PAY_LABELS = array(
    'cash'               => 'Cash on Delivery',
    'mpesa'              => 'M-Pesa',
    'cash_on_delivery'   => 'Cash on Move-In',
    'mpesa_on_delivery'  => 'M-Pesa on Delivery',
);

$ALL_STEPS = array('pending','confirmed','processing','dispatched','delivered');

try {
    $db    = getDB();
    $ref   = strtoupper(trim(isset($_GET['ref'])   ? $_GET['ref']   : ''));
    $phone = trim(isset($_GET['phone']) ? $_GET['phone'] : '');

    if ($ref === '' && $phone === '') {
        echo json_encode(array('success'=>false, 'error'=>'Provide an order reference or phone number.'));
        exit;
    }

    $where  = array();
    $params = array();

    if ($ref !== '') {
        $where[]  = 'o.order_ref = ?';
        $params[] = $ref;
    }
    if ($phone !== '') {
        $tail     = normalisePhone($phone);
        $where[]  = 'o.customer_phone LIKE ?';
        $params[] = '%' . $tail;
    }

    $sql = "SELECT o.id, o.order_ref, o.category,
               o.listing_id, o.listing_title, o.listing_price,
               o.customer_name, o.customer_phone, o.customer_address,
               o.quantity, o.total_amount, o.payment_method,
               o.notes, o.status, o.payment_status,
               o.created_at, o.updated_at, o.delivered_at,
               o.wa_notified,
               c.icon  AS category_icon,
               c.name  AS category_name,
               l.image_url     AS listing_image,
               l.contact_phone AS seller_phone,
               l.contact_name  AS seller_name
        FROM orders o
        LEFT JOIN categories c ON c.slug  = o.category
        LEFT JOIN listings   l ON l.id    = o.listing_id
        WHERE " . implode(' AND ', $where) . "
        ORDER BY o.created_at DESC LIMIT 20";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($rows)) {
        echo json_encode(array('success'=>false, 'error'=>'No orders found. Check your reference or phone number.'));
        exit;
    }

    // ---- Build response rows ----
    foreach ($rows as &$row) {
        $s = isset($row['status'])         ? $row['status']         : 'pending';
        $p = isset($row['payment_status']) ? $row['payment_status'] : 'pending';

        $row['status_meta']          = isset($STATUS_META[$s])           ? $STATUS_META[$s]           : $STATUS_META['pending'];
        $row['payment_meta']         = isset($PAY_META[$p])              ? $PAY_META[$p]              : $PAY_META['pending'];
        $row['payment_method_label'] = isset($PAY_LABELS[$row['payment_method']]) 
                                       ? $PAY_LABELS[$row['payment_method']] 
                                       : ucfirst(str_replace('_', ' ', $row['payment_method']));

        // ---- Build timeline ----
        $timeline = array(array(
            'status' => 'pending',
            'label'  => 'Order Placed',
            'icon'   => 'pending',
            'time'   => $row['created_at'],
            'note'   => 'Order received by Malaba Homes.',
            'done'   => true,
        ));

        // Fetch status history
        $histStmt = $db->prepare(
            "SELECT new_status, note, changed_at FROM order_status_log WHERE order_id = ? ORDER BY changed_at ASC"
        );
        $histStmt->execute(array($row['id']));
        $history = $histStmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($history as $h) {
            $hs   = $h['new_status'];
            $meta = isset($STATUS_META[$hs]) ? $STATUS_META[$hs] : array('label'=>ucfirst($hs), 'icon'=>'pending', 'hint'=>'');
            $timeline[] = array(
                'status' => $hs,
                'label'  => $meta['label'],
                'icon'   => $meta['icon'],
                'time'   => $h['changed_at'],
                'note'   => ($h['note'] !== null && $h['note'] !== '') ? $h['note'] : $meta['hint'],
                'done'   => true,
            );
        }

        // Add future steps (upcoming)
        if ($s !== 'cancelled') {
            $doneStatuses = array();
            foreach ($timeline as $t) { $doneStatuses[] = $t['status']; }
            foreach ($ALL_STEPS as $step) {
                if ($step === 'pending') { continue; }
                if (!in_array($step, $doneStatuses)) {
                    $meta = $STATUS_META[$step];
                    $timeline[] = array(
                        'status' => $step,
                        'label'  => $meta['label'],
                        'icon'   => $meta['icon'],
                        'time'   => null,
                        'note'   => '',
                        'done'   => false,
                    );
                }
            }
        } else {
            $timeline[] = array(
                'status' => 'cancelled',
                'label'  => 'Order Cancelled',
                'icon'   => 'cancelled',
                'time'   => $row['updated_at'],
                'note'   => 'Order was cancelled.',
                'done'   => true,
            );
        }

        $row['timeline'] = $timeline;

        $sellerPhone     = isset($row['seller_phone']) ? $row['seller_phone'] : '';
        $row['wa_seller']  = ($sellerPhone !== '') ? waNum($sellerPhone) : ADMIN_WA;
        $row['wa_support'] = ADMIN_WA;

        // Mask phone for privacy
        $rawPhone = preg_replace('/\D/', '', isset($row['customer_phone']) ? $row['customer_phone'] : '');
        $row['customer_phone_masked'] = '***' . substr($rawPhone, -4);
        unset($row['customer_phone']);
    }
    unset($row);

    $isSingle = ($ref !== '' && count($rows) === 1);
    echo json_encode(array(
        'success' => true,
        'data'    => $isSingle ? $rows[0] : $rows,
        'single'  => $isSingle,
        'count'   => count($rows),
    ));

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('success'=>false, 'error'=>$e->getMessage()));
}
