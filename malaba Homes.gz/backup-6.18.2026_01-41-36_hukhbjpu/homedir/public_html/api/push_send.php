<?php
/**
 * api/push_send.php
 * Upload to: public_html/api/push_send.php
 *
 * Called by the admin panel to send a push notification.
 * Uses Firebase HTTP v1 API (most up-to-date, long-lived).
 *
 * SETUP:
 * 1. In Firebase Console → Project Settings → Service accounts
 * 2. Click "Generate new private key" → download JSON
 * 3. Rename it firebase-service-account.json
 * 4. Upload to public_html/firebase-service-account.json
 * 5. Set FCM_PROJECT_ID below to your Firebase project ID
 *    (found in the downloaded JSON as "project_id")
 */

require_once dirname(__FILE__) . '/../mh-portal-2026/auth.php';
require_once dirname(__FILE__) . '/../mh-portal-2026/db.php';
/* Only admins can send notifications */
requirePerm('send_notifications');

header('Content-Type: application/json');

/* ── CONFIG ── */
define('FCM_PROJECT_ID',       'malaba-homes');
define('SERVICE_ACCOUNT_PATH', dirname(__FILE__) . '/../firebase-service-account.json');

/* ── READ POST DATA ── */
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data) {
    echo json_encode(array('success'=>false,'error'=>'Invalid JSON'));
    exit;
}

$title    = isset($data['title'])    ? trim($data['title'])    : '';
$body     = isset($data['body'])     ? trim($data['body'])     : '';
$imageUrl = isset($data['image'])    ? trim($data['image'])    : '';
$clickUrl = isset($data['url'])      ? trim($data['url'])      : '/index.php';
$segment  = isset($data['segment'])  ? trim($data['segment'])  : 'all';
$notifId  = isset($data['notif_id']) ? (int)$data['notif_id'] : 0;

if (!$title || !$body) {
    echo json_encode(array('success'=>false,'error'=>'Title and body are required'));
    exit;
}

/* ── GET ACCESS TOKEN from service account ── */
function getAccessToken() {
    if (!file_exists(SERVICE_ACCOUNT_PATH)) {
        throw new Exception('Service account file not found at: ' . SERVICE_ACCOUNT_PATH);
    }

    $sa = json_decode(file_get_contents(SERVICE_ACCOUNT_PATH), true);
    if (!$sa || empty($sa['private_key']) || empty($sa['client_email'])) {
        throw new Exception('Invalid service account JSON');
    }

    /* Build JWT */
    $now    = time();
    $header = base64url_encode(json_encode(array('alg'=>'RS256','typ'=>'JWT')));
    $claims = base64url_encode(json_encode(array(
        'iss'   => $sa['client_email'],
        'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
        'aud'   => 'https://oauth2.googleapis.com/token',
        'iat'   => $now,
        'exp'   => $now + 3600
    )));

    $toSign = $header . '.' . $claims;
    $key    = openssl_pkey_get_private($sa['private_key']);
    if (!$key) throw new Exception('Could not load private key');

    $sig = '';
    openssl_sign($toSign, $sig, $key, 'SHA256');
    $jwt = $toSign . '.' . base64url_encode($sig);

    /* Exchange JWT for access token */
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, array(
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query(array(
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion'  => $jwt
        )),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER     => array('Content-Type: application/x-www-form-urlencoded')
    ));
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) throw new Exception('Token exchange failed: '.$response);

    $tokenData = json_decode($response, true);
    if (empty($tokenData['access_token'])) throw new Exception('No access token in response');

    return $tokenData['access_token'];
}

function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

/* ── SEND TO ONE DEVICE ── */
function sendToDevice($accessToken, $fcmToken, $title, $body, $imageUrl, $clickUrl) {
    $message = array(
        'message' => array(
            'token' => $fcmToken,
            'notification' => array(
                'title' => $title,
                'body'  => $body,
            ),
            'data' => array(
                'title'     => $title,
                'body'      => $body,
                'click_url' => $clickUrl,
                'image'     => $imageUrl,
            ),
            'android' => array(
                'notification' => array(
                    'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
                    'sound'        => 'default',
                    'channel_id'   => 'malaba_default',
                    'image'        => $imageUrl ?: null,
                    'icon'         => 'ic_notification',
                    'color'        => '#E8521A',
                ),
                'priority' => 'high',
            ),
            'webpush' => array(
                'notification' => array(
                    'title'              => $title,
                    'body'               => $body,
                    'icon'               => '/icons/icon-192.png',
                    'badge'              => '/icons/icon-96.png',
                    'image'              => $imageUrl ?: null,
                    'requireInteraction' => false,
                    'vibrate'            => array(200, 100, 200),
                ),
                'fcm_options' => array(
                    'link' => $clickUrl
                )
            ),
            'apns' => array(
                'payload' => array(
                    'aps' => array(
                        'alert' => array(
                            'title' => $title,
                            'body'  => $body,
                        ),
                        'sound' => 'default',
                        'badge' => 1,
                    )
                ),
                'fcm_options' => array(
                    'image' => $imageUrl ?: null
                )
            )
        )
    );

    $url = 'https://fcm.googleapis.com/v1/projects/' . FCM_PROJECT_ID . '/messages:send';

    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($message),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER     => array(
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        )
    ));
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError= curl_error($ch);
    curl_close($ch);

    if ($curlError) return array('ok'=>false,'error'=>$curlError);
    if ($httpCode === 200) return array('ok'=>true);

    /* Handle invalid/expired token */
    $resp = json_decode($response, true);
    $errCode = isset($resp['error']['details'][0]['errorCode'])
               ? $resp['error']['details'][0]['errorCode'] : '';
    if ($errCode === 'UNREGISTERED' || $errCode === 'INVALID_ARGUMENT') {
        return array('ok'=>false,'error'=>'unregistered','deactivate'=>true);
    }
    return array('ok'=>false,'error'=>$response);
}

/* ── MAIN SEND LOGIC ── */
try {
    $db = getDB();

    /* Get subscribers for this segment */
    if ($segment === 'all') {
        $stmt = $db->prepare("SELECT id, token FROM push_subscribers WHERE is_active = 1");
        $stmt->execute(array());
    } else {
        $stmt = $db->prepare(
            "SELECT id, token FROM push_subscribers
             WHERE is_active = 1
             AND (segment = ? OR segment = 'all')"
        );
        $stmt->execute(array($segment));
    }
    $subscribers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($subscribers)) {
        echo json_encode(array('success'=>true,'sent'=>0,'message'=>'No subscribers in this segment'));
        exit;
    }

    /* Get access token once — reuse for all sends */
    $accessToken = getAccessToken();

    $sent = 0; $failed = 0;
    $deactivate = array();

    /* Send in batches of 50 to avoid timeout */
    $batches = array_chunk($subscribers, 50);

    foreach ($batches as $batch) {
        foreach ($batch as $sub) {
            $result = sendToDevice(
                $accessToken,
                $sub['token'],
                $title, $body, $imageUrl, $clickUrl
            );
            if ($result['ok']) {
                $sent++;
            } else {
                $failed++;
                if (!empty($result['deactivate'])) {
                    $deactivate[] = $sub['id'];
                }
            }
        }
        /* Small pause between batches to be kind to the API */
        if (count($batches) > 1) usleep(200000); /* 0.2 seconds */
    }

    /* Deactivate invalid tokens */
    if (!empty($deactivate)) {
        $placeholders = implode(',', array_fill(0, count($deactivate), '?'));
        $db->prepare("UPDATE push_subscribers SET is_active=0 WHERE id IN ($placeholders)")
           ->execute($deactivate);
    }

    /* Update notification log if notif_id was passed */
    if ($notifId) {
        $db->prepare(
            "UPDATE push_notifications
             SET sent_count=?, fail_count=?, status='sent', sent_at=NOW()
             WHERE id=?"
        )->execute(array($sent, $failed, $notifId));
    }

    echo json_encode(array(
        'success'  => true,
        'sent'     => $sent,
        'failed'   => $failed,
        'total'    => count($subscribers),
        'deactivated' => count($deactivate),
    ));

} catch (Exception $e) {
    error_log('push_send error: ' . $e->getMessage());
    echo json_encode(array(
        'success' => false,
        'error'   => $e->getMessage()
    ));
}