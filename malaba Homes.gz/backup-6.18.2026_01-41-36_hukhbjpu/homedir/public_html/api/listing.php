<?php
/**
 * api/listing.php - PHP 5.6+ compatible
 * GET ?id=h1  - fetch one listing by id
 */
header('Content-Type: application/json');

$dbPath = __DIR__ . '/../mh-portal-2026/db.php';
if (!file_exists($dbPath)) { $dbPath = __DIR__ . '/mh-portal-2026/db.php'; }
require_once $dbPath;

$id = trim(isset($_GET['id']) ? $_GET['id'] : '');
if ($id === '') {
    echo json_encode(array('success'=>false,'error'=>'Missing id')); exit;
}

try {
    $db   = getDB();
    $stmt = $db->prepare(
        "SELECT l.*,
                IFNULL(l.badge,'')      AS badge,
                IFNULL(l.views,0)       AS views,
                IFNULL(l.is_featured,0) AS is_featured,
                c.slug AS type
         FROM listings l
         JOIN categories c ON l.category_id = c.id
         WHERE l.id = ? AND l.is_active = 1
         LIMIT 1"
    );
    $stmt->execute(array($id));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        echo json_encode(array('success'=>false,'error'=>'Not found')); exit;
    }

    // Bump views
    try { $db->prepare("UPDATE listings SET views=IFNULL(views,0)+1 WHERE id=?")->execute(array($id)); }
    catch(Exception $e) {}

    // Gallery
    $s = $db->prepare("SELECT image_url FROM listing_images WHERE listing_id=? ORDER BY sort_order");
    $s->execute(array($id));
    $imgs = array();
    foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $r) { $imgs[] = $r['image_url']; }
    $row['images'] = !empty($imgs) ? $imgs : array($row['image_url']);
    $row['image']  = $row['image_url'];

    // Features
    $s2 = $db->prepare("SELECT icon, feature_text AS `text` FROM listing_features WHERE listing_id=? ORDER BY sort_order");
    $s2->execute(array($id));
    $row['features'] = $s2->fetchAll(PDO::FETCH_ASSOC);

    $row['contact'] = array(
        'phone' => isset($row['contact_phone']) ? $row['contact_phone'] : '',
        'name'  => isset($row['contact_name'])  ? $row['contact_name']  : '',
    );

    echo json_encode(array('success'=>true,'data'=>$row));

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('success'=>false,'error'=>$e->getMessage()));
}
