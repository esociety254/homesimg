/**
 * MALABA HOMES — DATA LAYER
 * ============================================================
 * This file is the bridge between the PHP/MySQL backend and
 * the JavaScript frontend. In development it falls back to
 * static seed data. In production every call hits /api/*.php
 *
 * Usage (anywhere in the frontend):
 *   const items = await MalabaAPI.getListings('houses');
 *   const item  = await MalabaAPI.getListingById('h1');
 * ============================================================
 */

const MalabaAPI = (() => {

  /* ── Config ── */
  const BASE = '/api';          // adjust if your api/ folder is elsewhere
  const CACHE_TTL = 2 * 60 * 1000;  // 2-minute client cache
  const _cache = {};

  /* ── Internals ── */
  async function _fetch(url) {
    const now = Date.now();
    if (_cache[url] && now - _cache[url].ts < CACHE_TTL) return _cache[url].data;
    try {
      const res  = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      _cache[url] = { data, ts: now };
      return data;
    } catch (err) {
      console.warn(`[MalabaAPI] ${url} failed, using fallback`, err.message);
      return null;
    }
  }

  /* ── Public API ── */

  /**
   * Get listings by category: 'houses' | 'food' | 'items'
   * @param {string} type
   * @param {object} opts  { page, limit, search, sort, priceMin, priceMax, filter }
   */
  async function getListings(type, opts = {}) {
    const params = new URLSearchParams({ type, ...opts }).toString();
    const remote = await _fetch(`${BASE}/listings.php?${params}`);
    if (remote?.success) return remote.data;
    // Fallback to bundled seed data
    return _seed[type] || [];
  }

  /**
   * Get a single listing by id
   */
  async function getListingById(id) {
    const remote = await _fetch(`${BASE}/listing.php?id=${encodeURIComponent(id)}`);
    if (remote?.success) return remote.data;
    // Fallback
    for (const cat of Object.values(_seed)) {
      const found = cat.find(i => i.id === String(id));
      if (found) return found;
    }
    return null;
  }

  /**
   * Search across all categories
   */
  async function search(query) {
    const remote = await _fetch(`${BASE}/search.php?q=${encodeURIComponent(query)}`);
    if (remote?.success) return remote.data;
    const q = query.toLowerCase();
    return Object.values(_seed).flat().filter(i =>
      i.title.toLowerCase().includes(q) ||
      i.description.toLowerCase().includes(q) ||
      i.location.toLowerCase().includes(q)
    );
  }

  /**
   * Get featured / trending items for a category
   */
  async function getFeatured(type, limit = 6) {
    const remote = await _fetch(`${BASE}/featured.php?type=${type}&limit=${limit}`);
    if (remote?.success) return remote.data;
    return (_seed[type] || []).slice(0, limit);
  }

  /**
   * Smart shop recommendations — scored algorithm
   * Combines: recency, views, price range affinity, category match
   * Falls back to local scoring when API is unavailable
   */
  async function getRecommended(opts = {}) {
    const { limit = 20, exclude = [], history = [] } = opts;
    const remote = await _fetch(`${BASE}/recommended.php?limit=${limit}`);
    if (remote?.success) return remote.data;

    // Client-side scoring fallback
    return _scoreItems(_seed.items || [], { exclude, history, limit });
  }

  /**
   * Log an inquiry (fire-and-forget)
   */
  async function logInquiry(payload) {
    try {
      await fetch(`${BASE}/inquiry.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        body: JSON.stringify(payload)
      });
    } catch (_) {}
  }

  /* ── Smart Scoring Algorithm ── */
  function _scoreItems(items, { exclude = [], history = [], limit = 20 } = {}) {
    const now    = Date.now();
    const viewed = JSON.parse(localStorage.getItem('mh_viewed') || '[]');
    const prefs  = _inferPrefs(history.concat(viewed));

    return items
      .filter(i => !exclude.includes(i.id))
      .map(i => {
        let score = 50;

        // Recency boost (newer items win)
        if (i.created_at) {
          const age = (now - new Date(i.created_at).getTime()) / 86400000;
          score += Math.max(0, 20 - age);
        }

        // Price affinity (items close to user's typical spend score higher)
        if (prefs.avgPrice > 0) {
          const itemPrice = _parsePrice(i.price);
          const diff      = Math.abs(itemPrice - prefs.avgPrice) / prefs.avgPrice;
          score += Math.max(0, 15 - diff * 30);
        }

        // Popularity proxy (views from seed)
        score += (i.views || 0) * 0.1;

        // Category affinity
        if (prefs.topCat && i.subCategory === prefs.topCat) score += 12;

        // Not seen recently → boost discovery
        if (!viewed.includes(i.id)) score += 8;

        // Has multiple images → quality signal
        if ((i.images || []).length > 1) score += 5;

        return { ...i, _score: score };
      })
      .sort((a, b) => b._score - a._score)
      .slice(0, limit);
  }

  function _inferPrefs(history) {
    if (!history.length) return { avgPrice: 0, topCat: null };
    const prices = history.map(id => {
      const item = Object.values(_seed).flat().find(i => i.id === id);
      return item ? _parsePrice(item.price) : 0;
    }).filter(Boolean);
    const cats   = history.map(id => {
      const item = Object.values(_seed).flat().find(i => i.id === id);
      return item?.subCategory || null;
    }).filter(Boolean);
    const catFreq = cats.reduce((acc, c) => { acc[c] = (acc[c]||0)+1; return acc; }, {});
    const topCat  = Object.entries(catFreq).sort((a,b)=>b[1]-a[1])[0]?.[0] || null;
    return {
      avgPrice: prices.length ? prices.reduce((a,b)=>a+b,0)/prices.length : 0,
      topCat
    };
  }

  function _parsePrice(str) {
    const n = parseInt((str || '').replace(/[^0-9]/g, ''));
    return isNaN(n) ? 0 : n;
  }

  /* ── Track a viewed item (for recommendation engine) ── */
  function trackView(id) {
    const viewed = JSON.parse(localStorage.getItem('mh_viewed') || '[]');
    if (!viewed.includes(id)) {
      viewed.unshift(id);
      localStorage.setItem('mh_viewed', JSON.stringify(viewed.slice(0, 50)));
    }
    // Async ping to backend
    fetch(`${BASE}/track.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
      body: JSON.stringify({ id, event: 'view', ts: Date.now() })
    }).catch(() => {});
  }

  /* ══════════════════════════════════════════════════
     SEED DATA — replaces old data.js static object
     Production: this is always overridden by the API
     ══════════════════════════════════════════════════ */
  const _seed = {
    houses: [
      {
        id: 'h1', type: 'houses',
        title: '2 Bedroom Apartment',
        description: 'Modern apartment with spacious rooms, kitchen, and bathroom. Close to town center.',
        price: 'KSH 15,000/month', location: 'Downtown, Malaba',
        image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=80',
        images: [
          'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=80',
          'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80',
          'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80'
        ],
        features: [
          { icon: '🛏️', text: '2 Bedrooms' }, { icon: '🚿', text: '1 Bathroom' },
          { icon: '🍳', text: 'Kitchen included' }, { icon: '💡', text: 'All utilities' }
        ],
        contact: { phone: '254712345678', name: 'John Kamau' },
        badge: 'Popular', created_at: '2025-01-10'
      },
      {
        id: 'h2', type: 'houses',
        title: 'Studio Apartment',
        description: 'Cozy studio perfect for students or young professionals. Secure compound with 24/7 security.',
        price: 'KSH 8,000/month', location: 'Westlands, Malaba',
        image: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80',
        images: [
          'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80',
          'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=80'
        ],
        features: [
          { icon: '🛏️', text: '1 Room' }, { icon: '🚿', text: 'Shared bathroom' },
          { icon: '🔒', text: '24/7 Security' }, { icon: '💧', text: 'Water included' }
        ],
        contact: { phone: '254723456789', name: 'Mary Wanjiku' },
        badge: 'Budget', created_at: '2025-01-15'
      },
      {
        id: 'h3', type: 'houses',
        title: '3 Bedroom House',
        description: 'Spacious family home with garden and parking. Quiet neighborhood, close to schools.',
        price: 'KSH 35,000/month', location: 'Karen, Malaba',
        image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80',
        images: [
          'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80',
          'https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=800&q=80'
        ],
        features: [
          { icon: '🛏️', text: '3 Bedrooms' }, { icon: '🚿', text: '2 Bathrooms' },
          { icon: '🌳', text: 'Garden' }, { icon: '🚗', text: 'Parking space' }
        ],
        contact: { phone: '254734567890', name: 'Peter Ochieng' },
        badge: 'Family Home', created_at: '2025-01-05'
      }
    ],

    food: [
      {
        id: 'f1', type: 'food',
        title: 'Chicken Burger Combo',
        description: 'Juicy grilled chicken burger with fries, coleslaw, and a soft drink.',
        price: 'KSH 450', location: "Mama's Kitchen, CBD",
        image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80',
        images: [
          'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80',
          'https://images.unsplash.com/photo-1550547660-d9450f859349?w=800&q=80'
        ],
        features: [
          { icon: '🍗', text: 'Grilled chicken' }, { icon: '🍟', text: 'French fries' },
          { icon: '🥗', text: 'Coleslaw' }, { icon: '🥤', text: 'Soft drink' }
        ],
        contact: { phone: '254745678901', name: "Mama's Kitchen" },
        prepTime: '15–20 min', badge: '🔥 Bestseller', rating: 4.8, created_at: '2025-01-01'
      },
      {
        id: 'f2', type: 'food',
        title: 'Beef Pilau & Kachumbari',
        description: 'Traditional Kenyan pilau cooked with tender beef, served with fresh kachumbari salad.',
        price: 'KSH 350', location: 'Swahili Delights, Eastleigh',
        image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80'],
        features: [
          { icon: '🍚', text: 'Spiced rice' }, { icon: '🥩', text: 'Tender beef' },
          { icon: '🥗', text: 'Kachumbari' }, { icon: '🌶️', text: 'Authentic spices' }
        ],
        contact: { phone: '254756789012', name: 'Swahili Delights' },
        prepTime: '20–25 min', badge: '⭐ Local Fave', rating: 4.6, created_at: '2025-01-02'
      },
      {
        id: 'f3', type: 'food',
        title: 'Vegetable Samosas (10 pcs)',
        description: 'Crispy golden samosas filled with spiced vegetables. Perfect snack for any time!',
        price: 'KSH 150', location: 'Spice Corner, Ngara',
        image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80'],
        features: [
          { icon: '🥟', text: '10 pieces' }, { icon: '🥬', text: 'Fresh vegetables' },
          { icon: '🔥', text: 'Hot & crispy' }, { icon: '🌱', text: 'Vegetarian' }
        ],
        contact: { phone: '254767890123', name: 'Spice Corner' },
        prepTime: '10 min', badge: '⚡ Quick', rating: 4.5, created_at: '2025-01-08'
      },
      {
        id: 'f4', type: 'food',
        title: 'Nyama Choma Platter',
        description: 'Half kilo of grilled meat with ugali, kachumbari and sukuma wiki. A Kenyan favorite!',
        price: 'KSH 800', location: 'Carnivore Junction, Langata',
        image: 'https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=800&q=80'],
        features: [
          { icon: '🥩', text: '500g grilled meat' }, { icon: '🍞', text: 'Ugali' },
          { icon: '🥗', text: 'Kachumbari' }, { icon: '🥬', text: 'Sukuma wiki' }
        ],
        contact: { phone: '254778901234', name: 'Carnivore Junction' },
        prepTime: '25–30 min', badge: '👑 Premium', rating: 4.9, created_at: '2025-01-03'
      }
    ],

    items: [
      {
        id: 'i1', type: 'items', subCategory: 'kitchen',
        title: 'Non-Stick Cooking Set',
        description: '5-piece non-stick cookware set. Perfect for any kitchen!',
        price: 'KSH 3,500', location: 'HomeGoods Store, Westlands',
        image: 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=800&q=80','https://images.unsplash.com/photo-1556909212-d5b604d0c90d?w=800&q=80'],
        features: [{ icon: '🍳', text: '5-piece set' },{ icon: '✨', text: 'Non-stick coating' },{ icon: '🔥', text: 'Heat resistant' },{ icon: '🧼', text: 'Easy to clean' }],
        contact: { phone: '254789012345', name: 'HomeGoods Store' },
        badge: '⭐ Top Pick', views: 240, created_at: '2025-01-12'
      },
      {
        id: 'i2', type: 'items', subCategory: 'decor',
        title: 'Wall Art Canvas Set',
        description: 'Beautiful 3-piece canvas wall art to brighten up your living room or bedroom.',
        price: 'KSH 2,800', location: 'Decor Haven, Karen',
        image: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=800&q=80'],
        features: [{ icon: '🖼️', text: '3-piece set' },{ icon: '🎨', text: 'Modern design' },{ icon: '📏', text: '40x60cm each' },{ icon: '🔨', text: 'Easy to hang' }],
        contact: { phone: '254790123456', name: 'Decor Haven' },
        badge: '🎨 Trending', views: 180, created_at: '2025-01-14'
      },
      {
        id: 'i3', type: 'items', subCategory: 'appliances',
        title: 'Electric Kettle 1.8L',
        description: 'Fast-boiling electric kettle with auto shut-off. Energy efficient and safe.',
        price: 'KSH 1,200', location: 'Tech Appliances, CBD',
        image: 'https://images.unsplash.com/photo-1563297007-0686b7003af7?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1563297007-0686b7003af7?w=800&q=80'],
        features: [{ icon: '⚡', text: '1800W power' },{ icon: '💧', text: '1.8L capacity' },{ icon: '🔒', text: 'Auto shut-off' },{ icon: '✅', text: '1 year warranty' }],
        contact: { phone: '254701234567', name: 'Tech Appliances' },
        badge: '🔥 Hot Deal', views: 310, created_at: '2025-01-16'
      },
      {
        id: 'i4', type: 'items', subCategory: 'storage',
        title: 'Bamboo Storage Baskets',
        description: 'Set of 3 handwoven bamboo baskets. Eco-friendly and stylish.',
        price: 'KSH 1,800', location: 'Eco Living, Kilimani',
        image: 'https://images.unsplash.com/photo-1567880905822-56f8e06fe630?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1567880905822-56f8e06fe630?w=800&q=80'],
        features: [{ icon: '🧺', text: '3 different sizes' },{ icon: '🌿', text: 'Handwoven bamboo' },{ icon: '♻️', text: 'Eco-friendly' },{ icon: '🏠', text: 'Multipurpose' }],
        contact: { phone: '254712345670', name: 'Eco Living' },
        badge: '🌱 Eco', views: 95, created_at: '2025-01-09'
      }
    ]
  };

  /* Legacy compatibility — keeps old code that calls getListingById() working */
  window.getListingById = function(id) {
    for (const cat of Object.values(_seed)) {
      const f = cat.find(i => i.id === String(id));
      if (f) return f;
    }
    return null;
  };
  window.getListingsByType = (type) => _seed[type] || [];
  window.listings = _seed;

  return { getListings, getListingById, search, getFeatured, getRecommended, logInquiry, trackView, _seed };
})();
