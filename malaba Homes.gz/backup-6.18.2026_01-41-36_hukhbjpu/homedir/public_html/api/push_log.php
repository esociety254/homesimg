<?php
/**
 * api/push_log.php
 * Upload to: public_html/api/push_log.php
 * Saves a notification to the log before/after sending.
 */
require_once dirname(__FILE__) . '/../mh-portal-2026/auth.php';
require_once dirname(__FILE__) . '/../mh-portal-2026/db.php';


requirePerm('send_notifications');

header('Content-Type: application/json');

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data || empty($data['title']) || empty($data['body'])) {
    echo json_encode(array('success'=>false,'error'=>'Title and body required'));
    exit;
}

$title   = trim(substr($data['title'],   0, 255));
$body    = trim(substr($data['body'],    0, 2000));
$image   = isset($data['image'])   ? trim($data['image'])   : '';
$url     = isset($data['url'])     ? trim($data['url'])     : '/index.php';
$segment = isset($data['segment']) ? trim($data['segment']) : 'all';
$status  = isset($data['status'])  ? trim($data['status'])  : 'draft';

/* Who sent it */
$sentBy = isset($_SESSION['admin_username']) ? $_SESSION['admin_username'] : 'admin';

try {
    $db   = getDB();
    $stmt = $db->prepare(
        "INSERT INTO push_notifications
            (title, body, image_url, click_url, segment, status, sent_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, NOW())"
    );
    $stmt->execute(array($title, $body, $image, $url, $segment, $status, $sentBy));
    $id = $db->lastInsertId();
    echo json_encode(array('success'=>true, 'id'=>(int)$id));
} catch (Exception $e) {
    error_log('push_log error: ' . $e->getMessage());
    echo json_encode(array('success'=>false,'error'=>'Database error'));
}