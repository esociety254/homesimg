<?php
/**
 * api/listings.php — PHP 5.6+ compatible
 * Serves listings filtered strictly by category_id (via slug),
 * sub_category, search, sort and pagination.
 *
 * Key fixes vs previous version:
 *  - Selects seller_id, is_premium, contact_name, contact_phone explicitly
 *  - same-shop filter via seller_id OR contact_name
 *  - featured/premium flags come straight from DB columns
 *  - sub_category filter is exact-match on the DB column
 *  - video_url / is_premium columns checked gracefully
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$dbPath = __DIR__ . '/../mh-portal-2026/db.php';
if (!file_exists($dbPath)) { $dbPath = __DIR__ . '/mh-portal-2026/db.php'; }
require_once $dbPath;

function g($a,$k,$def=''){ return isset($a[$k]) ? $a[$k] : $def; }

/* ── Input params ── */
$type        = trim(g($_GET,'type','items'));
$page        = max(1,  (int)g($_GET,'page',1));
$limit       = min(60, max(6, (int)g($_GET,'limit',24)));
$search      = trim(g($_GET,'search',''));
$sort        = trim(g($_GET,'sort','smart'));
$priceMin    = (int)g($_GET,'priceMin',0);
$priceMax    = (int)g($_GET,'priceMax',0);
$subCat      = trim(g($_GET,'filter',''));       /* exact sub_category match */
$sellerPhone = trim(g($_GET,'seller_phone','')); /* same-shop: by phone */
$sellerName  = trim(g($_GET,'seller_name',''));  /* same-shop: by name  */
$sellerId    = (int)g($_GET,'seller_id',0);      /* same-shop: by seller_id */
$featuredOnly= (int)g($_GET,'featured',0);       /* 1 = is_featured=1 only */
$premiumOnly = (int)g($_GET,'premium',0);        /* 1 = is_premium=1 only  */
$exclude     = trim(g($_GET,'exclude',''));       /* exclude a listing id    */
$offset      = ($page - 1) * $limit;

/* ── Sort SQL ── */
$sortMap = array(
    'newest'     => 'l.created_at DESC',
    'price_asc'  => "CAST(REPLACE(REPLACE(l.price,'KSH ',''),',','') AS UNSIGNED) ASC",
    'price_desc' => "CAST(REPLACE(REPLACE(l.price,'KSH ',''),',','') AS UNSIGNED) DESC",
    'popular'    => 'IFNULL(l.views,0) DESC, l.created_at DESC',
    /* smart: featured first, then premium, then popular, then recent */
    'smart'      => 'IFNULL(l.is_featured,0) DESC, IFNULL(l.is_premium,0) DESC, IFNULL(l.views,0) DESC, l.created_at DESC',
);
$orderSQL = isset($sortMap[$sort]) ? $sortMap[$sort] : $sortMap['smart'];

try {
    $db = getDB();

    /* ── Graceful column checks ── */
    $hasVideo   = false;
    $hasPremium = false;
    $hasSeller  = false;
    try { $db->query("SELECT video_url  FROM listings LIMIT 0"); $hasVideo   = true; } catch (Exception $e) {}
    try { $db->query("SELECT is_premium FROM listings LIMIT 0"); $hasPremium = true; } catch (Exception $e) {}
    try { $db->query("SELECT seller_id  FROM listings LIMIT 0"); $hasSeller  = true; } catch (Exception $e) {}

    $extraCols  = $hasVideo   ? ", IFNULL(l.video_url,'')  AS video_url"  : ", '' AS video_url";
    $extraCols .= $hasPremium ? ", IFNULL(l.is_premium,0)  AS is_premium" : ", 0 AS is_premium";
    $extraCols .= $hasSeller  ? ", l.seller_id"                           : ", NULL AS seller_id";

    /* ── Resolve category slug → id ── */
    $catStmt = $db->prepare("SELECT id FROM categories WHERE slug = ? LIMIT 1");
    $catStmt->execute(array($type));
    $catId = $catStmt->fetchColumn();
    if (!$catId) {
        echo json_encode(array('success'=>false,'error'=>'Unknown category: '.$type));
        exit;
    }

    /* ── WHERE clause ── */
    $where  = array('l.category_id = ?', 'l.is_active = 1');
    $params = array($catId);

    /* Full-text search across title, description, location, contact_name */
    if ($search !== '') {
        $where[]  = '(l.title LIKE ? OR l.description LIKE ? OR l.location LIKE ? OR l.contact_name LIKE ?)';
        $s = '%'.$search.'%';
        $params[] = $s; $params[] = $s; $params[] = $s; $params[] = $s;
    }

    /* Exact sub_category filter */
    if ($subCat !== '') {
        $where[]  = 'l.sub_category = ?';
        $params[] = $subCat;
    }

    /* Price range */
    if ($priceMin > 0) {
        $where[]  = "CAST(REPLACE(REPLACE(l.price,'KSH ',''),',','') AS UNSIGNED) >= ?";
        $params[] = $priceMin;
    }
    if ($priceMax > 0) {
        $where[]  = "CAST(REPLACE(REPLACE(l.price,'KSH ',''),',','') AS UNSIGNED) <= ?";
        $params[] = $priceMax;
    }

    /* Featured-only filter — reads directly from is_featured column */
    if ($featuredOnly) {
        $where[]  = 'l.is_featured = 1';
    }

    /* Premium-only filter — reads directly from is_premium column */
    if ($premiumOnly && $hasPremium) {
        $where[]  = 'l.is_premium = 1';
    }

    /* ── Same-shop filter ──────────────────────────────────────────────────
       The ONLY reliable shop identifier in this dataset is contact_name.
       Phone numbers are shared across multiple different shops so we NEVER
       filter by phone alone — doing so returns every listing in the DB.

       Priority:
         1. seller_id match (definitive when set)
         2. contact_name exact match, case-insensitive (primary identifier)
         3. seller_id OR contact_name together if both supplied

       Phone is intentionally excluded from the OR because real data shows
       many different sellers share the same contact_phone.
    ────────────────────────────────────────────────────────────────────── */
    $shopClauses = array();
    $shopParams  = array();

    if ($sellerId > 0 && $hasSeller) {
        $shopClauses[] = 'l.seller_id = ?';
        $shopParams[]  = $sellerId;
    }
    // if ($sellerName !== '') {
    //     /* Case-insensitive, trimmed exact match */
    //     $shopClauses[] = 'LOWER(TRIM(l.contact_name)) = LOWER(TRIM(?))';
    //     $shopParams[]  = $sellerName;
    // }
    /* NOTE: sellerPhone intentionally NOT used — shared phones break shop identity */

    if (!empty($shopClauses)) {
        $where[]  = '(' . implode(' OR ', $shopClauses) . ')';
        foreach ($shopParams as $sp) { $params[] = $sp; }
    }

    /* Exclude a specific listing (e.g. the currently viewed item) */
    if ($exclude !== '') {
        $where[]  = 'l.id != ?';
        $params[] = $exclude;
    }

    $whereSQL = implode(' AND ', $where);

    /* ── Count ── */
    $cntStmt = $db->prepare("SELECT COUNT(*) FROM listings l WHERE $whereSQL");
    $cntStmt->execute($params);
    $total = (int)$cntStmt->fetchColumn();

    /* ── Main query ── */
    $sql = "SELECT
                l.id,
                l.title,
                l.description,
                l.price,
                l.location,
                l.image_url        AS image,
                l.contact_phone,
                l.contact_name,
                IFNULL(l.badge,'')          AS badge,
                IFNULL(l.views,0)           AS views,
                l.rating,
                l.prep_time,
                IFNULL(l.sub_category,'')   AS sub_category,
                IFNULL(l.is_featured,0)     AS is_featured,
                l.created_at,
                c.slug                      AS type
                $extraCols
            FROM listings l
            JOIN categories c ON l.category_id = c.id
            WHERE $whereSQL
            ORDER BY $orderSQL
            LIMIT $limit OFFSET $offset";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    /* ── Attach images + features per listing ── */
    $imgStmt  = $db->prepare(
        "SELECT image_url FROM listing_images WHERE listing_id = ? ORDER BY sort_order"
    );
    $featStmt = $db->prepare(
        "SELECT icon, feature_text AS `text` FROM listing_features WHERE listing_id = ? ORDER BY sort_order"
    );

    foreach ($rows as &$row) {
        /* Images */
        $imgStmt->execute(array($row['id']));
        $imgRows = $imgStmt->fetchAll(PDO::FETCH_ASSOC);
        $imgs = array();
        foreach ($imgRows as $ir) { $imgs[] = $ir['image_url']; }
        $row['images'] = !empty($imgs) ? $imgs : array($row['image']);

        /* Features */
        $featStmt->execute(array($row['id']));
        $row['features'] = $featStmt->fetchAll(PDO::FETCH_ASSOC);

        /* Normalise contact into a sub-object */
        $row['contact'] = array(
            'phone' => $row['contact_phone'],
            'name'  => $row['contact_name'],
        );

        /* has_video flag for the frontend Watch button */
        $row['has_video'] = (!empty($row['video_url']));

        /* Cast booleans so JSON is clean */
        $row['is_featured'] = (bool)$row['is_featured'];
        $row['is_premium']  = isset($row['is_premium']) ? (bool)$row['is_premium'] : false;
        $row['views']       = (int)$row['views'];


        unset($row['contact_phone'], $row['contact_name']);
    }
    unset($row);

    echo json_encode(array(
        'success' => true,
        'data'    => $rows,
        'meta'    => array(
            'total'  => $total,
            'page'   => $page,
            'limit'  => $limit,
            'pages'  => $total > 0 ? (int)ceil($total / $limit) : 1,
        ),
    ));

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('success'=>false,'error'=>$e->getMessage()));
}