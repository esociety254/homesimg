<?php
/**
 * api/order.php - PHP 5.6+ compatible
 * POST JSON: handles checkout from homes, food, shop pages
 */
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(array('success'=>false,'error'=>'POST required')); exit;
}

$dbPath = __DIR__ . '/../mh-portal-2026/db.php';
if (!file_exists($dbPath)) { $dbPath = __DIR__ . '/mh-portal-2026/db.php'; }
require_once $dbPath;

function g($a,$k,$def='') { return isset($a[$k]) ? $a[$k] : $def; }

try {
    $raw  = file_get_contents('php://input');
    $data = array();
    if ($raw) {
        $d = json_decode($raw, true);
        $data = is_array($d) ? $d : $_POST;
    }
    if (empty($data)) { $data = $_POST; }

    $db = getDB();

    $listing_id       = trim(g($data,'listing_id',''));
    $category         = trim(g($data,'category','items'));
    $customer_name    = substr(trim(g($data,'name', g($data,'customer_name',''))), 0, 100);
    $customer_phone   = substr(trim(g($data,'phone',g($data,'customer_phone',''))), 0, 20);
    $customer_address = substr(trim(g($data,'address','')), 0, 250);
    $customer_id_no   = substr(trim(g($data,'id_no','')), 0, 30);
    $payment_method   = trim(g($data,'payment_method','cash'));
    $notes            = substr(trim(g($data,'notes', g($data,'message',''))), 0, 1000);
    $quantity         = max(1, (int)g($data,'quantity',1));

    // Resolve listing title/price
    $listing_title = trim(g($data,'listing_title',''));
    $listing_price = trim(g($data,'listing_price',''));
    $raw_amount    = (float)preg_replace('/[^0-9.]/','',str_replace(',','',g($data,'total_amount','0')));

    if ($listing_id !== '') {
        $ls = $db->prepare("SELECT title,price FROM listings WHERE id=? LIMIT 1");
        $ls->execute(array($listing_id));
        $row = $ls->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            if ($listing_title === '') { $listing_title = $row['title']; }
            if ($listing_price === '') { $listing_price = $row['price']; }
            if ($raw_amount <= 0) {
                $raw_amount = (float)preg_replace('/[^0-9.]/','',str_replace(',',' ',$row['price']));
            }
        }
    }

    // Cart items (multi-item orders)
    $cart_items = isset($data['cart_items']) && is_array($data['cart_items']) ? $data['cart_items'] : array();
    if (!empty($cart_items)) {
        if ($listing_title === '') {
            $titles = array();
            foreach ($cart_items as $ci) { $titles[] = g($ci,'title',''); }
            $first3 = array_slice($titles,0,3);
            $listing_title = implode(', ', $first3) . (count($titles)>3?'...':'');
        }
        if ($listing_id === '' && isset($cart_items[0]['id'])) {
            $listing_id = $cart_items[0]['id'];
        }
        if ($raw_amount <= 0) {
            foreach ($cart_items as $ci) {
                $p = (float)preg_replace('/[^0-9.]/','',str_replace(',','',g($ci,'price','0')));
                $raw_amount += $p * max(1,(int)g($ci,'qty',1));
            }
        }
    }

    $validCats = array('houses','food','items');
    if (!in_array($category, $validCats)) { $category = 'items'; }

    // Generate order ref
    $maxId = (int)$db->query("SELECT IFNULL(MAX(id),0) FROM orders")->fetchColumn();
    $ref   = 'MH-' . date('Y') . '-' . str_pad($maxId+1, 4, '0', STR_PAD_LEFT);

    $db->prepare(
        "INSERT INTO orders
           (order_ref,category,listing_id,listing_title,listing_price,
            customer_name,customer_phone,customer_address,customer_id_no,
            quantity,total_amount,payment_method,notes,status,payment_status)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'pending','pending')"
    )->execute(array(
        $ref, $category,
        $listing_id !== '' ? $listing_id : null,
        $listing_title, $listing_price,
        $customer_name, $customer_phone, $customer_address, $customer_id_no,
        $quantity, $raw_amount, $payment_method, $notes
    ));

    $order_id = $db->lastInsertId();

    // Mirror to inquiries
    $mirror = $notes ? $notes : "Cat:$category|Items:$listing_title|Pay:$payment_method|Total:KSH $raw_amount|Addr:$customer_address";
    $db->prepare("INSERT INTO inquiries (listing_id,user_name,user_phone,message) VALUES (?,?,?,?)")
       ->execute(array(
           $listing_id !== '' ? $listing_id : null,
           $customer_name, $customer_phone,
           substr($mirror,0,1000)
       ));

    echo json_encode(array('success'=>true,'order_id'=>$order_id,'order_ref'=>$ref));

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('success'=>false,'error'=>$e->getMessage()));
}
