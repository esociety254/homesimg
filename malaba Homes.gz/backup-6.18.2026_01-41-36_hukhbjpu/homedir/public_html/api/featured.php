<?php
/**
 * api/featured.php — PHP 5.6+ compatible
 * Returns featured (is_featured=1) and/or premium (is_premium=1) listings.
 * Falls back to most-viewed if neither flag is set on any row.
 *
 * GET params:
 *   type    = items | food | houses
 *   limit   = 3–20  (default 8)
 *   premium = 1     (return is_premium=1 items instead of/as well as featured)
 *   mode    = featured | premium | both | popular  (default: featured)
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$dbPath = __DIR__ . '/../mh-portal-2026/db.php';
if (!file_exists($dbPath)) { $dbPath = __DIR__ . '/mh-portal-2026/db.php'; }
require_once $dbPath;

$type  = trim(isset($_GET['type'])  ? $_GET['type']  : 'items');
$limit = min(20, max(3, (int)(isset($_GET['limit']) ? $_GET['limit'] : 8)));
$mode  = trim(isset($_GET['mode'])  ? $_GET['mode']  : 'featured');

try {
    $db = getDB();

    $hasVideo   = false;
    $hasPremium = false;
    $hasSeller  = false;
    try { $db->query("SELECT video_url  FROM listings LIMIT 0"); $hasVideo   = true; } catch (Exception $e) {}
    try { $db->query("SELECT is_premium FROM listings LIMIT 0"); $hasPremium = true; } catch (Exception $e) {}
    try { $db->query("SELECT seller_id  FROM listings LIMIT 0"); $hasSeller  = true; } catch (Exception $e) {}

    $extraCols  = $hasVideo   ? ", IFNULL(l.video_url,'') AS video_url"  : ", '' AS video_url";
    $extraCols .= $hasPremium ? ", IFNULL(l.is_premium,0) AS is_premium" : ", 0 AS is_premium";
    $extraCols .= $hasSeller  ? ", l.seller_id"                          : ", NULL AS seller_id";

    /* Resolve category */
    $catStmt = $db->prepare("SELECT id FROM categories WHERE slug = ? LIMIT 1");
    $catStmt->execute(array($type));
    $catId = $catStmt->fetchColumn();
    if (!$catId) {
        echo json_encode(array('success'=>false,'error'=>'Unknown category: '.$type)); exit;
    }

    /* Build WHERE based on mode */
    $baseWhere = 'l.category_id = ? AND l.is_active = 1';
    $params    = array($catId);

    if ($mode === 'premium' && $hasPremium) {
        $filterWhere = $baseWhere . ' AND l.is_premium = 1';
        $orderSQL    = 'IFNULL(l.views,0) DESC, l.created_at DESC';
    } elseif ($mode === 'both' && $hasPremium) {
        $filterWhere = $baseWhere . ' AND (l.is_featured = 1 OR l.is_premium = 1)';
        $orderSQL    = 'IFNULL(l.is_featured,0) DESC, IFNULL(l.is_premium,0) DESC, IFNULL(l.views,0) DESC, l.created_at DESC';
    } elseif ($mode === 'popular') {
        $filterWhere = $baseWhere;
        $orderSQL    = 'IFNULL(l.views,0) DESC, l.created_at DESC';
    } else {
        /* default: featured */
        $filterWhere = $baseWhere . ' AND l.is_featured = 1';
        $orderSQL    = 'IFNULL(l.views,0) DESC, l.created_at DESC';
    }

    $stmt = $db->prepare(
        "SELECT l.id, l.title, l.description, l.price, l.location,
                l.image_url AS image,
                l.contact_phone, l.contact_name,
                IFNULL(l.badge,'')          AS badge,
                IFNULL(l.views,0)           AS views,
                l.rating,
                l.prep_time,
                IFNULL(l.sub_category,'')   AS sub_category,
                IFNULL(l.is_featured,0)     AS is_featured,
                l.created_at,
                c.slug AS type
                $extraCols
         FROM listings l
         JOIN categories c ON l.category_id = c.id
         WHERE $filterWhere
         ORDER BY $orderSQL
         LIMIT $limit"
    );
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    /*
     * Fallback: if no featured/premium items exist yet, return most-viewed.
     * This prevents an empty response during early stages of a new installation.
     */
    if (empty($rows) && $mode !== 'popular') {
        $fallback = $db->prepare(
            "SELECT l.id, l.title, l.description, l.price, l.location,
                    l.image_url AS image,
                    l.contact_phone, l.contact_name,
                    IFNULL(l.badge,'')          AS badge,
                    IFNULL(l.views,0)           AS views,
                    l.rating, l.prep_time,
                    IFNULL(l.sub_category,'')   AS sub_category,
                    IFNULL(l.is_featured,0)     AS is_featured,
                    l.created_at, c.slug AS type
                    $extraCols
             FROM listings l
             JOIN categories c ON l.category_id = c.id
             WHERE l.category_id = ? AND l.is_active = 1
             ORDER BY IFNULL(l.views,0) DESC, l.created_at DESC
             LIMIT $limit"
        );
        $fallback->execute(array($catId));
        $rows = $fallback->fetchAll(PDO::FETCH_ASSOC);
    }

    /* Attach images + features */
    $imgStmt  = $db->prepare("SELECT image_url FROM listing_images WHERE listing_id=? ORDER BY sort_order LIMIT 5");
    $featStmt = $db->prepare("SELECT icon, feature_text AS `text` FROM listing_features WHERE listing_id=? ORDER BY sort_order");

    foreach ($rows as &$row) {
        $imgStmt->execute(array($row['id']));
        $imgRows = $imgStmt->fetchAll(PDO::FETCH_ASSOC);
        $imgs = array();
        foreach ($imgRows as $ir) { $imgs[] = $ir['image_url']; }
        $row['images']    = !empty($imgs) ? $imgs : array($row['image']);

        $featStmt->execute(array($row['id']));
        $row['features']  = $featStmt->fetchAll(PDO::FETCH_ASSOC);

        $row['contact']   = array('phone'=>$row['contact_phone'],'name'=>$row['contact_name']);
        $row['has_video'] = (!empty($row['video_url']));
        $row['is_featured']=(bool)$row['is_featured'];
        $row['is_premium']= isset($row['is_premium']) ? (bool)$row['is_premium'] : false;
        $row['views']     = (int)$row['views'];

        unset($row['contact_phone'], $row['contact_name']);
    }
    unset($row);

    echo json_encode(array('success'=>true, 'data'=>$rows, 'meta'=>array('mode'=>$mode,'count'=>count($rows))));

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('success'=>false,'error'=>$e->getMessage()));
}