<?php
/**
 * api/recommended.php - PHP 5.6+ compatible
 * Smart-scored shop items
 */
header('Content-Type: application/json');

$dbPath = __DIR__ . '/../mh-portal-2026/db.php';
if (!file_exists($dbPath)) { $dbPath = __DIR__ . '/mh-portal-2026/db.php'; }
require_once $dbPath;

$limit  = min(60, max(6, (int)(isset($_GET['limit']) ? $_GET['limit'] : 24)));
$page   = max(1,  (int)(isset($_GET['page'])  ? $_GET['page']  : 1));
$offset = ($page - 1) * $limit;
$pMin   = max(0,  (int)(isset($_GET['pMin'])  ? $_GET['pMin']  : 0));
$pMax   = max(0,  (int)(isset($_GET['pMax'])  ? $_GET['pMax']  : 0));
$sub    = trim(isset($_GET['sub']) ? $_GET['sub'] : '');

try {
    $db = getDB();

    $where  = array("l.is_active = 1", "c.slug = 'items'");
    $params = array();

    if ($sub  !== '') { $where[] = 'l.sub_category = ?';                                                       $params[] = $sub; }
    if ($pMin > 0)    { $where[] = "CAST(REPLACE(REPLACE(l.price,'KSH ',''),',','') AS UNSIGNED) >= ?";       $params[] = $pMin; }
    if ($pMax > 0)    { $where[] = "CAST(REPLACE(REPLACE(l.price,'KSH ',''),',','') AS UNSIGNED) <= ?";       $params[] = $pMax; }

    $whereSQL = implode(' AND ', $where);

    $scoreSQL = "IFNULL(l.views,0) * 0.3
        + IF(IFNULL(l.is_featured,0)=1, 50, 0)
        + CASE
            WHEN l.badge LIKE '%🔥%' THEN 20
            WHEN l.badge LIKE '%👑%' THEN 18
            WHEN l.badge LIKE '%⭐%' THEN 15
            ELSE 5 END
        + GREATEST(0, 30 - DATEDIFF(NOW(), l.created_at))";

    $cntStmt = $db->prepare("SELECT COUNT(*) FROM listings l JOIN categories c ON l.category_id=c.id WHERE $whereSQL");
    $cntStmt->execute($params);
    $total = (int)$cntStmt->fetchColumn();

    $sql = "SELECT l.id, l.title, l.description, l.price, l.location,
                   l.image_url AS image, l.contact_phone, l.contact_name,
                   IFNULL(l.badge,'')      AS badge,
                   IFNULL(l.views,0)       AS views,
                   l.rating, l.sub_category AS subCategory,
                   IFNULL(l.is_featured,0) AS is_featured,
                   l.created_at, c.slug AS type,
                   ($scoreSQL) AS smart_score
            FROM listings l
            JOIN categories c ON l.category_id = c.id
            WHERE $whereSQL
            ORDER BY smart_score DESC
            LIMIT $limit OFFSET $offset";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $imgStmt  = $db->prepare("SELECT image_url FROM listing_images WHERE listing_id=? ORDER BY sort_order LIMIT 3");
    $featStmt = $db->prepare("SELECT icon, feature_text AS `text` FROM listing_features WHERE listing_id=? ORDER BY sort_order");

    foreach ($rows as &$row) {
        $imgStmt->execute(array($row['id']));
        $imgs = array();
        foreach ($imgStmt->fetchAll(PDO::FETCH_ASSOC) as $r) { $imgs[] = $r['image_url']; }
        $row['images']  = !empty($imgs) ? $imgs : array($row['image']);
        $row['contact'] = array('phone'=>$row['contact_phone'],'name'=>$row['contact_name']);
        $featStmt->execute(array($row['id']));
        $row['features'] = $featStmt->fetchAll(PDO::FETCH_ASSOC);
        unset($row['contact_phone'],$row['contact_name'],$row['smart_score']);
    }
    unset($row);

    echo json_encode(array(
        'success' => true,
        'data'    => $rows,
        'meta'    => array(
            'total' => $total, 'page'=>$page, 'limit'=>$limit,
            'pages' => max(1, (int)ceil($total/$limit)),
        ),
    ));

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('success'=>false,'error'=>$e->getMessage()));
}
