<?php
// admin/db.php — single place to change DB credentials
define('DB_HOST', '102.212.247.115');
define('DB_USER', 'hukhbjpu_odiedo');
define('DB_PASS', 'Emuriaodeke1436123.');  
define('DB_NAME', 'hukhbjpu_mh_portal_2026');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}
