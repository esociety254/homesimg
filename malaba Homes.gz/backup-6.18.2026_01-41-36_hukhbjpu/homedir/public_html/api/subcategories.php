<?php
/**
 * api/subcategories.php — PHP 5.6+ compatible
 * Returns the distinct non-null sub_category values for a given category,
 * ordered by listing count descending so the most-stocked appear first.
 *
 * GET ?type=items
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$dbPath = __DIR__ . '/../mh-portal-2026/db.php';
if (!file_exists($dbPath)) { $dbPath = __DIR__ . '/mh-portal-2026/db.php'; }
require_once $dbPath;

$type = trim(isset($_GET['type']) ? $_GET['type'] : 'items');

try {
    $db = getDB();

    /* Resolve slug → id */
    $catStmt = $db->prepare("SELECT id FROM categories WHERE slug = ? LIMIT 1");
    $catStmt->execute(array($type));
    $catId = $catStmt->fetchColumn();
    if (!$catId) {
        echo json_encode(array('success'=>false,'error'=>'Unknown category: '.$type)); exit;
    }

    /* Distinct sub_categories with item counts */
    $stmt = $db->prepare(
        "SELECT sub_category AS name, COUNT(*) AS item_count
         FROM listings
         WHERE category_id = ?
           AND is_active = 1
           AND sub_category IS NOT NULL
           AND TRIM(sub_category) != ''
         GROUP BY sub_category
         ORDER BY item_count DESC, sub_category ASC"
    );
    $stmt->execute(array($catId));
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $subs = array();
    foreach ($rows as $r) {
        $subs[] = array(
            'slug'  => strtolower(trim($r['name'])),
            'label' => $r['name'],
            'count' => (int)$r['item_count'],
        );
    }

    echo json_encode(array('success'=>true, 'data'=>$subs));

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('success'=>false,'error'=>$e->getMessage()));
}