<?php
/**
 * pwa_check.php — PWA Diagnostic Tool
 * Upload to public_html/pwa_check.php
 * Open in browser to see exactly what's wrong
 * DELETE this file after fixing everything
 */

// Check if files exist
$root = $_SERVER['DOCUMENT_ROOT'];
$checks = array(
  'manifest.json'          => file_exists($root.'/manifest.json'),
  'sw.js'                  => file_exists($root.'/sw.js'),
  'offline.html'           => file_exists($root.'/offline.html'),
  'icons/icon-192.png'     => file_exists($root.'/icons/icon-192.png'),
  'icons/icon-512.png'     => file_exists($root.'/icons/icon-512.png'),
  'icons/icon-144.png'     => file_exists($root.'/icons/icon-144.png'),
  'icons/icon-96.png'      => file_exists($root.'/icons/icon-96.png'),
  'pwa_head.php'           => file_exists($root.'/pwa_head.php'),
  'pwa_install_banner.php' => file_exists($root.'/pwa_install_banner.php'),
);

// Check HTTPS
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
           || $_SERVER['SERVER_PORT'] == 443
           || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');

// Check manifest is valid JSON
$manifestOk = false;
$manifestError = '';
if ($checks['manifest.json']) {
  $json = json_decode(file_get_contents($root.'/manifest.json'), true);
  if ($json) {
    $manifestOk = isset($json['name']) && isset($json['icons']) && isset($json['start_url']) && isset($json['display']);
    if (!$manifestOk) $manifestError = 'Missing required fields (name, icons, start_url or display)';
  } else {
    $manifestError = 'Invalid JSON — ' . json_last_error_msg();
  }
}

// Check sw.js is at root (not in subfolder)
$swUrl = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/sw.js';

// Check index.php includes pwa_head
$indexOk = false;
if (file_exists($root.'/index.php')) {
  $idx = file_get_contents($root.'/index.php');
  $indexOk = strpos($idx, 'pwa_head') !== false || strpos($idx, 'manifest.json') !== false;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PWA Check — Malaba Homes</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:system-ui,sans-serif;background:#080400;color:#F5F0EB;padding:20px;min-height:100vh;}
h1{font-size:20px;font-weight:800;color:#E8521A;margin-bottom:4px;}
.sub{font-size:12px;color:rgba(255,255,255,.4);margin-bottom:24px;}
.section{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:16px;margin-bottom:14px;}
.section h2{font-size:13px;font-weight:700;color:rgba(255,255,255,.5);letter-spacing:.5px;text-transform:uppercase;margin-bottom:12px;}
.check-row{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.05);}
.check-row:last-child{border-bottom:none;}
.icon{font-size:16px;flex-shrink:0;width:20px;}
.label{flex:1;font-size:13px;}
.status{font-size:11px;font-weight:700;padding:2px 8px;border-radius:8px;}
.ok{background:rgba(34,197,94,.15);color:#4ade80;}
.fail{background:rgba(239,68,68,.15);color:#fca5a5;}
.warn{background:rgba(245,158,11,.15);color:#fcd34d;}
.big-status{
  text-align:center;padding:18px;border-radius:14px;margin-bottom:14px;
  font-size:16px;font-weight:700;
}
.big-ok{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.25);color:#4ade80;}
.big-fail{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:#fca5a5;}
.fix-box{background:rgba(232,82,26,.08);border:1px solid rgba(232,82,26,.2);border-radius:12px;padding:14px;margin-top:10px;}
.fix-box h3{font-size:12px;font-weight:700;color:#FF7043;margin-bottom:8px;text-transform:uppercase;letter-spacing:.5px;}
.fix-box ul{padding-left:16px;font-size:13px;color:rgba(255,255,255,.6);line-height:1.9;}
code{background:rgba(255,255,255,.08);padding:2px 6px;border-radius:4px;font-size:11px;color:#FF7043;}
.debug-btn{
  display:block;width:100%;padding:12px;
  background:linear-gradient(135deg,#E8521A,#FF7043);
  color:#fff;border:none;border-radius:12px;
  font-size:15px;font-weight:700;font-family:inherit;
  cursor:pointer;margin-top:16px;
}
</style>
</head>
<body>

<h1>🔍 PWA Diagnostic — Malaba Homes</h1>
<p class="sub">Run this on your phone to find exactly what's wrong. Delete this file after fixing.</p>

<!-- Overall status -->
<?php
$allGood = $isHttps && $checks['manifest.json'] && $checks['sw.js']
           && $checks['icons/icon-192.png'] && $checks['icons/icon-512.png']
           && $manifestOk && $indexOk;
if ($allGood):
?>
<div class="big-status big-ok">✅ PWA is correctly configured!</div>
<?php else: ?>
<div class="big-status big-fail">❌ Issues found — see below to fix</div>
<?php endif; ?>

<!-- HTTPS Check -->
<div class="section">
  <h2>🔒 HTTPS (Required for PWA)</h2>
  <div class="check-row">
    <span class="icon"><?= $isHttps ? '✅' : '❌' ?></span>
    <span class="label">Site is running on HTTPS</span>
    <span class="status <?= $isHttps ? 'ok' : 'fail' ?>"><?= $isHttps ? 'OK' : 'FAIL' ?></span>
  </div>
  <?php if (!$isHttps): ?>
  <div class="fix-box">
    <h3>How to fix</h3>
    <ul>
      <li>In cPanel → <strong>SSL/TLS</strong> → install a free Let's Encrypt certificate</li>
      <li>Or in cPanel → <strong>AutoSSL</strong> → Run AutoSSL</li>
      <li>Then visit your site with <code>https://</code> not <code>http://</code></li>
      <li>PWA will NOT work without HTTPS — this is the #1 reason</li>
    </ul>
  </div>
  <?php endif; ?>
</div>

<!-- Files check -->
<div class="section">
  <h2>📁 Required Files</h2>
  <?php foreach ($checks as $file => $exists): ?>
  <div class="check-row">
    <span class="icon"><?= $exists ? '✅' : '❌' ?></span>
    <span class="label"><code>/<?= $file ?></code></span>
    <span class="status <?= $exists ? 'ok' : 'fail' ?>"><?= $exists ? 'Found' : 'MISSING' ?></span>
  </div>
  <?php endforeach; ?>

  <?php
  $missingFiles = array_filter($checks, function($v){ return !$v; });
  if (!empty($missingFiles)):
  ?>
  <div class="fix-box">
    <h3>Missing files — upload these to public_html</h3>
    <ul>
      <?php foreach ($missingFiles as $f => $v): ?>
      <li>Upload <code><?= $f ?></code> to <code>public_html/<?= $f ?></code></li>
      <?php endforeach; ?>
      <li>For icons: open <code>generate_icons.html</code> in Chrome, download all icons, create <code>public_html/icons/</code> folder, upload icons there</li>
    </ul>
  </div>
  <?php endif; ?>
</div>

<!-- Manifest check -->
<div class="section">
  <h2>📋 Manifest Quality</h2>
  <div class="check-row">
    <span class="icon"><?= $manifestOk ? '✅' : '❌' ?></span>
    <span class="label">manifest.json is valid</span>
    <span class="status <?= $manifestOk ? 'ok' : 'fail' ?>"><?= $manifestOk ? 'Valid' : 'Invalid' ?></span>
  </div>
  <?php if ($manifestError): ?>
  <div class="fix-box">
    <h3>Manifest error</h3>
    <ul><li><?= htmlspecialchars($manifestError) ?></li></ul>
  </div>
  <?php endif; ?>
  <?php if ($manifestOk): ?>
  <div class="check-row">
    <span class="icon">✅</span>
    <span class="label">Has name, icons, start_url, display</span>
    <span class="status ok">OK</span>
  </div>
  <?php endif; ?>
</div>

<!-- index.php check -->
<div class="section">
  <h2>📄 index.php Integration</h2>
  <div class="check-row">
    <span class="icon"><?= $indexOk ? '✅' : '❌' ?></span>
    <span class="label">pwa_head.php is included in index.php</span>
    <span class="status <?= $indexOk ? 'ok' : 'fail' ?>"><?= $indexOk ? 'Found' : 'MISSING' ?></span>
  </div>
  <?php if (!$indexOk): ?>
  <div class="fix-box">
    <h3>How to fix</h3>
    <ul>
      <li>Open <code>index.php</code> in cPanel File Manager</li>
      <li>Find <code>&lt;head&gt;</code> at the top</li>
      <li>Add this right after it: <code>&lt;?php include 'pwa_head.php'; ?&gt;</code></li>
      <li>Do the same for ALL your PHP pages</li>
    </ul>
  </div>
  <?php endif; ?>
</div>

<!-- SW URL check -->
<div class="section">
  <h2>⚙️ Service Worker Location</h2>
  <div class="check-row">
    <span class="icon"><?= $checks['sw.js'] ? '✅' : '❌' ?></span>
    <span class="label">sw.js URL: <code><?= htmlspecialchars($swUrl) ?></code></span>
    <span class="status <?= $checks['sw.js'] ? 'ok' : 'fail' ?>"><?= $checks['sw.js'] ? 'Found' : 'MISSING' ?></span>
  </div>
  <div class="check-row">
    <span class="icon">⚠️</span>
    <span class="label">sw.js MUST be at root, not in a subfolder</span>
    <span class="status warn">Check</span>
  </div>
</div>

<!-- Oppo/Android specific -->
<div class="section">
  <h2>📱 Oppo / Android Specific Fixes</h2>
  <div class="check-row">
    <span class="icon">ℹ️</span>
    <span class="label">Your browser</span>
    <span class="status warn" style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:9px;"
      id="browserLabel">Detecting...</span>
  </div>
  <div class="fix-box">
    <h3>Oppo phone — "Added but not on home screen" fix</h3>
    <ul>
      <li><strong>Use Chrome browser</strong> on your Oppo — not the built-in Oppo browser</li>
      <li>In Chrome, tap the <strong>3-dot menu (⋮)</strong> top right</li>
      <li>Tap <strong>"Add to Home screen"</strong> or <strong>"Install app"</strong></li>
      <li>If it says "Added" but icon doesn't appear: <strong>swipe all home screen pages</strong> — Oppo sometimes adds it to a different page</li>
      <li>Also check your <strong>App Drawer</strong> (swipe up from home screen)</li>
      <li>If still missing: Settings → Apps → Chrome → check if "Add shortcuts" permission is enabled</li>
      <li>Last resort: long-press on home screen → tap <strong>"Add widget"</strong> or <strong>"Shortcuts"</strong></li>
    </ul>
  </div>
</div>

<!-- JS diagnostic -->
<div class="section">
  <h2>🔧 Live Browser Check</h2>
  <div id="jsDiag">Running checks...</div>
</div>

<button class="debug-btn" onclick="runDebug()">🔄 Re-run All Checks</button>

<script>
document.getElementById('browserLabel').textContent = navigator.userAgent.substring(0,60)+'...';

function runDebug() {
  var diag = document.getElementById('jsDiag');
  var results = [];

  /* Service Worker support */
  results.push(row('serviceWorker' in navigator, 'Service Worker supported by this browser'));

  /* HTTPS */
  results.push(row(location.protocol === 'https:', 'Page loaded over HTTPS'));

  /* Manifest linked */
  var mLink = document.querySelector('link[rel="manifest"]');
  results.push(row(!!mLink, 'manifest.json is linked in <head>', mLink ? mLink.href : 'Not found'));

  /* SW registered */
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistration('/').then(function(reg) {
      var swRow = document.createElement('div');
      swRow.className = 'check-row';
      if (reg) {
        swRow.innerHTML = '<span class="icon">✅</span><span class="label">Service Worker is registered</span><span class="status ok">Active</span>';
      } else {
        swRow.innerHTML = '<span class="icon">❌</span><span class="label">Service Worker is NOT registered</span><span class="status fail">Not registered — check sw.js is at root and HTTPS is on</span>';
      }
      diag.appendChild(swRow);
    });
  }

  /* beforeinstallprompt */
  results.push(rowInfo(
    'display-mode: ' + (window.matchMedia('(display-mode: standalone)').matches ? 'standalone (already installed!)' : 'browser (not installed yet)')
  ));

  /* Render */
  diag.innerHTML = results.join('');

  /* Check manifest fetch */
  var xhr = new XMLHttpRequest();
  xhr.open('GET', '/manifest.json', true);
  xhr.onload = function() {
    var r = document.createElement('div');
    r.className = 'check-row';
    if (xhr.status === 200) {
      try {
        JSON.parse(xhr.responseText);
        r.innerHTML = '<span class="icon">✅</span><span class="label">manifest.json fetches correctly (HTTP 200, valid JSON)</span><span class="status ok">OK</span>';
      } catch(e) {
        r.innerHTML = '<span class="icon">❌</span><span class="label">manifest.json is invalid JSON: '+e.message+'</span><span class="status fail">FAIL</span>';
      }
    } else {
      r.innerHTML = '<span class="icon">❌</span><span class="label">manifest.json returned HTTP '+xhr.status+'</span><span class="status fail">FAIL</span>';
    }
    diag.appendChild(r);
  };
  xhr.send();
}

function row(ok, label, detail) {
  return '<div class="check-row">' +
    '<span class="icon">'+(ok?'✅':'❌')+'</span>' +
    '<span class="label">'+label+(detail?' — <code>'+detail+'</code>':'')+'</span>' +
    '<span class="status '+(ok?'ok':'fail')+'">'+(ok?'OK':'FAIL')+'</span>' +
    '</div>';
}
function rowInfo(label) {
  return '<div class="check-row">' +
    '<span class="icon">ℹ️</span>' +
    '<span class="label">'+label+'</span>' +
    '<span class="status warn">Info</span>' +
    '</div>';
}

runDebug();
</script>
</body>
</html>