/**
 * MALABA HOMES — DATA LAYER
 * ============================================================
 * This file is the bridge between the PHP/MySQL backend and
 * the JavaScript frontend. In development it falls back to
 * static seed data. In production every call hits /api/*.php
 *
 * Usage (anywhere in the frontend):
 *   const items = await MalabaAPI.getListings('houses');
 *   const item  = await MalabaAPI.getListingById('h1');
 * ============================================================
 */

const MalabaAPI = (() => {

  /* ── Config ── */
  const BASE = '/api';          // adjust if your api/ folder is elsewhere
  const CACHE_TTL = 2 * 60 * 1000;  // 2-minute client cache
  const _cache = {};

  /* ── Internals ── */
  async function _fetch(url) {
    const now = Date.now();
    if (_cache[url] && now - _cache[url].ts < CACHE_TTL) return _cache[url].data;
    try {
      const res  = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      _cache[url] = { data, ts: now };
      return data;
    } catch (err) {
      console.warn(`[MalabaAPI] ${url} failed, using fallback`, err.message);
      return null;
    }
  }

  /* ── Public API ── */

  /**
   * Get listings by category: 'houses' | 'food' | 'items'
   * @param {string} type
   * @param {object} opts  { page, limit, search, sort, priceMin, priceMax, filter }
   */
  async function getListings(type, opts = {}) {
    const params = new URLSearchParams({ type, ...opts }).toString();
    const remote = await _fetch(`${BASE}/listings.php?${params}`);
    if (remote?.success) return remote.data;
    // Fallback to bundled seed data
    return _seed[type] || [];
  }

  /**
   * Get a single listing by id
   */
  async function getListingById(id) {
    const remote = await _fetch(`${BASE}/listing.php?id=${encodeURIComponent(id)}`);
    if (remote?.success) return remote.data;
    // Fallback
    for (const cat of Object.values(_seed)) {
      const found = cat.find(i => i.id === String(id));
      if (found) return found;
    }
    return null;
  }

  /**
   * Search across all categories
   */
  async function search(query) {
    const remote = await _fetch(`${BASE}/search.php?q=${encodeURIComponent(query)}`);
    if (remote?.success) return remote.data;
    const q = query.toLowerCase();
    return Object.values(_seed).flat().filter(i =>
      i.title.toLowerCase().includes(q) ||
      i.description.toLowerCase().includes(q) ||
      i.location.toLowerCase().includes(q)
    );
  }

  /**
   * Get featured / trending items for a category
   */
  async function getFeatured(type, limit = 6) {
    const remote = await _fetch(`${BASE}/featured.php?type=${type}&limit=${limit}`);
    if (remote?.success) return remote.data;
    return (_seed[type] || []).slice(0, limit);
  }

  /**
   * Smart shop recommendations — scored algorithm
   * Combines: recency, views, price range affinity, category match
   * Falls back to local scoring when API is unavailable
   */
  async function getRecommended(opts = {}) {
    const { limit = 20, exclude = [], history = [] } = opts;
    const remote = await _fetch(`${BASE}/recommended.php?limit=${limit}`);
    if (remote?.success) return remote.data;

    // Client-side scoring fallback
    return _scoreItems(_seed.items || [], { exclude, history, limit });
  }

  /**
   * Log an inquiry (fire-and-forget)
   */
  async function logInquiry(payload) {
    try {
      await fetch(`${BASE}/inquiry.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        body: JSON.stringify(payload)
      });
    } catch (_) {}
  }

  /* ── Smart Scoring Algorithm ── */
  function _scoreItems(items, { exclude = [], history = [], limit = 20 } = {}) {
    const now    = Date.now();
    const viewed = JSON.parse(localStorage.getItem('mh_viewed') || '[]');
    const prefs  = _inferPrefs(history.concat(viewed));

    return items
      .filter(i => !exclude.includes(i.id))
      .map(i => {
        let score = 50;

        // Recency boost (newer items win)
        if (i.created_at) {
          const age = (now - new Date(i.created_at).getTime()) / 86400000;
          score += Math.max(0, 20 - age);
        }

        // Price affinity (items close to user's typical spend score higher)
        if (prefs.avgPrice > 0) {
          const itemPrice = _parsePrice(i.price);
          const diff      = Math.abs(itemPrice - prefs.avgPrice) / prefs.avgPrice;
          score += Math.max(0, 15 - diff * 30);
        }

        // Popularity proxy (views from seed)
        score += (i.views || 0) * 0.1;

        // Category affinity
        if (prefs.topCat && i.subCategory === prefs.topCat) score += 12;

        // Not seen recently → boost discovery
        if (!viewed.includes(i.id)) score += 8;

        // Has multiple images → quality signal
        if ((i.images || []).length > 1) score += 5;

        return { ...i, _score: score };
      })
      .sort((a, b) => b._score - a._score)
      .slice(0, limit);
  }

  function _inferPrefs(history) {
    if (!history.length) return { avgPrice: 0, topCat: null };
    const prices = history.map(id => {
      const item = Object.values(_seed).flat().find(i => i.id === id);
      return item ? _parsePrice(item.price) : 0;
    }).filter(Boolean);
    const cats   = history.map(id => {
      const item = Object.values(_seed).flat().find(i => i.id === id);
      return item?.subCategory || null;
    }).filter(Boolean);
    const catFreq = cats.reduce((acc, c) => { acc[c] = (acc[c]||0)+1; return acc; }, {});
    const topCat  = Object.entries(catFreq).sort((a,b)=>b[1]-a[1])[0]?.[0] || null;
    return {
      avgPrice: prices.length ? prices.reduce((a,b)=>a+b,0)/prices.length : 0,
      topCat
    };
  }

  function _parsePrice(str) {
    const n = parseInt((str || '').replace(/[^0-9]/g, ''));
    return isNaN(n) ? 0 : n;
  }

  /* ── Track a viewed item (for recommendation engine) ── */
  function trackView(id) {
    const viewed = JSON.parse(localStorage.getItem('mh_viewed') || '[]');
    if (!viewed.includes(id)) {
      viewed.unshift(id);
      localStorage.setItem('mh_viewed', JSON.stringify(viewed.slice(0, 50)));
    }
    // Async ping to backend
    fetch(`${BASE}/track.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
      body: JSON.stringify({ id, event: 'view', ts: Date.now() })
    }).catch(() => {});
  }

  /* ══════════════════════════════════════════════════
     SEED DATA — replaces old data.js static object
     Production: this is always overridden by the API
     ══════════════════════════════════════════════════ */
  const _seed = {
    houses: [
      {
        id: 'h1', type: 'houses',
        title: '2 Bedroom Apartment',
        description: 'Modern apartment with spacious rooms, kitchen, and bathroom. Close to town center.',
        price: 'KSH 15,000/month', location: 'Downtown, Malaba',
        image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=80',
        images: [
          'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=80',
          'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80',
          'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80'
        ],
        features: [
          { icon: '🛏️', text: '2 Bedrooms' }, { icon: '🚿', text: '1 Bathroom' },
          { icon: '🍳', text: 'Kitchen included' }, { icon: '💡', text: 'All utilities' }
        ],
        contact: { phone: '254712345678', name: 'John Kamau' },
        badge: 'Popular', created_at: '2025-01-10'
      },
      {
        id: 'h2', type: 'houses',
        title: 'Studio Apartment',
        description: 'Cozy studio perfect for students or young professionals. Secure compound with 24/7 security.',
        price: 'KSH 8,000/month', location: 'Westlands, Malaba',
        image: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80',
        images: [
          'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80',
          'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=80'
        ],
        features: [
          { icon: '🛏️', text: '1 Room' }, { icon: '🚿', text: 'Shared bathroom' },
          { icon: '🔒', text: '24/7 Security' }, { icon: '💧', text: 'Water included' }
        ],
        contact: { phone: '254723456789', name: 'Mary Wanjiku' },
        badge: 'Budget', created_at: '2025-01-15'
      },
      {
        id: 'h3', type: 'houses',
        title: '3 Bedroom House',
        description: 'Spacious family home with garden and parking. Quiet neighborhood, close to schools.',
        price: 'KSH 35,000/month', location: 'Karen, Malaba',
        image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80',
        images: [
          'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80',
          'https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=800&q=80'
        ],
        features: [
          { icon: '🛏️', text: '3 Bedrooms' }, { icon: '🚿', text: '2 Bathrooms' },
          { icon: '🌳', text: 'Garden' }, { icon: '🚗', text: 'Parking space' }
        ],
        contact: { phone: '254734567890', name: 'Peter Ochieng' },
        badge: 'Family Home', created_at: '2025-01-05'
      }
    ],

    food: [
      {
        id: 'f1', type: 'food',
        title: 'Chicken Burger Combo',
        description: 'Juicy grilled chicken burger with fries, coleslaw, and a soft drink.',
        price: 'KSH 450', location: "Mama's Kitchen, CBD",
        image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80',
        images: [
          'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80',
          'https://images.unsplash.com/photo-1550547660-d9450f859349?w=800&q=80'
        ],
        features: [
          { icon: '🍗', text: 'Grilled chicken' }, { icon: '🍟', text: 'French fries' },
          { icon: '🥗', text: 'Coleslaw' }, { icon: '🥤', text: 'Soft drink' }
        ],
        contact: { phone: '254745678901', name: "Mama's Kitchen" },
        prepTime: '15–20 min', badge: '🔥 Bestseller', rating: 4.8, created_at: '2025-01-01'
      },
      {
        id: 'f2', type: 'food',
        title: 'Beef Pilau & Kachumbari',
        description: 'Traditional Kenyan pilau cooked with tender beef, served with fresh kachumbari salad.',
        price: 'KSH 350', location: 'Swahili Delights, Eastleigh',
        image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80'],
        features: [
          { icon: '🍚', text: 'Spiced rice' }, { icon: '🥩', text: 'Tender beef' },
          { icon: '🥗', text: 'Kachumbari' }, { icon: '🌶️', text: 'Authentic spices' }
        ],
        contact: { phone: '254756789012', name: 'Swahili Delights' },
        prepTime: '20–25 min', badge: '⭐ Local Fave', rating: 4.6, created_at: '2025-01-02'
      },
      {
        id: 'f3', type: 'food',
        title: 'Vegetable Samosas (10 pcs)',
        description: 'Crispy golden samosas filled with spiced vegetables. Perfect snack for any time!',
        price: 'KSH 150', location: 'Spice Corner, Ngara',
        image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80'],
        features: [
          { icon: '🥟', text: '10 pieces' }, { icon: '🥬', text: 'Fresh vegetables' },
          { icon: '🔥', text: 'Hot & crispy' }, { icon: '🌱', text: 'Vegetarian' }
        ],
        contact: { phone: '254767890123', name: 'Spice Corner' },
        prepTime: '10 min', badge: '⚡ Quick', rating: 4.5, created_at: '2025-01-08'
      },
      {
        id: 'f4', type: 'food',
        title: 'Nyama Choma Platter',
        description: 'Half kilo of grilled meat with ugali, kachumbari and sukuma wiki. A Kenyan favorite!',
        price: 'KSH 800', location: 'Carnivore Junction, Langata',
        image: 'https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=800&q=80'],
        features: [
          { icon: '🥩', text: '500g grilled meat' }, { icon: '🍞', text: 'Ugali' },
          { icon: '🥗', text: 'Kachumbari' }, { icon: '🥬', text: 'Sukuma wiki' }
        ],
        contact: { phone: '254778901234', name: 'Carnivore Junction' },
        prepTime: '25–30 min', badge: '👑 Premium', rating: 4.9, created_at: '2025-01-03'
      }
    ],

    items: [
      /* ── KITCHEN ── */
      {
        id: 'i1', type: 'items', subCategory: 'kitchen', sub_category: 'kitchen',
        title: 'Non-Stick Cooking Set (5 Piece)',
        description: '5-piece non-stick cookware set including frying pan, saucepans and lids. Dishwasher safe.',
        price: 'KSH 3,500', location: 'HomeGoods Store, Westlands',
        image: 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=800&q=80','https://images.unsplash.com/photo-1556909212-d5b604d0c90d?w=800&q=80'],
        features: [{ icon: '🍳', text: '5-piece set' },{ icon: '✨', text: 'Non-stick coating' },{ icon: '🔥', text: 'Heat resistant' },{ icon: '🧼', text: 'Easy to clean' }],
        contact: { phone: '254789012345', name: 'HomeGoods Store' },
        badge: '⭐ Top Pick', views: 240, is_featured: 1, created_at: '2025-01-12'
      },
      {
        id: 'i10', type: 'items', subCategory: 'kitchen', sub_category: 'kitchen',
        title: 'Wooden Spoon & Spatula Set',
        description: 'Pack of 6 wooden kitchen utensils. Heat resistant, safe for all cookware.',
        price: 'KSH 450', location: 'Kitchen Depot, CBD',
        image: 'https://images.unsplash.com/photo-1556909212-d5b604d0c90d?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1556909212-d5b604d0c90d?w=800&q=80'],
        features: [{ icon: '🥄', text: '6 pieces' },{ icon: '🌿', text: 'Natural wood' },{ icon: '🔥', text: 'Heat safe' }],
        contact: { phone: '254789012399', name: 'Kitchen Depot' },
        badge: '🌿 Natural', views: 120, created_at: '2025-01-20'
      },
      {
        id: 'i11', type: 'items', subCategory: 'kitchen', sub_category: 'kitchen',
        title: 'Stainless Steel Mixing Bowls',
        description: 'Set of 3 nesting stainless steel mixing bowls. Ideal for baking and prep work.',
        price: 'KSH 900', location: 'HomeGoods Store, Westlands',
        image: 'https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&q=80'],
        features: [{ icon: '🥣', text: '3 sizes' },{ icon: '✨', text: 'Stainless steel' },{ icon: '🧊', text: 'Dishwasher safe' }],
        contact: { phone: '254789012345', name: 'HomeGoods Store' },
        views: 88, created_at: '2025-02-01'
      },

      /* ── DECOR ── */
      {
        id: 'i2', type: 'items', subCategory: 'decor', sub_category: 'decor',
        title: 'Wall Art Canvas Set (3 Piece)',
        description: 'Beautiful 3-piece canvas wall art to brighten up your living room or bedroom.',
        price: 'KSH 2,800', location: 'Decor Haven, Karen',
        image: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=800&q=80'],
        features: [{ icon: '🖼️', text: '3-piece set' },{ icon: '🎨', text: 'Modern design' },{ icon: '📏', text: '40×60cm each' }],
        contact: { phone: '254790123456', name: 'Decor Haven' },
        badge: '🎨 Trending', views: 180, is_featured: 1, created_at: '2025-01-14'
      },
      {
        id: 'i12', type: 'items', subCategory: 'decor', sub_category: 'decor',
        title: 'Decorative Throw Pillow Covers',
        description: '4 pack of modern geometric throw pillow covers. Fits 45×45cm inserts.',
        price: 'KSH 1,100', location: 'Decor Haven, Karen',
        image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&q=80'],
        features: [{ icon: '🛋', text: '4 covers' },{ icon: '🧵', text: 'Cotton blend' },{ icon: '🎨', text: 'Geometric print' }],
        contact: { phone: '254790123456', name: 'Decor Haven' },
        views: 95, created_at: '2025-01-25'
      },
      {
        id: 'i13', type: 'items', subCategory: 'decor', sub_category: 'decor',
        title: 'Scented Soy Candle Set',
        description: 'Set of 3 hand-poured soy candles in lavender, vanilla and eucalyptus scents.',
        price: 'KSH 850', location: 'Aroma Corner, Kilimani',
        image: 'https://images.unsplash.com/photo-1603006905003-be475563bc59?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1603006905003-be475563bc59?w=800&q=80'],
        features: [{ icon: '🕯', text: '3 candles' },{ icon: '🌿', text: 'Soy wax' },{ icon: '✨', text: '40hr burn time' }],
        contact: { phone: '254790123488', name: 'Aroma Corner' },
        views: 67, created_at: '2025-02-05'
      },

      /* ── APPLIANCES ── */
      {
        id: 'i3', type: 'items', subCategory: 'appliances', sub_category: 'appliances',
        title: 'Electric Kettle 1.8L',
        description: 'Fast-boiling electric kettle with auto shut-off. Energy efficient and safe.',
        price: 'KSH 1,200', location: 'Tech Appliances, CBD',
        image: 'https://images.unsplash.com/photo-1563297007-0686b7003af7?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1563297007-0686b7003af7?w=800&q=80'],
        features: [{ icon: '⚡', text: '1800W power' },{ icon: '💧', text: '1.8L capacity' },{ icon: '🔒', text: 'Auto shut-off' }],
        contact: { phone: '254701234567', name: 'Tech Appliances' },
        badge: '🔥 Hot Deal', views: 310, is_featured: 1, created_at: '2025-01-16'
      },
      {
        id: 'i14', type: 'items', subCategory: 'appliances', sub_category: 'appliances',
        title: 'Handheld Blender 300W',
        description: 'Immersion blender with stainless steel blade. Perfect for soups, smoothies and sauces.',
        price: 'KSH 2,200', location: 'Tech Appliances, CBD',
        image: 'https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=800&q=80'],
        features: [{ icon: '⚡', text: '300W motor' },{ icon: '🔧', text: 'Detachable blade' },{ icon: '✅', text: '1yr warranty' }],
        contact: { phone: '254701234567', name: 'Tech Appliances' },
        views: 145, created_at: '2025-01-28'
      },
      {
        id: 'i15', type: 'items', subCategory: 'appliances', sub_category: 'appliances',
        title: 'Table Fan 16 inch',
        description: '3-speed table fan with oscillation. Quiet motor, ideal for bedroom or office.',
        price: 'KSH 1,800', location: 'Cool Breeze Electronics, Ngara',
        image: 'https://images.unsplash.com/photo-1551184451-76b762117ea6?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1551184451-76b762117ea6?w=800&q=80'],
        features: [{ icon: '💨', text: '3 speeds' },{ icon: '🔄', text: 'Oscillates 80°' },{ icon: '🔇', text: 'Quiet motor' }],
        contact: { phone: '254701234590', name: 'Cool Breeze Electronics' },
        views: 210, created_at: '2025-02-03'
      },

      /* ── STORAGE ── */
      {
        id: 'i4', type: 'items', subCategory: 'storage', sub_category: 'storage',
        title: 'Bamboo Storage Baskets (Set of 3)',
        description: 'Handwoven bamboo baskets in 3 sizes. Eco-friendly and stylish for any room.',
        price: 'KSH 1,800', location: 'Eco Living, Kilimani',
        image: 'https://images.unsplash.com/photo-1567880905822-56f8e06fe630?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1567880905822-56f8e06fe630?w=800&q=80'],
        features: [{ icon: '🧺', text: '3 different sizes' },{ icon: '🌿', text: 'Handwoven bamboo' },{ icon: '♻️', text: 'Eco-friendly' }],
        contact: { phone: '254712345670', name: 'Eco Living' },
        badge: '🌱 Eco', views: 95, created_at: '2025-01-09'
      },
      {
        id: 'i16', type: 'items', subCategory: 'storage', sub_category: 'storage',
        title: 'Stackable Plastic Storage Boxes',
        description: 'Set of 5 clear stackable boxes with lids. Ideal for clothes, toys, documents.',
        price: 'KSH 1,500', location: 'Organise It, Westlands',
        image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80'],
        features: [{ icon: '📦', text: '5 boxes' },{ icon: '👁', text: 'Clear lid' },{ icon: '🔢', text: 'Stackable' }],
        contact: { phone: '254712345699', name: 'Organise It' },
        views: 77, created_at: '2025-01-30'
      },

      /* ── FURNITURE ── */
      {
        id: 'i5', type: 'items', subCategory: 'furniture', sub_category: 'furniture',
        title: 'Foldable Study Chair',
        description: 'Comfortable padded foldable chair. Great for studying, dining or extra seating.',
        price: 'KSH 4,500', location: 'FurniturePlus, Industrial Area',
        image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&q=80'],
        features: [{ icon: '🪑', text: 'Padded seat' },{ icon: '📐', text: 'Foldable' },{ icon: '⚖', text: 'Up to 120kg' }],
        contact: { phone: '254756789011', name: 'FurniturePlus' },
        badge: '🏠 Home Pick', views: 133, is_featured: 1, created_at: '2025-01-18'
      },
      {
        id: 'i17', type: 'items', subCategory: 'furniture', sub_category: 'furniture',
        title: 'Wooden Bedside Table',
        description: 'Compact bedside table with 2 drawers. Easy to assemble, fits any bedroom.',
        price: 'KSH 5,800', location: 'FurniturePlus, Industrial Area',
        image: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=800&q=80'],
        features: [{ icon: '🪵', text: 'Solid wood' },{ icon: '🗃', text: '2 drawers' },{ icon: '🔧', text: 'Easy assembly' }],
        contact: { phone: '254756789011', name: 'FurniturePlus' },
        views: 98, created_at: '2025-02-07'
      },

      /* ── LIGHTING ── */
      {
        id: 'i6', type: 'items', subCategory: 'lighting', sub_category: 'lighting',
        title: 'LED Desk Lamp with USB Port',
        description: 'Touch-dimming LED lamp with 3 colour modes and a USB charging port. Eye-care friendly.',
        price: 'KSH 1,350', location: 'Bright Ideas, CBD',
        image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1513694203232-719a280e022f?w=800&q=80'],
        features: [{ icon: '💡', text: 'Touch dimmer' },{ icon: '🎨', text: '3 colour modes' },{ icon: '🔌', text: 'USB charging' }],
        contact: { phone: '254745678911', name: 'Bright Ideas' },
        badge: '⚡ Popular', views: 175, is_featured: 1, created_at: '2025-01-22'
      },
      {
        id: 'i18', type: 'items', subCategory: 'lighting', sub_category: 'lighting',
        title: 'Solar Garden String Lights (10m)',
        description: '10 metre solar-powered string lights with 100 LEDs. Waterproof, auto dusk-to-dawn.',
        price: 'KSH 980', location: 'Solar Shop, Karen',
        image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80'],
        features: [{ icon: '☀️', text: 'Solar powered' },{ icon: '💧', text: 'Waterproof' },{ icon: '🌙', text: 'Auto on/off' }],
        contact: { phone: '254745678922', name: 'Solar Shop' },
        views: 112, created_at: '2025-02-10'
      },

      /* ── CLEANING ── */
      {
        id: 'i7', type: 'items', subCategory: 'cleaning', sub_category: 'cleaning',
        title: 'Microfibre Cleaning Cloth Bundle',
        description: '12-pack ultra-soft microfibre cloths. Lint-free, suitable for all surfaces.',
        price: 'KSH 600', location: 'CleanMaster, CBD',
        image: 'https://images.unsplash.com/photo-1563453392212-326f5e854473?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1563453392212-326f5e854473?w=800&q=80'],
        features: [{ icon: '🧹', text: '12 cloths' },{ icon: '🪣', text: 'Lint-free' },{ icon: '♻️', text: 'Reusable' }],
        contact: { phone: '254789012366', name: 'CleanMaster' },
        views: 88, created_at: '2025-01-27'
      },
      {
        id: 'i19', type: 'items', subCategory: 'cleaning', sub_category: 'cleaning',
        title: 'Spin Mop with Bucket',
        description: 'Self-wringing spin mop with 360° rotation head. Includes 2 replacement heads.',
        price: 'KSH 2,100', location: 'CleanMaster, CBD',
        image: 'https://images.unsplash.com/photo-1527515545081-5db817172677?w=800&q=80',
        images: ['https://images.unsplash.com/photo-1527515545081-5db817172677?w=800&q=80'],
        features: [{ icon: '🪣', text: 'With bucket' },{ icon: '🔄', text: '360° rotation' },{ icon: '🧻', text: '2 spare heads' }],
        contact: { phone: '254789012366', name: 'CleanMaster' },
        badge: '🔥 Bestseller', views: 195, created_at: '2025-01-15'
      }
    ]
  };

  /* Legacy compatibility — keeps old code that calls getListingById() working */
  window.getListingById = function(id) {
    for (const cat of Object.values(_seed)) {
      const f = cat.find(i => i.id === String(id));
      if (f) return f;
    }
    return null;
  };
  window.getListingsByType = (type) => _seed[type] || [];
  window.listings = _seed;

  return { getListings, getListingById, search, getFeatured, getRecommended, logInquiry, trackView, _seed };
})();