// ============================================
// MALABA HOMES - ENHANCED INTERACTIONS
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    initParallaxEffect();
    initCategoryCards();
    initSmoothScroll();
    initNavbar();
});

// ============================================
// PARALLAX EFFECT ON HERO
// ============================================
function initParallaxEffect() {
    const hero = document.querySelector('.hero');
    const heroContent = document.querySelector('.hero-content');
    const aerialView = document.querySelector('.aerial-gif');
    const orbs = document.querySelectorAll('.gradient-orb');
    
    if (!hero) return;
    
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const rate = scrolled * 0.5;
        
        // Parallax on aerial view
        if (aerialView) {
            aerialView.style.transform = `translateY(${rate * 0.3}px) scale(1.1)`;
        }
        
        // Fade out hero content on scroll
        if (heroContent) {
            const opacity = 1 - (scrolled / 600);
            heroContent.style.opacity = Math.max(0, opacity);
            heroContent.style.transform = `translateY(${scrolled * 0.3}px)`;
        }
        
        // Move orbs
        orbs.forEach((orb, index) => {
            const speed = (index + 1) * 0.2;
            orb.style.transform = `translate(${scrolled * speed * 0.1}px, ${scrolled * speed * 0.15}px)`;
        });
    });
}

// ============================================
// CATEGORY CARDS INTERACTIONS
// ============================================
function initCategoryCards() {
    const cards = document.querySelectorAll('.category-card');
    
    cards.forEach(card => {
        // Magnetic effect on mouse move
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const moveX = (x - centerX) / 20;
            const moveY = (y - centerY) / 20;
            
            card.style.transform = `translate(${moveX}px, ${moveY}px) scale(1.02)`;
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = '';
        });
        
        // Add ripple effect on click
        card.addEventListener('click', function(e) {
            createRipple(e, this);
        });
        
        // Add hover sound effect (subtle)
        card.addEventListener('mouseenter', () => {
            // You can add a subtle sound here if desired
            card.classList.add('hovered');
        });
        
        card.addEventListener('mouseleave', () => {
            card.classList.remove('hovered');
        });
    });
}

// ============================================
// RIPPLE EFFECT
// ============================================
function createRipple(event, element) {
    const ripple = document.createElement('div');
    const rect = element.getBoundingClientRect();
    
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.style.position = 'absolute';
    ripple.style.borderRadius = '50%';
    ripple.style.background = 'rgba(255, 255, 255, 0.6)';
    ripple.style.transform = 'scale(0)';
    ripple.style.pointerEvents = 'none';
    ripple.style.zIndex = '100';
    
    element.appendChild(ripple);
    
    ripple.animate([
        { transform: 'scale(0)', opacity: 1 },
        { transform: 'scale(2)', opacity: 0 }
    ], {
        duration: 600,
        easing: 'ease-out'
    }).onfinish = () => ripple.remove();
}

// ============================================
// SMOOTH SCROLL
// ============================================
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// ============================================
// NAVBAR SCROLL EFFECTS
// ============================================
function initNavbar() {
    const nav = document.querySelector('.floating-nav');
    if (!nav) return;
    
    let lastScroll = 0;
    
    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;
        
        // Add shadow when scrolled
        if (currentScroll > 50) {
            nav.style.boxShadow = '0 8px 32px rgba(0,0,0,0.12)';
        } else {
            nav.style.boxShadow = 'none';
        }
        
        // Hide/show nav on scroll
        if (currentScroll > lastScroll && currentScroll > 200) {
            nav.style.transform = 'translateX(-50%) translateY(-100px)';
            nav.style.opacity = '0';
        } else {
            nav.style.transform = 'translateX(-50%) translateY(0)';
            nav.style.opacity = '1';
        }
        
        lastScroll = currentScroll;
    });
}

// ============================================
// INTERSECTION OBSERVER FOR SCROLL ANIMATIONS
// ============================================
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe all category cards
document.querySelectorAll('.category-card').forEach(card => {
    observer.observe(card);
});

// ============================================
// TOUCH DEVICE OPTIMIZATIONS
// ============================================
if ('ontouchstart' in window) {
    document.body.classList.add('touch-device');
    
    // Remove hover effects on touch devices
    const cards = document.querySelectorAll('.category-card');
    cards.forEach(card => {
        card.addEventListener('touchstart', function() {
            this.classList.add('touch-active');
        });
        
        card.addEventListener('touchend', function() {
            setTimeout(() => {
                this.classList.remove('touch-active');
            }, 300);
        });
    });
}

// ============================================
// PERFORMANCE: REQUEST ANIMATION FRAME
// ============================================
let ticking = false;

function optimizedScroll(callback) {
    if (!ticking) {
        window.requestAnimationFrame(() => {
            callback();
            ticking = false;
        });
        ticking = true;
    }
}

// ============================================
// PRELOAD IMAGES FOR SMOOTH EXPERIENCE
// ============================================
function preloadImages() {
    const images = document.querySelectorAll('img[data-src]');
    
    images.forEach(img => {
        const src = img.getAttribute('data-src');
        if (src) {
            const preload = new Image();
            preload.src = src;
            preload.onload = () => {
                img.src = src;
                img.classList.add('loaded');
            };
        }
    });
}

// ============================================
// ADD CUSTOM CURSOR (OPTIONAL - PREMIUM TOUCH)
// ============================================
function initCustomCursor() {
    const cursor = document.createElement('div');
    cursor.className = 'custom-cursor';
    document.body.appendChild(cursor);
    
    let mouseX = 0;
    let mouseY = 0;
    let cursorX = 0;
    let cursorY = 0;
    
    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
    });
    
    function animateCursor() {
        const speed = 0.15;
        
        cursorX += (mouseX - cursorX) * speed;
        cursorY += (mouseY - cursorY) * speed;
        
        cursor.style.left = cursorX + 'px';
        cursor.style.top = cursorY + 'px';
        
        requestAnimationFrame(animateCursor);
    }
    
    animateCursor();
    
    // Expand cursor on hover over interactive elements
    const interactiveElements = document.querySelectorAll('a, button, .category-card');
    
    interactiveElements.forEach(el => {
        el.addEventListener('mouseenter', () => {
            cursor.style.transform = 'scale(2)';
        });
        
        el.addEventListener('mouseleave', () => {
            cursor.style.transform = 'scale(1)';
        });
    });
}

// Uncomment to enable custom cursor on desktop
// if (!('ontouchstart' in window)) {
//     initCustomCursor();
// }

// ============================================
// PAGE LOAD ANIMATION
// ============================================
window.addEventListener('load', () => {
    document.body.classList.add('loaded');
    
    // Trigger confetti on first load (optional celebration)
    // setTimeout(triggerConfetti, 1000);
});

// ============================================
// EASTER EGG: KONAMI CODE
// ============================================
let konamiCode = [];
const konamiSequence = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'];

document.addEventListener('keydown', (e) => {
    konamiCode.push(e.key);
    konamiCode = konamiCode.slice(-10);
    
    if (konamiCode.join('') === konamiSequence.join('')) {
        activateEasterEgg();
    }
});

function activateEasterEgg() {
    // Add fun animation or special effect
    document.body.style.animation = 'rainbow 2s linear infinite';
    
    setTimeout(() => {
        document.body.style.animation = '';
    }, 5000);
}

// ============================================
// ACCESSIBILITY ENHANCEMENTS
// ============================================
document.addEventListener('keydown', (e) => {
    // Add visual focus indicators for keyboard navigation
    if (e.key === 'Tab') {
        document.body.classList.add('keyboard-nav');
    }
});

document.addEventListener('mousedown', () => {
    document.body.classList.remove('keyboard-nav');
});

// ============================================
// SERVICE WORKER REGISTRATION (PWA READY)
// ============================================
if ('serviceWorker' in navigator) {
    // Uncomment when you have a service worker file
    // navigator.serviceWorker.register('/sw.js');
}

console.log('🏡 Malaba Homes - Loaded successfully!');
