<?php
// Resolve API path at serve-time -- works in any XAMPP subfolder
// e.g. /malaba/track_order.php -> API = /malaba/api/order_status.php
$apiBase = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/api';
$apiUrl  = $apiBase . '/order_status.php';

// Pre-fill from URL params for server-side convenience
$urlRef   = htmlspecialchars(trim(isset($_GET['ref'])   ? $_GET['ref']   : ''), ENT_QUOTES);
$urlPhone = htmlspecialchars(trim(isset($_GET['phone']) ? $_GET['phone'] : ''), ENT_QUOTES);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="theme-color" content="#080604">
<meta name="description" content="Track your Malaba Homes order in real time.">
<title>Track Order - Malaba Homes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<?php include 'pwa_head.php'; ?>
  <script src="/firebase-config.js"></script>
  <script src="/push_register.js"></script>
<style>
:root {
  --bg: #080604; --bg2: #0D0B08; --surface: #141210; --card: #1A1714;
  --border: rgba(255,255,255,0.07); --border2: rgba(255,255,255,0.13);
  --text: #F2EDE6; --text2: #B8AFA5; --muted: #6E6560;
  --amber: #E8521A; --amber2: #FF7043;
  --green: #52B788; --blue: #4895EF; --red: #ef4444; --gold: #f59e0b;
  --safe-b: env(safe-area-inset-bottom, 0px);
  --safe-t: env(safe-area-inset-top, 0px);
  --r: 14px; --r-lg: 20px; --r-xl: 28px;
}
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
html { overflow-x:hidden; scroll-behavior:smooth; }
body {
  font-family:'DM Sans',sans-serif;
  background:var(--bg); color:var(--text);
  min-height:100dvh; -webkit-font-smoothing:antialiased;
  padding-bottom:calc(32px + var(--safe-b));
}
a { color:inherit; text-decoration:none; }
button { cursor:pointer; font-family:inherit; border:none; background:none; }
img { display:block; max-width:100%; }

/* Header */
.header {
  position:sticky; top:0; z-index:100;
  padding-top:var(--safe-t);
  background:rgba(8,6,4,.95);
  backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
}
.header-inner {
  max-width:680px; margin:0 auto;
  height:56px; display:flex; align-items:center; gap:12px;
  padding:0 16px;
}
.back-btn {
  width:36px; height:36px; border-radius:50%;
  background:var(--surface); border:1px solid var(--border2);
  display:flex; align-items:center; justify-content:center; flex-shrink:0;
}
.back-btn svg { width:18px; height:18px; color:var(--text); }
.back-btn:active { transform:scale(.9); }
.brand { flex:1; font-family:'Syne',sans-serif; font-weight:800; font-size:16px; letter-spacing:-.3px; }
.brand span { color:var(--amber2); }
.refresh-btn {
  width:36px; height:36px; border-radius:50%;
  background:var(--surface); border:1px solid var(--border2);
  display:flex; align-items:center; justify-content:center; font-size:16px;
}
.refresh-btn:active { transform:scale(.9); }
@keyframes spin { to { transform:rotate(360deg); } }
.spinning { animation:spin .6s linear; }

/* Page */
.page { max-width:680px; margin:0 auto; padding:20px 16px 0; }

/* Search card */
.search-card {
  background:var(--card); border:1px solid var(--border);
  border-radius:var(--r-xl); padding:24px; margin-bottom:20px;
}
.search-title { font-family:'Syne',sans-serif; font-weight:800; font-size:20px; margin-bottom:4px; }
.search-sub { font-size:13px; color:var(--muted); margin-bottom:20px; }

.input-group { margin-bottom:14px; }
.input-group label {
  display:block; font-size:11px; font-weight:700; color:var(--muted);
  letter-spacing:.5px; text-transform:uppercase; margin-bottom:7px;
}
.input-wrap {
  display:flex; align-items:center;
  background:var(--surface); border:1.5px solid var(--border2);
  border-radius:12px; overflow:hidden; transition:border-color .2s;
}
.input-wrap:focus-within { border-color:var(--amber2); }
.input-wrap svg { margin:0 12px; color:var(--muted); flex-shrink:0; width:16px; height:16px; }
.input-wrap input {
  flex:1; padding:13px 14px 13px 0;
  background:transparent; border:none; outline:none;
  font-family:inherit; font-size:15px; color:var(--text);
}
.input-wrap input::placeholder { color:var(--muted); }

.divider-or {
  display:flex; align-items:center; gap:12px;
  margin:6px 0 16px; font-size:12px; font-weight:600;
  color:var(--muted); letter-spacing:.5px; text-transform:uppercase;
}
.divider-or::before, .divider-or::after { content:''; flex:1; height:1px; background:var(--border2); }

.track-btn {
  width:100%; padding:14px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff; border-radius:var(--r-lg);
  font-family:'Syne',sans-serif; font-weight:800; font-size:15px;
  transition:all .2s; display:flex; align-items:center; justify-content:center; gap:8px;
  box-shadow:0 4px 20px rgba(232,82,26,.3);
}
.track-btn:active { transform:scale(.98); opacity:.92; }
.track-btn:disabled { opacity:.5; cursor:not-allowed; }

/* Saved chip */
.saved-chip {
  display:flex; align-items:center; gap:10px;
  background:rgba(82,183,136,.1); border:1px solid rgba(82,183,136,.22);
  border-radius:12px; padding:11px 14px; margin-bottom:16px;
}
.sc-avatar {
  width:32px; height:32px; border-radius:50%;
  background:rgba(82,183,136,.2); display:flex; align-items:center;
  justify-content:center; font-size:14px; flex-shrink:0; overflow:hidden;
}
.sc-avatar img { width:100%; height:100%; object-fit:cover; }
.sc-name { font-size:13px; font-weight:700; color:var(--green); }
.sc-sub  { font-size:11px; color:var(--muted); }
.sc-clear {
  margin-left:auto; font-size:11px; font-weight:700;
  color:rgba(255,255,255,.35); border:1px solid rgba(255,255,255,.1);
  border-radius:7px; padding:4px 9px; flex-shrink:0;
}

/* Debug box (shown only if API unreachable) */
.debug-box {
  background:rgba(139,92,246,.08); border:1px solid rgba(139,92,246,.2);
  border-radius:var(--r); padding:14px 16px; margin-top:12px;
  font-size:12px; color:#c4b5fd; line-height:1.6; display:none;
  font-family:monospace;
}
.debug-box strong { color:#e9d5ff; display:block; margin-bottom:4px; font-size:13px; }

/* Loader */
.loader {
  display:flex; flex-direction:column; align-items:center;
  padding:48px 0; gap:12px; color:var(--muted); font-size:13px;
}
.loader-ring {
  width:36px; height:36px; border-radius:50%;
  border:3px solid var(--border2); border-top-color:var(--amber2);
  animation:spin .7s linear infinite;
}

/* Error */
.error-box {
  background:rgba(239,68,68,.08); border:1px solid rgba(239,68,68,.2);
  border-radius:var(--r); padding:16px 18px;
  display:flex; align-items:flex-start; gap:12px;
  font-size:14px; color:#fca5a5; line-height:1.5;
}
.error-box .ei { font-size:20px; flex-shrink:0; }

/* Order card */
.order-card {
  background:var(--card); border:1px solid var(--border);
  border-radius:var(--r-xl); overflow:hidden;
  margin-bottom:16px; animation:fadeUp .4s ease both;
}
@keyframes fadeUp { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }

.oc-header {
  display:flex; align-items:flex-start; gap:12px;
  padding:18px 18px 14px; border-bottom:1px solid var(--border);
}
.oc-img {
  width:56px; height:56px; border-radius:12px;
  object-fit:cover; flex-shrink:0; background:var(--surface);
}
.oc-img-ph {
  width:56px; height:56px; border-radius:12px;
  background:var(--surface); border:1px solid var(--border2);
  display:flex; align-items:center; justify-content:center;
  font-size:24px; flex-shrink:0;
}
.oc-info { flex:1; min-width:0; }
.oc-ref  { font-size:11px; font-weight:700; color:var(--muted); letter-spacing:.6px; margin-bottom:3px; }
.oc-title {
  font-family:'Syne',sans-serif; font-weight:700; font-size:15px;
  color:var(--text); line-height:1.25;
  white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-bottom:5px;
}
.oc-cat {
  display:inline-flex; align-items:center; gap:5px;
  font-size:11px; font-weight:600; padding:3px 9px; border-radius:20px;
}
.cat-houses { background:rgba(82,183,136,.15); color:var(--green); }
.cat-food   { background:rgba(255,112,67,.15);  color:#FF7043; }
.cat-items  { background:rgba(72,149,239,.15);  color:var(--blue); }

.oc-status-pill {
  padding:6px 12px; border-radius:20px; font-size:11px; font-weight:800;
  text-transform:uppercase; letter-spacing:.4px; white-space:nowrap; flex-shrink:0;
}
.sp-pending    { background:rgba(245,158,11,.15); color:#f59e0b; }
.sp-confirmed  { background:rgba(9,132,227,.15);  color:#74b9ff; }
.sp-processing { background:rgba(139,92,246,.15); color:#c4b5fd; }
.sp-dispatched { background:rgba(13,148,136,.15); color:#2dd4bf; }
.sp-delivered  { background:rgba(0,184,148,.15);  color:var(--green); }
.sp-cancelled  { background:rgba(214,48,49,.15);  color:#fca5a5; }

/* Hint */
.oc-hint {
  display:flex; align-items:flex-start; gap:10px;
  padding:14px 18px; background:rgba(255,255,255,.025);
  border-bottom:1px solid var(--border);
  font-size:13px; color:var(--text2); line-height:1.5;
}
.oc-hint .hi { font-size:18px; flex-shrink:0; }

/* Meta grid */
.oc-meta {
  display:grid; grid-template-columns:1fr 1fr;
  gap:10px; padding:14px 18px; border-bottom:1px solid var(--border);
}
.oc-meta-item { display:flex; flex-direction:column; gap:2px; }
.oc-meta-label { font-size:10px; font-weight:700; color:var(--muted); text-transform:uppercase; letter-spacing:.5px; }
.oc-meta-val   { font-size:13px; font-weight:600; color:var(--text); }
.mv-green  { color:var(--green); }
.mv-amber  { color:var(--gold); }
.mv-blue   { color:var(--blue); }
.mv-red    { color:var(--red); }

/* Timeline */
.tl-wrap { padding:18px 18px 6px; }
.tl-title { font-size:11px; font-weight:700; color:var(--muted); letter-spacing:.6px; text-transform:uppercase; margin-bottom:16px; }
.tl { display:flex; flex-direction:column; }
.tl-item { display:flex; gap:14px; align-items:flex-start; position:relative; }
.tl-item:not(:last-child)::before {
  content:''; position:absolute; left:15px; top:32px;
  width:2px; height:calc(100% - 6px); background:var(--border2); border-radius:1px;
}
.tl-item.tl-done:not(:last-child)::before { background:rgba(232,82,26,.4); }
.tl-dot {
  width:32px; height:32px; border-radius:50%; flex-shrink:0; z-index:1;
  display:flex; align-items:center; justify-content:center; font-size:14px;
  border:2px solid var(--border2); background:var(--surface);
}
.tl-item.tl-done   .tl-dot { background:rgba(232,82,26,.15); border-color:rgba(232,82,26,.4); }
.tl-item.tl-active .tl-dot {
  background:var(--amber); border-color:var(--amber2);
  box-shadow:0 0 0 0 rgba(232,82,26,.4);
  animation:pulse-dot 2s infinite;
}
.tl-item.tl-upcoming .tl-dot { opacity:.3; }
@keyframes pulse-dot {
  0%,100% { box-shadow:0 0 0 0 rgba(232,82,26,.4); }
  50%      { box-shadow:0 0 0 8px rgba(232,82,26,0); }
}
.tl-content { flex:1; padding:4px 0 20px; }
.tl-label   { font-family:'Syne',sans-serif; font-weight:700; font-size:14px; margin-bottom:2px; }
.tl-item.tl-upcoming .tl-label { color:var(--muted); }
.tl-time    { font-size:11px; color:var(--muted); margin-bottom:3px; }
.tl-note    { font-size:12px; color:var(--text2); line-height:1.4; }
.tl-item.tl-upcoming .tl-note { color:var(--muted); }

/* Actions */
.oc-actions {
  display:flex; gap:10px; padding:14px 18px 18px; flex-wrap:wrap;
}
.oc-btn {
  flex:1; min-width:130px;
  display:flex; align-items:center; justify-content:center; gap:7px;
  padding:12px 14px; border-radius:var(--r);
  font-family:'Syne',sans-serif; font-weight:700; font-size:13px;
  transition:all .2s;
}
.oc-btn:active { transform:scale(.97); }
.btn-wa   { background:#25D366; color:#fff; box-shadow:0 3px 12px rgba(37,211,102,.25); }
.btn-call { background:var(--surface); color:var(--text2); border:1px solid var(--border2); }
.btn-share { flex:0; padding:12px 14px; background:var(--surface); border:1px solid var(--border2); color:var(--text2); }

/* Footer of card */
.oc-footer { padding:0 18px 14px; font-size:11px; color:var(--muted); }

/* Multi-orders notice */
.orders-notice {
  display:flex; align-items:center; gap:10px;
  background:rgba(72,149,239,.08); border:1px solid rgba(72,149,239,.15);
  border-radius:var(--r); padding:13px 16px; margin-bottom:14px;
  font-size:13px; color:var(--text2);
}
.orders-notice strong { color:var(--blue); }

/* Toast */
.toast {
  position:fixed; bottom:calc(20px + var(--safe-b));
  left:50%; transform:translateX(-50%) translateY(10px);
  background:var(--text); color:var(--bg);
  padding:10px 20px; border-radius:30px;
  font-size:13px; font-weight:600; z-index:999;
  opacity:0; pointer-events:none; transition:all .25s;
  white-space:nowrap; box-shadow:0 8px 24px rgba(0,0,0,.4);
}
.toast.show { opacity:1; transform:translateX(-50%) translateY(0); }

/* Bottom nav */
.bnav {
  display:none; position:fixed; bottom:0; left:0; right:0; z-index:200;
  background:rgba(8,6,4,.97); backdrop-filter:blur(20px);
  border-top:1px solid var(--border);
  padding:8px 0 calc(8px + var(--safe-b));
}
.bni {
  flex:1; display:flex; flex-direction:column; align-items:center;
  gap:3px; font-size:9px; font-weight:600; color:var(--muted);
  letter-spacing:.3px; text-transform:uppercase; cursor:pointer;
  transition:color .2s; padding:4px 0;
}
.bni.active { color:var(--amber2); }
.bni-icon { font-size:20px; line-height:1.1; }

@media(max-width:600px) {
  body { padding-bottom:calc(70px + var(--safe-b)); }
  .bnav { display:flex; }
  .page { padding:14px 12px 0; }
  .search-card { padding:18px 16px; border-radius:20px; }
  .oc-header { padding:14px 14px 12px; }
  .oc-meta { gap:8px; padding:12px 14px; }
  .oc-actions { padding:10px 14px 14px; gap:8px; }
  .oc-btn { font-size:12px; padding:11px 10px; }
  .tl-wrap { padding:14px 14px 4px; }
}
</style>
</head>
<body>

<header class="header">
  <div class="header-inner">
    <a href="index.php" class="back-btn" aria-label="Back">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
        <path d="M19 12H5M5 12l7-7M5 12l7 7"/>
      </svg>
    </a>
    <div class="brand">Malaba <span>Track</span></div>
    <button class="refresh-btn" id="refreshBtn" onclick="doRefresh()" aria-label="Refresh">&#x1F504;</button>
  </div>
</header>

<div class="page">
  <div class="search-card">
    <h1 class="search-title">Track Your Order</h1>
    <p class="search-sub">Enter your order reference or the phone number you used</p>

    <div id="savedChip" style="display:none;" class="saved-chip">
      <div class="sc-avatar" id="scAvatar">&#x1F464;</div>
      <div>
        <div class="sc-name" id="scName"></div>
        <div class="sc-sub"  id="scSub"></div>
      </div>
      <button class="sc-clear" onclick="clearSaved()">Change</button>
    </div>

    <div class="input-group">
      <label>Order Reference (e.g. MH-2026-0001)</label>
      <div class="input-wrap">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
          <rect x="9" y="1" width="6" height="6" rx="1"/><path d="M9 1H7a2 2 0 00-2 2v16a2 2 0 002 2h10a2 2 0 002-2V3a2 2 0 00-2-2h-2"/>
        </svg>
        <input type="text" id="refInput" placeholder="MH-2026-0001"
               autocomplete="off" spellcheck="false"
               value="<?= $urlRef ?>"
               style="text-transform:uppercase;">
      </div>
    </div>

    <div class="divider-or">or</div>

    <div class="input-group">
      <label>Phone Number Used at Checkout</label>
      <div class="input-wrap">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
          <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.5 9.86 19.79 19.79 0 01.46 1.21 2 2 0 012.44 0h3a2 2 0 012 1.72 12 12 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 7.91a16 16 0 006.13 6.13l1.27-.79a2 2 0 012.11-.45 12 12 0 002.81.7A2 2 0 0122 16.92z"/>
        </svg>
        <input type="tel" id="phoneInput" placeholder="0712 345 678"
               autocomplete="tel" inputmode="tel"
               value="<?= $urlPhone ?>">
      </div>
    </div>

    <button class="track-btn" id="trackBtn" onclick="trackOrder()">
      &#x1F50D; Track My Order
    </button>

    <div class="debug-box" id="debugBox">
      <strong>Connection Details (for troubleshooting)</strong>
      <span id="debugText"></span>
    </div>
  </div>

  <div id="results"></div>
</div>

<nav class="bnav">
  <a href="index.php"         class="bni"><span class="bni-icon">&#x1F3E1;</span>Home</a>
  <a href="homes_listing.php" class="bni"><span class="bni-icon">&#x1F3E0;</span>Homes</a>
  <a href="food_listing.php"  class="bni"><span class="bni-icon">&#x1F354;</span>Food</a>
  <a href="shop_listing.php"  class="bni"><span class="bni-icon">&#x1F6D2;</span>Shop</a>
  <a href="track_order.php"   class="bni active"><span class="bni-icon">&#x1F4E6;</span>Track</a>
</nav>

<div class="toast" id="toast"></div>

<script src="mh_user.js" onerror="window.MhUser=null"></script>
<script>
// API URL resolved by PHP at serve-time -- always correct regardless of subfolder
var API_URL = <?php echo json_encode($apiUrl); ?>;

var STATUS_META = {
  pending:    {label:'Order Received',  icon:'&#x1F4CB;', hint:'Your order has been received and is being reviewed.',        cls:'sp-pending'},
  confirmed:  {label:'Confirmed',       icon:'&#x2705;',  hint:'Your order is confirmed and will be prepared shortly.',       cls:'sp-confirmed'},
  processing: {label:'Being Prepared',  icon:'&#x1F504;', hint:'Your order is being prepared right now!',                    cls:'sp-processing'},
  dispatched: {label:'On the Way',      icon:'&#x1F69A;', hint:'Your order is on its way. Please be ready to receive it.',   cls:'sp-dispatched'},
  delivered:  {label:'Delivered',       icon:'&#x1F389;', hint:'Your order has been delivered. Enjoy!',                      cls:'sp-delivered'},
  cancelled:  {label:'Cancelled',       icon:'&#x274C;',  hint:'This order was cancelled. WhatsApp us for assistance.',      cls:'sp-cancelled'}
};

var PAY_META = {
  pending:  {label:'Payment Pending',  icon:'&#x23F3;', cls:'mv-amber'},
  received: {label:'Payment Received', icon:'&#x1F49A;', cls:'mv-green'},
  failed:   {label:'Payment Failed',   icon:'&#x274C;',  cls:'mv-red'},
  refunded: {label:'Refunded',         icon:'&#x21A9;&#xFE0F;',  cls:'mv-blue'}
};

var PAY_LABELS = {
  'cash':             'Cash on Delivery',
  'mpesa':            'M-Pesa',
  'cash_on_delivery': 'Cash on Move-In',
  'mpesa_on_delivery':'M-Pesa on Delivery'
};

var _lastRef = '', _lastPhone = '';

// ---- Saved user chip --------------------------------------------------
function initSavedChip() {
  if (!window.MhUser) return;
  var d = MhUser.getDetails();
  if (!d || !d.phone) return;
  document.getElementById('scName').textContent = d.name || 'Saved account';
  document.getElementById('scSub').textContent  = d.phone + (d.address ? ' - ' + d.address.substring(0,22) : '');
  if (d.avatar) document.getElementById('scAvatar').innerHTML = '<img src="' + d.avatar + '" alt="">';
  document.getElementById('savedChip').style.display = 'flex';
  if (!document.getElementById('phoneInput').value) {
    document.getElementById('phoneInput').value = d.phone;
  }
}
function clearSaved() {
  document.getElementById('savedChip').style.display = 'none';
  document.getElementById('phoneInput').value = '';
  document.getElementById('refInput').value   = '';
  document.getElementById('results').innerHTML = '';
}

// ---- Core track function ----------------------------------------------
function trackOrder() {
  var ref   = document.getElementById('refInput').value.trim().toUpperCase();
  var phone = document.getElementById('phoneInput').value.trim();

  if (!ref && !phone) {
    showToast('Enter an order reference or phone number');
    return;
  }

  _lastRef = ref; _lastPhone = phone;
  var params = '';
  if (ref)   params += 'ref='   + encodeURIComponent(ref);
  if (phone) params += (params ? '&' : '') + 'phone=' + encodeURIComponent(phone);

  var url = API_URL + '?' + params;

  setLoading(true);
  document.getElementById('results').innerHTML = '<div class="loader"><div class="loader-ring"></div>Looking up your order...</div>';
  document.getElementById('debugBox').style.display = 'none';

  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
  xhr.timeout = 15000;

  xhr.onload = function() {
    setLoading(false);
    if (xhr.status === 200) {
      try {
        var data = JSON.parse(xhr.responseText);
        if (data.success) {
          var orders = data.single ? [data.data] : (Array.isArray(data.data) ? data.data : [data.data]);
          renderOrders(orders);
        } else {
          showError(data.error || 'Order not found. Check your reference or phone number.');
        }
      } catch(e) {
        showNetworkError(url, xhr.status, xhr.responseText.substring(0,200));
      }
    } else {
      showNetworkError(url, xhr.status, xhr.responseText.substring(0,200));
    }
  };

  xhr.onerror = xhr.ontimeout = function() {
    setLoading(false);
    showNetworkError(url, 0, xhr.statusText || 'Timeout or network error');
  };

  xhr.send();
}

function showError(msg) {
  document.getElementById('results').innerHTML =
    '<div class="error-box"><div class="ei">&#x1F50D;</div><div><strong style="color:var(--text);display:block;margin-bottom:3px;">Not found</strong>' + esc(msg) + '</div></div>';
}

function showNetworkError(url, status, body) {
  document.getElementById('results').innerHTML =
    '<div class="error-box"><div class="ei">&#x1F4F6;</div><div>' +
    '<strong style="color:var(--text);display:block;margin-bottom:3px;">Could not reach the server</strong>' +
    'Check that XAMPP is running and the API file exists. See details below.' +
    '</div></div>';

  var dbg = document.getElementById('debugBox');
  document.getElementById('debugText').innerHTML =
    'URL tried: <em>' + esc(url) + '</em><br>' +
    'HTTP status: ' + (status || 'no response') + '<br>' +
    (body ? 'Server said: <em>' + esc(body) + '</em>' : '');
  dbg.style.display = 'block';
}

// ---- Render -----------------------------------------------------------
function renderOrders(orders) {
  var html = '';
  if (orders.length > 1) {
    html += '<div class="orders-notice"><strong>' + orders.length + ' orders</strong>&nbsp;linked to your number &mdash; newest first.</div>';
  }
  for (var i = 0; i < orders.length; i++) {
    html += buildCard(orders[i], i);
  }
  document.getElementById('results').innerHTML = html;
}

function buildCard(o, idx) {
  var s   = o.status || 'pending';
  var sm  = o.status_meta  || STATUS_META[s]  || STATUS_META.pending;
  var pm  = o.payment_meta || PAY_META[o.payment_status] || PAY_META.pending;
  var pml = PAY_LABELS[o.payment_method] || o.payment_method || '';
  var cat = o.category || 'items';
  var delay = Math.min(idx * 0.08, 0.32);

  var imgHtml = o.listing_image
    ? '<img class="oc-img" src="' + esc(o.listing_image) + '" alt="" onerror="this.style.display=\'none\'">'
    : '<div class="oc-img-ph">' + (o.category_icon || '&#x1F4E6;') + '</div>';

  var total = parseFloat(o.total_amount) > 0
    ? 'KSH ' + Number(o.total_amount).toLocaleString('en-KE')
    : (o.listing_price || '&#x2014;');

  var waMsg = encodeURIComponent(
    'Hi! Checking on my order *' + (o.order_ref||'') + '*\n' +
    'Item: ' + (o.listing_title||'') + '\n' +
    'Status: ' + (sm.label||s) + '\n' +
    'Ref: ' + (o.order_ref||'')
  );
  var waSeller  = 'https://wa.me/' + (o.wa_seller  || '254700000000') + '?text=' + waMsg;
  var waSupport = 'https://wa.me/' + (o.wa_support || '254700000000') + '?text=' + waMsg;

  var metaRows = [
    {label:'Customer',       val: esc(o.customer_name||''),                              cls:''},
    {label:'Phone',          val: esc(o.customer_phone_masked||'***'),                   cls:''},
    {label:'Amount',         val: total,                                                  cls:'mv-green'},
    {label:'Payment Method', val: esc(pml),                                              cls:''},
    {label:'Payment Status', val: (pm.icon||'') + ' ' + esc(pm.label||''),              cls: pm.cls||''},
    {label:'Category',       val: (o.category_icon||'') + ' ' + esc(o.category_name||ucFirst(cat)), cls:''}
  ];
  if (o.customer_address) metaRows.push({label:'Deliver To', val:esc(o.customer_address), cls:''});
  if (o.quantity > 1)     metaRows.push({label:'Quantity',   val:o.quantity + ' items',   cls:''});

  var metaHtml = metaRows.map(function(m) {
    return '<div class="oc-meta-item"><div class="oc-meta-label">' + m.label + '</div>' +
           '<div class="oc-meta-val ' + m.cls + '">' + m.val + '</div></div>';
  }).join('');

  var shareBtn = navigator.share
    ? '<button class="oc-btn btn-share" onclick="shareOrder(\'' + esc(o.order_ref||'') + '\',\'' + esc(o.listing_title||'') + '\',\'' + esc(sm.label||'') + '\')">' +
      '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg></button>'
    : '';

  return '<div class="order-card" style="animation-delay:' + delay + 's">' +

    '<div class="oc-header">' +
      imgHtml +
      '<div class="oc-info">' +
        '<div class="oc-ref">' + esc(o.order_ref||'') + '</div>' +
        '<div class="oc-title">' + esc(o.listing_title||'Order') + '</div>' +
        '<span class="oc-cat cat-' + cat + '">' + (o.category_icon||'') + ' ' + esc(o.category_name||ucFirst(cat)) + '</span>' +
      '</div>' +
      '<span class="oc-status-pill ' + (sm.cls||'sp-'+s) + '">' + (sm.icon||'') + ' ' + esc(sm.label||ucFirst(s)) + '</span>' +
    '</div>' +

    (sm.hint ? '<div class="oc-hint"><div class="hi">' + (sm.icon||'') + '</div><div>' + esc(sm.hint) + '</div></div>' : '') +

    '<div class="oc-meta">' + metaHtml + '</div>' +

    '<div class="tl-wrap">' +
      '<div class="tl-title">Order Journey</div>' +
      '<div class="tl">' + buildTimeline(o.timeline || [], s) + '</div>' +
    '</div>' +

    '<div class="oc-actions">' +
      '<a href="' + waSeller + '" target="_blank" rel="noopener" class="oc-btn btn-wa">&#x1F4AC; WhatsApp Update</a>' +
      (o.wa_seller !== o.wa_support
        ? '<a href="' + waSupport + '" target="_blank" rel="noopener" class="oc-btn btn-call">&#x1F198; Support</a>'
        : '<a href="tel:+' + (o.wa_support||'') + '" class="oc-btn btn-call">&#x1F4DE; Call Us</a>') +
      shareBtn +
    '</div>' +

    '<div class="oc-footer">Placed ' + fmtDate(o.created_at) +
      (o.delivered_at ? ' &bull; Delivered ' + fmtDate(o.delivered_at) : '') +
      (o.wa_notified ? ' &bull; <span style="color:var(--green)">&#x2705; WA notified</span>' : '') +
    '</div>' +

  '</div>';
}

function buildTimeline(timeline, currentStatus) {
  if (!timeline || !timeline.length) {
    return '<p style="color:var(--muted);font-size:13px;padding:4px 0 16px;">No history yet.</p>';
  }

  // Find the last done item to mark as active
  var lastDoneIdx = -1;
  for (var i = 0; i < timeline.length; i++) {
    if (timeline[i].done) lastDoneIdx = i;
  }

  return timeline.map(function(item, i) {
    var cls = 'tl-upcoming';
    if (item.done) {
      cls = (i === lastDoneIdx) ? 'tl-item tl-done tl-active' : 'tl-item tl-done';
    } else {
      cls = 'tl-item tl-upcoming';
    }
    // Override: the first occurrence without "tl-item" prefix
    if (cls === 'tl-item tl-done tl-active' || cls === 'tl-item tl-done') {
      // already has tl-item
    } else {
      cls = 'tl-item ' + cls;
    }

    var timeStr = item.time ? fmtDate(item.time) : 'Upcoming';
    return '<div class="' + cls + '">' +
      '<div class="tl-dot">' + (item.icon || 'o') + '</div>' +
      '<div class="tl-content">' +
        '<div class="tl-label">' + esc(item.label||'') + '</div>' +
        '<div class="tl-time">' + timeStr + '</div>' +
        (item.note ? '<div class="tl-note">' + esc(item.note) + '</div>' : '') +
      '</div>' +
    '</div>';
  }).join('');
}

// ---- Helpers ----------------------------------------------------------
function fmtDate(str) {
  if (!str) return '';
  var d = new Date(str);
  if (isNaN(d.getTime())) return str;
  var now  = new Date();
  var diff = (now - d) / 1000;
  if (diff < 60)    return 'Just now';
  if (diff < 3600)  return Math.floor(diff/60) + ' min ago';
  var sameDay = d.toDateString() === now.toDateString();
  var time = d.toLocaleTimeString('en-KE', {hour:'2-digit', minute:'2-digit'});
  if (sameDay) return 'Today, ' + time;
  return d.toLocaleDateString('en-KE', {day:'numeric', month:'short', year:'numeric'}) + ' - ' + time;
}

function ucFirst(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }

function esc(s) {
  return String(s||'')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function showToast(msg) {
  var t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(function(){ t.classList.remove('show'); }, 2400);
}

function setLoading(on) {
  var btn = document.getElementById('trackBtn');
  btn.disabled = on;
  btn.textContent = on ? 'Searching...' : '\uD83D\uDD0D Track My Order';
}

function doRefresh() {
  if (!_lastRef && !_lastPhone) return;
  document.getElementById('refreshBtn').classList.add('spinning');
  trackOrder();
  setTimeout(function(){ document.getElementById('refreshBtn').classList.remove('spinning'); }, 700);
}

function shareOrder(ref, title, status) {
  if (!navigator.share) return;
  navigator.share({
    title: 'Order ' + ref + ' - Malaba Homes',
    text:  title + ' - Status: ' + status,
    url:   location.origin + location.pathname + '?ref=' + encodeURIComponent(ref)
  }).catch(function(){});
}

// ---- Init ------------------------------------------------------------
document.getElementById('refInput').addEventListener('keydown', function(e){ if(e.key==='Enter') trackOrder(); });
document.getElementById('phoneInput').addEventListener('keydown', function(e){ if(e.key==='Enter') trackOrder(); });

// Force uppercase on ref input
document.getElementById('refInput').addEventListener('input', function(){
  var pos = this.selectionStart;
  this.value = this.value.toUpperCase();
  this.setSelectionRange(pos, pos);
});

// Load saved chip
if (typeof MhUser !== 'undefined' && MhUser) {
  initSavedChip();
} else {
  window.addEventListener('load', function(){ if(window.MhUser) initSavedChip(); });
}

// Auto-track if ref or phone came from URL
<?php if ($urlRef || $urlPhone): ?>
window.addEventListener('load', function(){ setTimeout(trackOrder, 300); });
<?php endif; ?>
</script>
</body>
</html>
