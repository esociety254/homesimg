/**
 * mh_user.js  — Malaba Homes User Identity Layer
 * ===================================================
 * Handles:
 *   1. localStorage "saved details" (name, phone, address)  — works offline, no account needed
 *   2. Optional Google One-Tap sign-in  — fills name + pre-links phone
 *   3. MhUser.getDetails()  → { name, phone, address, idNo, email, avatar, source }
 *   4. MhUser.saveDetails() → persists to localStorage + server (if signed in)
 *   5. MhUser.fillForm(map) → auto-fills any checkout form field
 *   6. MhUser.renderChip()  → shows "Delivering to Kevin — change?" chip in checkout
 *
 * Usage in any page:
 *   <script src="mh_user.js"></script>
 *   MhUser.fillForm({ name:'ck_name', phone:'ck_phone', address:'ck_addr' });
 *
 * Google Client ID — replace with yours from console.cloud.google.com
 *   (Create OAuth 2.0 credential → Web application → Authorised JS origins = your domain)
 *   Leave empty string '' to disable Google Sign-In entirely.
 */

const GOOGLE_CLIENT_ID = '';   // ← paste your Google Client ID here, or leave '' to disable

const MhUser = (() => {
  const LS_KEY   = 'mh_user_v2';
  const API_BASE = (() => {
    const s = document.querySelector('script[src*="mh_user.js"]');
    if (s) return s.src.replace(/\/mh_user\.js.*$/, '/api');
    return window.location.pathname.replace(/\/[^/]*$/, '') + '/api';
  })();

  /* ── Internal helpers ── */
  function load() {
    try { return JSON.parse(localStorage.getItem(LS_KEY) || '{}'); } catch { return {}; }
  }
  function save(data) {
    const merged = { ...load(), ...data, savedAt: Date.now() };
    localStorage.setItem(LS_KEY, JSON.stringify(merged));
    // Async persist to server if we have a session token
    if (merged.token) _syncToServer(merged).catch(() => {});
    return merged;
  }

  async function _syncToServer(data) {
    await fetch(`${API_BASE}/user_auth.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
      body: JSON.stringify({ action: 'update_profile', token: data.token, name: data.name, phone: data.phone, address: data.address }),
    });
  }

  /* ── Public API ── */
  function getDetails() {
    return load();
  }

  function saveDetails(fields) {
    return save(fields);
  }

  function clearDetails() {
    localStorage.removeItem(LS_KEY);
  }

  function hasDetails() {
    const d = load();
    return !!(d.name && d.phone);
  }

  /**
   * Auto-fill a checkout form.
   * @param {object} map  Maps field names to element IDs.
   *   e.g. { name: 'ck_name', phone: 'ck_phone', address: 'ck_addr', idNo: 'bk_id' }
   */
  function fillForm(map) {
    const d = load();
    Object.entries(map).forEach(([field, elId]) => {
      const el = document.getElementById(elId);
      if (el && d[field]) el.value = d[field];
    });
  }

  /**
   * Listen for checkout form changes and auto-save.
   * @param {object} map  Same map as fillForm
   */
  function watchForm(map) {
    Object.entries(map).forEach(([field, elId]) => {
      const el = document.getElementById(elId);
      if (!el) return;
      el.addEventListener('blur', () => {
        if (el.value.trim()) save({ [field]: el.value.trim() });
      });
    });
  }

  /**
   * Render a "Delivering to X" chip above the form.
   * @param {string} containerId  Element to inject the chip into.
   * @param {function} onClear    Called when user clicks "Change details"
   */
  function renderChip(containerId, onClear) {
    const d = load();
    const container = document.getElementById(containerId);
    if (!container || !d.name || !d.phone) return false;

    const chip = document.createElement('div');
    chip.id    = 'mh-user-chip';
    chip.style.cssText = `
      display:flex; align-items:center; justify-content:space-between;
      background:rgba(82,183,136,.1); border:1px solid rgba(82,183,136,.25);
      border-radius:12px; padding:12px 14px; margin-bottom:14px; gap:10px;
      font-family:inherit;
    `;
    chip.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px;min-width:0;">
        <div style="width:34px;height:34px;border-radius:50%;background:rgba(82,183,136,.2);display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;">
          ${d.avatar ? `<img src="${d.avatar}" style="width:34px;height:34px;border-radius:50%;object-fit:cover;">` : '👤'}
        </div>
        <div style="min-width:0;">
          <div style="font-size:13px;font-weight:700;color:#52B788;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
            ${_esc(d.name)}
          </div>
          <div style="font-size:11px;color:rgba(255,255,255,.5);">${_esc(d.phone)}${d.address ? ' · ' + _esc(d.address.substring(0,24)) + (d.address.length>24?'…':'') : ''}</div>
        </div>
      </div>
      <button id="mh-chip-change" style="font-size:11px;font-weight:700;color:rgba(255,255,255,.45);background:transparent;border:1px solid rgba(255,255,255,.12);border-radius:8px;padding:5px 10px;cursor:pointer;white-space:nowrap;font-family:inherit;flex-shrink:0;">Change</button>
    `;
    container.prepend(chip);

    document.getElementById('mh-chip-change').addEventListener('click', () => {
      chip.remove();
      if (typeof onClear === 'function') onClear();
    });
    return true;
  }

  /** Show the Google One-Tap button + load SDK */
  function initGoogle(callbackFn) {
    if (!GOOGLE_CLIENT_ID) return;
    if (typeof google !== 'undefined') { _renderGoogle(callbackFn); return; }
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.onload = () => _renderGoogle(callbackFn);
    document.head.appendChild(script);
  }

  function _renderGoogle(callbackFn) {
    if (!window.google?.accounts) return;
    google.accounts.id.initialize({
      client_id: GOOGLE_CLIENT_ID,
      callback: (response) => _handleGoogleCred(response, callbackFn),
      auto_select: false,
      cancel_on_tap_outside: true,
    });
    // One-tap prompt
    google.accounts.id.prompt();
  }

  async function _handleGoogleCred(response, callbackFn) {
    // Decode JWT payload (no secret needed for client-side display)
    const payload = JSON.parse(atob(response.credential.split('.')[1]));
    const profile = {
      name:   payload.name  || '',
      email:  payload.email || '',
      avatar: payload.picture || '',
      googleId: payload.sub,
      source: 'google',
    };

    // Register/login with backend
    try {
      const res = await fetch(`${API_BASE}/user_auth.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        body: JSON.stringify({ action: 'google_login', id_token: response.credential, ...profile }),
      });
      const data = await res.json();
      if (data.success && data.token) {
        profile.token = data.token;
        if (data.phone)   profile.phone   = data.phone;
        if (data.address) profile.address = data.address;
      }
    } catch (_) { /* network error — still save locally */ }

    save(profile);
    if (typeof callbackFn === 'function') callbackFn(profile);
  }

  function _esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  /* ── Google sign-out ── */
  function signOut() {
    const d = load();
    if (d.googleId && window.google?.accounts?.id) {
      google.accounts.id.revoke(d.email || '', () => {});
    }
    clearDetails();
  }

  return { getDetails, saveDetails, clearDetails, hasDetails, fillForm, watchForm, renderChip, initGoogle, signOut };
})();
