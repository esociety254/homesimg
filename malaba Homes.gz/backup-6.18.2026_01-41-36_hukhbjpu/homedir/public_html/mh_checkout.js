/**
 * mh_checkout.js  — Fast Checkout Shared Logic
 * ===================================================
 * Drop this AFTER mh_user.js and data.js on every listing page.
 *
 * What it does:
 *  • Injects a "Saved details" chip at the top of step 1 in any checkout form
 *  • Auto-fills name / phone / address fields on first open
 *  • Saves filled details on submission so next order is 1-tap
 *  • Shows a "Sign in with Google" prompt if details aren't saved yet
 *  • Works identically on food_listing, homes_listing, shop_listing
 *
 * Usage:
 *  Call MhCheckout.init(formConfig) after you've rendered a checkout form.
 *
 *   MhCheckout.init({
 *     chipContainer : 'ckChipWrap',          // id of div to inject the "Hi Kevin" chip
 *     googleBtn     : 'ckGoogleBtn',          // id of the Google button container (optional)
 *     fields: {                               // field name → input element id
 *       name    : 'ck_name',
 *       phone   : 'ck_phone',
 *       address : 'ck_addr',
 *       idNo    : 'bk_id',                    // optional, homes only
 *     },
 *     onSave: (details) => {},                // called after successful form submission
 *   });
 */

const MhCheckout = (() => {

  const GOOGLE_CLIENT_ID = '';  // same value as mh_user.js — leave '' to disable

  /* CSS injected once */
  const CSS = `
    .mhc-chip {
      display: flex; align-items: center; justify-content: space-between;
      border-radius: 13px; padding: 11px 13px; margin-bottom: 14px; gap: 10px;
      background: rgba(82,183,136,.1); border: 1px solid rgba(82,183,136,.22);
      animation: mhcIn .3s ease;
    }
    @keyframes mhcIn { from { opacity:0; transform:translateY(-6px); } to { opacity:1; transform:translateY(0); } }
    .mhc-chip-left { display:flex; align-items:center; gap:10px; min-width:0; }
    .mhc-avatar {
      width:34px; height:34px; border-radius:50%; background:rgba(82,183,136,.2);
      display:flex; align-items:center; justify-content:center; font-size:15px;
      flex-shrink:0; overflow:hidden;
    }
    .mhc-avatar img { width:100%; height:100%; object-fit:cover; }
    .mhc-name  { font-size:13px; font-weight:700; color:#52B788; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .mhc-sub   { font-size:11px; color:rgba(255,255,255,.45); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .mhc-change {
      font-size:11px; font-weight:700; color:rgba(255,255,255,.4);
      background:transparent; border:1px solid rgba(255,255,255,.12);
      border-radius:8px; padding:5px 10px; cursor:pointer; white-space:nowrap;
      font-family:inherit; flex-shrink:0;
    }
    .mhc-google-wrap {
      margin-bottom: 14px;
    }
    .mhc-google-btn {
      display: flex; align-items: center; justify-content: center; gap: 10px;
      width: 100%; padding: 11px; border-radius: 12px;
      background: #fff; color: #1a1a1a;
      font-size: 14px; font-weight: 600; font-family: inherit;
      border: none; cursor: pointer; transition: opacity .2s;
    }
    .mhc-google-btn:hover { opacity: .9; }
    .mhc-google-btn:active { transform: scale(.98); }
    .mhc-google-btn svg { flex-shrink:0; }
    .mhc-divider {
      display: flex; align-items: center; gap: 10px; margin-bottom: 14px;
      font-size: 11px; font-weight: 600; color: rgba(255,255,255,.25);
      letter-spacing: .5px; text-transform: uppercase;
    }
    .mhc-divider::before, .mhc-divider::after {
      content:''; flex:1; height:1px; background:rgba(255,255,255,.08);
    }
    .mhc-save-tick {
      display: flex; align-items: center; gap: 7px; margin-bottom: 12px;
      font-size: 12px; color: rgba(255,255,255,.4); cursor: pointer;
      font-family: inherit;
    }
    .mhc-save-tick input[type=checkbox] { accent-color: #52B788; width:14px; height:14px; }
  `;

  let _styleInjected = false;
  function _injectStyle() {
    if (_styleInjected) return;
    const s = document.createElement('style');
    s.textContent = CSS;
    document.head.appendChild(s);
    _styleInjected = true;
  }

  /**
   * Main init — call after checkout form HTML exists in the DOM.
   */
  function init(config) {
    _injectStyle();
    const { chipContainer, googleBtn, fields = {}, onSave } = config;
    const d = MhUser.getDetails();

    /* 1 – If we have saved details: show chip + pre-fill silently */
    if (MhUser.hasDetails()) {
      _showChip(chipContainer, d, () => {
        _clearChip(chipContainer);
        _showGooglePrompt(googleBtn, fields, onSave);
      });
      MhUser.fillForm(fields);
    } else {
      /* 2 – Show Google sign-in prompt + "or fill manually" */
      _showGooglePrompt(googleBtn, fields, onSave);
    }

    /* 3 – Watch fields so we auto-save as user types (on blur) */
    MhUser.watchForm(fields);
  }

  function _showChip(containerId, d, onClear) {
    const wrap = document.getElementById(containerId);
    if (!wrap) return;
    const old = wrap.querySelector('.mhc-chip');
    if (old) old.remove();

    const chip = document.createElement('div');
    chip.className = 'mhc-chip';
    const addr = d.address ? d.address.substring(0, 26) + (d.address.length > 26 ? '…' : '') : '';
    chip.innerHTML = `
      <div class="mhc-chip-left">
        <div class="mhc-avatar">
          ${d.avatar ? `<img src="${d.avatar}" alt="">` : '👤'}
        </div>
        <div style="min-width:0;">
          <div class="mhc-name">${_esc(d.name)}</div>
          <div class="mhc-sub">${_esc(d.phone)}${addr ? ' · ' + _esc(addr) : ''}</div>
        </div>
      </div>
      <button class="mhc-change">Change</button>
    `;
    chip.querySelector('.mhc-change').addEventListener('click', () => {
      chip.remove();
      // Clear the pre-filled values
      Object.values(typeof onClear === 'object' ? {} : {}).forEach(id => {
        const el = document.getElementById(id); if (el) el.value = '';
      });
      if (typeof onClear === 'function') onClear();
    });
    wrap.prepend(chip);
  }

  function _clearChip(containerId) {
    const wrap = document.getElementById(containerId);
    if (!wrap) return;
    const chip = wrap.querySelector('.mhc-chip');
    if (chip) chip.remove();
  }

  function _showGooglePrompt(googleBtnId, fields, onSave) {
    const wrap = document.getElementById(googleBtnId);
    if (!wrap || !GOOGLE_CLIENT_ID) return;

    wrap.innerHTML = `
      <div class="mhc-google-wrap">
        <button class="mhc-google-btn" id="_mhcGoogleBtn">
          <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
          Continue with Google
        </button>
      </div>
      <div class="mhc-divider">or fill in manually</div>
    `;

    document.getElementById('_mhcGoogleBtn')?.addEventListener('click', () => {
      MhUser.initGoogle((profile) => {
        // After Google login: fill form + show chip
        MhUser.fillForm(fields);
        _showChip(
          // find the chip container: look for sibling element with mhc-chip parent role
          wrap.closest('[id]')?.id || wrap.parentElement?.id || '',
          profile,
          () => {}
        );
        wrap.innerHTML = ''; // hide the Google button
        if (typeof onSave === 'function') onSave(profile);
      });
    });
  }

  /**
   * Call this AFTER a successful order submission to persist what was entered.
   * @param {object} map  Same fields map used in init()
   */
  function saveFromForm(map) {
    const details = {};
    Object.entries(map).forEach(([field, elId]) => {
      const el = document.getElementById(elId);
      if (el && el.value.trim()) details[field] = el.value.trim();
    });
    if (details.name || details.phone) {
      MhUser.saveDetails(details);
    }
  }

  function _esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  return { init, saveFromForm };
})();
