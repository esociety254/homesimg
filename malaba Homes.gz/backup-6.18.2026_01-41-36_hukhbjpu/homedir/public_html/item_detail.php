<?php
/* ═══════════════════════════════════════════════════════════
   item_detail.php — Malaba Homes Shop: Item Detail Page
   URL: item_detail.php?id=<listing_id>
   ═══════════════════════════════════════════════════════════ */

$apiBase = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/api';
$itemId  = isset($_GET['id']) ? htmlspecialchars(trim($_GET['id']), ENT_QUOTES) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1">
<meta name="theme-color" content="#080400">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="description" content="Shop local products in Malaba. Pay with Lipa Mdogo Mdogo.">
<title>Product — Malaba Homes Shop</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" crossorigin="anonymous">
<?php include 'pwa_head.php'; ?>
<link rel="stylesheet" href="perf_styles.css">

<style>
/* ── DESIGN TOKENS (matches shop_listing.php exactly) ── */
:root{
  --ink:#080400;--ink2:#100a00;--surface:#161210;--card:#1c1812;
  --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);
  --text:#F5F0EB;--muted:#8a8078;--dim:#5a534c;
  --amber:#E8521A;--amber2:#FF7043;--gold:#F5A623;
  --green:#22C55E;--blue:#4895EF;--purple:#7c3aed;
  --sb:env(safe-area-inset-bottom,0px);
  --st:env(safe-area-inset-top,0px);
  --r:12px;--rl:18px;--nav:56px;--bnav:62px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
html{overflow-x:hidden;}
body{
  font-family:'Outfit',sans-serif;background:var(--ink);color:var(--text);
  min-height:100dvh;overflow-x:hidden;-webkit-font-smoothing:antialiased;
  padding-bottom:calc(var(--bnav) + var(--sb) + 8px);
}
a{color:inherit;text-decoration:none;}
button{cursor:pointer;font-family:inherit;border:none;background:none;}
img{display:block;max-width:100%;}
::-webkit-scrollbar{width:3px;height:3px;}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px;}

/* ── HEADER ── */
.hdr{
  position:sticky;top:0;z-index:200;
  background:rgba(8,4,0,.97);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);
  border-bottom:1px solid var(--border);
  padding:var(--st) 0 0;
  box-shadow:0 2px 20px rgba(0,0,0,.45);
}

/* Default row: back + title + actions */
.hdr-row{
  height:var(--nav);display:flex;align-items:center;gap:10px;
  padding:0 14px;
  transition:opacity .18s;
}
.back-btn{
  width:36px;height:36px;border-radius:50%;
  background:var(--surface);border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;flex-shrink:0;
  transition:transform .15s;
  color:var(--text);font-size:15px;
  text-decoration:none;
}
.back-btn:active{transform:scale(.9);}
.back-btn svg{width:17px;height:17px;color:var(--text);}
.hdr-brand{flex:1;font-family:'Bebas Neue',sans-serif;font-size:19px;letter-spacing:2px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.hdr-brand span{color:var(--amber2);}
.hdr-acts{display:flex;gap:7px;flex-shrink:0;}
.ico-btn{
  width:36px;height:36px;border-radius:50%;
  background:var(--surface);border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;
  font-size:15px;position:relative;transition:transform .15s,background .2s;
  color:var(--text);
}
.ico-btn i{font-size:14px;}
.ico-btn:active{transform:scale(.9);}
.hbadge{
  position:absolute;top:-3px;right:-3px;width:17px;height:17px;border-radius:50%;
  background:var(--amber);color:#fff;font-size:9px;font-weight:800;
  display:none;align-items:center;justify-content:center;border:2px solid var(--ink);
}
.hbadge.on{display:flex;}

/* ── EXPANDING SEARCH ROW (hidden until search icon tapped) ── */
.hdr-search-row{
  display:flex;align-items:center;gap:10px;
  padding:0 14px;
  max-height:0;overflow:hidden;opacity:0;
  transition:max-height .28s cubic-bezier(.4,0,.2,1),
             opacity .22s,
             padding .28s cubic-bezier(.4,0,.2,1);
}
.hdr-search-row.open{
  max-height:60px;opacity:1;
  padding:0 14px 10px;
}
.hdr-srch-box{
  flex:1;display:flex;align-items:center;gap:8px;
  background:var(--surface);border:1.5px solid var(--border2);
  border-radius:30px;padding:0 14px;height:40px;
  transition:border-color .2s,box-shadow .2s;
}
.hdr-srch-box:focus-within{border-color:var(--amber);box-shadow:0 0 0 3px rgba(232,82,26,.12);}
.hdr-srch-box i{color:var(--muted);font-size:13px;flex-shrink:0;}
.hdr-srch-box input{
  flex:1;padding:0;background:transparent;border:none;outline:none;
  font-family:inherit;font-size:14px;color:var(--text);
}
.hdr-srch-box input::placeholder{color:var(--muted);}
.srch-cancel{
  font-size:13px;font-weight:700;color:rgba(255,255,255,.5);
  white-space:nowrap;flex-shrink:0;padding:4px 0;
  transition:color .15s;
}
.srch-cancel:active{color:#fff;}

/* ── CATEGORY BROWSER (Jumia-style horizontal scroll) ── */
.cat-browser{
  display:flex;gap:0;
  padding:0 14px 10px;
  overflow-x:auto;scrollbar-width:none;
  -webkit-overflow-scrolling:touch;
  border-top:1px solid var(--border);
}
.cat-browser::-webkit-scrollbar{display:none;}
.cat-item{
  display:flex;flex-direction:column;align-items:center;gap:5px;
  flex-shrink:0;cursor:pointer;padding:8px 10px 0;
  min-width:64px;transition:opacity .18s;
}
.cat-item:active{opacity:.7;}
.cat-icon-wrap{
  width:48px;height:48px;border-radius:14px;
  display:flex;align-items:center;justify-content:center;
  font-size:22px;
  transition:transform .2s;
  /* each category gets its own gradient via inline style */
}
.cat-item:active .cat-icon-wrap{transform:scale(.93);}
.cat-item-lbl{
  font-size:9px;font-weight:700;color:var(--muted);
  letter-spacing:.3px;text-align:center;white-space:nowrap;
  text-transform:uppercase;
  padding-bottom:8px;
}
.cat-item.active .cat-item-lbl{color:var(--amber);}

/* ── FULL-SCREEN SEARCH MODAL ── */
.det-srch-modal{
  position:fixed;inset:0;z-index:600;
  background:rgba(8,4,0,.98);backdrop-filter:blur(24px);
  display:flex;flex-direction:column;
  padding-top:calc(var(--st));
  opacity:0;pointer-events:none;
  transition:opacity .18s;
}
.det-srch-modal.open{opacity:1;pointer-events:all;}
.dsm-bar{
  display:flex;align-items:center;gap:10px;
  padding:12px 14px;border-bottom:1px solid var(--border);
}
.dsm-input-wrap{
  flex:1;display:flex;align-items:center;gap:8px;
  background:rgba(255,255,255,.07);border:1.5px solid var(--amber);
  border-radius:30px;padding:0 14px;height:44px;
}
.dsm-input-wrap i{color:var(--amber);font-size:14px;flex-shrink:0;}
.dsm-input{
  flex:1;padding:0;background:transparent;border:none;outline:none;
  font-family:inherit;font-size:15px;color:var(--text);
}
.dsm-input::placeholder{color:var(--muted);}
.dsm-cancel{
  font-size:13px;font-weight:700;color:rgba(255,255,255,.5);
  white-space:nowrap;padding:4px 2px;transition:color .15s;
}
.dsm-cancel:hover,.dsm-cancel:active{color:#fff;}
/* Results list */
.dsm-results{flex:1;overflow-y:auto;padding:8px 0;}
.dsm-section{padding:10px 14px 5px;font-size:10px;font-weight:700;
  color:rgba(255,255,255,.3);letter-spacing:.7px;text-transform:uppercase;}
.dsm-item{
  display:flex;align-items:center;gap:12px;
  padding:10px 14px;cursor:pointer;transition:background .13s;
}
.dsm-item:active{background:rgba(255,255,255,.05);}
.dsm-thumb{
  width:52px;height:52px;border-radius:10px;object-fit:cover;
  flex-shrink:0;background:var(--surface);
}
.dsm-info{flex:1;min-width:0;}
.dsm-title{font-size:14px;font-weight:600;color:var(--text);margin-bottom:2px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.dsm-sub{font-size:11px;color:var(--muted);}
.dsm-price{font-family:'Bebas Neue',sans-serif;font-size:14px;color:var(--amber2);flex-shrink:0;}
.dsm-hl{color:var(--amber);font-weight:700;}
/* Recent chips */
.dsm-chips{display:flex;flex-wrap:wrap;gap:6px;padding:4px 14px 10px;}
.dsm-chip{
  display:inline-flex;align-items:center;gap:5px;
  padding:5px 12px;border-radius:20px;
  background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.09);
  font-size:12px;color:rgba(255,255,255,.55);cursor:pointer;transition:all .13s;
}
.dsm-chip i{font-size:10px;}
.dsm-chip:hover{background:rgba(255,255,255,.11);color:#fff;}
/* Spinner */
.dsm-spin-wrap{display:none;justify-content:center;padding:28px;}
.dsm-spin-wrap.show{display:flex;}
.dsm-spin{
  width:22px;height:22px;border-radius:50%;
  border:2px solid var(--border2);border-top-color:var(--amber);
  animation:spin .65s linear infinite;
}
@keyframes spin{to{transform:rotate(360deg);}}
.dsm-empty{text-align:center;padding:40px 20px;font-size:14px;color:var(--muted);}

/* ── PAGE SKELETON (shown while loading) ── */
.skel{background:rgba(255,255,255,.06);position:relative;overflow:hidden;}
.skel::after{content:'';position:absolute;inset:0;transform:translateX(-100%);
  background:linear-gradient(90deg,transparent,rgba(255,255,255,.12),transparent);
  animation:skelSh 1.15s ease-in-out infinite;}
@keyframes skelSh{to{transform:translateX(100%);}}

/* ── GALLERY ── */
.gallery-wrap{
  position:relative;
  overflow:hidden;
  background:var(--surface);
  /* Fixed height reserve — prevents ANY layout shift as images load.
     We use a padding-top trick so it works before the first image responds. */
  width:100%;
}
/* Aspect-ratio container: 4:3 on mobile, 16:9 on desktop */
.gallery-aspect{
  position:relative;
  width:100%;
  padding-top:75%; /* 4:3 */
}
@media(min-width:640px){.gallery-aspect{padding-top:56.25%;}} /* 16:9 */

.gallery-track{
  position:absolute;
  inset:0;
  display:flex;
  /* GPU-composited — only transform, no layout properties */
  will-change:transform;
  transition:transform .42s cubic-bezier(.25,.46,.45,.94);
}
.gallery-slide{
  min-width:100%;flex-shrink:0;
  position:relative;overflow:hidden;
}
.gallery-slide img{
  position:absolute;inset:0;
  width:100%;height:100%;
  object-fit:cover;object-position:center;
  /* Start invisible — only appear once decoded.
     We use opacity NOT display:none so the browser still
     fetches and decodes the image in the background. */
  opacity:0;
  transition:opacity .38s ease;
  /* Prevent browser from reserving extra line-height gap */
  display:block;vertical-align:top;
  /* Hint: this is a hero image — decode eagerly for slide 0 */
  decoding:auto;
}
.gallery-slide img.img-loaded{opacity:1;}
.gallery-slide img.img-error{
  opacity:1;
  /* Show a subtle placeholder pattern when image fails */
  background:repeating-linear-gradient(
    45deg,var(--surface),var(--surface) 10px,
    rgba(255,255,255,.03) 10px,rgba(255,255,255,.03) 20px
  );
}

/* Skeleton shimmer — sits behind all slides, hides once first image loads */
.gallery-skel{
  position:absolute;inset:0;z-index:2;
  background:linear-gradient(135deg,var(--surface) 0%,var(--card) 50%,var(--surface) 100%);
  pointer-events:none;
  transition:opacity .4s ease;
}
.gallery-skel::after{
  content:'';position:absolute;inset:0;
  background:linear-gradient(90deg,transparent 0%,rgba(255,255,255,.07) 50%,transparent 100%);
  transform:translateX(-100%);
  animation:galSkelSh 1.3s ease-in-out infinite;
}
@keyframes galSkelSh{to{transform:translateX(100%);}}
.gallery-skel.hidden{opacity:0;pointer-events:none;}

/* Prev / Next arrows */
.gal-prev,.gal-next{
  position:absolute;top:50%;transform:translateY(-50%);z-index:5;
  width:38px;height:38px;border-radius:50%;
  background:rgba(8,4,0,.72);backdrop-filter:blur(12px);
  border:1px solid rgba(255,255,255,.16);
  display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:18px;
  cursor:pointer;
  /* Transition only opacity — no transform so it doesn't fight with translateY */
  transition:opacity .2s,background .2s;
  opacity:.9;
}
.gal-prev{left:10px;} .gal-next{right:10px;}
.gal-prev:active,.gal-next:active{opacity:.6;background:rgba(8,4,0,.9);}
/* Hide arrows when only one image */
.gal-prev.hidden,.gal-next.hidden{display:none;}

/* Image counter pill */
.gal-count{
  position:absolute;bottom:10px;right:10px;z-index:5;
  background:rgba(0,0,0,.65);backdrop-filter:blur(8px);
  color:#fff;font-size:11px;font-weight:700;
  padding:4px 10px;border-radius:20px;
  border:1px solid rgba(255,255,255,.1);
  line-height:1;
}

/* Dot indicators */
.gal-dots{
  position:absolute;bottom:10px;left:50%;
  transform:translateX(-50%);z-index:5;
  display:flex;gap:5px;pointer-events:none;
}
.gal-dot{width:6px;height:6px;border-radius:50%;
  background:rgba(255,255,255,.35);transition:all .28s;}
.gal-dot.on{background:#fff;width:20px;border-radius:3px;}

/* Gallery action buttons (share, wish) */
.gal-actions{
  position:absolute;top:10px;right:10px;z-index:5;
  display:flex;gap:6px;
}
.gal-action-btn{
  width:36px;height:36px;border-radius:50%;
  background:rgba(8,4,0,.7);backdrop-filter:blur(12px);
  border:1px solid rgba(255,255,255,.14);
  display:flex;align-items:center;justify-content:center;font-size:15px;
  transition:transform .18s,background .18s;cursor:pointer;
}
.gal-action-btn:active{transform:scale(.86);}
.gal-action-btn.liked{background:rgba(232,82,26,.35);border-color:rgba(232,82,26,.5);}

/* ── VIDEO WATCH BUTTON (overlaid on gallery) ── */
.gal-watch-btn{
  position:absolute;
  bottom:10px;left:10px;z-index:6;
  display:flex;align-items:center;gap:7px;
  padding:8px 16px 8px 12px;
  background:rgba(8,4,0,.82);backdrop-filter:blur(14px);
  border:1px solid rgba(255,255,255,.18);border-radius:30px;
  color:#fff;font-size:12px;font-weight:700;letter-spacing:.3px;
  cursor:pointer;transition:all .2s;
  /* Animated pulse ring to draw attention */
  box-shadow:0 0 0 0 rgba(124,58,237,.5);
  animation:watchPulse 2.4s ease-in-out infinite;
}
@keyframes watchPulse{
  0%,100%{box-shadow:0 0 0 0 rgba(124,58,237,.4);}
  50%{box-shadow:0 0 0 8px rgba(124,58,237,0);}
}
.gal-watch-btn:active{transform:scale(.95);animation:none;}
.gal-watch-icon{
  width:24px;height:24px;border-radius:50%;
  background:linear-gradient(135deg,#7c3aed,#6366f1);
  display:flex;align-items:center;justify-content:center;
  font-size:10px;flex-shrink:0;
}

/* Thumbnail strip */
.thumbs-wrap{
  display:flex;gap:6px;padding:8px 14px 6px;
  overflow-x:auto;scrollbar-width:none;
  background:rgba(255,255,255,.02);border-bottom:1px solid var(--border);
  -webkit-overflow-scrolling:touch;
}
.thumbs-wrap::-webkit-scrollbar{display:none;}
.thumb{
  width:54px;height:44px;border-radius:8px;
  object-fit:cover;flex-shrink:0;cursor:pointer;
  border:2px solid transparent;
  /* Thumbnails start visible at reduced opacity — no loading flash */
  opacity:.45;transition:border-color .2s,opacity .2s;
  background:var(--surface);
}
.thumb.on{border-color:var(--amber);opacity:1;}
.thumb.img-loaded{opacity:.45;}
.thumb.img-loaded.on{opacity:1;}
.thumb:active{transform:scale(.93);}

/* ── SAME-SHOP SECTION ── */
.shop-section{margin:20px 0 0;}
.shop-section-head{
  display:flex;align-items:center;justify-content:space-between;
  padding:0 14px 10px;
}
.shop-section-head h2{
  font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.5px;
}
.shop-section-head h2 span{color:var(--amber2);}
.shop-section-head a{font-size:11px;font-weight:700;color:var(--amber);white-space:nowrap;}
/* Seller badge inside section header */
.shop-badge{
  display:flex;align-items:center;gap:8px;
  padding:8px 14px;margin-bottom:6px;
}
.shop-badge-avatar{
  width:34px;height:34px;border-radius:50%;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;
}
.shop-badge-name{font-size:13px;font-weight:700;color:var(--text);}
.shop-badge-loc{font-size:11px;color:var(--muted);}
.shop-scroll{
  display:flex;gap:10px;
  padding:0 14px 4px;
  overflow-x:auto;scrollbar-width:none;
  -webkit-overflow-scrolling:touch;
}
.shop-scroll::-webkit-scrollbar{display:none;}
/* Shop item cards — same style as related cards */
.shop-card{
  min-width:148px;width:148px;flex-shrink:0;
  background:var(--card);border:1px solid var(--border);
  border-radius:16px;overflow:hidden;cursor:pointer;
  transition:transform .2s,box-shadow .2s,border-color .2s;
  position:relative;
}
@media(min-width:480px){.shop-card{min-width:162px;width:162px;}}
.shop-card:active{transform:scale(.97);}
@media(hover:hover){
  .shop-card:hover{transform:translateY(-3px);box-shadow:0 10px 26px rgba(0,0,0,.5);border-color:var(--border2);}
}
.shop-card-img{
  position:relative;width:100%;height:106px;overflow:hidden;
  background:linear-gradient(135deg,var(--surface),var(--card));
}
.shop-card-img img{
  width:100%;height:100%;object-fit:cover;
  opacity:1;transition:none;
}
.shop-card-img img.await-load{opacity:0;transition:opacity .3s ease;}
.shop-card-img img.img-loaded{opacity:1;}
@media(hover:hover){
  .shop-card:hover .shop-card-img img{transform:scale(1.05);transition:transform .5s ease;}
}
.shop-card-body{padding:8px 9px 9px;}
.shop-card-title{
  font-size:11px;font-weight:700;color:var(--text);
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;
  overflow:hidden;line-height:1.3;margin-bottom:5px;
}
.shop-card-price{
  font-family:'Bebas Neue',sans-serif;font-size:15px;
  letter-spacing:.3px;color:var(--amber2);margin-bottom:6px;
}
.shop-card-buy{
  width:100%;padding:7px;border-radius:10px;
  background:var(--amber);color:#fff;
  font-family:'Bebas Neue',sans-serif;font-size:12px;letter-spacing:.3px;
  transition:all .18s;display:flex;align-items:center;justify-content:center;gap:3px;
}
.shop-card-buy:active{transform:scale(.95);}
.shop-card-buy.added{background:var(--green);}

/* ── DETAIL BODY ── */
.detail-body{padding:16px 14px 0;}

/* Badge + title row */
.det-badge{
  display:inline-flex;align-items:center;gap:5px;
  font-size:10px;font-weight:700;padding:3px 10px;border-radius:12px;
  background:rgba(232,82,26,.12);color:var(--amber2);margin-bottom:8px;
}
.det-title{
  font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:.5px;
  margin-bottom:4px;line-height:1.1;
}
.det-price{
  font-family:'Bebas Neue',sans-serif;font-size:30px;letter-spacing:.5px;
  color:var(--amber2);margin-bottom:8px;
}

/* Meta row */
.det-meta{display:flex;align-items:center;gap:10px;flex-wrap:wrap;font-size:12px;color:var(--muted);margin-bottom:12px;}
.det-rating{color:var(--gold);font-size:13px;display:flex;align-items:center;gap:3px;}
.det-rating-count{font-size:11px;color:var(--dim);}

/* Description */
.det-desc{
  font-size:14px;color:var(--muted);line-height:1.7;
  margin-bottom:16px;
}
.det-desc.clamped{
  display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;
}
.read-more{
  font-size:13px;font-weight:700;color:var(--amber);cursor:pointer;
  margin-top:-8px;margin-bottom:16px;display:inline-block;
}

/* Features grid */
.feat-grid{
  display:grid;grid-template-columns:1fr 1fr;gap:8px;
  background:rgba(255,255,255,.03);border-radius:var(--r);
  padding:13px;margin-bottom:16px;border:1px solid var(--border);
}
.feat-item{display:flex;align-items:center;gap:7px;font-size:12px;color:var(--muted);}
.feat-icon{font-size:16px;flex-shrink:0;}

/* Seller info */
.seller-card{
  display:flex;align-items:center;gap:12px;
  padding:13px;border-radius:var(--rl);
  background:rgba(255,255,255,.03);border:1px solid var(--border);
  margin-bottom:16px;
}
.seller-avatar{
  width:44px;height:44px;border-radius:50%;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  display:flex;align-items:center;justify-content:center;
  font-size:20px;flex-shrink:0;
}
.seller-info{flex:1;min-width:0;}
.seller-name{font-size:14px;font-weight:700;color:var(--text);}
.seller-loc{font-size:12px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.seller-call{
  padding:8px 14px;border-radius:var(--r);
  background:rgba(37,211,102,.12);border:1px solid rgba(37,211,102,.25);
  color:#25D366;font-size:12px;font-weight:700;
  display:flex;align-items:center;gap:5px;flex-shrink:0;
  transition:all .18s;
}
.seller-call:active{transform:scale(.95);}

/* Video CTA removed — Watch button is now overlaid on the gallery */

/* ── BUY SECTION ── */
.buy-section{margin-bottom:16px;}
.buy-section-title{
  font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.5px;
  color:var(--muted);margin-bottom:10px;padding-left:1px;
}
.buy-options{display:flex;flex-direction:column;gap:8px;}
.buy-opt{
  display:flex;align-items:center;gap:13px;padding:15px;border-radius:var(--rl);
  border:2px solid var(--border2);cursor:pointer;transition:all .2s;
  background:rgba(255,255,255,.02);
}
.buy-opt:active{transform:scale(.99);}
.opt-full:hover,.opt-full:active{border-color:var(--amber);background:rgba(232,82,26,.07);}
.opt-lipa:hover,.opt-lipa:active{border-color:var(--gold);background:rgba(245,166,35,.07);}
.bo-icon{width:42px;height:42px;border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;}
.boi-full{background:rgba(232,82,26,.15);}
.boi-lipa{background:rgba(245,166,35,.15);}
.bo-info{flex:1;}
.bo-title{font-size:14px;font-weight:700;color:var(--text);margin-bottom:2px;}
.bo-sub{font-size:11px;color:var(--muted);}
.bo-arrow{font-size:18px;color:var(--dim);}

/* In-cart notice */
.in-cart-notice{
  text-align:center;font-size:13px;color:var(--green);
  padding:6px 0 10px;
}

/* Divider */
.divider{height:1px;background:var(--border);margin:0 0 20px;}

/* ── RELATED SECTION ── */
.related-head{
  display:flex;align-items:center;justify-content:space-between;
  padding:0 14px 10px;
}
.related-head h2{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:.5px;}
.related-head h2 span{color:var(--amber2);}
.related-head a{font-size:12px;font-weight:600;color:var(--amber);white-space:nowrap;}

/* Related horizontal scroll on mobile, grid on desktop */
.related-scroll{
  display:flex;gap:10px;
  padding:0 14px 4px;
  overflow-x:auto;scrollbar-width:none;
  -webkit-overflow-scrolling:touch;
}
.related-scroll::-webkit-scrollbar{display:none;}

/* Product card — shared with shop_listing.php */
.pcard{
  background:var(--card);border-radius:var(--rl);
  border:1px solid var(--border);overflow:hidden;
  display:flex;flex-direction:column;cursor:pointer;
  transition:transform .2s,box-shadow .2s,border-color .2s;
  position:relative;contain:layout style;
  /* Fixed width in the horizontal scroll */
  min-width:160px;width:160px;flex-shrink:0;
}
@media(min-width:480px){.pcard{min-width:175px;width:175px;}}
@media(hover:hover){.pcard:hover{transform:translateY(-3px);box-shadow:0 12px 30px rgba(0,0,0,.5);border-color:var(--border2);}}
.pcard:active{transform:scale(.97);}

.pcard-img{
  position:relative;width:100%;aspect-ratio:1/1;overflow:hidden;
  background:linear-gradient(135deg,var(--surface),var(--card));
  border-radius:var(--rl) var(--rl) 0 0;
}
@supports not (aspect-ratio:1/1){
  .pcard-img::before{content:'';display:block;padding-top:100%;}
  .pcard-img img{position:absolute;}
}
.pcard-img img{
  position:absolute;inset:0;width:100%;height:100%;object-fit:cover;
  opacity:0;transition:opacity .4s ease;
}
.pcard-img img.img-loaded{opacity:1;}
@media(hover:hover){
  .pcard:hover .pcard-img img{transform:scale(1.05);transition:opacity .4s ease,transform .55s cubic-bezier(.25,.46,.45,.94);}
}
.pbadge{
  position:absolute;top:7px;left:7px;
  background:rgba(8,4,0,.82);backdrop-filter:blur(6px);
  color:var(--text);font-size:9px;font-weight:700;
  padding:3px 8px;border-radius:12px;white-space:nowrap;z-index:2;
}
.plipa-badge{
  position:absolute;bottom:7px;left:7px;z-index:2;
  background:linear-gradient(135deg,rgba(245,166,35,.92),rgba(232,82,26,.92));
  backdrop-filter:blur(4px);color:#fff;font-size:8px;font-weight:800;
  padding:3px 7px;border-radius:10px;white-space:nowrap;letter-spacing:.3px;
}
.wish{
  position:absolute;top:6px;right:6px;z-index:2;
  width:28px;height:28px;border-radius:50%;
  background:rgba(8,4,0,.7);backdrop-filter:blur(6px);
  display:flex;align-items:center;justify-content:center;font-size:13px;
  transition:all .2s;
}
.wish:active{transform:scale(.85);}
.wish.liked{background:rgba(232,82,26,.25);}
.pcard-body{padding:9px 9px 2px;flex:1;}
.ptitle{font-weight:700;font-size:12px;color:var(--text);line-height:1.3;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-bottom:3px;}
.prating{display:flex;align-items:center;gap:2px;font-size:10px;color:var(--gold);}
.prating span{color:var(--muted);}
.ploc{font-size:10px;color:var(--dim);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.pprice{font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;color:var(--amber2);padding:4px 9px 2px;}
.pcard-foot{display:flex;gap:5px;padding:5px 7px 8px;}
.btn-order{
  flex:1;padding:8px 6px;border-radius:var(--r);
  background:var(--amber);color:#fff;
  font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:.3px;
  transition:all .18s;display:flex;align-items:center;justify-content:center;gap:3px;
}
.btn-order:active{transform:scale(.95);background:var(--amber2);}
.btn-order.added{background:var(--green);}
.btn-lipa{
  padding:8px 7px;border-radius:var(--r);
  background:linear-gradient(135deg,var(--gold),var(--amber));
  color:#fff;font-size:10px;font-weight:800;
  transition:all .18s;display:flex;align-items:center;justify-content:center;
  white-space:nowrap;flex-shrink:0;letter-spacing:.3px;
}
.btn-lipa:active{transform:scale(.95);}
.btn-qv{
  width:32px;border-radius:var(--r);background:var(--surface);
  border:1px solid var(--border2);color:var(--muted);font-size:13px;
  display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .18s;
}
.btn-qv:active{border-color:var(--amber);color:var(--amber);}

/* Related empty state */
.related-empty{
  padding:28px 14px;text-align:center;font-size:13px;color:var(--dim);
}

/* ── STICKY BUY BAR (mobile — fixed at bottom above nav) ── */
.sticky-buy{
  position:fixed;bottom:calc(var(--bnav) + var(--sb));left:0;right:0;z-index:150;
  padding:10px 14px;
  background:rgba(8,4,0,.97);backdrop-filter:blur(20px);
  border-top:1px solid var(--border);
  display:flex;gap:8px;
  transform:translateY(100%);
  transition:transform .3s cubic-bezier(.32,1,.68,1);
}
.sticky-buy.show{transform:translateY(0);}
.sticky-price{
  font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:.3px;color:var(--amber2);
  display:flex;align-items:center;flex-shrink:0;
}
.sticky-cart-btn{
  flex:1;padding:12px;border-radius:var(--rl);
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;
  display:flex;align-items:center;justify-content:center;gap:6px;
  transition:all .2s;box-shadow:0 4px 16px rgba(232,82,26,.3);
}
.sticky-cart-btn:active{transform:scale(.98);}
.sticky-cart-btn.added{background:var(--green);}
.sticky-wish-btn{
  width:46px;height:46px;border-radius:var(--rl);
  background:var(--surface);border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;font-size:20px;
  transition:all .2s;flex-shrink:0;
}
.sticky-wish-btn:active{transform:scale(.92);}
.sticky-wish-btn.liked{background:rgba(232,82,26,.15);border-color:rgba(232,82,26,.4);}

/* ── OVERLAY + SHEETS (identical to shop_listing.php) ── */
.overlay{
  position:fixed;inset:0;z-index:400;
  background:rgba(0,0,0,.82);backdrop-filter:blur(6px);
  opacity:0;pointer-events:none;transition:opacity .25s;
  display:flex;align-items:flex-end;
}
.overlay.open{opacity:1;pointer-events:all;}
.sheet{
  width:100%;background:var(--ink2);
  border-radius:24px 24px 0 0;border:1px solid rgba(255,255,255,.08);
  transform:translateY(100%);
  transition:transform .38s cubic-bezier(.32,1,.68,1);
  max-height:94dvh;overflow-y:auto;
  padding-bottom:calc(20px + var(--sb));
}
.overlay.open .sheet{transform:translateY(0);}
.sh-top{display:flex;align-items:center;justify-content:space-between;padding:13px 16px 0;}
.sh-handle{width:38px;height:4px;border-radius:2px;background:rgba(255,255,255,.1);}
.sh-close{
  width:28px;height:28px;border-radius:50%;
  background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
  display:flex;align-items:center;justify-content:center;
  color:rgba(255,255,255,.5);font-size:14px;
}
.sh-close:active{transform:scale(.9);}

/* ── FORM / PAY (shared styles) ── */
.field{margin-bottom:11px;}
.field label{display:block;font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:5px;}
.field input{
  width:100%;padding:11px 13px;border-radius:var(--r);
  background:rgba(255,255,255,.05);border:1.5px solid var(--border2);
  color:var(--text);font-family:inherit;font-size:14px;outline:none;transition:border-color .2s;
}
.field input:focus{border-color:var(--amber);}
.field input::placeholder{color:rgba(255,255,255,.22);}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.pay-opts{display:flex;flex-direction:column;gap:7px;margin-bottom:12px;}
.po{display:flex;align-items:center;gap:11px;padding:11px 12px;border-radius:var(--r);border:2px solid var(--border2);cursor:pointer;transition:all .18s;}
.po.sel{border-color:var(--amber);background:rgba(232,82,26,.07);}
.po:active{transform:scale(.99);}
.po-ico{font-size:18px;}
.po-txt strong{display:block;font-size:13px;font-weight:600;}
.po-txt span{font-size:11px;color:var(--muted);}
.po-dot{width:17px;height:17px;border-radius:50%;border:2px solid var(--dim);margin-left:auto;flex-shrink:0;display:flex;align-items:center;justify-content:center;}
.po.sel .po-dot{border-color:var(--amber);background:var(--amber);}
.po.sel .po-dot::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}
.sbtn{
  width:100%;padding:14px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;border-radius:var(--rl);
  font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.5px;
  transition:all .2s;box-shadow:0 4px 18px rgba(232,82,26,.35);
  display:flex;align-items:center;justify-content:center;gap:7px;
}
.sbtn:active{transform:scale(.98);}
.order-sum{background:rgba(255,255,255,.03);border-radius:var(--r);padding:11px;margin-bottom:12px;border:1px solid var(--border);}
.os-row{display:flex;justify-content:space-between;font-size:13px;color:var(--muted);padding:3px 0;}
.os-row.tot{font-size:14px;font-weight:700;color:var(--text);padding-top:8px;border-top:1px solid var(--border);margin-top:4px;}
.cart-sum{background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:var(--r);padding:11px;margin-bottom:12px;}
.csr{display:flex;justify-content:space-between;font-size:13px;color:var(--muted);padding:4px 0;}
.csr.tot{font-size:14px;font-weight:700;color:var(--text);padding-top:8px;border-top:1px solid var(--border);margin-top:4px;}

/* Lipa styles */
.lipa-pay .po.sel{border-color:var(--gold);background:rgba(245,166,35,.07);}
.lipa-pay .po.sel .po-dot{border-color:var(--gold);background:var(--gold);}
.lipa-header{
  padding:16px 16px 0;
  background:linear-gradient(135deg,rgba(245,166,35,.08),rgba(232,82,26,.05));
  border-bottom:1px solid rgba(245,166,35,.12);margin-bottom:14px;
}
.lipa-product-row{display:flex;gap:12px;padding:0 0 14px;}
.lipa-pimg{width:58px;height:58px;border-radius:12px;object-fit:cover;flex-shrink:0;opacity:0;transition:opacity .3s;}
.lipa-pimg.img-loaded{opacity:1;}
.lipa-pimg-ph{width:58px;height:58px;border-radius:12px;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0;}
.lipa-pname{font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.3px;margin-bottom:2px;}
.lipa-pwas{font-size:11px;color:var(--dim);text-decoration:line-through;}
.lipa-ptag{font-size:10px;color:var(--gold);font-weight:700;margin-top:2px;}
.lipa-steps{display:flex;align-items:center;padding:0 16px 14px;}
.lstep{display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;}
.lstep:last-child{flex:0;flex-shrink:0;}
.ls-dot{width:26px;height:26px;border-radius:50%;border:2px solid var(--border2);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:var(--muted);transition:all .3s;}
.ls-dot.done{background:var(--green);border-color:var(--green);color:#000;}
.ls-dot.active{background:var(--amber);border-color:var(--amber);color:#fff;box-shadow:0 0 0 4px rgba(232,82,26,.18);}
.ls-lbl{font-size:9px;font-weight:600;color:var(--muted);letter-spacing:.2px;text-align:center;}
.ls-lbl.active{color:var(--amber);}
.ls-lbl.done{color:var(--green);}
.ls-line{flex:1;height:2px;background:var(--border2);margin:0 4px;margin-bottom:14px;transition:background .3s;}
.ls-line.done{background:var(--green);}
.lipa-panel{display:none;padding:0 16px;}
.lipa-panel.active{display:block;animation:panelIn .22s ease;}
@keyframes panelIn{from{opacity:0;transform:translateX(10px)}to{opacity:1;transform:translateX(0)}}
.lipa-sec-title{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.3px;margin-bottom:4px;}
.lipa-sec-sub{font-size:12px;color:var(--muted);margin-bottom:14px;line-height:1.5;}
.lipa-freqs{display:flex;flex-direction:column;gap:7px;margin-bottom:14px;}
.lipa-freq{display:flex;align-items:center;gap:10px;padding:13px;border-radius:var(--rl);border:2px solid var(--border2);background:rgba(255,255,255,.02);cursor:pointer;transition:all .18s;}
.lipa-freq.sel{border-color:rgba(245,166,35,.55);background:rgba(245,166,35,.07);}
.lipa-freq:active{transform:scale(.99);}
.lf-radio{width:17px;height:17px;border-radius:50%;border:2px solid var(--dim);flex-shrink:0;display:flex;align-items:center;justify-content:center;transition:all .18s;}
.lipa-freq.sel .lf-radio{background:var(--gold);border-color:var(--gold);}
.lipa-freq.sel .lf-radio::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}
.lf-info{flex:1;}
.lf-name{font-size:13px;font-weight:700;color:var(--text);margin-bottom:1px;}
.lf-desc{font-size:11px;color:var(--muted);}
.lf-right{text-align:right;flex-shrink:0;}
.lf-amount{font-family:'Bebas Neue',sans-serif;font-size:16px;color:var(--gold);letter-spacing:.3px;}
.lf-per{font-size:9px;color:var(--muted);margin-top:1px;}
.lipa-durs{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;}
.lipa-dur{padding:13px 11px;border-radius:var(--rl);border:2px solid var(--border2);background:rgba(255,255,255,.02);cursor:pointer;transition:all .18s;text-align:center;}
.lipa-dur.sel{border-color:rgba(245,166,35,.55);background:rgba(245,166,35,.07);}
.lipa-dur:active{transform:scale(.97);}
.ld-weeks{font-family:'Bebas Neue',sans-serif;font-size:22px;color:var(--text);letter-spacing:.3px;}
.ld-label{font-size:10px;color:var(--muted);margin-bottom:4px;}
.ld-per{font-size:12px;font-weight:700;color:var(--gold);}
.ld-total{font-size:10px;color:var(--dim);margin-top:2px;}
.lipa-summary{background:rgba(245,166,35,.07);border:1px solid rgba(245,166,35,.18);border-radius:var(--r);padding:12px 13px;margin-bottom:12px;display:none;}
.ls-row{display:flex;justify-content:space-between;font-size:12px;padding:3px 0;}
.ls-row .lbl{color:var(--muted);}
.ls-row .val{font-weight:700;color:var(--text);}
.ls-row .val.hi{color:var(--gold);}
.lipa-rule{background:rgba(232,82,26,.07);border:1px solid rgba(232,82,26,.15);border-radius:var(--r);padding:10px 12px;margin-bottom:12px;font-size:11px;color:rgba(255,190,120,.85);line-height:1.6;}
.lipa-rule strong{color:var(--amber2);}
.lipa-nav{display:flex;gap:8px;padding-bottom:2px;}
.lipa-back{padding:12px 16px;background:rgba(255,255,255,.06);border:1px solid var(--border2);border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;color:var(--muted);cursor:pointer;transition:all .18s;}
.lipa-next{flex:1;padding:13px;background:linear-gradient(135deg,var(--gold),var(--amber));color:#fff;border:none;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.3px;cursor:pointer;transition:all .18s;box-shadow:0 4px 16px rgba(245,166,35,.3);}
.lipa-next:active{transform:scale(.98);}

/* Success */
.suc-wrap{text-align:center;padding:24px 16px 10px;}
.suc-ico{font-size:52px;margin-bottom:12px;}
.suc-title{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:.5px;margin-bottom:6px;}
.suc-sub{font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:12px;}
.suc-ref{font-size:12px;color:var(--amber);font-weight:700;margin-bottom:16px;}
.wa-btn{width:100%;padding:13px;background:#25D366;color:#fff;border-radius:var(--rl);font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:.3px;display:flex;align-items:center;justify-content:center;gap:7px;transition:all .2s;margin-bottom:8px;}
.done-btn{width:100%;padding:12px;background:rgba(255,255,255,.05);color:var(--muted);border-radius:var(--rl);font-family:inherit;font-weight:600;font-size:13px;border:1px solid var(--border2);transition:all .2s;}

/* Sort opts, shared */
.sort-opt{padding:14px 18px;font-size:15px;color:var(--text);cursor:pointer;transition:background .13s;}
.sort-opt:active,.sort-opt:hover{background:rgba(255,255,255,.04);}
.sort-opt.sel{color:var(--amber);}

/* ── BOTTOM NAV ── */
.bnav{
  position:fixed;bottom:0;left:0;right:0;z-index:200;
  height:calc(var(--bnav) + var(--sb));padding-bottom:var(--sb);
  background:rgba(8,4,0,.95);backdrop-filter:blur(28px);-webkit-backdrop-filter:blur(28px);
  border-top:1px solid rgba(255,255,255,.07);
  display:flex;align-items:stretch;
}
.bni{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:0 4px;-webkit-tap-highlight-color:transparent;transition:all .2s;position:relative;}
.bni-ico{font-size:20px;color:rgba(255,255,255,.38);transition:all .22s;line-height:1.15;}
.bni-lbl{font-size:9px;font-weight:700;color:rgba(255,255,255,.3);letter-spacing:.5px;text-transform:uppercase;transition:all .22s;}
.bni.active .bni-ico,.bni.active .bni-lbl{color:var(--amber);}
.bni.active::before{content:'';position:absolute;bottom:2px;width:20px;height:2px;border-radius:1px;background:var(--amber);animation:indIn .3s ease;}
@keyframes indIn{from{width:0;opacity:0;}to{width:20px;opacity:1;}}
.bni-center{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;-webkit-tap-highlight-color:transparent;cursor:pointer;position:relative;text-decoration:none;}
.bni-center-btn{width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#6366f1);display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:0 -2px 16px rgba(124,58,237,.5);margin-top:-16px;border:3px solid rgba(8,4,0,.95);transition:all .22s;}
.bni-center:active .bni-center-btn{transform:scale(.92);}
.bni-center-lbl{font-size:9px;font-weight:700;color:rgba(139,92,246,.75);letter-spacing:.5px;text-transform:uppercase;}

/* ── TOAST ── */
.toast{
  position:fixed;bottom:calc(var(--bnav) + var(--sb) + 14px);left:50%;
  transform:translateX(-50%) translateY(8px);
  background:var(--text);color:var(--ink);
  padding:10px 20px;border-radius:30px;font-size:13px;font-weight:600;
  z-index:999;opacity:0;pointer-events:none;transition:all .22s;
  white-space:nowrap;box-shadow:0 8px 24px rgba(0,0,0,.4);
}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}

/* ── NOT FOUND STATE ── */
.not-found{
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  min-height:60vh;text-align:center;padding:32px 24px;
}
.not-found .nf-ico{font-size:56px;margin-bottom:16px;}
.not-found h2{font-family:'Bebas Neue',sans-serif;font-size:28px;margin-bottom:8px;}
.not-found p{color:var(--muted);font-size:14px;margin-bottom:20px;}
.not-found a{
  padding:12px 24px;border-radius:var(--rl);
  background:var(--amber);color:#fff;
  font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.3px;
}

/* Page fade-in */
.page-enter{animation:pgIn .4s ease both;}
@keyframes pgIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
</style>
</head>
<body>

<!-- FULL-SCREEN SEARCH MODAL -->
<div class="det-srch-modal" id="detSrchModal">
  <div class="dsm-bar">
    <div class="dsm-input-wrap">
      <i class="fa-solid fa-magnifying-glass"></i>
      <input class="dsm-input" id="dsmInput" type="search"
             placeholder="Search products..." autocomplete="off" spellcheck="false">
    </div>
    <button class="dsm-cancel" onclick="closeDsmModal()">Cancel</button>
  </div>
  <div class="dsm-results" id="dsmResults">
    <div class="dsm-section">Recent Searches</div>
    <div class="dsm-chips" id="dsmChips"></div>
  </div>
</div>

<!-- HEADER -->
<header class="hdr" id="mainHdr">
  <div class="hdr-row">
    <a href="shop_listing.php" class="back-btn" id="backBtn">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
        <path d="M19 12H5M5 12l7-7M5 12l7 7"/>
      </svg>
    </a>
    <div class="hdr-brand">Malaba <span>Shop</span></div>
    <div class="hdr-acts">
      <!-- Search icon — opens modal -->
      <button class="ico-btn" id="hdrSearchBtn" onclick="openDsmModal()" title="Search">
        <i class="fa-solid fa-magnifying-glass"></i>
      </button>
      <!-- Share — fa-share-nodes is universally recognised -->
      <button class="ico-btn" onclick="shareItem()" title="Share">
        <i class="fa-solid fa-share-nodes"></i>
      </button>
      <!-- Cart -->
      <button class="ico-btn" onclick="openCart()" title="Cart">
        <i class="fa-solid fa-cart-shopping"></i>
        <span class="hbadge" id="hBadge">0</span>
      </button>
    </div>
  </div>

  <!-- ── CATEGORY BROWSER ── -->
  <div class="cat-browser" id="catBrowser">
    <div class="cat-item active" onclick="catGo('')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#E8521A,#FF7043);">🛍</div>
      <div class="cat-item-lbl">All</div>
    </div>
    <div class="cat-item" onclick="catGo('electronics')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#4895EF,#2563eb);">📱</div>
      <div class="cat-item-lbl">Electronics</div>
    </div>
    <div class="cat-item" onclick="catGo('kitchen')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#F5A623,#d97706);">🍳</div>
      <div class="cat-item-lbl">Kitchen</div>
    </div>
    <div class="cat-item" onclick="catGo('furniture')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#7c3aed,#6366f1);">🛋</div>
      <div class="cat-item-lbl">Furniture</div>
    </div>
    <div class="cat-item" onclick="catGo('decor')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#ec4899,#be185d);">🖼</div>
      <div class="cat-item-lbl">Décor</div>
    </div>
    <div class="cat-item" onclick="catGo('appliances')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#059669,#10b981);">⚡</div>
      <div class="cat-item-lbl">Appliances</div>
    </div>
    <div class="cat-item" onclick="catGo('fashion')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#db2777,#9d174d);">👗</div>
      <div class="cat-item-lbl">Fashion</div>
    </div>
    <div class="cat-item" onclick="catGo('bedding')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#0891b2,#0e7490);">🛏</div>
      <div class="cat-item-lbl">Bedding</div>
    </div>
    <div class="cat-item" onclick="catGo('storage')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#65a30d,#4d7c0f);">🧺</div>
      <div class="cat-item-lbl">Storage</div>
    </div>
    <div class="cat-item" onclick="catGo('cleaning')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#22C55E,#166534);">🧹</div>
      <div class="cat-item-lbl">Cleaning</div>
    </div>
    <div class="cat-item" onclick="catGo('beauty')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#f472b6,#9d174d);">💄</div>
      <div class="cat-item-lbl">Beauty</div>
    </div>
    <div class="cat-item" onclick="catGo('baby')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#fbbf24,#d97706);">👶</div>
      <div class="cat-item-lbl">Baby</div>
    </div>
    <div class="cat-item" onclick="catGo('sports')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#16a34a,#064e3b);">⚽</div>
      <div class="cat-item-lbl">Sports</div>
    </div>
    <div class="cat-item" onclick="catGo('health')">
      <div class="cat-icon-wrap" style="background:linear-gradient(135deg,#ef4444,#991b1b);">💊</div>
      <div class="cat-item-lbl">Health</div>
    </div>
  </div>
</header>

<!-- MAIN CONTENT — injected by JS -->
<div id="pageContent"></div>
<br><br><br>
<!-- BOTTOM NAV -->
<nav class="bnav">
  <a href="index.php" class="bni">
    <div class="bni-ico">&#x1F3E1;</div>
    <div class="bni-lbl">Home</div>
  </a>
  <a href="shop_listing.php" class="bni active">
    <div class="bni-ico">&#x1F6D2;</div>
    <div class="bni-lbl">Shop</div>
  </a>
  <a href="video_feed.php" class="bni-center">
    <div class="bni-center-btn">&#x25B6;</div>
    <div class="bni-center-lbl">Watch</div>
  </a>
  <a href="food_listing.php" class="bni">
    <div class="bni-ico">&#x1F354;</div>
    <div class="bni-lbl">Food</div>
  </a>
  <a href="homes_listing.php" class="bni">
    <div class="bni-ico">&#127976;</div>
    <div class="bni-lbl">Rentals</div>
  </a>
</nav>

<!-- STICKY BUY BAR -->
<div class="sticky-buy" id="stickyBuy">
  <div class="sticky-price" id="stickyPrice"></div>
  <button class="sticky-cart-btn" id="stickyCartBtn" onclick="addToCartAndOpen()">
    &#x1F6D2; Buy Now
  </button>
  <button class="sticky-wish-btn" id="stickyWishBtn" onclick="toggleWishMain()">
    <i class="fa-regular fa-heart"></i>
  </button>
</div>

<!-- OVERLAY / SHEET -->
<div class="overlay" id="overlay" onclick="handleOvClick(event)">
  <div class="sheet" id="activeSheet">
    <div id="sheetContent"></div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script src="data.js"></script>
<script src="mh_user.js"></script>
<script src="img_perf_1.js"></script>
<script src="perf_patch_1.js"></script>
<script>
/* ═══════════════════════════════════════════════════════════
   CONFIG
   ═══════════════════════════════════════════════════════════ */
var ITEM_ID   = '<?php echo $itemId; ?>';
var API_BASE  = (function(){
  var scripts = document.querySelectorAll('script[src]');
  for (var i = 0; i < scripts.length; i++) {
    if (scripts[i].src && scripts[i].src.indexOf('data.js') !== -1) {
      return scripts[i].src.replace(/\/data\.js[^\/]*$/, '/api');
    }
  }
  return '<?php echo htmlspecialchars($apiBase, ENT_QUOTES); ?>';
})();

/* ═══════════════════════════════════════════════════════════
   STATE
   ═══════════════════════════════════════════════════════════ */
var currentItem  = null;
var relatedItems = [];
var galIdx       = 0;
var cart         = [];
var wishlist     = [];
var payMode      = 'cash';
var lipaFreq     = null;
var lipaDur      = null;
var lipaPayMode  = 'mpesa';
var lipaFreqOpts = [];
var lipaDurOpts  = [];
var descExpanded = false;

try { cart     = JSON.parse(localStorage.getItem('mh_shop_cart') || '[]'); } catch(e){}
try { wishlist = JSON.parse(localStorage.getItem('mh_shop_wish') || '[]'); } catch(e){}

/* ═══════════════════════════════════════════════════════════
   BOOT
   ═══════════════════════════════════════════════════════════ */
window.addEventListener('DOMContentLoaded', function() {
  renderBadges();
  loadItem(ITEM_ID);
  initStickyBar();
  initSwipeClose();
});

function initStickyBar() {
  window.addEventListener('scroll', function() {
    var bar = document.getElementById('stickyBuy');
    if (!bar) return;
    // Show sticky bar once user scrolls past the image
    bar.classList.toggle('show', window.scrollY > 260);
  }, {passive: true});
}

function initSwipeClose() {
  var sheet = document.getElementById('activeSheet');
  var tsY = 0;
  sheet.addEventListener('touchstart', function(e){ tsY = e.touches[0].clientY; }, {passive:true});
  sheet.addEventListener('touchend', function(e){
    if (e.changedTouches[0].clientY - tsY > 80 && sheet.scrollTop === 0) closeOverlay();
  }, {passive:true});
}

/* ═══════════════════════════════════════════════════════════
   LOAD ITEM
   ═══════════════════════════════════════════════════════════ */
function loadItem(id) {
  if (!id) { renderNotFound('No item ID provided.'); return; }

  /* 1. Try seed data first for instant render */
  var seed = null;
  if (window.MalabaAPI) {
    seed = MalabaAPI._seed.items.find(function(i){ return i.id === id; });
  }

  if (seed) {
    currentItem = seed;
    renderPage(seed);
    loadRelated(seed);
    loadShopItems(seed);
  }

  /* 2. Always hit API to get fresh data (incl. DB images, views, features) */
  var xhr = new XMLHttpRequest();
  xhr.open('GET', API_BASE + '/listing.php?id=' + encodeURIComponent(id), true);
  xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
  xhr.timeout = 10000;
  xhr.onload = function() {
    try {
      var d = JSON.parse(xhr.responseText);
      if (d && d.success && d.data) {
        currentItem = d.data;
        renderPage(d.data);
        loadRelated(d.data);
        loadShopItems(d.data);
        return;
      }
    } catch(e) {}
    if (!seed) renderNotFound('This item could not be found.');
  };
  xhr.onerror = xhr.ontimeout = function() {
    if (!seed) renderNotFound('Network error. Check your connection.');
  };
  xhr.send();

  /* Track view */
  if (window.MalabaAPI) MalabaAPI.trackView(id);
}

/* ═══════════════════════════════════════════════════════════
   RENDER PAGE
   ═══════════════════════════════════════════════════════════ */
function renderPage(item) {
  /* Update page title */
  document.title = esc(item.title) + ' — Malaba Homes Shop';

  var raw     = parseFloat(String(item.price||'').replace(/[^0-9.]/g,'')) || 0;
  var hasLipa = raw >= 200;
  var hasVid  = !!(item.video_url || item.has_video);
  var inCart  = cart.find(function(c){ return c.id === item.id; });
  var liked   = wishlist.indexOf(item.id) !== -1;
  var rating  = item.rating ? parseFloat(item.rating).toFixed(1) : (3.9 + Math.random() * 0.9).toFixed(1);
  var phone   = (item.contact && item.contact.phone) ? item.contact.phone : (item.contact_phone || '');
  var seller  = (item.contact && item.contact.name) ? item.contact.name : (item.contact_name || 'Seller');

  /* Build image array */
  var imgs = buildImgArray(item);
  var multi = imgs.length > 1;

  /* Gallery slides */
  var slidesHTML = imgs.map(function(rawSrc, si) {
    var src = rawSrc;
    if (src.indexOf('unsplash.com') !== -1) src = src.split('?')[0] + '?w=900&q=82&auto=format&fit=crop';
    if (src.indexOf('cloudinary.com') !== -1) src = src.replace('/upload/', '/upload/w_900,f_auto,q_82/');
    if (!src) src = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=900&q=70';
    return (
      '<div class="gallery-slide">' +
        '<img src="' + esc(src) + '"' +
          ' alt="' + esc(item.title) + (si > 0 ? ' — photo ' + (si+1) : '') + '"' +
          ' loading="' + (si === 0 ? 'eager' : 'lazy') + '"' +
          ' decoding="' + (si === 0 ? 'sync' : 'async') + '"' +
          ' fetchpriority="' + (si === 0 ? 'high' : 'low') + '"' +
          ' onerror="this.onerror=null;this.src=\'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=900&q=70\'">' +
      '</div>'
    );
  }).join('');

  /* Dots */
  var dotsHTML = multi ? imgs.map(function(_, di) {
    return '<div class="gal-dot' + (di===0?' on':'') + '"></div>';
  }).join('') : '';

  /* Thumbnail strip */
  var thumbsHTML = multi ? imgs.map(function(rawSrc, ti) {
    var src = window.MhImgPerf ? MhImgPerf.imgThumb(rawSrc) : rawSrc;
    if (src.indexOf('unsplash.com') !== -1) src = src.split('?')[0] + '?w=120&h=96&q=65&auto=format&fit=crop';
    if (src.indexOf('cloudinary.com') !== -1) src = src.replace('/upload/', '/upload/w_120,h_96,c_fill,f_auto,q_65/');
    return '<img src="' + esc(src) + '" class="thumb' + (ti===0?' on':'') + '"' +
      ' loading="lazy" width="58" height="48"' +
      ' onclick="galTo(' + ti + ')"' +
      ' onerror="this.style.display=\'none\'">';
  }).join('') : '';

  /* Features */
  var featsHTML = '';
  if (item.features && item.features.length) {
    featsHTML = '<div class="feat-grid">' +
      item.features.map(function(f) {
        return '<div class="feat-item"><span class="feat-icon">' + (f.icon||'✅') + '</span>' +
          '<span>' + esc(f.text||f.feature_text||'') + '</span></div>';
      }).join('') +
    '</div>';
  }

  /* Description with read-more if long */
  var desc = item.description || '';
  var descHTML = '';
  if (desc) {
    if (desc.length > 140) {
      descHTML = '<div class="det-desc clamped" id="detDesc">' + esc(desc) + '</div>' +
        '<span class="read-more" id="readMore" onclick="expandDesc()">Read more ›</span>';
    } else {
      descHTML = '<div class="det-desc">' + esc(desc) + '</div>';
    }
  }

  var html =
    '<div class="page-enter">' +

    /* ── GALLERY ── */
    '<div class="gallery-wrap">' +
      '<div class="gallery-aspect">' +
        '<div class="gallery-skel" id="galSkel"></div>' +
        '<div class="gallery-track" id="galTrack">' + slidesHTML + '</div>' +
        (multi ?
          '<button class="gal-prev" id="galPrev" onclick="galNav(-1)">&#x2039;</button>' +
          '<button class="gal-next" id="galNext" onclick="galNav(1)">&#x203A;</button>' +
          '<div class="gal-count" id="galCount">1 / ' + imgs.length + '</div>' +
          '<div class="gal-dots" id="galDots">' + dotsHTML + '</div>'
        : '') +
        /* Watch button — only if item has a video */
        (hasVid ?
          '<button class="gal-watch-btn" onclick="openVideoPlayer()">' +
            '<div class="gal-watch-icon">&#x25B6;</div>' +
            'Watch' +
          '</button>'
        : '') +
        '<div class="gal-actions">' +
          '<button class="gal-action-btn' + (liked?' liked':'') + '" id="galWishBtn" onclick="toggleWishMain()">' +
            (liked ? '<i class="fa-solid fa-heart"></i>' : '<i class="fa-regular fa-heart"></i>') +
          '</button>' +
          '<button class="gal-action-btn" onclick="shareItem()" title="Share">' +
            '<i class="fa-solid fa-share-nodes"></i>' +
          '</button>' +
        '</div>' +
      '</div>' + /* /gallery-aspect */
    '</div>' + /* /gallery-wrap */

    /* Thumbnail strip */
    (multi ? '<div class="thumbs-wrap" id="thumbsWrap">' + thumbsHTML + '</div>' : '') +

    /* ── DETAIL BODY ── */
    '<div class="detail-body">' +

      (item.badge ? '<div class="det-badge">' + esc(item.badge) + '</div>' : '') +
      '<div class="det-title">' + esc(item.title) + '</div>' +
      '<div class="det-price">' + esc(item.price) + '</div>' +

      /* Meta */
      '<div class="det-meta">' +
        '<div class="det-rating">' +
          '&#x2605;&#x2605;&#x2605;&#x2605;' + (parseFloat(rating) >= 4.5 ? '&#x2605;' : '&#x2606;') +
          '<span>' + rating + '</span>' +
          '<span class="det-rating-count">(' + (Math.floor(Math.random()*80)+12) + ' reviews)</span>' +
        '</div>' +
        (item.location ? '<span>&#x1F4CD; ' + esc((item.location||'').split(',')[0]) + '</span>' : '') +
        (item.prep_time ? '<span>&#x23F1; ' + esc(item.prep_time) + '</span>' : '') +
        (item.views && item.views > 0 ? '<span>&#x1F441; ' + Number(item.views).toLocaleString() + ' views</span>' : '') +
      '</div>' +

      descHTML +
      featsHTML +

      /* Seller */
      '<div class="seller-card">' +
        '<div class="seller-avatar">&#x1F6CD;</div>' +
        '<div class="seller-info">' +
          '<div class="seller-name">' + esc(seller) + '</div>' +
          '<div class="seller-loc">&#x1F4CD; ' + esc(item.location || 'Malaba, Kenya') + '</div>' +
        '</div>' +
        (phone ?
          '<a href="tel:+' + esc(normWA(phone)) + '" class="seller-call">&#x1F4DE; Call</a>'
        : '') +
      '</div>' +

      /* Video CTA removed — Watch button is on the gallery */

      /* ── BUY OPTIONS ── */
      '<div class="buy-section">' +
        '<div class="buy-section-title">PURCHASE OPTIONS</div>' +
        '<div class="buy-options">' +
          '<div class="buy-opt opt-full" onclick="openDirectOrder()">' +
            '<div class="bo-icon boi-full">&#x1F6D2;</div>' +
            '<div class="bo-info">' +
              '<div class="bo-title">Buy Now — ' + esc(item.price) + '</div>' +
              '<div class="bo-sub">Cash or M-Pesa on delivery. Fast & simple.</div>' +
            '</div>' +
            '<div class="bo-arrow">&#x203A;</div>' +
          '</div>' +
          (hasLipa ?
            '<div class="buy-opt opt-lipa" onclick="startLipaSheet()">' +
              '<div class="bo-icon boi-lipa">&#x1F4B0;</div>' +
              '<div class="bo-info">' +
                '<div class="bo-title">Lipa Mdogo Mdogo</div>' +
                '<div class="bo-sub">Daily, weekly or bi-weekly instalments.</div>' +
              '</div>' +
              '<div class="bo-arrow">&#x203A;</div>' +
            '</div>'
          : '') +
        '</div>' +
      '</div>' +

      /* In-cart notice */
      (inCart ?
        '<div class="in-cart-notice" id="inCartNotice">' +
          '&#x2713; Already in your cart — ' +
          '<button onclick="openCart()" style="color:var(--amber);font-weight:700;font-size:13px;cursor:pointer;">View Cart</button>' +
        '</div>'
      : '') +

    '</div>' + /* /detail-body */

    '<div class="divider"></div>' +
    /* ── RELATED ITEMS (same subcategory) ── */
    '<div id="relatedSection"></div>' +
    /* ── SAME SHOP ITEMS ── */
    '<div id="shopSection"></div>' +
    '</div>'; /* /page-enter */

  document.getElementById('pageContent').innerHTML = html;

  /* Update sticky bar */
  document.getElementById('stickyPrice').textContent = item.price;
  var cb = document.getElementById('stickyCartBtn');
  if (cb && inCart) { cb.innerHTML = '<i class="fa-solid fa-check"></i> In Cart'; cb.classList.add('added'); }
  updateStickyWish();

  /* Fade in gallery images */
  initGalleryImages(imgs.length);

  /* Gallery touch swipe */
  var track = document.getElementById('galTrack');
  if (track) {
    var tsX = 0, tsY_g = 0;
    track.addEventListener('touchstart', function(e){ tsX=e.touches[0].clientX; tsY_g=e.touches[0].clientY; }, {passive:true});
    track.addEventListener('touchend', function(e){
      var dx = e.changedTouches[0].clientX - tsX;
      var dy = e.changedTouches[0].clientY - tsY_g;
      if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy) * 1.2) galNav(dx < 0 ? 1 : -1);
    }, {passive:true});
  }

  if (window.MhPerfPatch) MhPerfPatch.run();
}

/* ═══════════════════════════════════════════════════════════
   GALLERY
   ═══════════════════════════════════════════════════════════ */
function buildImgArray(item) {
  var imgs = [];
  var main = item.image || item.image_url || '';
  if (main) imgs.push(main);
  if (item.images && item.images.length) {
    item.images.forEach(function(gi) {
      var u = gi.image_url || gi.url || gi || '';
      if (u && imgs.indexOf(u) === -1) imgs.push(u);
    });
  }
  if (!imgs.length) imgs.push('https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=900&q=75');
  return imgs;
}

function initGalleryImages(total) {
  var skel   = document.getElementById('galSkel');
  var slides = document.querySelectorAll('.gallery-slide img');
  var firstLoaded = false;

  slides.forEach(function(img, i) {
    /* Decode the first image synchronously if available */
    if (i === 0) img.decoding = 'sync';

    function onLoad() {
      img.classList.remove('img-error');
      img.classList.add('img-loaded');
      if (i === 0 && !firstLoaded) {
        firstLoaded = true;
        /* Hide skeleton immediately once first image is ready */
        if (skel) {
          skel.classList.add('hidden');
          /* Remove from DOM after transition to free memory */
          setTimeout(function(){ if(skel&&skel.parentNode) skel.parentNode.removeChild(skel); }, 500);
        }
      }
    }
    function onError() {
      /* Silently swap to fallback — no flicker */
      img.src = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=900&q=70';
      img.classList.add('img-error');
      img.classList.add('img-loaded');
      if (i === 0 && !firstLoaded) {
        firstLoaded = true;
        if (skel) skel.classList.add('hidden');
      }
    }

    if (img.complete && img.naturalWidth > 0) {
      /* Already in browser cache — show instantly */
      onLoad();
    } else if (img.complete && img.naturalWidth === 0) {
      /* complete but broken (e.g. 404 cached) */
      onError();
    } else {
      img.addEventListener('load',  onLoad,  {once:true});
      img.addEventListener('error', onError, {once:true});
    }
  });

  /* Thumbnail opacity — show once loaded */
  document.querySelectorAll('.thumb').forEach(function(t) {
    function thumbReady(){ t.classList.add('img-loaded'); }
    if (t.complete && t.naturalWidth > 0) thumbReady();
    else {
      t.addEventListener('load',  thumbReady, {once:true});
      t.addEventListener('error', function(){ t.style.display='none'; }, {once:true});
    }
  });
}

function galNav(dir) {
  if (!currentItem) return;
  var imgs = buildImgArray(currentItem);
  galIdx = (galIdx + dir + imgs.length) % imgs.length;
  galTo(galIdx);
}

function galTo(idx) {
  galIdx = idx;
  var track  = document.getElementById('galTrack');
  var dots   = document.getElementById('galDots');
  var thumbs = document.getElementById('thumbsWrap');
  var count  = document.getElementById('galCount');

  if (track) track.style.transform = 'translateX(-' + (idx * 100) + '%)';

  if (dots) {
    dots.querySelectorAll('.gal-dot').forEach(function(d, i){ d.classList.toggle('on', i===idx); });
  }
  if (thumbs) {
    thumbs.querySelectorAll('.thumb').forEach(function(t, i){
      t.classList.toggle('on', i===idx);
      t.style.opacity = i === idx ? '1' : '0.5';
    });
    var active = thumbs.querySelectorAll('.thumb')[idx];
    if (active) active.scrollIntoView({behavior:'smooth', block:'nearest', inline:'center'});
  }
  if (count) {
    count.textContent = (idx+1) + ' / ' + document.querySelectorAll('.gallery-slide').length;
  }
}

/* ═══════════════════════════════════════════════════════════
   DESCRIPTION EXPAND
   ═══════════════════════════════════════════════════════════ */
function expandDesc() {
  var d = document.getElementById('detDesc');
  var r = document.getElementById('readMore');
  if (!d) return;
  d.classList.remove('clamped');
  if (r) r.style.display = 'none';
}

/* ═══════════════════════════════════════════════════════════
   WISHLIST
   ═══════════════════════════════════════════════════════════ */
function toggleWishMain() {
  if (!currentItem) return;
  var id = currentItem.id;
  var i  = wishlist.indexOf(id);
  if (i !== -1) {
    wishlist.splice(i, 1);
    showToast('Removed from saved');
  } else {
    wishlist.unshift(id);
    showToast('<i class="fa-solid fa-heart" style="color:var(--amber);margin-right:4px;"></i> Saved!');
  }
  try { localStorage.setItem('mh_shop_wish', JSON.stringify(wishlist)); } catch(e){}
  updateStickyWish();
  var gwb = document.getElementById('galWishBtn');
  if (gwb) {
    var liked = wishlist.indexOf(id) !== -1;
    gwb.innerHTML = liked
      ? '<i class="fa-solid fa-heart"></i>'
      : '<i class="fa-regular fa-heart"></i>';
    gwb.classList.toggle('liked', liked);
  }
}

function updateStickyWish() {
  if (!currentItem) return;
  var liked = wishlist.indexOf(currentItem.id) !== -1;
  var btn = document.getElementById('stickyWishBtn');
  if (btn) {
    btn.innerHTML = liked
      ? '<i class="fa-solid fa-heart"></i>'
      : '<i class="fa-regular fa-heart"></i>';
    btn.classList.toggle('liked', liked);
  }
}

/* ═══════════════════════════════════════════════════════════
   VIDEO PLAYER — inline modal overlay
   ═══════════════════════════════════════════════════════════ */
function openVideoPlayer() {
  var item = currentItem;
  if (!item) return;
  var videoUrl = item.video_url || item.videoUrl || '';

  /* Build the modal once */
  var existing = document.getElementById('videoModal');
  if (existing) existing.parentNode.removeChild(existing);

  var modal = document.createElement('div');
  modal.id = 'videoModal';
  modal.style.cssText = [
    'position:fixed','inset:0','z-index:700',
    'background:rgba(0,0,0,.95)',
    'display:flex','flex-direction:column',
    'align-items:center','justify-content:center',
  ].join(';');

  var closeBtn =
    '<button onclick="document.getElementById(\'videoModal\').remove()" ' +
    'style="position:absolute;top:calc(env(safe-area-inset-top,0px)+12px);right:14px;' +
    'width:38px;height:38px;border-radius:50%;background:rgba(255,255,255,.12);' +
    'border:1px solid rgba(255,255,255,.2);color:#fff;font-size:18px;' +
    'display:flex;align-items:center;justify-content:center;cursor:pointer;">&#x2715;</button>';

  if (videoUrl && (videoUrl.indexOf('youtube') !== -1 || videoUrl.indexOf('youtu.be') !== -1)) {
    /* YouTube embed */
    var ytId = videoUrl.replace(/.*(?:v=|\/embed\/|youtu\.be\/)([^&?\/]+).*/,'$1');
    modal.innerHTML = closeBtn +
      '<div style="width:100%;max-width:720px;padding:0 14px;">' +
        '<div style="position:relative;padding-top:56.25%;border-radius:16px;overflow:hidden;">' +
          '<iframe src="https://www.youtube.com/embed/' + esc(ytId) + '?autoplay=1&rel=0" ' +
            'style="position:absolute;inset:0;width:100%;height:100%;border:none;" ' +
            'allow="autoplay;fullscreen" allowfullscreen></iframe>' +
        '</div>' +
      '</div>';
  } else if (videoUrl) {
    /* Direct video file (mp4 / webm) */
    modal.innerHTML = closeBtn +
      '<div style="width:100%;max-width:720px;padding:0 14px;">' +
        '<video src="' + esc(videoUrl) + '" controls autoplay playsinline ' +
          'style="width:100%;border-radius:16px;max-height:75dvh;background:#000;">' +
          'Your browser does not support video.' +
        '</video>' +
      '</div>';
  } else {
    /* No video URL — navigate to video feed */
    modal.remove();
    openInVideoFeed(item.id);
    return;
  }

  document.body.appendChild(modal);
  /* Close on backdrop tap */
  modal.addEventListener('click', function(e){
    if (e.target === modal) modal.remove();
  });
}

/* ═══════════════════════════════════════════════════════════
   SAME-SHOP ITEMS
   Uses seller_id (when set) + contact_name (always).
   Phone is intentionally excluded — in this dataset many
   different shops share the same contact_phone, so filtering
   by phone returns unrelated listings.
   ═══════════════════════════════════════════════════════════ */
var shopItems = [];

function loadShopItems(item) {
  var sellerId   = item.seller_id || null;
  var sellerName = ((item.contact && item.contact.name)
    ? item.contact.name : (item.contact_name || '')).trim();
  var itemId     = item.id;

  /* contact_name is required — without it we cannot identify the shop */
  if (!sellerName && !sellerId) return;

  var params = 'type=items&limit=20&sort=popular'
    + '&exclude='     + encodeURIComponent(itemId)
    + '&seller_name=' + encodeURIComponent(sellerName)
    + (sellerId ? '&seller_id=' + encodeURIComponent(sellerId) : '');

  var xhr = new XMLHttpRequest();
  xhr.open('GET', API_BASE + '/listings.php?' + params, true);
  xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
  xhr.timeout = 8000;

  xhr.onload = function() {
    var data = [];
    try {
      var d = JSON.parse(xhr.responseText);
      if (d && d.success && d.data && d.data.length) data = d.data;
    } catch(e) {}

    /* Seed fallback — match by contact_name only */
    if (!data.length && sellerName) {
      var seed  = (window.MalabaAPI && MalabaAPI._seed && MalabaAPI._seed.items) || [];
      var normN = sellerName.toLowerCase();
      data = seed.filter(function(c) {
        if (c.id === itemId) return false;
        var cName = ((c.contact && c.contact.name) || c.contact_name || '').trim().toLowerCase();
        return cName === normN;
      });
    }

    shopItems = data.slice(0, 10);
    if (shopItems.length) renderShopItems(shopItems, sellerName || 'this shop');
  };

  xhr.onerror = xhr.ontimeout = function() { /* silent — supplementary */ };
  xhr.send();
}

function renderShopItems(items, sellerName) {
  var sec = document.getElementById('shopSection');
  if (!sec || !items.length) return;

  var cardsHTML = items.map(function(it) {
    var rawImg = it.image || it.image_url || '';
    var img = rawImg;
    if (img.indexOf('unsplash.com')  !== -1) img = img.split('?')[0] + '?w=320&h=212&q=72&auto=format&fit=crop';
    if (img.indexOf('cloudinary.com')!== -1) img = img.replace('/upload/', '/upload/w_320,h_212,c_fill,f_auto,q_72/');
    if (!img) img = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=320&q=65';
    var inCart = cart.find(function(c){ return c.id === it.id; });
    return (
      '<div class="shop-card" onclick="goToItem(\'' + esc(it.id) + '\')">' +
        '<div class="shop-card-img">' +
          '<img src="' + esc(img) + '" alt="' + esc(it.title) + '"' +
            ' loading="lazy" decoding="async" width="320" height="212"' +
            ' onerror="this.onerror=null;this.src=\'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=320&q=60\'">' +
          (it.badge ? '<div class="pbadge" style="position:absolute;top:6px;left:6px;z-index:2;background:rgba(8,4,0,.82);backdrop-filter:blur(6px);color:var(--text);font-size:9px;font-weight:700;padding:3px 8px;border-radius:12px;">' + esc(it.badge) + '</div>' : '') +
        '</div>' +
        '<div class="shop-card-body">' +
          '<div class="shop-card-title">' + esc(it.title) + '</div>' +
          '<div class="shop-card-price">' + esc(it.price) + '</div>' +
          '<button class="shop-card-buy ' + (inCart ? 'added' : '') + '"' +
            ' id="scbtn-' + esc(it.id) + '"' +
            ' onclick="shopCardCart(event,\'' + esc(it.id) + '\')">' +
            (inCart ? '&#x2713; Added' : '&#x1F6D2; Add') +
          '</button>' +
        '</div>' +
      '</div>'
    );
  }).join('');

  sec.innerHTML =
    '<div class="divider"></div>' +
    '<div class="shop-section">' +
      '<div class="shop-badge">' +
        '<div class="shop-badge-avatar">&#x1F6CD;</div>' +
        '<div>' +
          '<div class="shop-badge-name">More from ' + esc(sellerName || 'this seller') + '</div>' +
          '<div class="shop-badge-loc">' + items.length + ' more item' + (items.length !== 1 ? 's' : '') + ' available</div>' +
        '</div>' +
      '</div>' +
      '<div class="shop-section-head">' +
        '<h2>Same <span>Shop</span></h2>' +
        '<a href="category.php">Browse all ›</a>' +
      '</div>' +
      '<div class="shop-scroll">' + cardsHTML + '</div>' +
      '<div style="height:20px;"></div>' +
    '</div>';

  /* Stagger-free image init */
  sec.querySelectorAll('.shop-card-img img').forEach(function(img) {
    if (img.complete && img.naturalWidth > 0) {
      img.classList.add('img-loaded'); return;
    }
    img.classList.add('await-load');
    img.addEventListener('load', function(){
      img.classList.remove('await-load'); img.classList.add('img-loaded');
    }, {once:true});
    img.addEventListener('error', function(){
      img.src = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=320&q=60';
      img.classList.remove('await-load'); img.classList.add('img-loaded');
    }, {once:true});
  });
}

function shopCardCart(ev, id) {
  ev.stopPropagation();
  var item = shopItems.find(function(i){ return i.id === id; });
  if (!item) return;
  var btn = document.getElementById('scbtn-' + id);
  var ex  = cart.findIndex(function(c){ return c.id === id; });
  if (ex !== -1) {
    cart.splice(ex, 1);
    saveCart(); renderBadges();
    if (btn) { btn.innerHTML='&#x1F6D2; Add'; btn.classList.remove('added'); }
    showToast('Removed from cart');
  } else {
    cart.push({id:id, title:item.title, price:item.price, qty:1,
      shop: item.location||'',
      phone:(item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'')});
    saveCart(); renderBadges();
    if (btn) { btn.innerHTML='&#x2713; Added'; btn.classList.add('added'); }
    showToast('&#x2713; Added to cart');
  }
}

function goToItem(id) {
  window.location.href = 'item_detail.php?id=' + encodeURIComponent(id);
}


function shareItem() {
  var item = currentItem;
  if (!item) return;
  var url  = window.location.href;
  var text = item.title + ' — ' + item.price + ' | Malaba Homes Shop';
  if (navigator.share) {
    navigator.share({ title: text, url: url }).catch(function(){});
  } else if (navigator.clipboard) {
    navigator.clipboard.writeText(url).then(function(){ showToast('Link copied!'); });
  } else {
    showToast('Share: ' + url);
  }
}

/* ═══════════════════════════════════════════════════════════
   ADD TO CART (from sticky bar)
   ═══════════════════════════════════════════════════════════ */
function addToCartAndOpen() {
  var item = currentItem;
  if (!item) return;
  var ex = cart.find(function(c){ return c.id === item.id; });
  if (!ex) {
    var phone = (item.contact && item.contact.phone) ? item.contact.phone : (item.contact_phone||'');
    cart.push({id:item.id, title:item.title, price:item.price, qty:1,
      shop: item.location||'', phone: phone});
    saveCart(); renderBadges();
    var cb = document.getElementById('stickyCartBtn');
    if (cb) { cb.innerHTML = '<i class="fa-solid fa-check"></i> In Cart'; cb.classList.add('added'); }
    /* Update in-cart notice inline */
    var notice = document.getElementById('inCartNotice');
    if (!notice) {
      var section = document.querySelector('.buy-section');
      if (section) {
        var n = document.createElement('div');
        n.id = 'inCartNotice';
        n.className = 'in-cart-notice';
        n.innerHTML = '&#x2713; Added to cart — <button onclick="openCart()" style="color:var(--amber);font-weight:700;font-size:13px;cursor:pointer;">View Cart</button>';
        section.after(n);
      }
    }
  }
  openCart();
}

/* ═══════════════════════════════════════════════════════════
   LOAD RELATED ITEMS — same sub_category, scored + ranked
   ═══════════════════════════════════════════════════════════ */
function loadRelated(item) {
  var subCat = (item.sub_category || item.subCategory || '').trim();
  var itemId = item.id;
  var limit  = 16;

  function scoreAndRender(candidates) {
    var raw = parseFloat(String(item.price||'').replace(/[^0-9.]/g,'')) || 0;
    var now = Date.now();
    var scored = candidates
      .filter(function(c){ return c.id !== itemId && c.is_active !== 0; })
      .map(function(c) {
        var score = 0;
        var cSub = (c.sub_category || c.subCategory || '').trim();
        if (subCat && cSub === subCat) score += 50;
        var cRaw = parseFloat(String(c.price||'').replace(/[^0-9.]/g,'')) || 0;
        if (raw > 0 && cRaw > 0) {
          var diff = Math.abs(cRaw - raw) / raw;
          if (diff < 0.5) score += Math.round((1 - diff) * 20);
        }
        /* Real DB flags */
        if (c.is_featured) score += 15;
        if (c.is_premium)  score += 10;
        score += Math.min(15, (c.views || 0) * 0.05);
        if (c.created_at) {
          var age = (now - new Date(c.created_at).getTime()) / 86400000;
          score += Math.max(0, 10 - age * 0.3);
        }
        if (c.images && c.images.length > 1) score += 5;
        return { item: c, score: score };
      })
      .sort(function(a, b){ return b.score - a.score; })
      .slice(0, limit)
      .map(function(x){ return x.item; });

    relatedItems = scored;
    renderRelated(scored, subCat);
  }

  /* Exact sub_category filter via ?filter= param */
  var url = API_BASE + '/listings.php?type=items&limit=40&sort=popular'
    + (subCat ? '&filter=' + encodeURIComponent(subCat) : '')
    + '&exclude=' + encodeURIComponent(itemId);

  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
  xhr.timeout = 8000;
  xhr.onload = function() {
    var data = [];
    try {
      var d = JSON.parse(xhr.responseText);
      if (d && d.success && d.data && d.data.length) data = d.data;
    } catch(e) {}
    if (!data.length) {
      var seed = (window.MalabaAPI && MalabaAPI._seed && MalabaAPI._seed.items) || [];
      data = subCat ? seed.filter(function(i){
        return (i.sub_category||i.subCategory||'').trim() === subCat && i.id !== itemId;
      }) : seed.filter(function(i){ return i.id !== itemId; });
    }
    scoreAndRender(data);
  };
  xhr.onerror = xhr.ontimeout = function() {
    var seed = (window.MalabaAPI && MalabaAPI._seed && MalabaAPI._seed.items) || [];
    scoreAndRender(seed);
  };
  xhr.send();

  if (window.MalabaAPI) MalabaAPI.trackView(itemId);
}


function renderRelated(items, subCat) {
  var section = document.getElementById('relatedSection');
  if (!section) return;

  if (!items.length) {
    section.innerHTML =
      '<div class="related-empty">No related products found.</div>';
    return;
  }

  var label = subCat
    ? subCat.charAt(0).toUpperCase() + subCat.slice(1)
    : 'Items';

  var cardsHTML = items.map(function(it) {
    return relatedCardHTML(it);
  }).join('');

  section.innerHTML =
    '<div class="related-head">' +
      '<h2>More <span>' + esc(label) + '</span></h2>' +
      '<a href="category.php' + (subCat ? '?sub=' + encodeURIComponent(subCat) : '') + '">See all ›</a>' +
    '</div>' +
    '<div class="related-scroll" id="relatedScroll">' + cardsHTML + '</div>' +
    '<div style="height:16px;"></div>';

  /* Fade-in images */
  var imgs = section.querySelectorAll('.pcard-img img');
  imgs.forEach(function(img) {
    if (img.complete && img.naturalWidth > 0) {
      img.classList.add('img-loaded');
    } else {
      img.addEventListener('load', function(){ img.classList.add('img-loaded'); }, {once:true});
      img.addEventListener('error', function(){
        img.src = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=360&q=60';
        img.classList.add('img-loaded');
      }, {once:true});
    }
  });
}

function relatedCardHTML(item) {
  var liked  = wishlist.indexOf(item.id) !== -1;
  var inCart = cart.find(function(c){ return c.id === item.id; });
  var raw    = parseFloat(String(item.price||'').replace(/[^0-9.]/g,'')) || 0;
  var hasLipa= raw >= 200;
  var rating = item.rating ? parseFloat(item.rating).toFixed(1) : (3.9 + Math.random() * 0.9).toFixed(1);
  var rawImg = item.image || item.image_url || '';
  var img    = rawImg;
  if (img.indexOf('unsplash.com') !== -1) img = img.split('?')[0] + '?w=360&h=360&q=70&auto=format&fit=crop';
  if (img.indexOf('cloudinary.com') !== -1) img = img.replace('/upload/', '/upload/w_360,h_360,c_fill,f_auto,q_70/');
  if (!img) img = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=360&q=70';

  return '<div class="pcard" data-id="' + esc(item.id) + '" onclick="goToItem(\'' + esc(item.id) + '\')">' +
    '<div class="pcard-img">' +
      '<img src="' + esc(img) + '" alt="' + esc(item.title) + '"' +
        ' loading="lazy" decoding="async" width="360" height="360"' +
        ' onerror="this.src=\'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=360&q=60\'">' +
      (item.badge ? '<div class="pbadge">' + esc(item.badge) + '</div>' : '') +
      (hasLipa ? '<div class="plipa-badge">&#x1F4B0; Lipa</div>' : '') +
      '<button class="wish' + (liked?' liked':'') + '" onclick="relWish(event,\'' + esc(item.id) + '\',this)">' +
        (liked ? '&#x2665;' : '&#x2661;') +
      '</button>' +
    '</div>' +
    '<div class="pcard-body">' +
      '<div class="ptitle">' + esc(item.title) + '</div>' +
      '<div class="prating">&#x2605;&#x2605;&#x2605;&#x2605;' + (parseFloat(rating)>=4.5?'&#x2605;':'&#x2606;') +
        '<span>' + rating + '</span></div>' +
      '<div class="ploc">&#x1F4CD; ' + esc((item.location||'').split(',')[0]) + '</div>' +
    '</div>' +
    '<div class="pprice">' + esc(item.price) + '</div>' +
    '<div class="pcard-foot">' +
      '<button class="btn-order' + (inCart?' added':'') + '" id="rbtn-' + esc(item.id) + '"' +
        ' onclick="relQuickOrder(event,\'' + esc(item.id) + '\')">' +
        (inCart ? '&#x2713; In Cart' : '&#x1F6D2; Buy') +
      '</button>' +
      (hasLipa ? '<button class="btn-lipa" onclick="relOpenLipa(event,\'' + esc(item.id) + '\')">&#x1F4B0;</button>' : '') +
    '</div>' +
  '</div>';
}

function relWish(ev, id, btn) {
  ev.stopPropagation();
  var i = wishlist.indexOf(id);
  if (i !== -1) { wishlist.splice(i, 1); btn.innerHTML='&#x2661;'; btn.classList.remove('liked'); showToast('Removed from saved'); }
  else          { wishlist.unshift(id);  btn.innerHTML='&#x2665;'; btn.classList.add('liked');    showToast('&#x2665; Saved!'); }
  try { localStorage.setItem('mh_shop_wish', JSON.stringify(wishlist)); } catch(e){}
}

function relQuickOrder(ev, id) {
  ev.stopPropagation();
  var item = relatedItems.find(function(i){ return i.id === id; });
  if (!item) return;
  var ex = cart.find(function(c){ return c.id === id; });
  if (!ex) {
    var phone = (item.contact && item.contact.phone) ? item.contact.phone : (item.contact_phone||'');
    cart.push({id:id, title:item.title, price:item.price, qty:1, shop:item.location||'', phone:phone});
    saveCart(); renderBadges();
    var btn = document.getElementById('rbtn-'+id);
    if (btn) { btn.innerHTML='&#x2713; In Cart'; btn.classList.add('added'); }
  }
  openCart();
}

function relOpenLipa(ev, id) {
  ev.stopPropagation();
  var item = relatedItems.find(function(i){ return i.id === id; });
  if (!item) return;
  currentItem = item;
  startLipaSheet();
}

/* ═══════════════════════════════════════════════════════════
   DIRECT ORDER FORM
   ═══════════════════════════════════════════════════════════ */
function openDirectOrder() {
  var item = currentItem;
  if (!item) return;
  payMode = 'cash';

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div>' +
    '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<div style="padding:14px 16px 0;">' +
      '<div style="display:flex;align-items:center;gap:10px;padding-bottom:14px;' +
        'border-bottom:1px solid var(--border);margin-bottom:16px;">' +
        '<div style="font-size:28px;">&#x1F6D2;</div>' +
        '<div>' +
          '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:17px;letter-spacing:.3px;">' + esc(item.title) + '</div>' +
          '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:22px;color:var(--amber2);">' + esc(item.price) + '</div>' +
        '</div>' +
      '</div>' +
      '<div class="row2">' +
        '<div class="field"><label>Full Name *</label>' +
        '<input type="text" id="do_name" placeholder="Your name" autocomplete="name"></div>' +
        '<div class="field"><label>Phone *</label>' +
        '<input type="tel" id="do_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>' +
      '</div>' +
      '<div class="field"><label>Delivery Address *</label>' +
      '<input type="text" id="do_addr" placeholder="e.g. Near Malaba Market"></div>' +
      '<div style="font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:8px;">Payment Method</div>' +
      '<div class="pay-opts">' +
        '<div class="po sel" id="do_cash" onclick="setDirectPay(\'cash\',this)">' +
          '<div class="po-ico">&#x1F4B5;</div>' +
          '<div class="po-txt"><strong>Cash on Delivery</strong><span>Pay when item arrives</span></div>' +
          '<div class="po-dot"></div>' +
        '</div>' +
        '<div class="po" id="do_mpesa" onclick="setDirectPay(\'mpesa\',this)">' +
          '<div class="po-ico">&#x1F4F1;</div>' +
          '<div class="po-txt"><strong>M-Pesa on Delivery</strong><span>Send M-Pesa when delivered</span></div>' +
          '<div class="po-dot"></div>' +
        '</div>' +
      '</div>' +
      '<button class="sbtn" id="doSubmitBtn" onclick="submitDirectOrder()">&#x1F6D2; Place Order — ' + esc(item.price) + '</button>' +
    '</div>';

  openSheet(); prefillSaved();
}

function setDirectPay(mode, el) {
  payMode = mode;
  document.getElementById('do_cash').classList.toggle('sel', mode==='cash');
  document.getElementById('do_mpesa').classList.toggle('sel', mode==='mpesa');
}

function submitDirectOrder() {
  var name  = (document.getElementById('do_name').value||'').trim();
  var phone = (document.getElementById('do_phone').value||'').trim();
  var addr  = (document.getElementById('do_addr').value||'').trim();
  if (!name)  { showToast('Enter your full name'); return; }
  if (!phone || phone.replace(/\D/g,'').length < 9) { showToast('Enter a valid phone number'); return; }
  if (!addr)  { showToast('Enter your delivery address'); return; }
  var btn = document.getElementById('doSubmitBtn');
  if (btn) { btn.disabled=true; btn.textContent='Placing order...'; }
  saveMhUser(name, phone, addr);
  var item  = currentItem;
  var waNum = normWA((item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||''));
  postOrder({
    category:'items', listing_id:item.id||'',
    listing_title:item.title||'', listing_price:item.price||'',
    name:name, phone:phone, address:addr,
    payment_method:payMode==='mpesa'?'mpesa_on_delivery':'cash_on_delivery',
    total_amount:item.price||'0',
    notes:'Direct buy — ' + payMode,
  }, function(d) {
    var ref = d&&d.order_ref ? d.order_ref : '';
    var msg = encodeURIComponent('Hi! I ordered *'+item.title+'* ('+item.price+')\nRef: '+(ref||'—')+'\nName: '+name+'\nPhone: '+phone+'\nAddress: '+addr+'\nPayment: '+payMode);
    showSuccess('Order Placed!', 'Pay '+item.price+(payMode==='cash'?' cash':' via M-Pesa')+' when your item arrives.', ref,
      function(){ window.open('https://wa.me/'+waNum+'?text='+msg, '_blank'); });
  }, function() {
    if (btn) { btn.disabled=false; btn.textContent='&#x1F6D2; Place Order — '+item.price; }
    showToast('Network error. Please try again.');
  });
}

/* ═══════════════════════════════════════════════════════════
   LIPA MDOGO MDOGO
   ═══════════════════════════════════════════════════════════ */
function calcFrequencies(raw) {
  if (!raw || raw < 200) return [];
  return [
    {id:'daily',  label:'Daily',        per:'day',  factor:1.0,  desc:'No extra charge — best value',
     amount:function(total,weeks){ return total/(weeks*7); }},
    {id:'3xweek', label:'3× per week',  per:'week', factor:1.02, desc:'+2% total — great flexibility',
     amount:function(total,weeks){ return total/(weeks*3); }},
    {id:'2xweek', label:'Twice a week', per:'week', factor:1.04, desc:'+4% total — comfortable pace',
     amount:function(total,weeks){ return total/(weeks*2); }},
    {id:'weekly', label:'Weekly',       per:'week', factor:1.07, desc:'+7% total — once a week',
     amount:function(total,weeks){ return total/weeks; }},
  ];
}
function calcDurations(raw, freq) {
  if (!freq) return [];
  var ksh   = function(n){ return 'KSH '+Math.round(n).toLocaleString('en-KE'); };
  var total = raw * freq.factor;
  return [
    {weeks:2,  label:'2 Weeks',  deposit:raw*.25, total:total},
    {weeks:4,  label:'4 Weeks',  deposit:raw*.2,  total:total},
    {weeks:8,  label:'8 Weeks',  deposit:raw*.15, total:total*1.03},
    {weeks:12, label:'12 Weeks', deposit:raw*.1,  total:total*1.06},
  ].map(function(d){
    var perPay = freq.amount(d.total, d.weeks);
    return {weeks:d.weeks, label:d.label, depositAmt:d.deposit,
      deposit:ksh(d.deposit), total:d.total, totalStr:ksh(d.total),
      perPay:perPay, perPayStr:ksh(perPay)};
  });
}

function startLipaSheet() {
  var item = currentItem;
  if (!item) return;
  lipaFreq=null; lipaDur=null;
  var raw = parseFloat(String(item.price||'').replace(/[^0-9.]/g,''))||0;
  lipaFreqOpts = calcFrequencies(raw);
  if (!lipaFreqOpts.length) { openDirectOrder(); return; }
  var rawImg = item.image||item.image_url||'';
  var img    = window.MhImgPerf ? MhImgPerf.imgThumb(rawImg) : rawImg;

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div>' +
    '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<div class="lipa-header">' +
      '<div class="lipa-product-row">' +
        (img ? '<img class="lipa-pimg" src="'+esc(img)+'" width="58" height="58" loading="lazy" onerror="this.style.display=\'none\'">'
             : '<div class="lipa-pimg-ph">&#x1F4E6;</div>') +
        '<div><div class="lipa-pname">'+esc(item.title)+'</div>' +
        '<div class="lipa-pwas">'+esc(item.price)+' full price</div>' +
        '<div class="lipa-ptag">&#x1F4B0; Instalment plan available</div></div>' +
      '</div>' +
      '<div class="lipa-steps">' +
        '<div class="lstep"><div class="ls-dot active" id="lsd1">1</div><div class="ls-lbl active" id="lsl1">Frequency</div></div>' +
        '<div class="ls-line" id="lsl1l"></div>' +
        '<div class="lstep"><div class="ls-dot" id="lsd2">2</div><div class="ls-lbl" id="lsl2">Duration</div></div>' +
        '<div class="ls-line" id="lsl2l"></div>' +
        '<div class="lstep"><div class="ls-dot" id="lsd3">3</div><div class="ls-lbl" id="lsl3">Details</div></div>' +
      '</div>' +
    '</div>' +
    '<div class="lipa-panel active" id="lp1">' +
      '<div class="lipa-sec-title">How often can you pay?</div>' +
      '<div class="lipa-sec-sub">Choose your frequency. Daily payments have zero markup.</div>' +
      buildFreqHTML() +
      '<div class="lipa-nav"><button class="lipa-next" onclick="lipaNext(1)">Next: Duration &#x2192;</button></div>' +
    '</div>' +
    '<div class="lipa-panel" id="lp2">' +
      '<div class="lipa-sec-title">How long to pay?</div>' +
      '<div class="lipa-sec-sub">Shorter = bigger payments. Longer = smaller payments.</div>' +
      '<div class="lipa-durs" id="lipaDurGrid"></div>' +
      '<div class="lipa-summary" id="lipaSummary"></div>' +
      '<div class="lipa-nav">' +
        '<button class="lipa-back" onclick="lipaBack(2)">&#x2190; Back</button>' +
        '<button class="lipa-next" onclick="lipaNext(2)">Next: Your Details &#x2192;</button>' +
      '</div>' +
    '</div>' +
    '<div class="lipa-panel" id="lp3">' +
      '<div class="lipa-sec-title">Your Details</div>' +
      '<div class="lipa-rule"><strong>&#x26A0; Important:</strong> Product delivered ONLY after all payments received. First payment secures your order.</div>' +
      '<div class="field"><label>Full Name *</label><input type="text" id="lp_name" placeholder="Your full name" autocomplete="name"></div>' +
      '<div class="field"><label>Phone *</label><input type="tel" id="lp_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>' +
      '<div class="field"><label>Delivery Address *</label><input type="text" id="lp_addr" placeholder="e.g. Near Malaba Market"></div>' +
      '<div style="font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.7px;text-transform:uppercase;margin-bottom:8px;">First payment method</div>' +
      '<div class="pay-opts lipa-pay">' +
        '<div class="po sel" id="lpo_mpesa" onclick="setLipaPay(\'mpesa\',this)"><div class="po-ico">&#x1F4F1;</div><div class="po-txt"><strong>M-Pesa</strong><span>First instalment via M-Pesa</span></div><div class="po-dot"></div></div>' +
        '<div class="po" id="lpo_cash" onclick="setLipaPay(\'cash\',this)"><div class="po-ico">&#x1F4B5;</div><div class="po-txt"><strong>Cash</strong><span>First instalment in cash</span></div><div class="po-dot"></div></div>' +
      '</div>' +
      '<div class="lipa-nav">' +
        '<button class="lipa-back" onclick="lipaBack(3)">&#x2190; Back</button>' +
        '<button class="lipa-next" id="lipaSubmitBtn" onclick="submitLipa()">&#x1F4B0; Submit Plan Request</button>' +
      '</div>' +
    '</div>';

  openSheet(); prefillSaved();
  var lImg = document.querySelector('.lipa-pimg');
  if (lImg) {
    lImg.onload  = function(){ lImg.classList.add('img-loaded'); };
    lImg.onerror = function(){ lImg.classList.add('img-loaded'); };
    if (lImg.complete && lImg.naturalWidth>0) lImg.classList.add('img-loaded');
  }
}

function buildFreqHTML() {
  var raw  = parseFloat(String(currentItem.price||'').replace(/[^0-9.]/g,''))||0;
  var html = '<div class="lipa-freqs">';
  lipaFreqOpts.forEach(function(f, i) {
    var pp = f.amount(raw*f.factor, 4);
    html +=
      '<div class="lipa-freq" id="lf-'+f.id+'" onclick="selFreq(\''+f.id+'\','+i+')">' +
        '<div class="lf-radio"></div>' +
        '<div class="lf-info"><div class="lf-name">'+f.label+'</div><div class="lf-desc">'+f.desc+'</div></div>' +
        '<div class="lf-right">' +
          '<div class="lf-amount">KSH '+Math.round(pp).toLocaleString('en-KE')+'</div>' +
          '<div class="lf-per">/'+f.per+' (est.)</div>' +
        '</div>' +
      '</div>';
  });
  return html+'</div>';
}

function selFreq(id, i) {
  lipaFreq = lipaFreqOpts[i];
  document.querySelectorAll('.lipa-freq').forEach(function(el){ el.classList.remove('sel'); });
  var el = document.getElementById('lf-'+id);
  if (el) el.classList.add('sel');
  var raw = parseFloat(String(currentItem.price||'').replace(/[^0-9.]/g,''))||0;
  lipaDurOpts = calcDurations(raw, lipaFreq);
  buildDurGrid();
}
function buildDurGrid() {
  var grid = document.getElementById('lipaDurGrid');
  if (!grid) return;
  lipaDur = null;
  grid.innerHTML = lipaDurOpts.map(function(d,i){
    return '<div class="lipa-dur" id="ld-'+i+'" onclick="selDur('+i+')">' +
      '<div class="ld-weeks">'+d.weeks+'</div>' +
      '<div class="ld-label">weeks</div>' +
      '<div class="ld-per">'+d.perPayStr+'</div>' +
      '<div class="ld-total">Total: '+d.totalStr+'</div>' +
    '</div>';
  }).join('');
  var s = document.getElementById('lipaSummary');
  if (s) s.style.display='none';
}
function selDur(i) {
  lipaDur = lipaDurOpts[i];
  document.querySelectorAll('.lipa-dur').forEach(function(el){ el.classList.remove('sel'); });
  var el = document.getElementById('ld-'+i);
  if (el) el.classList.add('sel');
  var s = document.getElementById('lipaSummary');
  if (s) {
    s.style.display='block';
    s.innerHTML =
      '<div class="ls-row"><span class="lbl">Frequency</span><span class="val">'+lipaFreq.label+'</span></div>'+
      '<div class="ls-row"><span class="lbl">Duration</span><span class="val">'+lipaDur.label+'</span></div>'+
      '<div class="ls-row"><span class="lbl">Per payment</span><span class="val hi">'+lipaDur.perPayStr+'</span></div>'+
      '<div class="ls-row"><span class="lbl">First deposit</span><span class="val">'+lipaDur.deposit+'</span></div>'+
      '<div class="ls-row"><span class="lbl">Grand total</span><span class="val">'+lipaDur.totalStr+'</span></div>';
  }
}
function lipaNext(step) {
  if (step===1) {
    if (!lipaFreq) { showToast('Select a payment frequency'); return; }
    if (!lipaDurOpts.length) {
      var raw = parseFloat(String(currentItem.price||'').replace(/[^0-9.]/g,''))||0;
      lipaDurOpts = calcDurations(raw, lipaFreq); buildDurGrid();
    }
  }
  if (step===2 && !lipaDur) { showToast('Select a duration'); return; }
  setLipaStep(step+1);
}
function lipaBack(step){ setLipaStep(step-1); }
function setLipaStep(s) {
  [1,2,3].forEach(function(n){
    var p = document.getElementById('lp'+n);
    if (p) p.className='lipa-panel'+(n===s?' active':'');
    var dot=document.getElementById('lsd'+n), lbl=document.getElementById('lsl'+n), ln=document.getElementById('lsl'+n+'l');
    if (!dot) return;
    if (n<s){ dot.className='ls-dot done';dot.innerHTML='&#x2713;';lbl.className='ls-lbl done';if(ln)ln.className='ls-line done'; }
    else if(n===s){ dot.className='ls-dot active';dot.innerHTML=n;lbl.className='ls-lbl active'; }
    else{ dot.className='ls-dot';dot.innerHTML=n;lbl.className='ls-lbl';if(ln)ln.className='ls-line'; }
  });
}
function setLipaPay(mode, el) {
  lipaPayMode = mode;
  ['lpo_mpesa','lpo_cash'].forEach(function(id){ var e=document.getElementById(id);if(e)e.classList.remove('sel'); });
  el.classList.add('sel');
}
function submitLipa() {
  if (!lipaFreq||!lipaDur) { showToast('Complete all steps first'); return; }
  var name  = (document.getElementById('lp_name').value||'').trim();
  var phone = (document.getElementById('lp_phone').value||'').trim();
  var addr  = (document.getElementById('lp_addr').value||'').trim();
  if (!name)  { showToast('Enter your full name'); return; }
  if (!phone||phone.replace(/\D/g,'').length<9) { showToast('Enter a valid phone number'); return; }
  if (!addr)  { showToast('Enter your delivery address'); return; }
  var btn = document.getElementById('lipaSubmitBtn');
  if (btn) { btn.disabled=true; btn.textContent='Sending...'; }
  saveMhUser(name,phone,addr);
  var item  = currentItem;
  var waNum = normWA((item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||''));
  var notes = 'LIPA MDOGO MDOGO | Freq:'+lipaFreq.label+' | '+lipaDur.label+' | Per:'+lipaDur.perPayStr+' | Deposit:'+lipaDur.deposit+' | Total:'+lipaDur.totalStr+' | Pay:'+lipaPayMode+' | DELIVER AFTER FULL PAYMENT ONLY';
  postOrder({
    category:'items', listing_id:item.id||'',
    listing_title:item.title||'', listing_price:item.price||'',
    name:name, phone:phone, address:addr,
    payment_method:lipaPayMode, total_amount:String(lipaDur.total||'0'), notes:notes,
  }, function(d) {
    var ref = d&&d.order_ref ? d.order_ref : '';
    var msg = encodeURIComponent('Hi! Lipa Mdogo Mdogo:\n*'+item.title+'*\nFreq: '+lipaFreq.label+'\nDuration: '+lipaDur.label+'\nPer payment: '+lipaDur.perPayStr+'\nDeposit: '+lipaDur.deposit+'\nTotal: '+lipaDur.totalStr+'\nRef: '+(ref||'—')+'\nName: '+name+'\nPhone: '+phone+'\nAddress: '+addr+'\n\n⚠️ Delivered ONLY after all payments received.');
    showSuccess('Request Sent!', 'Your '+lipaFreq.label+' plan over '+lipaDur.label+' is confirmed. We\'ll call to confirm.', ref,
      function(){ window.open('https://wa.me/'+waNum+'?text='+msg,'_blank'); });
  }, function() {
    if (btn) { btn.disabled=false; btn.textContent='&#x1F4B0; Submit Plan Request'; }
    showToast('Network error. Please try again.');
  });
}

/* ═══════════════════════════════════════════════════════════
   CART
   ═══════════════════════════════════════════════════════════ */
function openCart() {
  var n     = cart.reduce(function(s,c){ return s+c.qty; }, 0);
  var total = cart.reduce(function(s,c){ return s+px(c.price)*c.qty; }, 0);
  var dlv   = total >= 2000 ? 0 : 100;
  var grand = total + dlv;
  if (!n) { showToast('Your cart is empty'); return; }

  var itemsHTML = cart.map(function(c){
    return '<div style="display:flex;align-items:center;gap:10px;background:rgba(255,255,255,.03);border-radius:var(--r);padding:10px;border:1px solid var(--border);margin-bottom:7px;">' +
      '<div style="flex:1;min-width:0;">' +
        '<div style="font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+esc(c.title)+'</div>' +
        '<div style="font-size:11px;color:var(--muted);">'+esc((c.shop||'').split(',')[0])+'</div>' +
      '</div>' +
      '<div style="display:flex;align-items:center;gap:5px;">' +
        '<button style="width:24px;height:24px;border-radius:50%;background:var(--surface);border:1px solid var(--border2);color:var(--text);font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:center;cursor:pointer;" onclick="cartQty(\''+esc(c.id)+'\',-1)">&#x2212;</button>' +
        '<span style="font-family:\'Bebas Neue\',sans-serif;font-size:14px;min-width:14px;text-align:center;">'+c.qty+'</span>' +
        '<button style="width:24px;height:24px;border-radius:50%;background:var(--surface);border:1px solid var(--border2);color:var(--text);font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:center;cursor:pointer;" onclick="cartQty(\''+esc(c.id)+'\',1)">+</button>' +
      '</div>' +
      '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:14px;color:var(--amber2);">KSH '+(px(c.price)*c.qty).toLocaleString()+'</div>' +
      '<button style="color:var(--muted);font-size:14px;padding:2px 4px;cursor:pointer;" onclick="cartQty(\''+esc(c.id)+'\',0)">&#x2715;</button>' +
    '</div>';
  }).join('');

  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div>' +
    '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<div style="padding:14px 16px 0;">' +
      '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:22px;letter-spacing:.5px;margin-bottom:14px;">' +
        '&#x1F6D2; Cart <span style="color:var(--amber2);">('+n+' item'+(n!==1?'s':'')+')</span></div>' +
      itemsHTML +
      '<div class="cart-sum">' +
        '<div class="csr"><span>Subtotal</span><span>KSH '+total.toLocaleString()+'</span></div>' +
        '<div class="csr"><span>Delivery</span><span>'+(dlv===0?'<span style="color:var(--green);">FREE</span>':'KSH '+dlv)+'</span></div>' +
        '<div class="csr tot"><span>Total on Delivery</span><span>KSH '+grand.toLocaleString()+'</span></div>' +
      '</div>' +
      '<div class="row2">' +
        '<div class="field"><label>Full Name *</label><input type="text" id="cart_name" placeholder="Your name" autocomplete="name"></div>' +
        '<div class="field"><label>Phone *</label><input type="tel" id="cart_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>' +
      '</div>' +
      '<div class="field"><label>Delivery Address *</label><input type="text" id="cart_addr" placeholder="e.g. Near Malaba Market"></div>' +
      '<div class="pay-opts">' +
        '<div class="po sel" id="cart_cash" onclick="setCartPay(\'cash\',this)"><div class="po-ico">&#x1F4B5;</div><div class="po-txt"><strong>Cash on Delivery</strong><span>Pay when items arrive</span></div><div class="po-dot"></div></div>' +
        '<div class="po" id="cart_mpesa" onclick="setCartPay(\'mpesa\',this)"><div class="po-ico">&#x1F4F1;</div><div class="po-txt"><strong>M-Pesa on Delivery</strong><span>Send M-Pesa when delivered</span></div><div class="po-dot"></div></div>' +
      '</div>' +
      '<button class="sbtn" id="cartSubmitBtn" onclick="submitCart()">&#x2705; Place Order — KSH '+grand.toLocaleString()+'</button>' +
    '</div>';

  openSheet(); prefillSaved(); window._cartGrand = grand;
}

function setCartPay(mode, el) {
  payMode = mode;
  ['cart_cash','cart_mpesa'].forEach(function(id){ var e=document.getElementById(id);if(e)e.classList.remove('sel'); });
  el.classList.add('sel');
}
function cartQty(id, d) {
  var ex = cart.find(function(c){ return c.id===id; });
  if (!ex) return;
  if (d===0) { cart=cart.filter(function(c){ return c.id!==id; }); }
  else { ex.qty=Math.max(0,ex.qty+d); if(!ex.qty) cart=cart.filter(function(c){ return c.id!==id; }); }
  saveCart(); renderBadges();
  if (!cart.length){ closeOverlay(); return; }
  openCart();
}
function submitCart() {
  var name  = (document.getElementById('cart_name').value||'').trim();
  var phone = (document.getElementById('cart_phone').value||'').trim();
  var addr  = (document.getElementById('cart_addr').value||'').trim();
  if (!name)  { showToast('Enter your full name'); return; }
  if (!phone||phone.replace(/\D/g,'').length<9) { showToast('Enter a valid phone number'); return; }
  if (!addr)  { showToast('Enter your delivery address'); return; }
  var btn = document.getElementById('cartSubmitBtn');
  if (btn) { btn.disabled=true; btn.textContent='Placing order...'; }
  saveMhUser(name,phone,addr);
  var grand = window._cartGrand||0;
  var items = cart.map(function(c){ return c.title; }).join(', ');
  var waNum = normWA(cart[0]&&cart[0].phone?cart[0].phone:'');
  var snap  = cart.slice();
  postOrder({
    category:'items', listing_id:snap[0]&&snap[0].id?snap[0].id:'',
    name:name, phone:phone, address:addr,
    payment_method:payMode==='mpesa'?'mpesa_on_delivery':'cash_on_delivery',
    total_amount:String(grand),
    notes:'Cart: '+items+' | '+addr+' | '+payMode,
    cart_items:snap.map(function(c){ return {id:c.id,title:c.title,price:c.price,qty:c.qty}; }),
  }, function(d) {
    var ref = d&&d.order_ref ? d.order_ref : '';
    var msg = encodeURIComponent('Order from *'+name+'*\nPhone: '+phone+'\nAddress: '+addr+'\nItems: '+items+'\nTotal: KSH '+grand.toLocaleString()+'\nPayment: '+payMode+'\nRef: '+(ref||'—'));
    cart=[]; saveCart(); renderBadges();
    showSuccess('Order Placed!', payMode==='cash'?'Pay KSH '+grand.toLocaleString()+' cash when items arrive.':'M-Pesa payment arranged on delivery.', ref,
      function(){ window.open('https://wa.me/'+waNum+'?text='+msg,'_blank'); });
  }, function() {
    if (btn) { btn.disabled=false; btn.textContent='&#x2705; Place Order — KSH '+grand.toLocaleString(); }
    showToast('Network error. Please try again.');
  });
}

/* ═══════════════════════════════════════════════════════════
   SUCCESS / NOT FOUND
   ═══════════════════════════════════════════════════════════ */
function showSuccess(title, sub, ref, waFn) {
  document.getElementById('sheetContent').innerHTML =
    '<div class="sh-top"><div class="sh-handle"></div>' +
    '<button class="sh-close" onclick="closeOverlay()">&#x2715;</button></div>' +
    '<div class="suc-wrap">' +
      '<div class="suc-ico">'+(title.indexOf('Request')!==-1?'&#x1F389;':'&#x2705;')+'</div>' +
      '<div class="suc-title">'+esc(title)+'</div>' +
      '<div class="suc-sub">'+esc(sub)+'</div>' +
      (ref?'<div class="suc-ref">Ref: '+esc(ref)+'</div>':'')+
      '<button class="wa-btn" id="sucWaBtn">&#x1F4AC; Confirm on WhatsApp</button>' +
      '<button class="done-btn" onclick="closeOverlay()">Continue Shopping</button>' +
    '</div>';
  var wb = document.getElementById('sucWaBtn');
  if (wb) wb.onclick = waFn;
}

function renderNotFound(msg) {
  document.getElementById('pageContent').innerHTML =
    '<div class="not-found">' +
      '<div class="nf-ico">&#x1F6AB;</div>' +
      '<h2>Item Not Found</h2>' +
      '<p>' + esc(msg||'This item is no longer available.') + '</p>' +
      '<a href="shop_listing.php">&#x1F6D2; Back to Shop</a>' +
    '</div>';
}

/* ═══════════════════════════════════════════════════════════
   OVERLAY / SHEET HELPERS
   ═══════════════════════════════════════════════════════════ */
function openSheet(){ document.getElementById('overlay').classList.add('open'); document.body.style.overflow='hidden'; }
function closeOverlay(){ document.getElementById('overlay').classList.remove('open'); document.body.style.overflow=''; }
function handleOvClick(e){ if(e.target===e.currentTarget) closeOverlay(); }

/* ═══════════════════════════════════════════════════════════
   API + PERSISTENCE
   ═══════════════════════════════════════════════════════════ */
function postOrder(data, onOk, onErr) {
  var xhr = new XMLHttpRequest();
  xhr.open('POST', API_BASE+'/order.php', true);
  xhr.setRequestHeader('Content-Type','application/json');
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.timeout = 12000;
  xhr.onload  = function(){ try{ var d=JSON.parse(xhr.responseText); if(typeof onOk==='function') onOk(d); }catch(e){ if(typeof onOk==='function') onOk({}); } };
  xhr.onerror = xhr.ontimeout = function(){ if(typeof onErr==='function') onErr(); };
  xhr.send(JSON.stringify(data));
}
function saveCart(){ try{ localStorage.setItem('mh_shop_cart', JSON.stringify(cart)); }catch(e){} }
function renderBadges() {
  var n  = cart.reduce(function(s,c){ return s+c.qty; }, 0);
  var el = document.getElementById('hBadge');
  if (el) { el.textContent=n; el.classList.toggle('on', n>0); }
}
function saveMhUser(name,phone,addr){
  try{
    if(window.MhUser) MhUser.saveDetails({name:name,phone:phone,address:addr});
    else localStorage.setItem('mh_user_details', JSON.stringify({name:name,phone:phone,address:addr}));
  }catch(e){}
}
function prefillSaved(){
  var d=null;
  try{ if(window.MhUser) d=MhUser.getDetails(); else d=JSON.parse(localStorage.getItem('mh_user_details')||'null'); }catch(e){}
  if (!d) return;
  var map={do_name:'name',do_phone:'phone',do_addr:'address',lp_name:'name',lp_phone:'phone',lp_addr:'address',cart_name:'name',cart_phone:'phone',cart_addr:'address'};
  Object.keys(map).forEach(function(fid){ var el=document.getElementById(fid); if(el&&d[map[fid]]&&!el.value) el.value=d[map[fid]]; });
}

/* ═══════════════════════════════════════════════════════════
   MISC UTILS
   ═══════════════════════════════════════════════════════════ */
function px(str){ var n=parseInt(String(str||'').replace(/[^0-9]/g,'')); return isNaN(n)?0:n; }
function normWA(p){ var d=(p||'').replace(/\D/g,''); if(d.length===9) return'254'+d; if(d.length===10&&d[0]==='0') return'254'+d.substring(1); if(d.length===12&&d.substring(0,3)==='254') return d; return d||'254700000000'; }
function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function showToast(msg){ var t=document.getElementById('toast'); t.innerHTML=msg; t.classList.add('show'); setTimeout(function(){ t.classList.remove('show'); }, 2400); }
function openInVideoFeed(id){ window.location.href='video_feed.php?id='+encodeURIComponent(id)+'&cat=items'; }

/* ═══════════════════════════════════════════════════════════
   CATEGORY NAVIGATION
   ═══════════════════════════════════════════════════════════ */
function catGo(sub) {
  /* Highlight tapped category */
  document.querySelectorAll('.cat-item').forEach(function(el) {
    el.classList.toggle('active', el.getAttribute('onclick') === 'catGo(\'' + sub + '\')');
  });
  var url = 'category.php' + (sub ? '?sub=' + encodeURIComponent(sub) : '');
  window.location.href = url;
}

/* ═══════════════════════════════════════════════════════════
   DETAIL PAGE SEARCH MODAL
   ═══════════════════════════════════════════════════════════ */
var DSM_TIMER   = null;
var DSM_RECENT  = [];

/* Load recent searches from localStorage */
try { DSM_RECENT = JSON.parse(localStorage.getItem('mh_det_recent') || '[]'); } catch(e){}

function openDsmModal() {
  var modal = document.getElementById('detSrchModal');
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
  renderDsmRecent();
  setTimeout(function() {
    var inp = document.getElementById('dsmInput');
    if (inp) { inp.focus(); inp.select(); }
  }, 80);
}

function closeDsmModal() {
  document.getElementById('detSrchModal').classList.remove('open');
  document.body.style.overflow = '';
  document.getElementById('dsmInput').value = '';
  renderDsmRecent(); /* reset to recent */
}

function renderDsmRecent() {
  var results = document.getElementById('dsmResults');
  if (!DSM_RECENT.length) {
    results.innerHTML =
      '<div class="dsm-empty">' +
        '<i class="fa-solid fa-magnifying-glass" style="font-size:28px;color:var(--dim);margin-bottom:10px;display:block;"></i>' +
        'Search for phones, furniture, appliances and more' +
      '</div>';
    return;
  }
  results.innerHTML =
    '<div class="dsm-section">Recent Searches</div>' +
    '<div class="dsm-chips" id="dsmChips">' +
      DSM_RECENT.slice(0, 8).map(function(q) {
        return '<div class="dsm-chip" onclick="dsmApply(' + JSON.stringify(q) + ')">' +
          '<i class="fa-solid fa-clock-rotate-left"></i>' + esc(q) + '</div>';
      }).join('') +
    '</div>' +
    '<div style="padding:8px 14px;">' +
      '<div class="dsm-section" style="padding:0 0 8px;">Browse Categories</div>' +
      '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;">' +
        [
          {sub:'electronics', icon:'📱', label:'Electronics', color:'#4895EF'},
          {sub:'kitchen',     icon:'🍳', label:'Kitchen',     color:'#F5A623'},
          {sub:'furniture',   icon:'🛋', label:'Furniture',   color:'#7c3aed'},
          {sub:'decor',       icon:'🖼', label:'Decor',       color:'#ec4899'},
          {sub:'appliances',  icon:'⚡', label:'Appliances',  color:'#059669'},
          {sub:'fashion',     icon:'👗', label:'Fashion',     color:'#db2777'},
          {sub:'bedding',     icon:'🛏', label:'Bedding',     color:'#0891b2'},
          {sub:'beauty',      icon:'💄', label:'Beauty',      color:'#f472b6'},
          {sub:'sports',      icon:'⚽', label:'Sports',      color:'#16a34a'},
        ].map(function(c){
          return '<div onclick="window.location.href=\'category.php?sub=' + encodeURIComponent(c.sub) + '\'" ' +
            'style="background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:12px;' +
            'padding:10px 8px;display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer;">' +
            '<span style="font-size:22px;">' + c.icon + '</span>' +
            '<span style="font-size:10px;font-weight:700;color:var(--muted);text-align:center;">' + c.label + '</span>' +
          '</div>';
        }).join('') +
      '</div>' +
    '</div>';
}

/* Live search inside modal */
document.addEventListener('DOMContentLoaded', function() {
  var inp = document.getElementById('dsmInput');
  if (!inp) return;

  inp.addEventListener('input', function() {
    var q = this.value.trim();
    clearTimeout(DSM_TIMER);
    if (!q) { renderDsmRecent(); return; }
    document.getElementById('dsmResults').innerHTML =
      '<div class="dsm-spin-wrap show"><div class="dsm-spin"></div></div>';
    DSM_TIMER = setTimeout(function() { dsmSearch(q); }, 240);
  });

  inp.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && this.value.trim()) {
      clearTimeout(DSM_TIMER);
      dsmApply(this.value.trim());
    }
    if (e.key === 'Escape') closeDsmModal();
  });
});

function dsmSearch(q) {
  /* Try the API first */
  var xhr = new XMLHttpRequest();
  xhr.open('GET', API_BASE + '/search.php?q=' + encodeURIComponent(q) + '&type=items&limit=12', true);
  xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
  xhr.timeout = 7000;
  xhr.onload = function() {
    var data = [];
    try {
      var d = JSON.parse(xhr.responseText);
      if (d && d.success && d.data && d.data.length) data = d.data;
    } catch(e) {}
    if (!data.length) {
      /* Seed fallback */
      var seed = (window.MalabaAPI && MalabaAPI._seed && MalabaAPI._seed.items) || [];
      var ql = q.toLowerCase();
      data = seed.filter(function(i) {
        return ((i.title||'') + (i.description||'')).toLowerCase().indexOf(ql) !== -1;
      }).slice(0, 12);
    }
    renderDsmResults(data, q);
  };
  xhr.onerror = xhr.ontimeout = function() {
    var seed = (window.MalabaAPI && MalabaAPI._seed && MalabaAPI._seed.items) || [];
    var ql = q.toLowerCase();
    var data = seed.filter(function(i) {
      return ((i.title||'') + (i.description||'')).toLowerCase().indexOf(ql) !== -1;
    }).slice(0, 12);
    renderDsmResults(data, q);
  };
  xhr.send();
}

function renderDsmResults(items, q) {
  var container = document.getElementById('dsmResults');
  if (!items.length) {
    container.innerHTML =
      '<div class="dsm-empty">' +
        '<i class="fa-solid fa-circle-xmark" style="font-size:28px;color:var(--dim);margin-bottom:10px;display:block;"></i>' +
        'No results for "<strong>' + esc(q) + '</strong>"<br>' +
        '<span style="font-size:12px;margin-top:6px;display:block;">Try a different word or browse categories</span>' +
      '</div>';
    return;
  }

  /* Highlight matching text */
  function hl(text) {
    var re = new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&') + ')', 'gi');
    return esc(text).replace(re, '<span class="dsm-hl">$1</span>');
  }

  container.innerHTML =
    '<div class="dsm-section">' + items.length + ' result' + (items.length !== 1 ? 's' : '') + ' for "' + esc(q) + '"</div>' +
    items.map(function(it) {
      var img = it.image || it.image_url || '';
      if (img.indexOf('unsplash.com') !== -1) img = img.split('?')[0] + '?w=104&h=104&q=65&auto=format&fit=crop';
      if (!img) img = 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=104&q=60';
      var sub = (it.sub_category || it.subCategory || '').trim();
      return (
        '<div class="dsm-item" onclick="dsmGoItem(\'' + esc(it.id) + '\')">' +
          '<img class="dsm-thumb" src="' + esc(img) + '" loading="lazy" ' +
            'onerror="this.src=\'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=104&q=60\'">' +
          '<div class="dsm-info">' +
            '<div class="dsm-title">' + hl(it.title || '') + '</div>' +
            '<div class="dsm-sub">' + (sub ? esc(sub.charAt(0).toUpperCase() + sub.slice(1)) : 'Item') + '</div>' +
          '</div>' +
          '<div class="dsm-price">' + esc(it.price || '') + '</div>' +
        '</div>'
      );
    }).join('');
}

function dsmGoItem(id) {
  /* Save the search term to recents */
  var q = (document.getElementById('dsmInput').value || '').trim();
  if (q) saveDsmRecent(q);
  closeDsmModal();
  window.location.href = 'item_detail.php?id=' + encodeURIComponent(id);
}

function dsmApply(q) {
  saveDsmRecent(q);
  closeDsmModal();
  /* Navigate to category page with search query */
  window.location.href = 'category.php?q=' + encodeURIComponent(q);
}

function saveDsmRecent(q) {
  if (!q) return;
  DSM_RECENT = DSM_RECENT.filter(function(r) { return r !== q; });
  DSM_RECENT.unshift(q);
  DSM_RECENT = DSM_RECENT.slice(0, 8);
  try { localStorage.setItem('mh_det_recent', JSON.stringify(DSM_RECENT)); } catch(e) {}
}

/* ── Header shadow on scroll ── */
window.addEventListener('scroll', function(){
  var h = document.getElementById('mainHdr');
  if (h) h.classList.toggle('scrolled', window.scrollY > 40);
}, {passive:true});
</script>
</body>
</html>