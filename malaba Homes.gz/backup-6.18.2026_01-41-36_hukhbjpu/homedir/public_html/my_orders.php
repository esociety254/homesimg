<?php
$apiBase = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/api';
$apiUrl  = $apiBase . '/order_status.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="theme-color" content="#080604">
<title>My Orders - Malaba Homes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">


<style>
:root{
  --bg:#080604;--surface:#141210;--card:#1A1714;
  --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);
  --text:#F2EDE6;--text2:#B8AFA5;--muted:#6E6560;
  --amber:#E8521A;--amber2:#FF7043;--green:#52B788;
  --safe-b:env(safe-area-inset-bottom,0px);
  --safe-t:env(safe-area-inset-top,0px);
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
html{overflow-x:hidden;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100dvh;-webkit-font-smoothing:antialiased;padding-bottom:calc(32px + var(--safe-b));}
a{color:inherit;text-decoration:none;}
button{cursor:pointer;font-family:inherit;border:none;background:none;}

/* Header */
.header{position:sticky;top:0;z-index:100;padding-top:var(--safe-t);background:rgba(8,6,4,.95);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);}
.header-inner{max-width:680px;margin:0 auto;height:56px;display:flex;align-items:center;gap:12px;padding:0 16px;}
.back-btn{width:36px;height:36px;border-radius:50%;background:var(--surface);border:1px solid var(--border2);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.back-btn svg{width:18px;height:18px;color:var(--text);}
.back-btn:active{transform:scale(.9);}
.brand{flex:1;font-family:'Syne',sans-serif;font-weight:800;font-size:16px;}
.brand span{color:var(--amber2);}

/* Page */
.page{max-width:680px;margin:0 auto;padding:20px 16px 0;}

/* Phone lookup card */
.lookup-card{background:var(--card);border:1px solid var(--border);border-radius:24px;padding:24px;margin-bottom:20px;}
.lc-title{font-family:'Syne',sans-serif;font-weight:800;font-size:18px;margin-bottom:4px;}
.lc-sub{font-size:13px;color:var(--muted);margin-bottom:20px;}
.saved-chip{display:flex;align-items:center;gap:10px;background:rgba(82,183,136,.1);border:1px solid rgba(82,183,136,.22);border-radius:12px;padding:11px 13px;margin-bottom:16px;}
.sc-av{width:34px;height:34px;border-radius:50%;background:rgba(82,183,136,.2);display:flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0;overflow:hidden;}
.sc-av img{width:100%;height:100%;object-fit:cover;}
.sc-name{font-size:13px;font-weight:700;color:var(--green);}
.sc-sub{font-size:11px;color:var(--muted);}
.sc-clear{margin-left:auto;font-size:11px;font-weight:700;color:rgba(255,255,255,.35);border:1px solid rgba(255,255,255,.1);border-radius:7px;padding:4px 9px;flex-shrink:0;}
.input-wrap{display:flex;align-items:center;background:var(--surface);border:1.5px solid var(--border2);border-radius:12px;overflow:hidden;transition:border-color .2s;margin-bottom:12px;}
.input-wrap:focus-within{border-color:var(--amber2);}
.input-wrap svg{margin:0 12px;color:var(--muted);flex-shrink:0;width:16px;height:16px;}
.input-wrap input{flex:1;padding:13px 14px 13px 0;background:transparent;border:none;outline:none;font-family:inherit;font-size:15px;color:var(--text);}
.input-wrap input::placeholder{color:var(--muted);}
.load-btn{width:100%;padding:13px;background:linear-gradient(135deg,var(--amber),var(--amber2));color:#fff;border-radius:12px;font-family:'Syne',sans-serif;font-weight:800;font-size:14px;transition:all .2s;display:flex;align-items:center;justify-content:center;gap:8px;box-shadow:0 4px 16px rgba(232,82,26,.3);}
.load-btn:active{transform:scale(.98);}
.load-btn:disabled{opacity:.5;}

/* Stats row */
.stats-row{display:flex;gap:10px;margin-bottom:20px;}
.stat-chip{flex:1;background:var(--card);border:1px solid var(--border);border-radius:14px;padding:14px 12px;text-align:center;}
.stat-val{font-family:'Syne',sans-serif;font-weight:800;font-size:22px;color:var(--text);margin-bottom:2px;}
.stat-lbl{font-size:11px;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:.4px;}
.stat-val.green{color:var(--green);}
.stat-val.amber{color:var(--amber2);}

/* Order list */
.orders-list{display:flex;flex-direction:column;gap:12px;}
.order-row{background:var(--card);border:1px solid var(--border);border-radius:18px;overflow:hidden;display:flex;align-items:stretch;gap:0;cursor:pointer;transition:border-color .2s;}
.order-row:hover{border-color:var(--border2);}
.order-row:active{transform:scale(.99);}
.or-img{width:72px;flex-shrink:0;}
.or-img img{width:100%;height:100%;object-fit:cover;}
.or-img-ph{width:72px;background:var(--surface);display:flex;align-items:center;justify-content:center;font-size:24px;}
.or-body{flex:1;padding:12px 14px;min-width:0;}
.or-ref{font-size:10px;font-weight:700;color:var(--muted);letter-spacing:.5px;margin-bottom:3px;}
.or-title{font-family:'Syne',sans-serif;font-weight:700;font-size:14px;color:var(--text);margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.or-meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.or-status{font-size:11px;font-weight:700;padding:3px 9px;border-radius:20px;white-space:nowrap;}
.sp-pending   {background:rgba(245,158,11,.15);color:#f59e0b;}
.sp-confirmed {background:rgba(9,132,227,.15);color:#74b9ff;}
.sp-processing{background:rgba(139,92,246,.15);color:#c4b5fd;}
.sp-dispatched{background:rgba(13,148,136,.15);color:#2dd4bf;}
.sp-delivered {background:rgba(0,184,148,.15);color:var(--green);}
.sp-cancelled {background:rgba(214,48,49,.15);color:#fca5a5;}
.or-price{font-size:12px;font-weight:700;color:var(--amber2);}
.or-date{font-size:11px;color:var(--muted);}
.or-arrow{padding:0 14px;display:flex;align-items:center;color:var(--muted);font-size:16px;}

/* Empty / loader */
.empty-state{text-align:center;padding:48px 20px;}
.empty-icon{font-size:48px;margin-bottom:14px;}
.empty-title{font-family:'Syne',sans-serif;font-weight:800;font-size:18px;margin-bottom:8px;}
.empty-sub{font-size:13px;color:var(--muted);margin-bottom:24px;line-height:1.5;}
.empty-links{display:flex;flex-direction:column;gap:10px;}
.el-btn{display:flex;align-items:center;justify-content:center;gap:8px;padding:13px;border-radius:14px;font-family:'Syne',sans-serif;font-weight:700;font-size:14px;transition:all .2s;}
.el-btn:active{transform:scale(.98);}
.el-food{background:rgba(255,112,67,.12);color:#FF7043;border:1px solid rgba(255,112,67,.2);}
.el-shop{background:rgba(72,149,239,.12);color:#4895EF;border:1px solid rgba(72,149,239,.2);}
.el-homes{background:rgba(82,183,136,.12);color:var(--green);border:1px solid rgba(82,183,136,.2);}
.loader-ring{width:36px;height:36px;border-radius:50%;border:3px solid var(--border2);border-top-color:var(--amber2);animation:spin .7s linear infinite;margin:40px auto;}
@keyframes spin{to{transform:rotate(360deg)}}

/* Error */
.err-box{background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.2);border-radius:12px;padding:14px 16px;font-size:13px;color:#fca5a5;margin-bottom:16px;}

/* Bottom nav */
.bnav{display:none;position:fixed;bottom:0;left:0;right:0;z-index:200;background:rgba(8,6,4,.97);backdrop-filter:blur(20px);border-top:1px solid var(--border);padding:8px 0 calc(8px + var(--safe-b));}
.bni{flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;font-size:9px;font-weight:600;color:var(--muted);letter-spacing:.3px;text-transform:uppercase;cursor:pointer;transition:color .2s;padding:4px 0;text-decoration:none;}
.bni.active{color:var(--amber2);}
.bni-icon{font-size:20px;line-height:1.1;}
@media(max-width:600px){body{padding-bottom:calc(70px + var(--safe-b));}.bnav{display:flex;}.page{padding:14px 12px 0;}.lookup-card{padding:18px 16px;border-radius:20px;}}

.toast{position:fixed;bottom:calc(20px + var(--safe-b));left:50%;transform:translateX(-50%) translateY(10px);background:var(--text);color:var(--bg);padding:10px 20px;border-radius:30px;font-size:13px;font-weight:600;z-index:999;opacity:0;pointer-events:none;transition:all .25s;white-space:nowrap;}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
</style>
</head>
<body>

<header class="header">
  <div class="header-inner">
    <a href="index.php" class="back-btn">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
        <path d="M19 12H5M5 12l7-7M5 12l7 7"/>
      </svg>
    </a>
    <div class="brand">My <span>Orders</span></div>
  </div>
</header>

<div class="page">

  <!-- Phone lookup -->
  <div class="lookup-card">
    <h1 class="lc-title">&#x1F4E6; Your Order History</h1>
    <p class="lc-sub">Enter your phone number to see all your orders</p>
    <div id="savedChip" style="display:none;" class="saved-chip">
      <div class="sc-av" id="scAv">&#x1F464;</div>
      <div>
        <div class="sc-name" id="scName"></div>
        <div class="sc-sub"  id="scSub"></div>
      </div>
      <button class="sc-clear" onclick="clearSaved()">Change</button>
    </div>
    <div class="input-wrap">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
        <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.5 9.86 19.79 19.79 0 01.46 1.21 2 2 0 012.44 0h3a2 2 0 012 1.72 12 12 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 7.91a16 16 0 006.13 6.13l1.27-.79a2 2 0 012.11-.45 12 12 0 002.81.7A2 2 0 0122 16.92z"/>
      </svg>
      <input type="tel" id="phoneInput" placeholder="0712 345 678" inputmode="tel" autocomplete="tel">
    </div>
    <button class="load-btn" id="loadBtn" onclick="loadMyOrders()">
      &#x1F4CB; Load My Orders
    </button>
  </div>

  <!-- Results -->
  <div id="results"></div>

</div>

<nav class="bnav">
  <a href="index.php"         class="bni"><span class="bni-icon">&#x1F3E1;</span>Home</a>
  <a href="homes_listing.php" class="bni"><span class="bni-icon">&#x1F3E0;</span>Homes</a>
  <a href="food_listing.php"  class="bni"><span class="bni-icon">&#x1F354;</span>Food</a>
  <a href="shop_listing.php"  class="bni"><span class="bni-icon">&#x1F6D2;</span>Shop</a>
  <a href="my_orders.php"     class="bni active"><span class="bni-icon">&#x1F4E6;</span>Orders</a>
</nav>

<div class="toast" id="toast"></div>

<script src="mh_user.js" onerror="window.MhUser=null"></script>
<script>
var API_URL = <?php echo json_encode($apiUrl); ?>;

var STATUS_META = {
  pending:    {label:'Received',    icon:'&#x1F4CB;'},
  confirmed:  {label:'Confirmed',   icon:'&#x2705;'},
  processing: {label:'Preparing',   icon:'&#x1F504;'},
  dispatched: {label:'On the Way',  icon:'&#x1F69A;'},
  delivered:  {label:'Delivered',   icon:'&#x1F389;'},
  cancelled:  {label:'Cancelled',   icon:'&#x274C;'}
};

// Init saved chip
window.addEventListener('load', function() {
  if (!window.MhUser) return;
  var d = MhUser.getDetails();
  if (!d || !d.phone) return;
  document.getElementById('scName').textContent = d.name || 'Saved account';
  document.getElementById('scSub').textContent  = d.phone;
  if (d.avatar) document.getElementById('scAv').innerHTML = '<img src="' + d.avatar + '" alt="">';
  document.getElementById('savedChip').style.display = 'flex';
  document.getElementById('phoneInput').value = d.phone;
  // Auto-load
  setTimeout(loadMyOrders, 400);
});

function clearSaved() {
  document.getElementById('savedChip').style.display = 'none';
  document.getElementById('phoneInput').value = '';
  document.getElementById('results').innerHTML = '';
}

function loadMyOrders() {
  var phone = document.getElementById('phoneInput').value.trim();
  if (!phone || phone.replace(/\D/g,'').length < 9) {
    showToast('Enter your phone number first');
    return;
  }

  var btn = document.getElementById('loadBtn');
  btn.disabled = true;
  btn.textContent = 'Loading...';
  document.getElementById('results').innerHTML = '<div class="loader-ring"></div>';

  var xhr = new XMLHttpRequest();
  xhr.open('GET', API_URL + '?phone=' + encodeURIComponent(phone), true);
  xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
  xhr.timeout = 12000;

  xhr.onload = function() {
    btn.disabled = false;
    btn.innerHTML = '&#x1F4CB; Load My Orders';
    if (xhr.status === 200) {
      try {
        var data = JSON.parse(xhr.responseText);
        if (data.success) {
          var orders = data.single ? [data.data] : (Array.isArray(data.data) ? data.data : [data.data]);
          renderOrders(orders);
          return;
        }
      } catch(e) {}
    }
    document.getElementById('results').innerHTML = renderEmpty();
  };
  xhr.onerror = xhr.ontimeout = function() {
    btn.disabled = false;
    btn.innerHTML = '&#x1F4CB; Load My Orders';
    document.getElementById('results').innerHTML = '<div class="err-box">&#x26A0;&#xFE0F; Could not connect. Make sure XAMPP is running.</div>' + renderEmpty();
  };
  xhr.send();
}

function renderOrders(orders) {
  if (!orders || !orders.length) {
    document.getElementById('results').innerHTML = renderEmpty();
    return;
  }

  // Stats
  var total     = orders.length;
  var delivered = orders.filter(function(o){ return o.status === 'delivered'; }).length;
  var pending   = orders.filter(function(o){ return o.status === 'pending' || o.status === 'processing' || o.status === 'dispatched'; }).length;
  var spent     = orders.reduce(function(s,o){ return s + (parseFloat(o.total_amount)||0); }, 0);

  var html = '<div class="stats-row">' +
    '<div class="stat-chip"><div class="stat-val">' + total + '</div><div class="stat-lbl">Orders</div></div>' +
    '<div class="stat-chip"><div class="stat-val green">' + delivered + '</div><div class="stat-lbl">Delivered</div></div>' +
    '<div class="stat-chip"><div class="stat-val amber">' + pending + '</div><div class="stat-lbl">Active</div></div>' +
    '</div>';

  html += '<div class="orders-list">';
  orders.forEach(function(o) {
    var sm    = STATUS_META[o.status] || {label: o.status, icon:'&#x1F4CC;'};
    var img   = o.listing_image ? '<img src="' + esc(o.listing_image) + '" alt="" onerror="this.parentElement.innerHTML=\'&#x1F4E6;\'">' : '';
    var price = parseFloat(o.total_amount) > 0 ? 'KSH ' + Number(o.total_amount).toLocaleString('en-KE') : (o.listing_price || '');
    var date  = fmtDate(o.created_at);
    html +=
      '<div class="order-row" onclick="goTrack(\'' + esc(o.order_ref) + '\')">' +
        '<div class="or-img">' + (img || '<div class="or-img-ph">' + (o.category_icon||'&#x1F4E6;') + '</div>') + '</div>' +
        '<div class="or-body">' +
          '<div class="or-ref">' + esc(o.order_ref) + '</div>' +
          '<div class="or-title">' + esc(o.listing_title || 'Order') + '</div>' +
          '<div class="or-meta">' +
            '<span class="or-status sp-' + o.status + '">' + sm.icon + ' ' + sm.label + '</span>' +
            '<span class="or-price">' + price + '</span>' +
          '</div>' +
          '<div class="or-date">' + date + '</div>' +
        '</div>' +
        '<div class="or-arrow">&#x203A;</div>' +
      '</div>';
  });
  html += '</div>';
  html += '<div style="text-align:center;padding:20px 0;"><a href="track_order.php" style="font-size:13px;color:var(--amber2);">&#x1F50D; Track a specific order by reference</a></div>';

  document.getElementById('results').innerHTML = html;
}

function renderEmpty() {
  return '<div class="empty-state">' +
    '<div class="empty-icon">&#x1F6D2;</div>' +
    '<div class="empty-title">No orders found</div>' +
    '<div class="empty-sub">You have not placed any orders with this number yet.<br>Start shopping below!</div>' +
    '<div class="empty-links">' +
      '<a href="food_listing.php" class="el-btn el-food">&#x1F354; Order Food</a>' +
      '<a href="shop_listing.php" class="el-btn el-shop">&#x1F6D2; Shop Items</a>' +
      '<a href="homes_listing.php" class="el-btn el-homes">&#x1F3E0; Find a Home</a>' +
    '</div>' +
  '</div>';
}

function goTrack(ref) {
  window.location.href = 'track_order.php?ref=' + encodeURIComponent(ref);
}

function fmtDate(str) {
  if (!str) return '';
  var d = new Date(str);
  if (isNaN(d.getTime())) return str;
  var now  = new Date();
  var diff = (now - d) / 1000;
  if (diff < 60)    return 'Just now';
  if (diff < 3600)  return Math.floor(diff/60) + ' min ago';
  if (d.toDateString() === now.toDateString()) return 'Today ' + d.toLocaleTimeString('en-KE',{hour:'2-digit',minute:'2-digit'});
  return d.toLocaleDateString('en-KE',{day:'numeric',month:'short',year:'numeric'});
}

function esc(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function showToast(msg) {
  var t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(function(){ t.classList.remove('show'); }, 2200);
}

document.getElementById('phoneInput').addEventListener('keydown', function(e){
  if (e.key === 'Enter') loadMyOrders();
});
</script>
</body>
</html>
