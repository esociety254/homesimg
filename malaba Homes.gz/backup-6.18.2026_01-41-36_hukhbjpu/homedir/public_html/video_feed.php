<?php
$apiBase = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/api';
$initId  = isset($_GET['id'])  ? htmlspecialchars($_GET['id'],  ENT_QUOTES) : '';
$initCat = isset($_GET['cat']) ? htmlspecialchars($_GET['cat'], ENT_QUOTES) : 'mix';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1">
<meta name="theme-color" content="#000">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<title>Watch &amp; Shop — Malaba Homes</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800;900&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include 'pwa_head.php'; ?>
<?php include 'pwa_head.php'; ?>

  <script src="/firebase-config.js"></script>
  <script src="/push_register.js"></script>
<style>
/* ─── RESET ─── */
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
html,body{height:100%;overflow:hidden;background:#000;font-family:'DM Sans',sans-serif;-webkit-font-smoothing:antialiased;color:#fff;}
a,button{cursor:pointer;border:none;background:none;color:inherit;text-decoration:none;font-family:inherit;}
:root{
  --st:env(safe-area-inset-top,0px);
  --sb:env(safe-area-inset-bottom,0px);
  --amber:#E8521A;--amber2:#FF7043;--gold:#f59e0b;
  --green:#52B788;--blue:#4895EF;--purple:#8b5cf6;
}

/* ─── CATEGORY WRAPPER — horizontal slides ─── */
#catWrap{
  display:flex;width:100%;height:100dvh;
  overflow:hidden;position:relative;
}
.cat-pane{
  min-width:100%;height:100dvh;position:relative;
  transition:transform 0s; /* handled via JS translate */
  flex-shrink:0;
}

/* ─── FEED ─── */
.feed{
  height:100dvh;width:100%;
  overflow-y:scroll;overflow-x:hidden;
  scroll-snap-type:y mandatory;
  -webkit-overflow-scrolling:touch;
  scrollbar-width:none;
}
.feed::-webkit-scrollbar{display:none;}

/* ─── SLIDE ─── */
.slide{
  height:100dvh;width:100%;
  scroll-snap-align:start;scroll-snap-stop:always;
  position:relative;overflow:hidden;
  display:flex;align-items:flex-end;background:#050505;
}

/* ─── CROSSFADE transition layer ─── */
.slide-crossfade{
  position:absolute;inset:0;z-index:3;
  background:#000;opacity:0;pointer-events:none;
  transition:opacity .35s ease;
}
.slide.leaving .slide-crossfade{opacity:1;}

/* ─── MEDIA — VIDEO / IMAGE / CAROUSEL ─── */
.s-video{
  position:absolute;inset:0;z-index:0;
  width:100%;height:100%;object-fit:cover;
  pointer-events:none;
  background:#000;
}
/* Single image fallback */
.s-img{
  position:absolute;inset:0;z-index:0;
  width:100%;height:100%;object-fit:cover;
  object-position:center 35%; /* show product better — not cut off at waist */
  transition:transform 9s cubic-bezier(.25,.46,.45,.94);
  transform:scale(1.07);will-change:transform;
  user-select:none;-webkit-user-select:none;
  pointer-events:none;background:#050505;
}
.slide.active .s-img{transform:scale(1);}

/* ─── IMAGE CAROUSEL ─── */
.s-carousel{
  position:absolute;inset:0;z-index:0;
  overflow:hidden;
}
.s-carousel-track{
  display:flex;width:100%;height:100%;
  transition:transform .42s cubic-bezier(.25,.46,.45,.94);
  will-change:transform;
}
.s-carousel-slide{
  min-width:100%;height:100%;flex-shrink:0;position:relative;
}
.s-carousel-img{
  width:100%;height:100%;object-fit:cover;
  object-position:center 35%;
  pointer-events:none;user-select:none;-webkit-user-select:none;
  background:#050505;
  transition:transform 9s cubic-bezier(.25,.46,.45,.94);
  transform:scale(1.06);will-change:transform;
}
.slide.active .s-carousel-img.active-img{transform:scale(1);}

/* Carousel dots */
.s-carousel-dots{
  position:absolute;bottom:calc(120px + var(--sb));left:50%;
  transform:translateX(-50%);
  z-index:8;display:flex;gap:5px;pointer-events:none;
}
.s-cdot{
  width:5px;height:5px;border-radius:50%;
  background:rgba(255,255,255,.32);
  transition:all .25s;
}
.s-cdot.on{
  width:16px;border-radius:3px;
  background:#fff;box-shadow:0 0 6px rgba(255,255,255,.4);
}

/* Carousel swipe arrows (subtle) */
.s-arrow{
  position:absolute;top:50%;z-index:8;
  transform:translateY(-50%);
  width:32px;height:32px;border-radius:50%;
  background:rgba(0,0,0,.38);backdrop-filter:blur(6px);
  border:1px solid rgba(255,255,255,.12);
  display:flex;align-items:center;justify-content:center;
  font-size:13px;color:rgba(255,255,255,.75);
  pointer-events:all;transition:opacity .2s;
  opacity:0;
}
.slide.active .s-arrow{opacity:1;}
.s-arrow-l{left:8px;}
.s-arrow-r{right:8px;}
.s-arrow:active{background:rgba(0,0,0,.6);}

/* Image count badge */
.s-img-count{
  position:absolute;top:calc(var(--st) + 52px);right:12px;z-index:8;
  background:rgba(0,0,0,.5);backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.14);border-radius:12px;
  padding:3px 9px;font-size:10px;font-weight:700;
  color:rgba(255,255,255,.8);display:flex;align-items:center;gap:4px;
}

/* Video badge */
.s-vid-badge{
  position:absolute;top:calc(var(--st) + 52px);right:12px;z-index:8;
  background:rgba(0,0,0,.5);backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.14);border-radius:12px;
  padding:3px 9px;font-size:10px;font-weight:800;
  color:#fff;display:flex;align-items:center;gap:4px;
  letter-spacing:.3px;
}
.s-vid-dot{
  width:6px;height:6px;border-radius:50%;
  background:var(--amber2);
  box-shadow:0 0 4px rgba(255,112,67,.8);
  animation:vid-blink 1.4s ease infinite;
  flex-shrink:0;
}
@keyframes vid-blink{0%,100%{opacity:1}50%{opacity:.3}}

/* ─── PRODUCT HIGHLIGHT BAND (no video, single image) ─── */
/* Slightly more product-forward gradient for image-only slides */
.slide.img-only .s-grad{
  background:linear-gradient(
    to bottom,
    rgba(0,0,0,.5) 0%,
    transparent 18%,
    transparent 38%,
    rgba(0,0,0,.55) 58%,
    rgba(0,0,0,.98) 100%
  );
}

/* ─── GRADIENTS ─── */
.s-grad{
  position:absolute;inset:0;z-index:1;pointer-events:none;
  background:linear-gradient(
    to bottom,
    rgba(0,0,0,.6) 0%,
    transparent 22%,
    transparent 44%,
    rgba(0,0,0,.5) 62%,
    rgba(0,0,0,.96) 100%
  );
  transition:opacity .4s ease;
}
.s-vign{
  position:absolute;inset:0;z-index:1;pointer-events:none;
  background:radial-gradient(ellipse at center,transparent 52%,rgba(0,0,0,.42) 100%);
  transition:opacity .4s ease;
}

/* ─── CINEMA MODE (long press) ─── */
.slide.cinema .s-grad,
.slide.cinema .s-vign,
.slide.cinema .s-body,
.slide.cinema .prog,
.slide.cinema .wm{opacity:0!important;pointer-events:none;}

/* ─── WATERMARK ─── */
.wm{
  position:absolute;top:50%;left:50%;z-index:2;pointer-events:none;
  transform:translate(-50%,-50%) rotate(-20deg);
  font-family:'Syne',sans-serif;font-weight:900;
  font-size:clamp(20px,6.5vw,32px);
  letter-spacing:7px;text-transform:uppercase;
  color:#fff;opacity:.05;white-space:nowrap;user-select:none;
  transition:opacity .4s;
}

/* ─── PROGRESS ─── */
.prog{
  position:absolute;top:0;left:0;right:0;height:2px;z-index:20;
  background:rgba(255,255,255,.1);transition:opacity .4s;
}
.prog-fill{
  height:100%;width:0%;border-radius:0 1px 1px 0;
  background:linear-gradient(90deg,var(--amber),var(--amber2),#FFB347);
  transition:width .32s linear;
}

/* ─── PLAY PULSE ─── */
.pulse{
  position:absolute;top:50%;left:50%;z-index:10;pointer-events:none;
  transform:translate(-50%,-50%) scale(0);
  width:76px;height:76px;border-radius:50%;
  background:rgba(255,255,255,.18);backdrop-filter:blur(8px);
  display:flex;align-items:center;justify-content:center;font-size:30px;
  opacity:0;transition:transform .14s,opacity .22s;
}
.pulse.show{transform:translate(-50%,-50%) scale(1);opacity:1;}
.pulse.fade{transform:translate(-50%,-50%) scale(1.4);opacity:0;}

/* ─── TOP BAR ─── */
.top-bar{
  position:fixed;top:0;left:0;right:0;z-index:300;
  padding:calc(var(--st) + 10px) 13px 10px;
  display:flex;align-items:center;gap:7px;pointer-events:none;
}
.top-bar>*{pointer-events:all;}
.tb-back{
  width:38px;height:38px;border-radius:50%;flex-shrink:0;
  background:rgba(0,0,0,.55);backdrop-filter:blur(14px);
  border:1px solid rgba(255,255,255,.13);
  display:flex;align-items:center;justify-content:center;font-size:17px;
  transition:transform .14s;
}
.tb-back:active{transform:scale(.9);}

/* Category indicator row */
.tb-cats{
  flex:1;position:relative;height:36px;overflow:visible;
  display:flex;align-items:center;justify-content:center;
}
.tb-cat-pill{
  display:flex;align-items:center;gap:5px;padding:7px 16px;
  background:rgba(0,0,0,.52);backdrop-filter:blur(16px);
  border:1px solid rgba(255,255,255,.12);border-radius:30px;
  font-size:13px;font-weight:700;color:#fff;
  transition:all .28s cubic-bezier(.25,.46,.45,.94);
  white-space:nowrap;
}
/* side hints when swiping */
.tb-cat-side{
  position:absolute;font-size:11px;font-weight:600;
  color:rgba(255,255,255,.4);
  transition:opacity .28s;
  pointer-events:none;
  display:flex;align-items:center;gap:4px;
}
.tb-cat-side.left{left:0;opacity:.6;}
.tb-cat-side.right{right:0;opacity:.6;}

.tb-icon{
  width:38px;height:38px;border-radius:50%;flex-shrink:0;
  background:rgba(0,0,0,.55);backdrop-filter:blur(14px);
  border:1px solid rgba(255,255,255,.13);
  display:flex;align-items:center;justify-content:center;font-size:16px;
  transition:transform .14s;
}
.tb-icon:active{transform:scale(.9);}

/* ─── CAT SWIPE INDICATOR ─── */
.cat-flash{
  position:fixed;top:50%;z-index:500;pointer-events:none;
  transform:translateY(-50%);padding:10px 18px;
  background:rgba(232,82,26,.88);backdrop-filter:blur(12px);
  border-radius:30px;font-family:'Syne',sans-serif;
  font-weight:800;font-size:13px;color:#fff;
  opacity:0;transition:opacity .2s;white-space:nowrap;
}
.cat-flash.show{opacity:1;}

/* ─── SLIDE BODY ─── */
.s-body{
  position:relative;z-index:5;width:100%;
  padding:0 12px calc(14px + var(--sb)) 12px;
  display:flex;align-items:flex-end;gap:10px;
  transition:opacity .4s ease;
}

/* INFO */
.s-info{flex:1;min-width:0;}
.cat-pill{
  display:inline-flex;align-items:center;gap:4px;
  font-size:9px;font-weight:700;letter-spacing:.7px;text-transform:uppercase;
  padding:3px 9px;border-radius:20px;margin-bottom:7px;backdrop-filter:blur(8px);
}
.cp-shop  {background:rgba(72,149,239,.28);color:#93c5fd;border:1px solid rgba(72,149,239,.3);}
.cp-food  {background:rgba(232,82,26,.28); color:#fca5a5;border:1px solid rgba(232,82,26,.3);}
.cp-homes {background:rgba(82,183,136,.28);color:#86efac;border:1px solid rgba(82,183,136,.3);}
.s-title{
  font-family:'Syne',sans-serif;font-weight:900;
  font-size:clamp(18px,5.5vw,25px);
  line-height:1.15;letter-spacing:-.3px;color:#fff;margin-bottom:4px;
  text-shadow:0 2px 18px rgba(0,0,0,.65);
}
.s-loc{font-size:11px;color:rgba(255,255,255,.52);margin-bottom:9px;display:flex;align-items:center;gap:3px;}
.s-buy-row{display:flex;align-items:center;gap:8px;}
.s-price{
  font-family:'Syne',sans-serif;font-weight:900;
  font-size:clamp(17px,4.5vw,21px);color:var(--amber);
  text-shadow:0 2px 12px rgba(232,82,26,.4);flex-shrink:0;
}
.btn-order{
  flex:1;padding:11px 13px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;border-radius:12px;
  font-family:'Syne',sans-serif;font-weight:800;font-size:13px;
  display:flex;align-items:center;justify-content:center;gap:5px;
  box-shadow:0 4px 20px rgba(232,82,26,.45);
  transition:transform .14s;border:none;
}
.btn-order:active{transform:scale(.95);}

/* ─── ACTION BAR ─── */
.s-actions{display:flex;flex-direction:column;align-items:center;gap:14px;padding-bottom:4px;flex-shrink:0;}
.sa{display:flex;flex-direction:column;align-items:center;gap:4px;cursor:pointer;}
.sa-icon{
  width:46px;height:46px;border-radius:50%;
  background:rgba(255,255,255,.1);backdrop-filter:blur(10px);
  border:1px solid rgba(255,255,255,.14);
  display:flex;align-items:center;justify-content:center;font-size:19px;
  transition:transform .14s,background .14s;
}
.sa:active .sa-icon{transform:scale(.86);}
.sa-lbl{font-size:9px;font-weight:700;color:rgba(255,255,255,.65);letter-spacing:.3px;text-align:center;max-width:52px;line-height:1.2;}
/* Lipa */
.sa-lipa .sa-icon{
  background:linear-gradient(135deg,rgba(245,158,11,.28),rgba(232,82,26,.2));
  border-color:rgba(245,158,11,.5);color:#fcd34d;font-size:20px;
}
.sa-lipa .sa-lbl{color:#fcd34d;}
/* WA */
.sa-wa .sa-icon{background:rgba(37,211,102,.13);border-color:rgba(37,211,102,.3);color:#25D366;}
/* Houses */
.sa-enquire .sa-icon{background:rgba(82,183,136,.15);border-color:rgba(82,183,136,.35);color:#86efac;}

/* ─── CINEMA HINT ─── */
.cinema-hint{
  position:fixed;top:50%;left:50%;z-index:50;
  transform:translate(-50%,-50%);pointer-events:none;
  background:rgba(0,0,0,.7);backdrop-filter:blur(8px);
  border-radius:20px;padding:10px 20px;
  font-size:13px;font-weight:700;color:rgba(255,255,255,.8);
  opacity:0;transition:opacity .3s;
}

/* ─── SWIPE HINT ─── */
.swipe-hint{
  position:fixed;bottom:calc(22px + var(--sb));left:50%;
  transform:translateX(-50%);z-index:300;pointer-events:none;
  display:flex;flex-direction:column;align-items:center;gap:3px;
  animation:hintOut 3.5s ease forwards;
}
@keyframes hintOut{
  0%  {opacity:0;transform:translateX(-50%) translateY(10px);}
  18% {opacity:1;transform:translateX(-50%) translateY(0);}
  80% {opacity:1;}
  100%{opacity:0;transform:translateX(-50%) translateY(-8px);}
}
.sh-arr{font-size:24px;animation:bob .9s ease infinite;}
@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
.sh-lbl{font-size:9px;font-weight:700;letter-spacing:2px;color:rgba(255,255,255,.45);text-transform:uppercase;}

/* ─── SKELETON ─── */
.skel{height:100dvh;scroll-snap-align:start;background:#060606;display:flex;align-items:center;justify-content:center;}
.sk-ring{width:38px;height:38px;border-radius:50%;border:3px solid rgba(255,255,255,.07);border-top-color:var(--amber);animation:spin .65s linear infinite;}
@keyframes spin{to{transform:rotate(360deg)}}

/* ─── BOTTOM NAV ─── */
.bnav{
  position:fixed;bottom:0;left:0;right:0;z-index:200;
  background:rgba(0,0,0,.9);backdrop-filter:blur(20px);
  border-top:1px solid rgba(255,255,255,.07);
  display:flex;padding:7px 0 calc(7px + var(--sb));
}
.bni{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;font-size:8px;font-weight:700;color:rgba(255,255,255,.4);letter-spacing:.5px;text-transform:uppercase;padding:3px 0;}
.bni.on{color:var(--amber);}
.bni-i{font-size:19px;line-height:1.2;}

/* ─── SEARCH OVERLAY ─── */
.srch-overlay{
  position:fixed;inset:0;z-index:600;
  background:rgba(0,0,0,.97);backdrop-filter:blur(24px);
  display:flex;flex-direction:column;
  opacity:0;pointer-events:none;transition:opacity .22s;
  padding-top:calc(var(--st) + 8px);
}
.srch-overlay.open{opacity:1;pointer-events:all;}
.srch-bar{
  display:flex;align-items:center;gap:10px;
  padding:10px 14px;border-bottom:1px solid rgba(255,255,255,.06);
}
.srch-wrap{
  flex:1;display:flex;align-items:center;gap:8px;
  background:rgba(255,255,255,.07);border:1.5px solid rgba(255,255,255,.1);
  border-radius:12px;padding:0 12px;transition:border-color .2s;
}
.srch-wrap:focus-within{border-color:var(--amber);}
.srch-wrap svg{flex-shrink:0;opacity:.4;}
.srch-input{
  flex:1;background:transparent;border:none;
  padding:11px 0;color:#fff;font-size:15px;
  font-family:inherit;outline:none;
}
.srch-input::placeholder{color:rgba(255,255,255,.22);}
.srch-clear{display:none;width:18px;height:18px;border-radius:50%;background:rgba(255,255,255,.15);border:none;color:#fff;font-size:11px;flex-shrink:0;align-items:center;justify-content:center;cursor:pointer;}
.srch-clear.show{display:flex;}
.srch-cancel{font-size:13px;font-weight:700;color:rgba(255,255,255,.5);white-space:nowrap;padding:4px 0;}
.srch-cancel:hover{color:#fff;}

/* Filter tabs inside search */
.srch-filters{
  display:flex;gap:6px;padding:10px 14px 8px;
  overflow-x:auto;scrollbar-width:none;
}
.srch-filters::-webkit-scrollbar{display:none;}
.sf-tab{
  flex-shrink:0;padding:5px 13px;border-radius:20px;
  font-size:11px;font-weight:700;
  border:1px solid rgba(255,255,255,.12);
  color:rgba(255,255,255,.5);transition:all .15s;cursor:pointer;
}
.sf-tab.on{background:var(--amber);border-color:var(--amber);color:#fff;}

/* Results */
.srch-results{flex:1;overflow-y:auto;padding:4px 0;}
.sr-sec{padding:10px 14px 5px;font-size:10px;font-weight:700;color:rgba(255,255,255,.3);letter-spacing:.7px;text-transform:uppercase;}
.sr-item{
  display:flex;align-items:center;gap:12px;
  padding:9px 14px;cursor:pointer;transition:background .13s;
  -webkit-tap-highlight-color:transparent;
}
.sr-item:active{background:rgba(255,255,255,.05);}
.sr-img{width:56px;height:56px;border-radius:10px;object-fit:cover;flex-shrink:0;background:rgba(255,255,255,.06);}
.sr-img-ph{width:56px;height:56px;border-radius:10px;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0;}
.sr-info{flex:1;min-width:0;}
.sr-title{font-size:14px;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:2px;}
.sr-meta{font-size:11px;color:rgba(255,255,255,.38);}
.sr-right{display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0;}
.sr-price{font-size:13px;font-weight:700;color:var(--amber);}
.sr-play{font-size:10px;font-weight:700;padding:2px 7px;border-radius:7px;background:rgba(232,82,26,.18);color:var(--amber2);}
/* highlight */
.hl{color:var(--amber);font-weight:700;}
/* recent chips */
.srch-recent-wrap{padding:4px 14px 10px;display:flex;flex-wrap:wrap;gap:6px;}
.rc{
  display:inline-flex;align-items:center;gap:5px;padding:5px 11px;
  background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.09);
  border-radius:20px;font-size:12px;color:rgba(255,255,255,.55);cursor:pointer;
  transition:all .13s;
}
.rc:hover{background:rgba(255,255,255,.11);color:#fff;}
.rc-x{font-size:10px;color:rgba(255,255,255,.28);}
/* loading spinner */
.sr-spinner{display:none;justify-content:center;padding:28px;}
.sr-spinner.show{display:flex;}
.sr-sring{width:22px;height:22px;border-radius:50%;border:2px solid rgba(255,255,255,.1);border-top-color:var(--amber);animation:spin .65s linear infinite;}
/* empty */
.sr-empty{text-align:center;padding:44px 20px;font-size:14px;color:rgba(255,255,255,.28);}

/* ─── BACKDROP ─── */
.bdrop{position:fixed;inset:0;z-index:400;background:rgba(0,0,0,.8);backdrop-filter:blur(8px);opacity:0;pointer-events:none;transition:opacity .28s;}
.bdrop.open{opacity:1;pointer-events:all;}

/* ─── SHEET (shared) ─── */
.sheet{
  position:fixed;bottom:0;left:0;right:0;z-index:500;
  background:#0d0b09;border:1px solid rgba(255,255,255,.08);
  border-radius:24px 24px 0 0;
  transform:translateY(102%);
  transition:transform .38s cubic-bezier(.32,1,.68,1);
  max-height:94dvh;overflow-y:auto;
  padding-bottom:calc(18px + var(--sb));
}
.sheet.open{transform:translateY(0);}
.sh-grip{display:flex;align-items:center;justify-content:center;padding:13px 16px 4px;position:relative;}
.sh-bar{width:36px;height:4px;border-radius:2px;background:rgba(255,255,255,.11);}
.sh-x{position:absolute;right:14px;top:11px;width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;font-size:13px;color:rgba(255,255,255,.45);}

/* ── LIPA SHEET ── */
.lipa-product{display:flex;gap:12px;padding:12px 16px 14px;border-bottom:1px solid rgba(255,255,255,.06);}
.lipa-img{width:62px;height:62px;border-radius:12px;object-fit:cover;flex-shrink:0;}
.lipa-img-ph{width:62px;height:62px;border-radius:12px;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;font-size:26px;flex-shrink:0;}
.lipa-pname{font-family:'Syne',sans-serif;font-weight:800;font-size:15px;margin-bottom:3px;}
.lipa-price-was{font-size:11px;color:rgba(255,255,255,.3);text-decoration:line-through;}
.lipa-tag{font-size:10px;color:#fcd34d;font-weight:700;margin-top:2px;}

/* Lipa step indicator */
.lipa-steps{display:flex;align-items:center;padding:14px 16px 0;}
.lstep{
  display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;
}
.lstep-dot{
  width:26px;height:26px;border-radius:50%;border:2px solid rgba(255,255,255,.12);
  display:flex;align-items:center;justify-content:center;
  font-size:11px;font-weight:700;color:rgba(255,255,255,.3);
  transition:all .3s;
}
.lstep-dot.done{background:var(--green);border-color:var(--green);color:#fff;}
.lstep-dot.active{background:var(--amber);border-color:var(--amber);color:#fff;box-shadow:0 0 0 4px rgba(232,82,26,.22);}
.lstep-lbl{font-size:9px;font-weight:600;color:rgba(255,255,255,.3);text-align:center;letter-spacing:.2px;}
.lstep-lbl.active{color:var(--amber);}
.lstep-lbl.done{color:var(--green);}
.lstep-line{height:2px;flex:1;background:rgba(255,255,255,.08);margin:0 4px;margin-bottom:14px;transition:background .3s;}
.lstep-line.done{background:var(--green);}

/* Lipa step panels */
.lipa-panel{display:none;animation:fadeUp .3s ease;}
.lipa-panel.active{display:block;}
@keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}

/* Step 1: Frequency */
.lipa-freq-title{padding:16px 16px 6px;font-family:'Syne',sans-serif;font-weight:800;font-size:15px;}
.lipa-freq-sub{padding:0 16px 14px;font-size:12px;color:rgba(255,255,255,.38);line-height:1.5;}
.lipa-freqs{display:flex;flex-direction:column;gap:7px;padding:0 16px 14px;}
.lipa-freq{
  display:flex;align-items:center;gap:10px;padding:13px 14px;
  border-radius:13px;border:2px solid rgba(255,255,255,.07);
  background:rgba(255,255,255,.02);cursor:pointer;transition:all .18s;
}
.lipa-freq.sel{border-color:rgba(245,158,11,.5);background:rgba(245,158,11,.07);}
.lf-radio{width:18px;height:18px;border-radius:50%;border:2px solid rgba(255,255,255,.18);flex-shrink:0;display:flex;align-items:center;justify-content:center;transition:all .18s;}
.lipa-freq.sel .lf-radio{background:var(--gold);border-color:var(--gold);}
.lipa-freq.sel .lf-radio::after{content:'';width:6px;height:6px;border-radius:50%;background:#fff;}
.lf-info{flex:1;}
.lf-name{font-size:13px;font-weight:700;color:#fff;margin-bottom:1px;}
.lf-desc{font-size:11px;color:rgba(255,255,255,.35);}
.lf-right{text-align:right;flex-shrink:0;}
.lf-amount{font-family:'Syne',sans-serif;font-weight:800;font-size:15px;color:var(--gold);}
.lf-period{font-size:9px;color:rgba(255,255,255,.3);margin-top:1px;}

/* Step 2: Duration */
.lipa-dur-title{padding:16px 16px 6px;font-family:'Syne',sans-serif;font-weight:800;font-size:15px;}
.lipa-dur-sub{padding:0 16px 12px;font-size:12px;color:rgba(255,255,255,.38);}
.lipa-durations{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:0 16px 14px;}
.lipa-dur{
  padding:14px 12px;border-radius:13px;
  border:2px solid rgba(255,255,255,.07);
  background:rgba(255,255,255,.02);cursor:pointer;transition:all .18s;text-align:center;
}
.lipa-dur.sel{border-color:rgba(245,158,11,.5);background:rgba(245,158,11,.07);}
.ld-weeks{font-family:'Syne',sans-serif;font-weight:800;font-size:20px;color:#fff;margin-bottom:2px;}
.ld-label{font-size:11px;color:rgba(255,255,255,.4);}
.ld-total{font-size:11px;font-weight:700;color:var(--gold);margin-top:4px;}
.lipa-summary-box{
  margin:0 16px 14px;padding:13px 14px;
  background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.2);
  border-radius:12px;
}
.lsb-row{display:flex;justify-content:space-between;align-items:center;font-size:12px;margin-bottom:5px;}
.lsb-row:last-child{margin-bottom:0;}
.lsb-lbl{color:rgba(255,255,255,.45);}
.lsb-val{font-weight:700;color:#fff;}
.lsb-val.highlight{color:var(--gold);}

/* Step 3: Details */
.sh-field{margin:0 16px 11px;}
.sh-field label{display:block;font-size:10px;font-weight:700;color:rgba(255,255,255,.3);letter-spacing:.8px;text-transform:uppercase;margin-bottom:5px;}
.sh-field input{
  width:100%;padding:11px 13px;
  background:rgba(255,255,255,.05);border:1.5px solid rgba(255,255,255,.08);
  border-radius:11px;color:#fff;font-family:inherit;font-size:14px;outline:none;
  transition:border-color .2s;
}
.sh-field input:focus{border-color:var(--gold);}
.sh-field input::placeholder{color:rgba(255,255,255,.22);}
.sh-pay{display:flex;gap:7px;padding:0 16px 14px;}
.sh-po{flex:1;padding:10px 6px;border-radius:11px;text-align:center;border:2px solid rgba(255,255,255,.07);cursor:pointer;transition:all .18s;}
.sh-po.sel{border-color:var(--gold);background:rgba(245,158,11,.09);}
.sh-po-i{font-size:17px;margin-bottom:3px;}
.sh-po-l{font-size:10px;font-weight:700;color:rgba(255,255,255,.45);}
.sh-po.sel .sh-po-l{color:var(--gold);}
.lipa-rule{
  margin:0 16px 14px;padding:10px 12px;
  background:rgba(232,82,26,.07);border:1px solid rgba(232,82,26,.18);
  border-radius:10px;font-size:11px;color:rgba(255,160,100,.85);line-height:1.55;
}
.lipa-rule strong{color:var(--amber2);}

/* Step nav buttons */
.lipa-nav{display:flex;gap:8px;padding:0 16px 4px;}
.lipa-back-btn{
  padding:13px 18px;background:rgba(255,255,255,.06);
  border:1px solid rgba(255,255,255,.1);border-radius:13px;
  font-family:inherit;font-weight:700;font-size:13px;color:rgba(255,255,255,.6);
  cursor:pointer;transition:all .18s;
}
.lipa-next-btn{
  flex:1;padding:13px;border:none;border-radius:13px;
  font-family:'Syne',sans-serif;font-weight:900;font-size:14px;color:#fff;
  cursor:pointer;transition:all .18s;
  background:linear-gradient(135deg,var(--gold),var(--amber));
  box-shadow:0 4px 18px rgba(245,158,11,.28);
}
.lipa-next-btn:active{transform:scale(.98);}

/* ── ORDER SHEET ── */
.os-head{padding:4px 16px 12px;}
.os-htitle{font-family:'Syne',sans-serif;font-weight:800;font-size:15px;margin-bottom:2px;}
.os-hsub{font-size:12px;color:rgba(255,255,255,.35);}
.os-product{display:flex;gap:12px;padding:8px 16px 14px;border-bottom:1px solid rgba(255,255,255,.06);}
.os-img{width:62px;height:62px;border-radius:12px;object-fit:cover;flex-shrink:0;}
.os-img-ph{width:62px;height:62px;border-radius:12px;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;font-size:26px;flex-shrink:0;}
.os-pname{font-family:'Syne',sans-serif;font-weight:800;font-size:15px;margin-bottom:2px;}
.os-pprice{font-size:20px;font-weight:900;color:var(--amber);}
.os-pay .sh-po.sel{border-color:var(--amber);background:rgba(232,82,26,.09);}
.os-pay .sh-po.sel .sh-po-l{color:var(--amber2);}
.os-submit{
  margin:4px 16px 0;width:calc(100% - 32px);padding:14px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  color:#fff;border:none;border-radius:13px;
  font-family:'Syne',sans-serif;font-weight:900;font-size:14px;
  cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px;
  box-shadow:0 4px 20px rgba(232,82,26,.3);transition:transform .15s;
}
.os-submit:active{transform:scale(.98);}

/* ── HOUSE SHEET ── */
.hs-head{padding:4px 16px 12px;}
.hs-title{font-family:'Syne',sans-serif;font-weight:800;font-size:15px;margin-bottom:2px;}
.hs-sub{font-size:12px;color:rgba(255,255,255,.35);line-height:1.5;}
.hs-wa{
  margin:8px 16px 0;width:calc(100% - 32px);padding:14px;
  background:#25D366;color:#fff;border:none;border-radius:13px;
  font-family:'Syne',sans-serif;font-weight:800;font-size:14px;
  cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;
}

/* ── SUCCESS ── */
.sw{text-align:center;padding:26px 16px 10px;display:none;}
.sw-icon{font-size:52px;margin-bottom:10px;}
.sw-title{font-family:'Syne',sans-serif;font-weight:900;font-size:21px;margin-bottom:5px;}
.sw-sub{font-size:13px;color:rgba(255,255,255,.45);line-height:1.55;margin-bottom:12px;}
.sw-ref{font-size:12px;color:var(--amber);font-weight:700;margin-bottom:16px;}
.sw-wa{width:100%;padding:13px;background:#25D366;color:#fff;border:none;border-radius:13px;font-family:'Syne',sans-serif;font-weight:800;font-size:14px;cursor:pointer;margin-bottom:8px;display:flex;align-items:center;justify-content:center;gap:7px;}
.sw-close{width:100%;padding:11px;border:1px solid rgba(255,255,255,.08);background:transparent;color:rgba(255,255,255,.4);border-radius:13px;font-family:inherit;font-weight:600;font-size:13px;cursor:pointer;}

/* ─── END-OF-FEED DISCOVERY GRID ─── */
.eof-grid{
  height:100dvh;
  min-height:100svh;
  scroll-snap-align:start;
  scroll-snap-stop:always;
  background:linear-gradient(180deg,#090706 0%,#060504 100%);
  position:relative;
  display:flex;flex-direction:column;
  overflow:hidden;
  flex-shrink:0;
}
.eof-header{
  padding:calc(var(--st) + 58px) 14px 12px;
  flex-shrink:0;
}
.eof-badge{
  display:inline-flex;align-items:center;gap:6px;
  background:rgba(232,82,26,.15);border:1px solid rgba(232,82,26,.3);
  border-radius:20px;padding:4px 12px;
  font-size:10px;font-weight:800;color:var(--amber2);
  letter-spacing:.5px;text-transform:uppercase;margin-bottom:8px;
}
.eof-badge-dot{
  width:5px;height:5px;border-radius:50%;
  background:var(--amber2);animation:vid-blink 1.4s ease infinite;
}
.eof-title{
  font-family:'Syne',sans-serif;font-weight:900;
  font-size:18px;letter-spacing:-.3px;color:#fff;
  margin-bottom:3px;
}
.eof-sub{font-size:12px;color:rgba(255,255,255,.38);}

/* Scrollable grid inside eof */
.eof-scroll{
  flex:1;overflow-y:auto;overflow-x:hidden;
  padding:4px 10px calc(20px + var(--sb));
  -webkit-overflow-scrolling:touch;
  scrollbar-width:none;
}
.eof-scroll::-webkit-scrollbar{display:none;}

.eof-cards{
  display:grid;grid-template-columns:1fr 1fr;
  gap:9px;
}

/* Individual product card in grid */
.eof-card{
  border-radius:16px;overflow:hidden;
  background:#141414;border:1px solid rgba(255,255,255,.07);
  position:relative;cursor:pointer;
  transition:transform .15s;
  -webkit-tap-highlight-color:transparent;
}
.eof-card:active{transform:scale(.97);}

.eof-card-media{
  position:relative;width:100%;aspect-ratio:3/4;overflow:hidden;
}
.eof-card-img{
  width:100%;height:100%;object-fit:cover;
  object-position:center 30%;
  transition:transform .4s ease;background:#0a0a0a;
}
.eof-card:active .eof-card-img{transform:scale(1.04);}

/* Play overlay on cards with video */
.eof-card-play{
  position:absolute;inset:0;
  display:flex;align-items:center;justify-content:center;
  background:rgba(0,0,0,.22);
}
.eof-play-ring{
  width:36px;height:36px;border-radius:50%;
  background:rgba(255,255,255,.18);backdrop-filter:blur(6px);
  border:1.5px solid rgba(255,255,255,.3);
  display:flex;align-items:center;justify-content:center;
  font-size:13px;padding-left:2px;
}

/* Bottom of card */
.eof-card-body{
  padding:9px 10px 10px;
}
.eof-card-name{
  font-family:'Syne',sans-serif;font-weight:800;
  font-size:12px;color:#fff;line-height:1.25;
  margin-bottom:5px;
  display:-webkit-box;-webkit-line-clamp:2;
  -webkit-box-orient:vertical;overflow:hidden;
}
.eof-card-row{
  display:flex;align-items:center;justify-content:space-between;gap:4px;
}
.eof-card-price{
  font-family:'Syne',sans-serif;font-weight:900;
  font-size:13px;color:var(--amber);flex-shrink:0;
}
.eof-card-btn{
  padding:5px 9px;border-radius:8px;
  background:linear-gradient(135deg,var(--amber),var(--amber2));
  font-size:10px;font-weight:800;color:#fff;
  white-space:nowrap;border:none;cursor:pointer;
  box-shadow:0 2px 8px rgba(232,82,26,.3);
  transition:transform .13s;
}
.eof-card-btn:active{transform:scale(.94);}

/* Category chip on eof cards */
.eof-card-chip{
  position:absolute;top:8px;left:8px;z-index:2;
  font-size:9px;font-weight:800;padding:3px 8px;
  border-radius:10px;backdrop-filter:blur(6px);
  letter-spacing:.3px;
}
.ecc-shop  {background:rgba(72,149,239,.35);color:#93c5fd;}
.ecc-food  {background:rgba(232,82,26,.35);color:#fca5a5;}
.ecc-homes {background:rgba(82,183,136,.35);color:#86efac;}

/* "Keep Scrolling" divider */
.eof-more{
  display:flex;align-items:center;gap:10px;
  padding:14px 10px 6px;
}
.eof-more-line{flex:1;height:1px;background:rgba(255,255,255,.07);}
.eof-more-txt{
  font-size:10px;font-weight:700;
  color:rgba(255,255,255,.25);letter-spacing:.8px;text-transform:uppercase;
  white-space:nowrap;
}

/* Bounce arrow in eof-grid */
.eof-down-hint{
  position:absolute;bottom:calc(16px + var(--sb));left:50%;
  transform:translateX(-50%);
  display:flex;flex-direction:column;align-items:center;gap:4px;
  pointer-events:none;opacity:.4;
}
.eof-down-txt{font-size:9px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#fff;}
.eof-arr{font-size:18px;animation:bob .9s ease infinite;}

/* ─── PRICE BADGE on main slides ─── */
.s-price-badge{
  display:inline-flex;align-items:center;
  background:rgba(232,82,26,.18);
  border:1px solid rgba(232,82,26,.35);
  border-radius:10px;padding:3px 8px;
  font-size:10px;font-weight:800;color:var(--amber2);
  margin-bottom:6px;
}

/* ─── DESCRIPTION (collapsed) ─── */
.s-desc{
  font-size:12px;color:rgba(255,255,255,.5);
  line-height:1.5;margin-bottom:8px;
  display:-webkit-box;-webkit-line-clamp:2;
  -webkit-box-orient:vertical;overflow:hidden;
  transition:all .3s;
}
.s-desc.open{-webkit-line-clamp:unset;}

/* ─── SOCIAL PROOF MICRO-BADGE ─── */
.s-views{
  display:inline-flex;align-items:center;gap:4px;
  font-size:10px;font-weight:600;
  color:rgba(255,255,255,.35);margin-bottom:8px;
}

/* ── TOAST ── */
.toast{
  position:fixed;top:calc(66px + var(--st));left:50%;
  transform:translateX(-50%) translateY(-8px);
  background:rgba(255,255,255,.96);color:#0a0a0a;
  padding:8px 16px;border-radius:18px;
  font-size:12px;font-weight:700;z-index:999;
  opacity:0;pointer-events:none;transition:all .22s;white-space:nowrap;
  box-shadow:0 6px 22px rgba(0,0,0,.5);
}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}

</style>
</head>
<body>

<!-- TOP BAR -->
<div class="top-bar">
  <a href="index.php" class="tb-back">&#x2190;</a>
  <div class="tb-cats" id="tbCats">
    <div class="tb-cat-side left" id="catLeft"></div>
    <div class="tb-cat-pill" id="catPill">&#x2728; For You</div>
    <div class="tb-cat-side right" id="catRight"></div>
  </div>
  <button class="tb-icon" id="muteBtn" onclick="toggleMute()" title="Toggle sound">&#x1F507;</button>
  <button class="tb-icon" onclick="openSearch()" title="Search">&#x1F50D;</button>
</div>

<!-- CAT SWIPE FLASH -->
<div class="cat-flash" id="catFlash"></div>

<!-- CINEMA HINT -->
<div class="cinema-hint" id="cinemaHint">Hold to clear screen</div>

<!-- FEED CONTAINER -->
<div id="catWrap">
  <!-- panes injected by JS: mix, items, food, houses -->
</div>

<!-- SWIPE HINT -->
<div class="swipe-hint" id="swipeHint">
  <div class="sh-arr">&#x2191;</div>
  <div class="sh-lbl">Slide up</div>
</div>

<!-- BOTTOM NAV -->
<!-- <nav class="bnav">
  <a href="index.php"         class="bni"><span class="bni-i">&#x1F3E1;</span>Home</a>
  <a href="shop_listing.php"  class="bni"><span class="bni-i">&#x1F6D2;</span>Shop</a>
  <a href="video_feed.php"    class="bni on"><span class="bni-i">&#x25B6;</span>Watch</a>
  <a href="food_listing.php"  class="bni"><span class="bni-i">&#x1F354;</span>Food</a>
  <a href="track_order.php"   class="bni"><span class="bni-i">&#x1F4E6;</span>Track</a>
</nav> -->

<!-- SEARCH OVERLAY -->
<div class="srch-overlay" id="srchOverlay">
  <div class="srch-bar">
    <div class="srch-wrap">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
      <input class="srch-input" id="srchInput" type="search" placeholder="Search items, food, houses..."
             autocomplete="off" autocorrect="off" spellcheck="false">
      <button class="srch-clear" id="srchClear" onclick="clearSearch()">&#x2715;</button>
    </div>
    <button class="srch-cancel" onclick="closeSearch()">Cancel</button>
  </div>
  <div class="srch-filters">
    <button class="sf-tab on" data-cat="" onclick="setSrchCat('',this)">All</button>
    <button class="sf-tab" data-cat="items"  onclick="setSrchCat('items',this)">&#x1F6CB; Shop</button>

    <button class="sf-tab" data-cat="houses" onclick="setSrchCat('houses',this)">&#x1F3E0; Houses</button>
  </div>
  <div class="srch-results" id="srchResults">
    <div class="sr-sec">Recent searches</div>
    <div class="srch-recent-wrap" id="recentWrap"></div>
  </div>
</div>

<!-- BACKDROP -->
<div class="bdrop" id="bdrop" onclick="closeSheets()"></div>

<!-- LIPA MDOGO MDOGO SHEET -->
<div class="sheet" id="lipaSheet">
  <div class="sh-grip"><div class="sh-bar"></div><button class="sh-x" onclick="closeSheets()">&#x2715;</button></div>
  <div id="lipaProductArea"></div>

  <!-- Step Indicator -->
  <div class="lipa-steps">
    <div class="lstep">
      <div class="lstep-dot active" id="lsd1">1</div>
      <div class="lstep-lbl active" id="lsl1">Frequency</div>
    </div>
    <div class="lstep-line" id="lsline1"></div>
    <div class="lstep">
      <div class="lstep-dot" id="lsd2">2</div>
      <div class="lstep-lbl" id="lsl2">Duration</div>
    </div>
    <div class="lstep-line" id="lsline2"></div>
    <div class="lstep">
      <div class="lstep-dot" id="lsd3">3</div>
      <div class="lstep-lbl" id="lsl3">Details</div>
    </div>
  </div>

  <!-- Step 1: Choose frequency -->
  <div class="lipa-panel active" id="lipaStep1">
    <div class="lipa-freq-title">How often can you pay?</div>
    <div class="lipa-freq-sub">Choose the payment frequency that works best for you. No interest for daily payments!</div>
    <div class="lipa-freqs" id="lipaFreqs"></div>
    <div class="lipa-nav">
      <button class="lipa-next-btn" onclick="lipaNext(1)">Next: Choose Duration &#x2192;</button>
    </div>
  </div>

  <!-- Step 2: Choose duration -->
  <div class="lipa-panel" id="lipaStep2">
    <div class="lipa-dur-title">How long to pay?</div>
    <div class="lipa-dur-sub">Longer plans mean smaller payments but a slightly higher total.</div>
    <div class="lipa-durations" id="lipaDurations"></div>
    <div class="lipa-summary-box" id="lipaSummaryBox" style="display:none;"></div>
    <div class="lipa-nav">
      <button class="lipa-back-btn" onclick="lipaPrev(2)">&#x2190; Back</button>
      <button class="lipa-next-btn" onclick="lipaNext(2)">Next: Your Details &#x2192;</button>
    </div>
  </div>

  <!-- Step 3: Details -->
  <div class="lipa-panel" id="lipaStep3">
    <div class="lipa-freq-title">Your Details</div>
    <div class="lipa-rule">
      <strong>&#x1F512; Pay first, receive later.</strong> Your first payment secures the order. The product is delivered only after full payment is confirmed.
    </div>
    <div class="sh-field"><label>Full Name *</label><input type="text" id="l_name" placeholder="Your full name" autocomplete="name"></div>
    <div class="sh-field"><label>Phone Number *</label><input type="tel" id="l_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>
    <div class="sh-field"><label>Delivery Address *</label><input type="text" id="l_addr" placeholder="e.g. Near Malaba Market"></div>
    <div class="sh-pay">
      <div class="sh-po sel" id="lpo_mpesa" onclick="selLipaPay('mpesa',this)"><div class="sh-po-i">&#x1F4F1;</div><div class="sh-po-l">M-Pesa</div></div>
      <div class="sh-po" id="lpo_cash" onclick="selLipaPay('cash',this)"><div class="sh-po-i">&#x1F4B5;</div><div class="sh-po-l">Cash</div></div>
    </div>
    <div class="lipa-nav">
      <button class="lipa-back-btn" onclick="lipaPrev(3)">&#x2190; Back</button>
      <button class="lipa-next-btn" id="lipaSubmitBtn" onclick="submitLipa()">&#x1F4B0; Submit Plan Request</button>
    </div>
  </div>

  <!-- Success -->
  <div class="sw" id="lipaSuccess">
    <div class="sw-icon">&#x1F389;</div>
    <div class="sw-title">Request Received!</div>
    <div class="sw-sub" id="lipaSucSub">We will contact you shortly on WhatsApp to confirm your payment schedule.</div>
    <div class="sw-ref" id="lipaSucRef"></div>
    <button class="sw-wa" id="lipaWaBtn">&#x1F4AC; Confirm on WhatsApp</button>
    <button class="sw-close" onclick="closeSheets()">Keep Watching</button>
  </div>
</div>

<!-- ORDER SHEET -->
<div class="sheet" id="orderSheet">
  <div class="sh-grip"><div class="sh-bar"></div><button class="sh-x" onclick="closeSheets()">&#x2715;</button></div>
  <div id="orderProductArea"></div>
  <div id="orderBody">
    <div class="os-head"><div class="os-htitle">&#x1F6D2; Order Now</div><div class="os-hsub">Fill in your details below</div></div>
    <div class="sh-field"><label>Full Name *</label><input type="text" id="o_name" placeholder="Your full name" autocomplete="name"></div>
    <div class="sh-field"><label>Phone *</label><input type="tel" id="o_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>
    <div class="sh-field"><label>Delivery Address *</label><input type="text" id="o_addr" placeholder="e.g. Near Malaba Market"></div>
    <div class="sh-pay os-pay">
      <div class="sh-po sel" id="opo_cash"  onclick="selOrderPay('cash',this)"><div class="sh-po-i">&#x1F4B5;</div><div class="sh-po-l">Cash</div></div>
      <div class="sh-po"     id="opo_mpesa" onclick="selOrderPay('mpesa',this)"><div class="sh-po-i">&#x1F4F1;</div><div class="sh-po-l">M-Pesa</div></div>
    </div>
    <button class="os-submit" id="orderSubmitBtn" onclick="submitOrder()">&#x1F6D2; Place Order</button>
  </div>
  <div class="sw" id="orderSuccess">
    <div class="sw-icon">&#x2705;</div>
    <div class="sw-title">Order Placed!</div>
    <div class="sw-sub" id="ordSucSub">Your order has been received. We will contact you shortly.</div>
    <div class="sw-ref" id="ordSucRef"></div>
    <button class="sw-wa" id="ordWaBtn">&#x1F4AC; Confirm on WhatsApp</button>
    <button class="sw-close" onclick="closeSheets()">Keep Watching</button>
  </div>
</div>

<!-- HOUSE ENQUIRY SHEET -->
<div class="sheet" id="houseSheet">
  <div class="sh-grip"><div class="sh-bar"></div><button class="sh-x" onclick="closeSheets()">&#x2715;</button></div>
  <div id="houseProductArea"></div>
  <div>
    <div class="hs-head"><div class="hs-title">&#x1F3E0; Enquire About This House</div><div class="hs-sub">WhatsApp the landlord directly. No upfront payment — just start a conversation.</div></div>
    <div class="sh-field"><label>Your Name</label><input type="text" id="h_name" placeholder="Your full name" autocomplete="name"></div>
    <div class="sh-field"><label>Your Phone</label><input type="tel" id="h_phone" placeholder="0712 345 678" inputmode="tel" autocomplete="tel"></div>
    <button class="hs-wa" id="houseWaBtn" onclick="sendHouseEnquiry()">&#x1F4AC; WhatsApp Landlord</button>
  </div>
</div>

<div class="toast" id="toast"></div>

<script src="mh_user.js" onerror="window.MhUser=null"></script>
<script src="image-performance-helper.js"></script>
<script>
/* ════════════════════════════════════════════════════════════
   CONFIG
════════════════════════════════════════════════════════════ */
var API     = <?php echo json_encode($apiBase); ?>;
var INITID  = <?php echo json_encode($initId); ?>;
var INITCAT = <?php echo json_encode($initCat); ?>;

/* ════════════════════════════════════════════════════════════
   CATEGORY SYSTEM
════════════════════════════════════════════════════════════ */
var CAT_ORDER  = ['mix','items','houses'];
var CAT_LABELS = {mix:'✨ For You', items:'🪑 Shop', houses:'🏠 Houses'};
var catIdx     = 0; // current index in CAT_ORDER
var currentCat = 'mix';
var isAnimating= false;

/* Per-category state */
var catState = {};
CAT_ORDER.forEach(function(c){
  catState[c] = {items:[], page:1, loading:false, done:false, built:false, currentIdx:0, observer:null, progTimers:{}};
});

var mutedGlobal  = true;
var currentItem  = null;

/* Lipa state */
var lipaFreq     = null;  // selected frequency option
var lipaDur      = null;  // selected duration
var lipaPay      = 'mpesa';
var lipaFreqOpts = [];    // computed from price
var lipaDurOpts  = [];
var lipaStep     = 1;

var orderPay     = 'cash';

/* Search state */
var srchCat      = '';
var srchTimer    = null;
var recentSearches = [];
try { recentSearches = JSON.parse(localStorage.getItem('mh_srch')||'[]'); } catch(e){}

/* ════════════════════════════════════════════════════════════
   LIPA PLAN CALCULATOR  — flexible frequencies
════════════════════════════════════════════════════════════ */
function calcFrequencies(rawPrice) {
    if (!rawPrice || rawPrice < 200) return [];
    var ksh = function(n){ return 'KSH ' + Math.round(n).toLocaleString('en-KE'); };
    return [
        { id:'daily',  label:'Daily',        times:1,   per:'day',
          desc:'Best deal — no extra charge',
          factor:1.0, perPayment: function(total, weeks){ return total / (weeks*7); } },
        { id:'3week',  label:'3× per week',  times:3,   per:'week',
          desc:'Slightly more flexible — 2% extra',
          factor:1.02, perPayment: function(total, weeks){ return total / (weeks*3); } },
        { id:'2week',  label:'Twice a week', times:2,   per:'week',
          desc:'Comfortable pace — 4% extra',
          factor:1.04, perPayment: function(total, weeks){ return total / (weeks*2); } },
        { id:'weekly', label:'Weekly',        times:1,   per:'week',
          desc:'Once a week — 7% extra',
          factor:1.07, perPayment: function(total, weeks){ return total / weeks; } },
    ];
}
function calcDurations(rawPrice, freq) {
    if (!freq) return [];
    var ksh = function(n){ return 'KSH ' + Math.round(n).toLocaleString('en-KE'); };
    var factor = freq.factor || 1;
    var total  = rawPrice * factor;
    return [
        { weeks:2,  label:'2 weeks',  deposit: rawPrice*.25, total: total },
        { weeks:4,  label:'4 weeks',  deposit: rawPrice*.2,  total: total },
        { weeks:8,  label:'8 weeks',  deposit: rawPrice*.15, total: total * 1.03 },
        { weeks:12, label:'12 weeks', deposit: rawPrice*.1,  total: total * 1.06 },
    ].map(function(d){
        var perPayment = freq.perPayment(d.total, d.weeks);
        return Object.assign(d, {
            perPaymentStr: ksh(perPayment),
            totalStr: ksh(d.total),
            depositStr: ksh(d.deposit),
            perPayment: perPayment,
        });
    });
}

/* ════════════════════════════════════════════════════════════
   INIT
════════════════════════════════════════════════════════════ */
window.addEventListener('load', function() {
    catIdx     = CAT_ORDER.indexOf(INITCAT) > -1 ? CAT_ORDER.indexOf(INITCAT) : 0;
    currentCat = CAT_ORDER[catIdx];
    buildCatPanes();
    updateCatUI();
    loadAndBuild(currentCat, function() {
        if (INITID) jumpToId(currentCat, INITID);
    });
    prefillSaved();
    initCatSwipe();
    setTimeout(function(){ var h=document.getElementById('swipeHint'); if(h) h.style.display='none'; }, 4000);
    renderRecent();
});

/* ════════════════════════════════════════════════════════════
   CAT PANES
════════════════════════════════════════════════════════════ */
function buildCatPanes() {
    var wrap = document.getElementById('catWrap');
    wrap.innerHTML = '';
    CAT_ORDER.forEach(function(cat) {
        var pane = document.createElement('div');
        pane.className = 'cat-pane';
        pane.id = 'pane-'+cat;
        pane.innerHTML = '<div class="feed" id="feed-'+cat+'"><div class="skel"><div class="sk-ring"></div></div></div>';
        wrap.appendChild(pane);
    });
    positionPanes(catIdx, false);
}

function positionPanes(toIdx, animate) {
    CAT_ORDER.forEach(function(cat, i) {
        var pane = document.getElementById('pane-'+cat);
        if (!pane) return;
        var offset = (i - toIdx) * 100;
        pane.style.transition = animate ? 'transform .38s cubic-bezier(.25,.46,.45,.94)' : 'none';
        pane.style.transform  = 'translateX(' + offset + '%)';
        pane.style.position   = 'absolute';
        pane.style.top = '0'; pane.style.left = '0';
        pane.style.width = '100%'; pane.style.height = '100dvh';
    });
}

function updateCatUI() {
    var pill  = document.getElementById('catPill');
    var lEl   = document.getElementById('catLeft');
    var rEl   = document.getElementById('catRight');
    var label = CAT_LABELS[CAT_ORDER[catIdx]] || '';
    pill.textContent = label;
    lEl.textContent  = catIdx > 0 ? '‹ ' + CAT_LABELS[CAT_ORDER[catIdx-1]] : '';
    rEl.textContent  = catIdx < CAT_ORDER.length-1 ? CAT_LABELS[CAT_ORDER[catIdx+1]] + ' ›' : '';
}

/* ════════════════════════════════════════════════════════════
   HORIZONTAL SWIPE TO SWITCH CATEGORY
════════════════════════════════════════════════════════════ */
function initCatSwipe() {
    var wrap   = document.getElementById('catWrap');
    var startX = 0, startY = 0, startTime = 0;
    var locked = false; // locked to vertical scroll

    wrap.addEventListener('touchstart', function(e) {
        var t   = e.touches[0];
        startX  = t.clientX;
        startY  = t.clientY;
        startTime = Date.now();
        locked  = false;
    }, {passive:true});

    wrap.addEventListener('touchmove', function(e) {
        if (locked) return;
        var t  = e.touches[0];
        var dx = t.clientX - startX;
        var dy = t.clientY - startY;
        // If moving more vertically, lock out horizontal
        if (Math.abs(dy) > Math.abs(dx) * 1.5) { locked = true; return; }
        // Resist horizontal on sheets (don't swipe cats when sheet open)
        if (document.querySelector('.sheet.open')) { locked = true; return; }
    }, {passive:true});

    wrap.addEventListener('touchend', function(e) {
        if (locked || isAnimating) return;
        // Don't trigger if a sheet is open
        if (document.querySelector('.sheet.open')) return;
        var t   = e.changedTouches[0];
        var dx  = t.clientX - startX;
        var dy  = t.clientY - startY;
        var dt  = Date.now() - startTime;
        // Require: fast (<450ms), mostly horizontal, significant distance
        if (dt > 450) return;
        if (Math.abs(dx) < 55) return;
        if (Math.abs(dy) > Math.abs(dx) * 0.6) return;

        if (dx < 0 && catIdx < CAT_ORDER.length - 1) {
            // Swipe left → next category
            switchCat(catIdx + 1);
        } else if (dx > 0 && catIdx > 0) {
            // Swipe right → previous category
            switchCat(catIdx - 1);
        }
    }, {passive:true});
}

function switchCat(newIdx) {
    if (newIdx === catIdx || isAnimating) return;
    isAnimating = true;

    // Pause current video
    var oldCat = CAT_ORDER[catIdx];
    var oldFeed = document.getElementById('feed-'+oldCat);
    if (oldFeed) {
        var vid = oldFeed.querySelector('.slide.active video');
        if (vid) { vid.pause(); }
    }

    catIdx     = newIdx;
    currentCat = CAT_ORDER[catIdx];
    positionPanes(catIdx, true);
    updateCatUI();
    flashCat();

    setTimeout(function(){ isAnimating = false; }, 420);

    // Load if not yet loaded
    if (!catState[currentCat].built) {
        loadAndBuild(currentCat, function(){});
    } else {
        // Resume video in new active slide
        var st  = catState[currentCat];
        var newFeed = document.getElementById('feed-'+currentCat);
        if (newFeed) {
            var slide = newFeed.querySelector('.slide.active');
            if (slide) {
                var v = slide.querySelector('video');
                if (v) { v.muted = mutedGlobal; v.play().catch(function(){}); }
            }
        }
    }
}

function flashCat() {
    var el  = document.getElementById('catFlash');
    var dir = catIdx > 0 ? 'right' : 'left'; // which side the pill came from
    el.textContent = CAT_LABELS[currentCat];
    el.style.left  = '50%';
    el.style.transform = 'translateX(-50%) translateY(-50%)';
    el.classList.add('show');
    setTimeout(function(){ el.classList.remove('show'); }, 900);
}

/* ════════════════════════════════════════════════════════════
   LOAD ITEMS
════════════════════════════════════════════════════════════ */
function loadAndBuild(cat, cb) {
    var st = catState[cat];
    if (st.loading) { if(cb) cb(); return; }
    st.loading = true;

var cats = (cat === 'mix') ? ['items','houses'] : [cat];
    var done = 0; var batch = [];

    cats.forEach(function(c) {
        xhr('GET', API+'/listings.php?type='+c+'&limit=20&page='+st.page+'&sort=smart', null, function(d) {
            done++;
            if (d && d.success && d.data) {
                batch = batch.concat(d.data);
                if (d.data.length < 20) st.done = true;
            } else { st.done = true; }
            if (done === cats.length) finish();
        }, function() {
            done++;
            batch = batch.concat(getFallback(c));
            st.done = true;
            if (done === cats.length) finish();
        });
    });

    function finish() {
        st.loading = false;
        var mixed = (cat==='mix') ? smartMix(batch) : smartSort(batch);
        if (!mixed.length) mixed = getFallback(cat);
        st.items = mixed;
        st.built = true;
        buildFeed(cat);
        if (cb) cb();
    }
}

function loadMore(cat) {
    var st = catState[cat];
    if (st.loading) return;
    st.page++;
    if (st.done || st.page > 8) {
        // Recycle with new random scores — user never runs out
        recycleItems(cat);
        return;
    }
    st.loading = true;
var cats = (cat==='mix') ? ['items','houses'] : [cat];
    var done = 0; var batch = [];
    cats.forEach(function(c) {
        xhr('GET', API+'/listings.php?type='+c+'&limit=20&page='+st.page+'&sort=popular', null, function(d) {
            done++;
            if (d && d.success && d.data && d.data.length) {
                batch = batch.concat(d.data);
                if (d.data.length < 20) st.done = true;
            } else { st.done = true; }
            if (done === cats.length) appendItems(cat, batch);
        }, function() {
            done++; st.done = true;
            if (done === cats.length) { st.loading=false; recycleItems(cat); }
        });
    });
}

function appendItems(cat, batch) {
    var st   = catState[cat];
    st.loading = false;
    if (!batch.length) { recycleItems(cat); return; }
    var mixed  = (cat==='mix') ? smartMix(batch) : smartSort(batch);
    var feed   = document.getElementById('feed-'+cat);
    // Remove old sentinel/EOF grid before adding slides
    var sentinel = document.getElementById('sentinel-'+cat);
    if (sentinel) sentinel.remove();
    var offset = st.items.length;
    mixed.forEach(function(item) {
        st.items.push(item);
        var slide = makeSlide(cat, item, offset++);
        if (feed) feed.appendChild(slide);
        if (st.observer) st.observer.observe(slide);
    });
    // Re-append fresh EOF grid
    appendSentinel(cat);
}

function recycleItems(cat) {
    var st   = catState[cat];
    if (!st.items.length) return;
    var pool = st.items.slice().sort(function(){ return Math.random()-.5; });
    var feed = document.getElementById('feed-'+cat);
    var s    = document.getElementById('sentinel-'+cat);
    var offset = st.items.length;
    pool.forEach(function(item) {
        var clone = Object.assign({}, item);
        st.items.push(clone);
        var slide = makeSlide(cat, clone, offset++);
        if (feed && s) feed.insertBefore(slide, s);
        else if (feed) feed.appendChild(slide);
        if (st.observer) st.observer.observe(slide);
    });
}

/* ════════════════════════════════════════════════════════════
   SMART ALGORITHM
════════════════════════════════════════════════════════════ */
function score(item) {
    var s = (parseInt(item.views)||0) * 0.3;
    s += item.is_featured==1 ? 45 : 0;
    s += (item.has_video||item.video_url) ? 38 : 0;
    s += item.is_premium==1 ? 22 : 0;
    s += Math.random() * 20;
    return s;
}
function smartMix(all) {
    var buckets = {items:[],food:[],houses:[]};
    all.forEach(function(i){ var t=i.type||'items'; if(buckets[t]) buckets[t].push(Object.assign({},i,{_s:score(i)})); });
    Object.keys(buckets).forEach(function(k){ buckets[k].sort(function(a,b){return b._s-a._s;}); });
    // 40% shop, 35% food, 25% homes
    var seq=['items','items','food','food','items','food','houses'], out=[], si=0, fi=0, hi=0;
    var maxIter=all.length*seq.length;
    for (var i=0; out.length<all.length && i<maxIter; i++) {
        var k=seq[i%seq.length], idx;
        if(k==='items') idx=si++; else if(k==='food') idx=fi++; else idx=hi++;
        if(buckets[k][idx]) out.push(buckets[k][idx]);
    }
    return out.map(function(i){ delete i._s; return i; });
}
function smartSort(all) {
    return all.slice().sort(function(a,b){return score(b)-score(a);});
}

/* ════════════════════════════════════════════════════════════
   BUILD FEED DOM
════════════════════════════════════════════════════════════ */
function buildFeed(cat) {
    var st   = catState[cat];
    var feed = document.getElementById('feed-'+cat);
    if (!feed) return;
    if (st.observer) { st.observer.disconnect(); st.observer = null; }
    Object.keys(st.progTimers).forEach(function(k){ clearInterval(st.progTimers[k]); delete st.progTimers[k]; });
    feed.innerHTML = '';
    st.currentIdx = 0;
    if (!st.items.length) {
        feed.innerHTML = '<div class="skel"><div style="color:rgba(255,255,255,.3);font-size:14px;">No items yet</div></div>';
        return;
    }
    st.items.forEach(function(item, i){ feed.appendChild(makeSlide(cat, item, i)); });
    appendSentinel(cat);
    activateSlide(cat, 0);
    initObserver(cat);
}

function appendSentinel(cat) {
    var feed = document.getElementById('feed-'+cat);
    var old  = document.getElementById('sentinel-'+cat);
    if (old) old.remove();
    var st = catState[cat];
    var s;
    if (st.items.length >= 4) {
        s = makeEofSlide(cat);      // full discovery grid (has id="sentinel-{cat}" inside)
    } else {
        s = document.createElement('div');
        s.className = 'skel';
        s.id = 'sentinel-'+cat;
        s.innerHTML = '<div class="sk-ring"></div>';
    }
    if (feed) feed.appendChild(s);
    if (st.observer) st.observer.observe(s);
}

/* ════════════════════════════════════════════════════════════
   MAKE SLIDE — video-first, multi-image carousel
════════════════════════════════════════════════════════════ */
function makeSlide(cat, item, idx) {
    var el    = document.createElement('div');
    el.className = 'slide';
    el.dataset.idx  = idx;
    el.dataset.id   = item.id || '';
    el.dataset.cat  = cat;

    /* ── Gather media ── */
    var vid    = item.video_url || '';
    var hasVid = !!vid;

    // Collect ALL images — works for every category (shop, food, homes)
    // Supports: images[] array, gallery[] array, photos[] array,
    //           image_1/image_2/image_3, image2/image3, additional_images,
    //           extra_images, image_url, image, photo, thumbnail
    //           AND JSON-encoded strings from the database
    var imgs = [];
    var seen = {};

    function addImg(src) {
        src = (src || '').trim();
        if (src && !seen[src]) { seen[src] = 1; imgs.push(src); }
    }

    // Helper: normalise a value that might be a JSON string, array, or plain string
    function extractImgs(val) {
        if (!val) return;
        if (Array.isArray(val)) {
            val.forEach(function(im) {
                addImg(typeof im === 'string' ? im : (im.url || im.src || im.image || ''));
            });
            return;
        }
        if (typeof val === 'string') {
            var t = val.trim();
            // Try to parse JSON strings like "[\"a.jpg\",\"b.jpg\"]"
            if (t.charAt(0) === '[' || t.charAt(0) === '{') {
                try {
                    var parsed = JSON.parse(t);
                    if (Array.isArray(parsed)) {
                        parsed.forEach(function(im) {
                            addImg(typeof im === 'string' ? im : (im.url || im.src || im.image || ''));
                        });
                        return;
                    }
                    if (parsed && typeof parsed === 'object') {
                        Object.values(parsed).forEach(function(v){ if(typeof v==='string') addImg(v); });
                        return;
                    }
                } catch(e) {}
            }
            // Plain URL string
            addImg(t);
        }
    }

    // 1. images field (array OR JSON-encoded string) — used by all categories
    extractImgs(item.images);
    // 2. gallery field
    extractImgs(item.gallery);
    // 3. photos field (common in homes listings)
    extractImgs(item.photos);
    // 4. additional_images / extra_images (common in food/homes APIs)
    extractImgs(item.additional_images);
    extractImgs(item.extra_images);
    // 5. Numbered fields: image_1…image_8 AND image2…image8
    for (var n = 1; n <= 8; n++) {
        addImg(item['image_' + n] || item['photo_' + n] || item['img_' + n] || '');
        addImg(item['image' + n]  || item['photo' + n]  || '');
    }
    // 6. Primary / fallback fields — always included (deduplication prevents repeats)
    addImg(item.image_url);
    addImg(item.image);
    addImg(item.photo);
    addImg(item.thumbnail);

    var firstImg  = imgs[0] || '';
    var multiImg  = !hasVid && imgs.length > 1;
    var singleImg = !hasVid && imgs.length <= 1;

    var itype  = item.type || cat || 'items';
    if (itype === 'mix') itype = 'items';
    var cls    = itype==='items'?'cp-shop':itype==='food'?'cp-food':'cp-homes';
    var lbl    = itype==='items'?'&#x1F6CB; Shop':itype==='food'?'&#x1F354; Food':'&#x1F3E0; Houses';
    var price  = item.price || '';
    var phone  = (item.contact&&item.contact.phone)?item.contact.phone:(item.contact_phone||'');
    var waNum  = normWA(phone);
    var isHouse= (itype==='houses');
    var isFood = (itype==='food');
    var isShop = (itype==='items');
    var hasLipa= isShop && parseFloat(String(price).replace(/[^0-9.]/g,'')) >= 200;

    if (singleImg) el.classList.add('img-only');

    /* ── Build media HTML ── */
    var mediaHTML = '';
    var badgeHTML = '';

    if (hasVid) {
        // VIDEO is the hero — poster is first image
        mediaHTML =
            '<video class="s-video" id="vid-'+cat+'-'+idx+'"' +
            ' src="'+esc(vid)+'" loop muted playsinline preload="none"' +
            ' poster="'+esc(firstImg)+'"' +
            ' controlsList="nodownload nofullscreen noremoteplayback"' +
            ' disablePictureInPicture oncontextmenu="return false;"></video>' +
            // Fallback image behind the video (shows while loading)
            (firstImg ? '<img class="s-img" src="'+esc(firstImg)+'" loading="lazy" alt="" style="z-index:-1;transform:none;">' : '');
        badgeHTML =
            '<div class="s-vid-badge" id="vbadge-'+cat+'-'+idx+'">' +
            '<div class="s-vid-dot"></div>Video' +
            '</div>';
    } else if (multiImg) {
        // MULTI-IMAGE CAROUSEL
        var slidesHTML = imgs.map(function(src, si) {
            return '<div class="s-carousel-slide">' +
                '<img class="s-carousel-img'+(si===0?' active-img':'')+'" src="'+esc(src)+'" loading="'+(si<2?'eager':'lazy')+'" alt="">' +
                '</div>';
        }).join('');
        var dotsHTML = imgs.length > 1 ? '<div class="s-carousel-dots" id="dots-'+cat+'-'+idx+'">' +
            imgs.map(function(_,si){ return '<div class="s-cdot'+(si===0?' on':'')+'" data-di="'+si+'"></div>'; }).join('') +
            '</div>' : '';
        mediaHTML =
            '<div class="s-carousel" id="car-'+cat+'-'+idx+'">' +
              '<div class="s-carousel-track" id="cart-'+cat+'-'+idx+'">' +
                slidesHTML +
              '</div>' +
            '</div>' +
            dotsHTML +
            '<button class="s-arrow s-arrow-l" id="arrl-'+cat+'-'+idx+'" onclick="carPrev(\''+cat+'\','+idx+',event)">&#x2039;</button>' +
            '<button class="s-arrow s-arrow-r" id="arrr-'+cat+'-'+idx+'" onclick="carNext(\''+cat+'\','+idx+',event)">&#x203A;</button>';
        badgeHTML =
            '<div class="s-img-count" id="imgcount-'+cat+'-'+idx+'">📷 1 / '+imgs.length+'</div>';
        el.dataset.carIdx  = 0;
        el.dataset.carTotal= imgs.length;
    } else {
        // SINGLE IMAGE fallback
        mediaHTML = firstImg
            ? '<img class="s-img" id="img-'+cat+'-'+idx+'" src="'+esc(firstImg)+'" loading="lazy" alt="" onerror="this.src=\'\'">'
            : '<div style="position:absolute;inset:0;background:linear-gradient(135deg,#1a0a00,#0a0a1a);z-index:0;"></div>';
    }

    /* ── Build action bar ── */
    var actHTML = '';
    if (isHouse) {
        actHTML =
          '<div class="sa sa-enquire" onclick="openHouseSheet(\''+cat+'\','+idx+')">' +
            '<div class="sa-icon">&#x1F3E0;</div><div class="sa-lbl">Enquire</div>' +
          '</div>' +
          '<div class="sa" onclick="shareItem(\''+esc(item.title||'')+'\',\''+esc(item.id||'')+'\',\'houses\')">' +
            '<div class="sa-icon">&#x21A9;&#xFE0F;</div><div class="sa-lbl">Share</div>' +
          '</div>' +
          '<a class="sa sa-wa" href="https://wa.me/'+waNum+'?text='+encodeURIComponent('Hi! I\'d like to enquire about "'+( item.title||''  )+'" ('+price+') on Malaba Watch & Shop.')+'" target="_blank" rel="noopener">' +
            '<div class="sa-icon">&#x1F4AC;</div><div class="sa-lbl">WhatsApp</div>' +
          '</a>';
    } else {
        actHTML =
          (hasLipa ?
          '<div class="sa sa-lipa" onclick="openLipa(\''+cat+'\','+idx+')">' +
            '<div class="sa-icon">&#x1F4B0;</div><div class="sa-lbl">Pay Later</div>' +
          '</div>' : '') +
          '<div class="sa" onclick="openOrderSheet(\''+cat+'\','+idx+')">' +
            '<div class="sa-icon">&#x1F6D2;</div><div class="sa-lbl">Order</div>' +
          '</div>' +
          '<div class="sa" onclick="shareItem(\''+esc(item.title||'')+'\',\''+esc(item.id||'')+'\',\''+itype+'\')">' +
            '<div class="sa-icon">&#x21A9;&#xFE0F;</div><div class="sa-lbl">Share</div>' +
          '</div>' +
          '<a class="sa sa-wa" href="https://wa.me/'+waNum+'?text='+encodeURIComponent('Hi! I\'d like to order "'+( item.title||''  )+'" ('+price+') from Malaba Watch & Shop.')+'" target="_blank" rel="noopener">' +
            '<div class="sa-icon">&#x1F4AC;</div><div class="sa-lbl">WhatsApp</div>' +
          '</a>';
    }

    /* ── description (tap to expand) ── */
    var desc = '';
    if (item.description) {
        desc = '<div class="s-desc" id="desc-'+cat+'-'+idx+'" onclick="toggleDesc(this)">'+esc(item.description)+'</div>';
    }

    /* ── views micro-badge ── */
    var views = parseInt(item.views) || 0;
    var viewsBadge = views > 20
        ? '<div class="s-views">👁 '+(views > 999 ? (Math.round(views/100)/10)+'k' : views)+' views</div>'
        : '';

    el.innerHTML =
        mediaHTML +
        badgeHTML +
        '<div class="slide-crossfade"></div>' +
        '<div class="s-grad"></div>' +
        '<div class="s-vign"></div>' +
        '<div class="wm">Malaba Homes</div>' +
        '<div class="prog"><div class="prog-fill" id="progf-'+cat+'-'+idx+'"></div></div>' +
        '<div class="pulse" id="pls-'+cat+'-'+idx+'">&#x23F8;</div>' +
        '<div class="s-body">' +
          '<div class="s-info">' +
            '<span class="cat-pill '+cls+'">'+lbl+'</span>' +
            '<div class="s-title">'+esc(item.title||'')+'</div>' +
            (item.location?'<div class="s-loc">&#x1F4CD; '+esc(item.location.split(',')[0])+'</div>':'') +
            desc +
            viewsBadge +
            '<div class="s-buy-row">' +
              '<div class="s-price">'+esc(price)+'</div>' +
              '<button class="btn-order" onclick="'+( isHouse ? 'openHouseSheet(\''+cat+'\','+idx+')' : 'openOrderSheet(\''+cat+'\','+idx+')' )+'">'+( isHouse ? '&#x1F3E0; Enquire' : '&#x1F6D2; Order' )+'</button>' +
            '</div>' +
          '</div>' +
          '<div class="s-actions">'+actHTML+'</div>' +
        '</div>';

    /* ── Tap to play/pause (video slides only) ── */
    el.addEventListener('click', function(e) {
        if (e.target.closest('.s-info,.s-actions,.s-arrow')) return;
        var v  = el.querySelector('video');
        var pp = document.getElementById('pls-'+cat+'-'+idx);
        if (!v) {
            // On image slide: tap opens full zoom view (future) — for now no-op
            return;
        }
        if (v.paused) { v.play().catch(function(){}); showPulse(pp,'&#x25B6;'); }
        else          { v.pause(); showPulse(pp,'&#x23F8;'); }
    });

    /* ── Horizontal swipe on multi-image carousel ── */
    if (multiImg) {
        var tx = 0, ty = 0, swX = 0, swY = 0, swLocked = false;
        var carousel = el.querySelector('.s-carousel');
        if (carousel) {
            carousel.addEventListener('touchstart', function(e) {
                if (e.target.closest('.s-actions,.s-info,.s-arrow')) return;
                swX = e.touches[0].clientX;
                swY = e.touches[0].clientY;
                swLocked = false;
            }, {passive:true});
            carousel.addEventListener('touchmove', function(e) {
                if (swLocked) return;
                var dx = e.touches[0].clientX - swX;
                var dy = e.touches[0].clientY - swY;
                if (Math.abs(dy) > Math.abs(dx) * 1.2) { swLocked = true; }
            }, {passive:true});
            carousel.addEventListener('touchend', function(e) {
                if (swLocked) return;
                var dx = e.changedTouches[0].clientX - swX;
                if (Math.abs(dx) < 40) return;
                if (dx < 0) carNext(cat, idx, e);
                else        carPrev(cat, idx, e);
            }, {passive:true});
        }
    }

    /* ── Long press = cinema mode ── */
    var longTimer  = null;
    var cinemaMode = false;
    el.addEventListener('touchstart', function(e) {
        if (e.target.closest('.s-info,.s-actions,.s-arrow')) return;
        longTimer = setTimeout(function() {
            cinemaMode = true;
            el.classList.add('cinema');
        }, 550);
    }, {passive:true});
    el.addEventListener('touchend', function() {
        clearTimeout(longTimer);
        if (cinemaMode) { cinemaMode=false; el.classList.remove('cinema'); }
    });
    el.addEventListener('touchmove', function() { clearTimeout(longTimer); }, {passive:true});
    el.addEventListener('contextmenu', function(e){ e.preventDefault(); });

    return el;
}

/* ════════════════════════════════════════════════════════════
   CAROUSEL NAVIGATION
════════════════════════════════════════════════════════════ */
function carGoTo(cat, idx, newCarIdx, e) {
    if (e) { e.stopPropagation(); e.preventDefault(); }
    var slide = document.querySelector('.slide[data-idx="'+idx+'"][data-cat="'+cat+'"]');
    if (!slide) return;
    var total = parseInt(slide.dataset.carTotal) || 1;
    newCarIdx = Math.max(0, Math.min(newCarIdx, total - 1));
    slide.dataset.carIdx = newCarIdx;

    // Move track
    var track = document.getElementById('cart-'+cat+'-'+idx);
    if (track) track.style.transform = 'translateX(-' + (newCarIdx * 100) + '%)';

    // Update active-img for ken burns
    var imgs = slide.querySelectorAll('.s-carousel-img');
    imgs.forEach(function(img, si) {
        img.classList.toggle('active-img', si === newCarIdx);
    });

    // Update dots
    var dots = slide.querySelectorAll('.s-cdot');
    dots.forEach(function(d, di) { d.classList.toggle('on', di === newCarIdx); });

    // Update count badge
    var badge = document.getElementById('imgcount-'+cat+'-'+idx);
    if (badge) badge.innerHTML = '&#x1F4F7; '+(newCarIdx+1)+' / '+total;
}
function carNext(cat, idx, e) {
    var slide = document.querySelector('.slide[data-idx="'+idx+'"][data-cat="'+cat+'"]');
    var cur   = parseInt(slide ? slide.dataset.carIdx : 0) || 0;
    carGoTo(cat, idx, cur + 1, e);
}
function carPrev(cat, idx, e) {
    var slide = document.querySelector('.slide[data-idx="'+idx+'"][data-cat="'+cat+'"]');
    var cur   = parseInt(slide ? slide.dataset.carIdx : 0) || 0;
    carGoTo(cat, idx, cur - 1, e);
}

function toggleDesc(el) {
    el.classList.toggle('open');
}

/* ════════════════════════════════════════════════════════════
   END-OF-FEED DISCOVERY GRID
   Shown instead of the plain loading spinner at end.
   Shows a 2-col grid of random items so user can pick & jump.
════════════════════════════════════════════════════════════ */
/* ════════════════════════════════════════════════════════════
   END-OF-FEED DISCOVERY GRID
   Full-screen snap slide showing a 2-col product grid.
   User taps any card to jump back to it in the feed.
   Scrolling down loads more items.
════════════════════════════════════════════════════════════ */
function makeEofSlide(cat) {
    var st   = catState[cat];
    var pool = st.items.slice();
    // Shuffle and pick up to 8 representative items
    pool.sort(function(){ return Math.random() - .5; });
    pool = pool.slice(0, 8);

    var el = document.createElement('div');
    el.className = 'eof-grid';          // full-height snap slide
    el.id = 'sentinel-' + cat;          // observer hooks here to trigger loadMore

    var cardsHTML = pool.map(function(item) {
        var itype  = item.type || cat || 'items';
        if (itype === 'mix') itype = 'items';
        var chipCls = itype === 'items' ? 'ecc-shop' : itype === 'food' ? 'ecc-food' : 'ecc-homes';
        var chipLbl = itype === 'items' ? '🛒 Shop' : itype === 'food' ? '🍔 Food' : '🏠 Homes';
        var img = '';
        // Same exhaustive lookup as makeSlide
        if (Array.isArray(item.images) && item.images.length) {
            img = typeof item.images[0] === 'string' ? item.images[0] : (item.images[0].url || item.images[0].src || '');
        }
        if (!img && Array.isArray(item.gallery) && item.gallery.length) {
            img = typeof item.gallery[0] === 'string' ? item.gallery[0] : (item.gallery[0].url || '');
        }
        if (!img) img = item.image_1 || item.photo_1 || '';
        if (!img) img = item.image_url || item.image || item.photo || item.thumbnail || '';
        var vid    = item.video_url || '';
        var price  = item.price || '';
        var safeId = esc(item.id || '');
        var safeTtl= esc(item.title || '');

        // Media element: video thumbnail if video exists, else image
        var mediaEl = vid
            ? '<img class="eof-card-img" src="' + esc(img) + '" loading="lazy" alt="" onerror="this.style.opacity=\'0\'">' +
              '<div class="eof-card-play"><div class="eof-play-ring">▶</div></div>'
            : '<img class="eof-card-img" src="' + esc(img) + '" loading="lazy" alt="" onerror="this.style.opacity=\'0\'">';

        return '<div class="eof-card" onclick="jumpToItemInFeed(\'' + cat + '\',\'' + safeId + '\')">' +
            '<div class="eof-card-media">' + mediaEl + '</div>' +
            '<div class="eof-card-chip ' + chipCls + '">' + chipLbl + '</div>' +
            '<div class="eof-card-body">' +
              '<div class="eof-card-name">' + safeTtl + '</div>' +
              '<div class="eof-card-row">' +
                '<div class="eof-card-price">' + esc(price) + '</div>' +
                '<button class="eof-card-btn" onclick="event.stopPropagation();jumpToItemInFeed(\'' + cat + '\',\'' + safeId + '\')">View</button>' +
              '</div>' +
            '</div>' +
          '</div>';
    }).join('');

    el.innerHTML =
        '<div class="eof-header">' +
          '<div class="eof-badge"><div class="eof-badge-dot"></div>You\'ve caught up</div>' +
          '<div class="eof-title">Pick something you love ✨</div>' +
          '<div class="eof-sub">Tap any item to view it · Scroll down to see more</div>' +
        '</div>' +
        '<div class="eof-scroll">' +
          '<div class="eof-cards">' + cardsHTML + '</div>' +
          '<div class="eof-more">' +
            '<div class="eof-more-line"></div>' +
            '<div class="eof-more-txt">More below</div>' +
            '<div class="eof-more-line"></div>' +
          '</div>' +
        '</div>' +
        '<div class="eof-down-hint">' +
          '<div class="eof-down-txt">Scroll</div>' +
          '<div class="eof-arr">↓</div>' +
        '</div>';

    return el;
}

function eofContinue(cat) {
    loadMore(cat);
    var eof = document.getElementById('sentinel-'+cat);
    if (eof && eof.nextElementSibling) {
        eof.nextElementSibling.scrollIntoView({behavior:'smooth'});
    }
}

function jumpToItemInFeed(cat, id) {
    // Find slide with this id and snap to it
    var feed = document.getElementById('feed-'+cat);
    if (!feed) return;
    var slides = feed.querySelectorAll('.slide');
    for (var i = 0; i < slides.length; i++) {
        if (slides[i].dataset.id === id) {
            slides[i].scrollIntoView({behavior:'smooth'});
            return;
        }
    }
}
function initObserver(cat) {
    var st   = catState[cat];
    var feed = document.getElementById('feed-'+cat);
    if (!feed) return;
    if (st.observer) { st.observer.disconnect(); }

    // Polished IO activation (threshold 0.6)
    st.observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (!entry.isIntersecting) return;
            var target = entry.target;

            // Sentinel triggers load more
            if (target.id === 'sentinel-' + cat) {
                loadMore(cat);
                return;
            }

            var idx = parseInt(target.dataset.idx);
            if (isNaN(idx)) return;

            // Only switch when a new slide becomes dominant
            if (idx === st.currentIdx) return;

            // Crossfade old slide
            if (typeof st.currentIdx === 'number') {
                var oldSlide = feed.querySelector('.slide[data-idx="' + st.currentIdx + '"]');
                if (oldSlide) {
                    var cf = oldSlide.querySelector('.slide-crossfade');
                    if (cf) {
                        cf.style.opacity = '1';
                        setTimeout(function() { cf.style.opacity = '0'; }, 350);
                    }
                }
            }

            deactivateSlide(cat, st.currentIdx);
            st.currentIdx = idx;
            activateSlide(cat, idx);
        });
    }, { threshold: 0.6 });

    feed.querySelectorAll('.slide').forEach(function(s){ st.observer.observe(s); });
    var sentinel = document.getElementById('sentinel-' + cat);
    if (sentinel) st.observer.observe(sentinel);
}

function activateSlide(cat, idx) {
    var st    = catState[cat];
    var feed  = document.getElementById('feed-'+cat);
    if (!feed) return;
    var slide = feed.querySelector('.slide[data-idx="'+idx+'"]');
    if (!slide) return;
    slide.classList.add('active');
    startProg(cat, idx);
    // Only play video if this is the visible cat
    if (cat === currentCat) {
        var vid = slide.querySelector('video');
        if (vid) {
            vid.muted = mutedGlobal;
            // Start preloading then play
            if (vid.readyState < 2) {
                vid.preload = 'auto';
                vid.load();
            }
            vid.play().catch(function(){});
            // Hide vid badge when playing, show when paused
            vid.addEventListener('playing', function onp() {
                var badge = document.getElementById('vbadge-'+cat+'-'+idx);
                if (badge) badge.style.opacity = '0.6';
                vid.removeEventListener('playing', onp);
            });
        }
    }
    // Trigger ken-burns on active carousel image
    var activeImg = slide.querySelector('.s-carousel-img.active-img');
    if (activeImg) activeImg.style.transform = 'scale(1)';
    trackView(slide.dataset.id);
}

function deactivateSlide(cat, idx) {
    var st    = catState[cat];
    var feed  = document.getElementById('feed-'+cat);
    if (!feed) return;
    var slide = feed.querySelector('.slide[data-idx="'+idx+'"]');
    if (!slide) return;
    slide.classList.remove('active');
    stopProg(cat, idx);
    var vid = slide.querySelector('video');
    if (vid) { vid.pause(); vid.currentTime = 0; }
}

/* ════════════════════════════════════════════════════════════
   PROGRESS BAR
════════════════════════════════════════════════════════════ */
function startProg(cat, idx) {
    stopProg(cat, idx);
    var fill = document.getElementById('progf-'+cat+'-'+idx);
    if (!fill) return;
    fill.style.width = '0%';
    var start = Date.now(), dur = 7500;
    var st = catState[cat];
    st.progTimers[idx] = setInterval(function() {
        var pct = Math.min(((Date.now()-start)/dur)*100, 100);
        fill.style.width = pct + '%';
        if (pct >= 100) stopProg(cat, idx);
    }, 130);
}
function stopProg(cat, idx) {
    var st = catState[cat];
    if (st.progTimers[idx]) { clearInterval(st.progTimers[idx]); delete st.progTimers[idx]; }
}
function showPulse(el, icon) {
    if (!el) return;
    el.innerHTML = icon;
    el.classList.remove('fade'); el.classList.add('show');
    setTimeout(function(){ el.classList.remove('show'); el.classList.add('fade');
        setTimeout(function(){ el.classList.remove('fade'); }, 280);
    }, 580);
}

/* ════════════════════════════════════════════════════════════
   MUTE
════════════════════════════════════════════════════════════ */
function toggleMute() {
    mutedGlobal = !mutedGlobal;
    document.getElementById('muteBtn').innerHTML = mutedGlobal ? '&#x1F507;' : '&#x1F508;';
    CAT_ORDER.forEach(function(cat) {
        var st   = catState[cat];
        var feed = document.getElementById('feed-'+cat);
        if (!feed) return;
        var slide = feed.querySelector('.slide.active');
        if (slide) { var v=slide.querySelector('video'); if(v) v.muted=mutedGlobal; }
    });
    showToast(mutedGlobal ? '🔇 Sound off' : '🔊 Sound on');
}

/* ════════════════════════════════════════════════════════════
   JUMP TO ITEM
════════════════════════════════════════════════════════════ */
function jumpToId(cat, id) {
    var feed = document.getElementById('feed-'+cat);
    if (!feed) return;
    var slides = feed.querySelectorAll('.slide');
    for (var i=0; i<slides.length; i++) {
        if (slides[i].dataset.id === id) { slides[i].scrollIntoView({behavior:'instant'}); return; }
    }
}

/* ════════════════════════════════════════════════════════════
   SEARCH
════════════════════════════════════════════════════════════ */
function openSearch() {
    document.getElementById('srchOverlay').classList.add('open');
    renderRecent();
    setTimeout(function(){ document.getElementById('srchInput').focus(); }, 180);
}
function closeSearch() {
    document.getElementById('srchOverlay').classList.remove('open');
    clearSearch();
}
function clearSearch() {
    document.getElementById('srchInput').value = '';
    document.getElementById('srchClear').classList.remove('show');
    renderRecent();
}
function setSrchCat(cat, el) {
    srchCat = cat;
    document.querySelectorAll('.sf-tab').forEach(function(t){ t.classList.toggle('on', t===el); });
    var q = document.getElementById('srchInput').value.trim();
    if (q) doSearch(q);
}

document.addEventListener('DOMContentLoaded', function() {
    var inp = document.getElementById('srchInput');
    inp.addEventListener('input', function() {
        var q = this.value.trim();
        document.getElementById('srchClear').classList.toggle('show', q.length > 0);
        clearTimeout(srchTimer);
        if (!q) { renderRecent(); return; }
        document.getElementById('srchResults').innerHTML =
            '<div class="sr-spinner show"><div class="sr-sring"></div></div>';
        srchTimer = setTimeout(function(){ doSearch(q); }, 250);
    });
    inp.addEventListener('keydown', function(e){ if(e.key==='Escape') closeSearch(); });
});

function doSearch(q) {
    var url = API+'/search.php?q='+encodeURIComponent(q)+'&limit=40'+(srchCat?'&type='+srchCat:'');
    xhr('GET', url, null, function(d) {
        if (d && d.success) { renderSearchResults(d.data, q); }
        else { renderSearchResults(localSearch(q), q); }
    }, function() { renderSearchResults(localSearch(q), q); });
}

function localSearch(q) {
    q = q.toLowerCase();
    var pool = [];
    CAT_ORDER.forEach(function(c){ pool = pool.concat(catState[c].items); });
    if (!pool.length) pool = getFallback('mix');
    return pool.filter(function(item) {
        var t = ((item.title||'')+(item.description||'')+(item.location||'')).toLowerCase();
        return t.indexOf(q) !== -1 && (!srchCat || item.type===srchCat);
    }).slice(0,25);
}

function renderSearchResults(data, q) {
    var wrap = document.getElementById('srchResults');
    if (!data || !data.length) {
        wrap.innerHTML = '<div class="sr-empty">🔍 No results for "'+esc(q)+'"<br><br><span style="font-size:12px;color:rgba(255,255,255,.2);">Try different words</span></div>';
        return;
    }
    saveRecent(q);
    var cats = {items:[],food:[],houses:[]};
    data.forEach(function(i){ var t=i.type||'items'; if(cats[t]) cats[t].push(i); });
    var secLbl = {items:'🪑 Shop',food:'🍔 Food',houses:'🏠 Houses'};
    var html = '';
    Object.keys(cats).forEach(function(k) {
        if (!cats[k].length) return;
        html += '<div class="sr-sec">'+secLbl[k]+'</div>';
        cats[k].forEach(function(item) {
            var img = item.image || item.image_url || '';
            var hl  = hlText(item.title||'', q);
            html +=
              '<div class="sr-item" onclick="goToSearchItem(\''+esc(item.id)+'\',\''+k+'\')">' +
              (img ? '<img class="sr-img" src="'+esc(img)+'" loading="lazy" onerror="this.style.display=\'none\'">'
                   : '<div class="sr-img-ph">'+(k==='food'?'🍔':k==='houses'?'🏠':'🪑')+'</div>') +
              '<div class="sr-info">' +
                '<div class="sr-title">'+hl+'</div>' +
                '<div class="sr-meta">'+(item.location||'')+(item.location&&k?' · ':'')+secLbl[k].replace(/[^ ]+ /,'')+'</div>' +
              '</div>' +
              '<div class="sr-right"><div class="sr-price">'+esc(item.price||'')+'</div>' +
              ((item.video_url||item.has_video)?'<div class="sr-play">▶ Video</div>':'')+
              '</div></div>';
        });
    });
    wrap.innerHTML = html;
}

/* ── When user taps a search result → open it in the feed ── */
function goToSearchItem(id, type) {
    closeSearch();
    // Determine which cat pane to use
    var targetCat = type; // 'items', 'food', or 'houses'
    var targetPaneIdx = CAT_ORDER.indexOf(targetCat);
    if (targetPaneIdx === -1) targetPaneIdx = 0;

    // Switch to that tab
    if (targetPaneIdx !== catIdx) {
        switchCat(targetPaneIdx);
        // Wait for pane to animate then jump
        setTimeout(function(){ jumpToItemInCat(targetCat, id); }, 450);
    } else {
        jumpToItemInCat(targetCat, id);
    }
}

function jumpToItemInCat(cat, id) {
    var st   = catState[cat];
    var feed = document.getElementById('feed-'+cat);

    // Try to jump to existing slide
    if (feed) {
        var slides = feed.querySelectorAll('.slide');
        for (var i=0; i<slides.length; i++) {
            if (slides[i].dataset.id === id) {
                slides[i].scrollIntoView({behavior:'smooth'});
                return;
            }
        }
    }

    // Item not loaded yet — fetch it and prepend a slide
    xhr('GET', API+'/listing.php?id='+encodeURIComponent(id), null, function(d) {
        if (!d || !d.success || !d.data) return;
        var item  = d.data;
        item.type = cat;
        var slide = makeSlide(cat, item, -1); // idx -1 = preview
        slide.dataset.idx = 'preview';
        if (feed) {
            feed.insertBefore(slide, feed.firstChild);
            slide.scrollIntoView({behavior:'smooth'});
            // Track view
            activateSlide(cat, 'preview');
        }
    }, function(){});
}

function hlText(text, q) {
    if (!q) return esc(text);
    var re = new RegExp('('+q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','gi');
    return esc(text).replace(re,'<span class="hl">$1</span>');
}
function saveRecent(q) {
    recentSearches = recentSearches.filter(function(r){ return r!==q; });
    recentSearches.unshift(q);
    recentSearches = recentSearches.slice(0,8);
    try { localStorage.setItem('mh_srch', JSON.stringify(recentSearches)); } catch(e){}
}
function renderRecent() {
    var wrap    = document.getElementById('srchResults');
    var rWrap   = '<div class="srch-recent-wrap" id="recentWrap">';
    if (!recentSearches.length) {
        wrap.innerHTML = '<div class="sr-empty" style="padding-top:32px;">🔍 Search for items, food, or houses</div>';
        return;
    }
    recentSearches.forEach(function(q) {
        rWrap += '<span class="rc" onclick="quickSearch(\''+esc(q)+'\')">🕐 '+esc(q)+'</span>';
    });
    rWrap += '</div>';
    wrap.innerHTML = '<div class="sr-sec">Recent searches</div>' + rWrap;
}
function quickSearch(q) {
    document.getElementById('srchInput').value = q;
    document.getElementById('srchClear').classList.add('show');
    doSearch(q);
}

/* ════════════════════════════════════════════════════════════
   LIPA MDOGO MDOGO — PROGRESSIVE 3-STEP FORM
   Shop items only. Product delivered after FULL payment.
════════════════════════════════════════════════════════════ */
function openLipa(cat, idx) {
    var st   = catState[cat];
    currentItem = st.items[idx];
    if (!currentItem) return;

    var price = currentItem.price || '';
    var raw   = parseFloat(String(price).replace(/[^0-9.]/g,'')) || 0;
    lipaFreqOpts = calcFrequencies(raw);
    if (!lipaFreqOpts.length) { openOrderSheet(cat, idx); return; }

    // Reset state
    lipaFreq  = null;
    lipaDur   = null;
    lipaStep  = 1;

    // Product area
    var img = currentItem.image || currentItem.image_url || '';
    document.getElementById('lipaProductArea').innerHTML =
        '<div class="lipa-product">' +
        (img ? '<img class="lipa-img" src="'+esc(img)+'" onerror="this.style.display=\'none\'">' : '<div class="lipa-img-ph">📦</div>') +
        '<div><div class="lipa-pname">'+esc(currentItem.title||'')+'</div>' +
        '<div class="lipa-price-was">'+esc(price)+' full price</div>' +
        '<div class="lipa-tag">💰 Pay in flexible instalments</div>' +
        '</div></div>';

    // Build frequency options
    var freqHTML = '';
    lipaFreqOpts.forEach(function(f, i) {
        var perPay = raw * f.factor / ( f.id==='daily' ? 28 : f.id==='3week' ? 12 : f.id==='2week' ? 8 : 4 );
        freqHTML +=
          '<div class="lipa-freq" id="lf-'+f.id+'" onclick="selFreq(\''+f.id+'\','+i+')">' +
            '<div class="lf-radio"></div>' +
            '<div class="lf-info"><div class="lf-name">'+f.label+'</div><div class="lf-desc">'+f.desc+'</div></div>' +
            '<div class="lf-right"><div class="lf-amount">KSH '+Math.round(perPay).toLocaleString('en-KE')+'</div><div class="lf-period">per '+f.per+'</div></div>' +
          '</div>';
    });
    document.getElementById('lipaFreqs').innerHTML = freqHTML;

    // Show step 1, hide success
    showLipaStep(1);
    document.getElementById('lipaSuccess').style.display = 'none';
    document.getElementById('lipaSubmitBtn').disabled = false;
    document.getElementById('lipaSubmitBtn').textContent = '💰 Submit Plan Request';

    openSheet('lipaSheet');
    prefillSaved();
}

function selFreq(id, i) {
    lipaFreq = lipaFreqOpts[i];
    document.querySelectorAll('.lipa-freq').forEach(function(el){ el.classList.remove('sel'); });
    var el = document.getElementById('lf-'+id);
    if (el) el.classList.add('sel');
    // Rebuild durations based on selected freq
    var raw = parseFloat(String(currentItem.price||'').replace(/[^0-9.]/g,'')) || 0;
    lipaDurOpts = calcDurations(raw, lipaFreq);
    buildDurationOptions();
}

function buildDurationOptions() {
    var html = '';
    lipaDurOpts.forEach(function(d, i) {
        html +=
          '<div class="lipa-dur" id="ld-'+i+'" onclick="selDur('+i+')">' +
            '<div class="ld-weeks">'+d.weeks+'</div>' +
            '<div class="ld-label">weeks</div>' +
            '<div class="ld-total">Total: '+d.totalStr+'</div>' +
          '</div>';
    });
    document.getElementById('lipaDurations').innerHTML = html;
    document.getElementById('lipaSummaryBox').style.display = 'none';
    lipaDur = null;
}

function selDur(i) {
    lipaDur = lipaDurOpts[i];
    document.querySelectorAll('.lipa-dur').forEach(function(el){ el.classList.remove('sel'); });
    var el = document.getElementById('ld-'+i);
    if (el) el.classList.add('sel');
    // Show summary
    var sb  = document.getElementById('lipaSummaryBox');
    sb.style.display = 'block';
    sb.innerHTML =
        '<div class="lsb-row"><span class="lsb-lbl">Frequency</span><span class="lsb-val">'+lipaFreq.label+'</span></div>' +
        '<div class="lsb-row"><span class="lsb-lbl">Duration</span><span class="lsb-val">'+lipaDur.label+'</span></div>' +
        '<div class="lsb-row"><span class="lsb-lbl">Each payment</span><span class="lsb-val highlight">'+lipaDur.perPaymentStr+'</span></div>' +
        '<div class="lsb-row"><span class="lsb-lbl">First deposit</span><span class="lsb-val">'+lipaDur.depositStr+'</span></div>' +
        '<div class="lsb-row"><span class="lsb-lbl">Total amount</span><span class="lsb-val">'+lipaDur.totalStr+'</span></div>';
}

function lipaNext(step) {
    if (step === 1) {
        if (!lipaFreq) { showToast('Please choose a payment frequency'); return; }
        showLipaStep(2);
    } else if (step === 2) {
        if (!lipaDur) { showToast('Please choose a duration'); return; }
        showLipaStep(3);
    }
}
function lipaPrev(step) {
    if (step === 2) showLipaStep(1);
    else if (step === 3) showLipaStep(2);
}

function showLipaStep(step) {
    lipaStep = step;
    document.querySelectorAll('.lipa-panel').forEach(function(p){ p.classList.remove('active'); });
    var panel = document.getElementById('lipaStep'+step);
    if (panel) panel.classList.add('active');
    // Update step indicator
    for (var i=1; i<=3; i++) {
        var dot = document.getElementById('lsd'+i);
        var lbl = document.getElementById('lsl'+i);
        var line = document.getElementById('lsline'+i);
        if (!dot) continue;
        if (i < step) { dot.className='lstep-dot done'; dot.innerHTML='✓'; lbl.className='lstep-lbl done'; if(line) line.className='lstep-line done'; }
        else if (i === step) { dot.className='lstep-dot active'; dot.innerHTML=i; lbl.className='lstep-lbl active'; }
        else { dot.className='lstep-dot'; dot.innerHTML=i; lbl.className='lstep-lbl'; if(line) line.className='lstep-line'; }
    }
}

function selLipaPay(mode, el) {
    lipaPay = mode;
    document.getElementById('lpo_mpesa').classList.toggle('sel', mode==='mpesa');
    document.getElementById('lpo_cash').classList.toggle('sel', mode==='cash');
}

function submitLipa() {
    if (!currentItem || !lipaFreq || !lipaDur) { showToast('Please complete all steps'); return; }
    var name  = (document.getElementById('l_name').value ||'').trim();
    var phone = (document.getElementById('l_phone').value||'').trim();
    var addr  = (document.getElementById('l_addr').value ||'').trim();
    if (!name)  { showToast('Enter your full name'); return; }
    if (!phone || phone.replace(/\D/g,'').length < 9) { showToast('Enter your phone number'); return; }
    if (!addr)  { showToast('Enter your delivery address'); return; }

    var btn = document.getElementById('lipaSubmitBtn');
    btn.disabled = true; btn.textContent = 'Sending...';

    if (window.MhUser) MhUser.saveDetails({name:name,phone:phone,address:addr});

    var notes = 'LIPA MDOGO MDOGO | Freq: '+lipaFreq.label+' | Duration: '+lipaDur.label+' | Per payment: '+lipaDur.perPaymentStr+' | Deposit: '+lipaDur.depositStr+' | Total: '+lipaDur.totalStr+' | Pay: '+lipaPay+' | PRODUCT DELIVERED AFTER FULL PAYMENT ONLY';
    var itemPhone = (currentItem.contact&&currentItem.contact.phone)?currentItem.contact.phone:(currentItem.contact_phone||'');
    var waNum     = normWA(itemPhone);

    xhr('POST', API+'/order.php', {
        category:'items', listing_id:currentItem.id||'',
        listing_title:currentItem.title||'', listing_price:currentItem.price||'',
        name:name, phone:phone, address:addr,
        payment_method:lipaPay, notes:notes,
        total_amount:String(lipaDur.total||'0'),
    }, function(d) {
        var ref = (d&&d.order_ref)?d.order_ref:'';
        var waMsg = encodeURIComponent(
            'Hi! Lipa Mdogo Mdogo request:\n*'+(currentItem.title||''  )+'*\n' +
            'Frequency: '+lipaFreq.label+'\nDuration: '+lipaDur.label+'\nPer payment: '+lipaDur.perPaymentStr+'\nDeposit: '+lipaDur.depositStr+'\nTotal: '+lipaDur.totalStr+'\n' +
            'Ref: '+(ref||'—')+'\nName: '+name+'\nPhone: '+phone+'\nAddress: '+addr+'\n\n' +
            '⚠️ Product will be delivered ONLY after full payment is received.'
        );
        // Show all step panels + hide them, show success
        document.querySelectorAll('.lipa-panel').forEach(function(p){ p.classList.remove('active'); });
        document.getElementById('lipaSuccess').style.display = 'block';
        document.getElementById('lipaSucSub').textContent = 'Your '+lipaFreq.label+' plan over '+lipaDur.label+' has been received. We will contact you on WhatsApp to confirm.';
        document.getElementById('lipaSucRef').textContent = ref ? 'Ref: '+ref : '';
        document.getElementById('lipaWaBtn').onclick = function(){ window.open('https://wa.me/'+waNum+'?text='+waMsg,'_blank'); };
    }, function() {
        btn.disabled=false; btn.textContent='💰 Submit Plan Request';
        showToast('Network error. Please try again.');
    });
}

/* ════════════════════════════════════════════════════════════
   ORDER SHEET (direct order — food + shop)
════════════════════════════════════════════════════════════ */
function openOrderSheet(cat, idx) {
    var st = catState[cat];
    currentItem = st.items[idx];
    if (!currentItem) return;
    var img = currentItem.image||currentItem.image_url||'';
    document.getElementById('orderProductArea').innerHTML =
        '<div class="os-product">' +
        (img?'<img class="os-img" src="'+esc(img)+'" onerror="this.style.display=\'none\'">':'<div class="os-img-ph">📦</div>') +
        '<div><div class="os-pname">'+esc(currentItem.title||'')+'</div><div class="os-pprice">'+esc(currentItem.price||'')+'</div></div></div>';
    document.getElementById('orderBody').style.display = 'block';
    document.getElementById('orderSuccess').style.display = 'none';
    document.getElementById('orderSubmitBtn').disabled = false;
    document.getElementById('orderSubmitBtn').innerHTML = '🛒 Place Order';
    openSheet('orderSheet');
    prefillSaved();
}

function selOrderPay(mode, el) {
    orderPay = mode;
    document.getElementById('opo_cash').classList.toggle('sel', mode==='cash');
    document.getElementById('opo_mpesa').classList.toggle('sel', mode==='mpesa');
}

function submitOrder() {
    var name  = (document.getElementById('o_name').value ||'').trim();
    var phone = (document.getElementById('o_phone').value||'').trim();
    var addr  = (document.getElementById('o_addr').value ||'').trim();
    if (!name)  { showToast('Enter your full name'); return; }
    if (!phone || phone.replace(/\D/g,'').length < 9) { showToast('Enter your phone number'); return; }
    if (!addr)  { showToast('Enter your delivery address'); return; }
    var btn = document.getElementById('orderSubmitBtn');
    btn.disabled=true; btn.innerHTML='Sending...';
    if (window.MhUser) MhUser.saveDetails({name:name,phone:phone,address:addr});
    var itemPhone = (currentItem.contact&&currentItem.contact.phone)?currentItem.contact.phone:(currentItem.contact_phone||'');
    var waNum = normWA(itemPhone);
    xhr('POST', API+'/order.php', {
        category:currentItem.type||'items', listing_id:currentItem.id||'',
        listing_title:currentItem.title||'', listing_price:currentItem.price||'',
        name:name, phone:phone, address:addr,
        payment_method:orderPay, total_amount:currentItem.price||'0',
        notes:'Watch & Shop direct order',
    }, function(d) {
        var ref = (d&&d.order_ref)?d.order_ref:'';
        var waMsg = encodeURIComponent('Hi! I ordered *'+(currentItem.title||''  )+'*\nRef: '+(ref||'—')+'\nName: '+name+'\nPhone: '+phone+'\nAddress: '+addr+'\nPayment: '+orderPay);
        document.getElementById('orderBody').style.display='none';
        document.getElementById('orderSuccess').style.display='block';
        document.getElementById('ordSucRef').textContent = ref?'Ref: '+ref:'';
        document.getElementById('ordWaBtn').onclick=function(){ window.open('https://wa.me/'+waNum+'?text='+waMsg,'_blank'); };
    }, function() {
        btn.disabled=false; btn.innerHTML='🛒 Place Order';
        showToast('Network error. Try again.');
    });
}

/* ════════════════════════════════════════════════════════════
   HOUSE ENQUIRY SHEET
════════════════════════════════════════════════════════════ */
function openHouseSheet(cat, idx) {
    var st = catState[cat];
    currentItem = st.items[idx];
    if (!currentItem) return;
    var img = currentItem.image||currentItem.image_url||'';
    document.getElementById('houseProductArea').innerHTML =
        '<div class="os-product">' +
        (img?'<img class="os-img" src="'+esc(img)+'" onerror="this.style.display=\'none\'">':'<div class="os-img-ph">🏠</div>') +
        '<div><div class="os-pname">'+esc(currentItem.title||'')+'</div><div style="font-size:16px;font-weight:800;color:#86efac;">'+esc(currentItem.price||'')+'</div></div></div>';
    openSheet('houseSheet');
    prefillSaved();
}

function sendHouseEnquiry() {
    if (!currentItem) return;
    var name  = (document.getElementById('h_name').value ||'').trim();
    var phone = (document.getElementById('h_phone').value||'').trim();
    var itemPhone = (currentItem.contact&&currentItem.contact.phone)?currentItem.contact.phone:(currentItem.contact_phone||'');
    var waNum = normWA(itemPhone);
    var waMsg = encodeURIComponent(
        'Hi! I\'d like to enquire about:\n*'+(currentItem.title||''  )+'*\n' +
        (currentItem.price?'Price: '+currentItem.price+'\n':'')+
        (currentItem.location?'Location: '+currentItem.location+'\n':'')+
        (name?'\nMy name: '+name:'')+(phone?'\nPhone: '+phone:'')
    );
    window.open('https://wa.me/'+waNum+'?text='+waMsg,'_blank');
    closeSheets();
}

/* ════════════════════════════════════════════════════════════
   SHEET HELPERS
════════════════════════════════════════════════════════════ */
function openSheet(id) {
    closeSheets();
    document.getElementById('bdrop').classList.add('open');
    document.getElementById(id).classList.add('open');
}
function closeSheets() {
    document.getElementById('bdrop').classList.remove('open');
    document.querySelectorAll('.sheet').forEach(function(s){ s.classList.remove('open'); });
}

/* ════════════════════════════════════════════════════════════
   SHARE (no download — share only)
════════════════════════════════════════════════════════════ */
function shareItem(title, id, cat) {
    var url = location.origin+location.pathname+'?id='+encodeURIComponent(id)+'&cat='+encodeURIComponent(cat||'items');
    if (navigator.share) {
        navigator.share({title:title+' — Malaba Watch & Shop', url:url}).catch(function(){});
    } else if (navigator.clipboard) {
        navigator.clipboard.writeText(url).then(function(){ showToast('Link copied!'); });
    } else { showToast('Share: '+url.substring(0,36)+'...'); }
}

/* ════════════════════════════════════════════════════════════
   TRACK VIEW
════════════════════════════════════════════════════════════ */
function trackView(id) {
    if (!id) return;
    xhr('POST', API+'/track.php', {id:id, event:'view'}, function(){}, function(){});
}

/* ════════════════════════════════════════════════════════════
   PREFILL
════════════════════════════════════════════════════════════ */
function prefillSaved() {
    if (!window.MhUser) return;
    var d = MhUser.getDetails();
    if (!d) return;
    var map = {l_name:'name',l_phone:'phone',l_addr:'address',o_name:'name',o_phone:'phone',o_addr:'address',h_name:'name',h_phone:'phone'};
    Object.keys(map).forEach(function(fid){
        var el=document.getElementById(fid);
        if(el&&d[map[fid]]&&!el.value) el.value=d[map[fid]];
    });
}

/* ════════════════════════════════════════════════════════════
   FALLBACK SEED DATA
════════════════════════════════════════════════════════════ */
function getFallback(cat) {
    var seed = {
        items:[
          {id:'i1',type:'items',title:'Non-Stick Cooking Set',price:'KSH 3,500',
           images:['https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=900&q=85','https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=900&q=85','https://images.unsplash.com/photo-1590794056226-79ef3a8147e1?w=900&q=85'],
           image:'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=900&q=85',
           contact_phone:'254700000000',location:'Malaba Market',views:240,is_featured:1,video_url:''},
          {id:'i2',type:'items',title:'Wall Art Canvas Set',price:'KSH 2,800',
           images:['https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=900&q=85','https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=900&q=85'],
           image:'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=900&q=85',
           contact_phone:'254700000000',location:'Malaba CBD',views:181,video_url:''},
          {id:'i3',type:'items',title:'Electric Kettle 1.8L',price:'KSH 1,200',
           image:'https://images.unsplash.com/photo-1563297007-0686b7003af7?w=900&q=85',
           contact_phone:'254700000000',location:'Malaba CBD',views:310,video_url:''},
          {id:'i4',type:'items',title:'Bedroom Wardrobe 4-Door',price:'KSH 18,500',
           images:['https://images.unsplash.com/photo-1558997519-83ea9252efc8?w=900&q=85','https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=900&q=85','https://images.unsplash.com/photo-1556020685-ae41abfc9365?w=900&q=85'],
           image:'https://images.unsplash.com/photo-1558997519-83ea9252efc8?w=900&q=85',
           contact_phone:'254700000000',location:'Malaba Town',views:195,is_featured:1,video_url:''},
          {id:'i5',type:'items',title:'Sofa Set 5-Seater',price:'KSH 32,000',
           images:['https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=900&q=85','https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?w=900&q=85'],
           image:'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=900&q=85',
           contact_phone:'254700000000',location:'Malaba Market',views:420,is_featured:1,video_url:''},
        ],
        food:[
          {id:'f1',type:'food',title:'Chicken Burger Combo',price:'KSH 450',
           images:['https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=900&q=85','https://images.unsplash.com/photo-1543340904-0d1f1b1f4c1e?w=900&q=85'],
           image:'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=900&q=85',
           contact_phone:'254700000000',location:'Malaba CBD',views:313,is_featured:1,video_url:''},
          {id:'f2',type:'food',title:'Nyama Choma Platter',price:'KSH 800',
           image:'https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=900&q=85',
           contact_phone:'254700000000',location:'Malaba Town',views:422,video_url:''},
          {id:'f3',type:'food',title:'Pilau & Kachumbari',price:'KSH 320',
           images:['https://images.unsplash.com/photo-1631292784640-2b24be784d5d?w=900&q=85','https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=900&q=85'],
           image:'https://images.unsplash.com/photo-1631292784640-2b24be784d5d?w=900&q=85',
           contact_phone:'254700000000',location:'Malaba Market',views:280,video_url:''},
          {id:'f4',type:'food',title:'Tilapia Fish & Ugali',price:'KSH 550',
           image:'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=900&q=85',
           contact_phone:'254700000000',location:'Malaba River Side',views:390,video_url:''},
        ],
        houses:[
          {id:'h1',type:'houses',title:'2 Bedroom Apartment',price:'KSH 15,000/month',
           images:['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=900&q=85','https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900&q=85','https://images.unsplash.com/photo-1484154218962-a197022b5858?w=900&q=85'],
           image:'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=900&q=85',
           contact_phone:'254700000000',location:'Malaba Downtown',views:232,video_url:''},
          {id:'h2',type:'houses',title:'Studio Apartment',price:'KSH 8,000/month',
           images:['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=900&q=85','https://images.unsplash.com/photo-1554995207-c18c203602cb?w=900&q=85'],
           image:'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=900&q=85',
           contact_phone:'254700000000',location:'Malaba Westlands',views:185,video_url:''},
          {id:'h3',type:'houses',title:'3 Bedroom Bungalow',price:'KSH 25,000/month',
           images:['https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=900&q=85','https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=900&q=85','https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=900&q=85'],
           image:'https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=900&q=85',
           contact_phone:'254700000000',location:'Malaba Outskirts',views:310,is_featured:1,video_url:''},
        ],
    };
    if (cat==='mix') return seed.items.concat(seed.houses);
    return seed[cat] || seed.items;
}

/* ════════════════════════════════════════════════════════════
   XHR HELPER
════════════════════════════════════════════════════════════ */
function xhr(method, url, data, onOk, onErr) {
    var r = new XMLHttpRequest();
    r.open(method, url, true);
    r.setRequestHeader('X-Requested-With','XMLHttpRequest');
    if (method==='POST') r.setRequestHeader('Content-Type','application/json');
    r.timeout = 10000;
    r.onload = function() {
        try { var d=JSON.parse(r.responseText); if(typeof onOk==='function') onOk(d); }
        catch(e){ if(typeof onOk==='function') onOk({}); } 
    };
    r.onerror = r.ontimeout = function(){ if(typeof onErr==='function') onErr(); };
    r.send(data ? JSON.stringify(data) : null);
}

/* ════════════════════════════════════════════════════════════
   UTILITIES
════════════════════════════════════════════════════════════ */
function normWA(p) {
    var d=(p||'').replace(/\D/g,'');
    if(d.length===9) return '254'+d;
    if(d.length===10&&d[0]==='0') return '254'+d.substring(1);
    if(d.length===12&&d.substring(0,3)==='254') return d;
    return d||'254700000000';
}
function esc(s) {
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function showToast(msg) {
    var t=document.getElementById('toast');
    t.innerHTML=msg; t.classList.add('show');
    setTimeout(function(){ t.classList.remove('show'); }, 2400);
}

</script>
</body>
</html>